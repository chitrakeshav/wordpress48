<?php
/*
Plugin Name: iFlair Cruise Property Management
Plugin URI: http://www.iflair.com/
Description: This Plugin will show cruie property assigned to you.
Author: Arvind Pal
Version: 1.0
Author URI: http://www.iflair.com/
*/
global $wpdb;
define( 'DETAIL_PAGE',esc_url(home_url('/'))."cruise-detail");
define( 'OPTION_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

wp_register_style( 'myPluginStylesheet', plugins_url('css/plugin_style.css', __FILE__) );
wp_enqueue_style( 'myPluginStylesheet' );

wp_enqueue_style('thickbox');
wp_enqueue_script('thickbox');
add_action('wp_ajax_shipenquirydetail', 'shipenquirydetail'); // Logged-in users
add_action('wp_ajax_nopriv_shipenquirydetail', 'shipenquirydetail'); // Guest users

add_action('wp_ajax_ship_img_fun', 'ship_img_fun'); // Logged-in users
add_action('wp_ajax_nopriv_ship_img_fun', 'ship_img_fun'); // Guest users

//ob_start();
//echo get_permalink(6);
add_action( 'admin_menu', 'iflair_agent_manage_property_listing' );

function iflair_agent_manage_property_listing(){
  global $wpdb;
  add_menu_page('iFlair Cruise Ship Mangement', 'iFlair Ship Mangement', 'manage_options', 'iflair-cruise-ships' , 'iflair_manage_agent_cruise_lisitng');
add_submenu_page( 'iflair-cruise-ships', 'Enquiry Management', 'Enquiry Management', 'manage_options', 'iflair_enquirymanagement' , 'iflair_enquirymanagement');

}
function iflair_enquirymanagement(){
  include 'manage_enquiry_agent.php';
}
function iflair_manage_agent_cruise_lisitng(){
  global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
  $mainsiteprefix='cm_';
  $agentsiteurl=get_option('siteurl');
  $agentsitedetail=iflair_get_subsite_id($agentsiteurl);
  $agentsiteid=$agentsitedetail->id;
  $agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
  //$select_ship = $mydb->get_results("SELECT * FROM cruise_cruise");
  
?>
<div class="wrap">
<h1>Manage Cruise </h1>
<!-- MK Start -->
<?php

global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
$mainsiteprefix='cm_';
$agentsiteurl=get_option('siteurl');
$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
$agentsiteid=$agentsitedetail->id;
$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
  //$getdetails_email=$wpdb->get_results("SELECT * FROM ship_enquiry_data"."");
  if ( empty( $per_page ) || $per_page < 1 )
    $per_page = 20;
  //-------------------------------Code For Paging
  
  $pagenum = 1;
  // if $_GET['page'] defined, use it as page number
  if(isset($_GET['pagenum'])){
    $pagenum = abs( (int) $_GET['pagenum'] );
  }
  // counting the offset
  $get_cruise_pag="SELECT cc.* FROM cruise_cruise AS cc INNER JOIN cruise_operators as co ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id IN($agent_assign_operator)";

  if($_POST['iflair_filter_operator']!="" || $_GET['operator']!=""){
      $operator = $_POST['iflair_filter_operator'];
      //$get_cruise_pag .=" AND site_id = '$agentsiteid'"; 
      $get_cruise_pag .=" AND cruise_operator_name = '$operator'";
    }
  else {
      //$get_cruise_pag .=" AND site_id = '$agentsiteid'";
  }
  $offset = ($pagenum - 1) * $per_page;
  //echo $get_cruise_pag;
  $res_total = $mydb->get_results($get_cruise_pag);
    
  $num_rows=count($res_total);
  //echo $get_cruise_pag;
  $get_cruise_pag .=" LIMIT ".$offset.", ".$per_page;
  //echo $get_cruise_pag;
  $getdetails_email=$mydb->get_results($get_cruise_pag);
  //echo count($getdetails_email)."<- count is ";
  ?>

<?php

$agent_assign_operator_cruise = $mydb->get_results($get_cruise_pag);
//print_r($agent_assign_operator_cruise);
//echo "SELECT cc.* FROM cruise_operators AS co INNER JOIN  cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id IN (".$agent_assign_operator.") GROUP BY cc.cruise_id ORDER BY cc.cruise_operator_name";
?>
<div class="wrap">
<div class="operator_filter">

<form action="./admin.php?page=iflair-cruise-ships" method="post" >
  <div class="alignleft actions" style="display: inline-flex;">

  <?php
  $cruise_ship_style ="SELECT cc.cruise_operator_name FROM cruise_cruise AS cc INNER JOIN cruise_operators as co ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id IN($agent_assign_operator) GROUP BY cc.cruise_operator_name ORDER BY cc.cruise_operator_name"; 
  $select_cruise_ship_style = $mydb->get_results($cruise_ship_style);
  echo "<select name='iflair_filter_operator' id='iflair_filter_operator'>";
  echo "<option value=''>Select Tour Operator</option>";
  for($i=0;$i<count($select_cruise_ship_style);$i++)
      {
        ?><option <?php if( $operator == $select_cruise_ship_style[$i]->cruise_operator_name ){ echo "selected"; } ?> value="<?php echo $select_cruise_ship_style[$i]->cruise_operator_name; ?>" ><?php echo $select_cruise_ship_style[$i]->cruise_operator_name; ?></option>
        <?php
      }
  echo "</select>";
  ?>
    <input type="submit" value="Filter" class="button" id="iflair_filter_apply" name="iflair_filter_apply">
  </div>
</form>
</div>

<?php 

  if(trim($erromsg)!=""){
    echo '<div style="color:#000;padding:20px;font-weight:bold;">';
    echo $erromsg;
    $erromsg='';
    echo '</div>';
  }

    if ( empty($pagenum) )
    {
      $pagenum = 1;
    }
    $iflair_operator = $_POST['iflair_filter_operator'];
    $iflair_site = $_POST['iflair_site_select'];
    $num_pages = ceil($num_rows / $per_page);
    if(isset($iflair_operator) && $iflair_operator!=""){
      $page_links = paginate_links( array(
        'base' => add_query_arg( array('pagenum' => '%#%', 'operator' => str_replace(' ','+',$operator), 'site_id' => $iflair_site ) ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => $num_pages,
        'current' => $pagenum
      ));
    }
    else{
      $page_links = paginate_links( array(
        'base' => add_query_arg( 'pagenum', '%#%' ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => $num_pages,
        'current' => $pagenum
      ));
    }
    echo '<div class="paginate">';
    echo  $page_links;
    echo '</div>';
?>
</div>
<table class="wp-list-table widefat fixed striped posts">
  <thead>
  <tr>
    <th>Tour Operator Name</th>
    <th>Cruise Title</th>
    <th>Cruise Image</th>
    
  </tr>
  </thead>
  <tbody id="the-list">
    <?php for($c=0;$c<count($agent_assign_operator_cruise);$c++){ ?>
    <tr>
      <td><?php echo $agent_assign_operator_cruise[$c]->cruise_operator_name; ?></td>
      <td><?php echo $agent_assign_operator_cruise[$c]->cruise_title; ?></td>
      <td><a class="thickbox ship_img_<?php echo $c; ?>">View Image</a></td>

      <?php
        $link = $agent_assign_operator_cruise[$c]->cruise_cover_image_href;
        $ajax_url = add_query_arg( 
        array( 
          'action' => 'ship_img_fun',
          'img_url'=> $link
        ), 
          admin_url( 'admin-ajax.php' ) 
        );
      ?>
      <script type="text/javascript">
        jQuery(document).ready(function() {
          jQuery(".ship_img_<?php echo $c; ?>").click(function() {
            tb_show('Ship Image', '<?php echo $ajax_url; ?>?width=1000' );
            var title=jQuery('#hidden_title_<?php echo $i; ?>').html();
            //var title=jQuery('#TB_ajaxWindowTitle').html();
            //alert(title);
            jQuery('#TB_ajaxWindowTitle').html(title);
          });

        });
      </script>
       
    </tr>
    <?php } ?>
  </tbody>
</table>
</div>
  <?php 
}
function ship_img_fun(){
  /*echo "<pre>";
  print_r($_GET);
  echo "</pre>";*/
  ?>
  <img style="width:100%;" src="<?php echo $_GET['img_url']; ?>" >
  <?php
  exit();
}


add_shortcode('shipenquiryform', 'shipenquiry_form_front');
function shipenquiry_form_front( $atts ){
global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
$mainsiteprefix='cm_';
$agentsiteurl=get_option('siteurl');
$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
$agentsiteid=$agentsitedetail->id;
//echo "SELECT * FROM cruise_ship_cruise WHERE cruise_id = '$_GET[cruise_id]' LIMIT 1";
if($_GET[cruise_id] != ""){
  $site_detail_result = $mydb->get_results("SELECT * FROM cruise_ship_cruise WHERE cruise_id = '$_GET[cruise_id]' LIMIT 1");
}
else{
 $site_detail_result = $mydb->get_results("SELECT * FROM cruise_ship_cruise WHERE cruise_id = '$_GET[cruise_id]' LIMIT 1"); 
}
//echo $_GET['ship_id'];
?>
<?php
$store_plugin_path=plugins_url().'/iflair_cruise-property-management';
?>
<script src="<?php echo $store_plugin_path; ?>/jquery.validate.js"></script>
<script src='https://www.google.com/recaptcha/api.js'></script>
<script type="text/javascript">

  jQuery(document).ready(function() {
    
    jQuery("#shipenquiry").validate({
      submitHandler: function(form) {
            jQuery('.loader1').css('display','block');
            //alert("112233");
            var params = jQuery(form).serialize();
            jQuery.ajax({
                type: "POST",
                url: ('<?php echo admin_url( 'admin-ajax.php' ); ?>'),
                data: params + "&action=shipenquirysendmail",
                success: function (response) {
                    jQuery('.loader1').css('display','none');
                    //alert(response);
                    jQuery('#the-list').html(response);
                }
            });
          }
    });
  });

</script>

<form class="shipenquiry" id="shipenquiry" method="post" action="" name="shipenquiry">
  <div class="popup_title" >Your Details</div>
  <?php
    $details = shortcode_atts( array(
        'ship_name' => 'ship_name',
        'cruise_name' => 'cruise_name',
        'date' => 'date',
        'cruise_id' => 'cruise_id',
        'ship_operator' => 'ship_operator'
    ), $atts );
    //echo $atts["ship_name"];
    /*echo "<pre>";
    print_r($atts);
    echo "</pre>";*/
    if(!empty($site_detail_result[0]->ship_operator)){
      $ship_operator = $site_detail_result[0]->ship_operator;
    }
    else{
      $ship_operator = $atts['ship_operator'];
    }

    if(!empty($site_detail_result[0]->cruise_id)){
      $cruise_id = $site_detail_result[0]->cruise_id;
    }
    else{
      $cruise_id = $atts["cruise_id"];
    }

  ?>
  <input type="hidden" name="iflair_site_id" value="<? echo $agentsiteid; ?>" >
  <input type="hidden" name="iflair_enquiry_cruise_operator_name" value="<?php echo $ship_operator; ?>" >
  <input type="hidden" name="iflair_enquiry_cruise_title" value="<?php echo $atts['cruise_name']; ?>" >
  <input type="hidden" name="iflair_enquiry_ship_title" value="<?php echo $atts['ship_name']; ?>" >
  <input type="hidden" name="iflair_enquiry_cruise_date" value="<?php echo $atts['date']; ?>" >
  <?php $detail_page_id = get_site_option( 'iflair_cruise_theme_ship_detail_page' );?>
  <input type="hidden" name="iflair_enquiry_page_url" value="<? echo get_page_link($detail_page_id)."?cruise_id=".$cruise_id; ?>" >
  <div class="">
  <input type="text" readonly name="iflair_enquiry_cruise_id" id="iflair_enquiry_cruise_id" value="<? echo $cruise_id; ?>" >
  </div>
  <div class="">
    <input type="text" name="iflair_enquiry_name" placeholder="Name" id="iflair_enquiry_name" required />
  </div>
  <div>
    <input type="email" name="iflair_enquiry_email" placeholder="Email" id="iflair_enquiry_email" required />
  </div>
  <div>
    <input type="number" name="iflair_enquiry_people" placeholder="How many people ?" id="iflair_enquiry_people" required min="0" />
  </div>
  <div>
    <input type="text" name="iflair_enquiry_phone" placeholder="Phone No." id="iflair_enquiry_phone" required />
  </div>
  <!-- <div>
    <input type="text" name="iflair_enquiry_postcode" placeholder="Postcode" id="iflair_enquiry_postcode" required />
  </div> -->
  <div>
    <select name="iflair_enquiry_call_me" id="iflair_enquiry_call_me" required >
      <option value="" >Select Call Time</option>
      <option value="No Preference" >No Preference</option>
      <option value="ASAP" >ASAP</option>
      <option value="Morning" >Morning</option>
      <option value="Afternoon" >Afternoon</option>
      <option value="Evening" >Evening</option>
    </select>
  </div>
  <div class="popup_title" >Your Cruise Preferences</div>
  <div>
    <select name="iflair_enquiry_cabin_type" id="iflair_enquiry_cabin_type" required >
      <option value="" >Select Cabin Type</option>
      <option value="No Preference" >No Preference</option>
      <option value="Inside" >Inside</option>
      <option value="Outside" >Outside</option>
      <option value="Balcony" >Balcony</option>
      <option value="Suite" >Suite</option>
      <option value="Single" >Single</option>
      <option value="Family of 4" >Family of 4</option>
    </select>
  </div>
  <div>
    <textarea name="iflair_enquiry_for" id="iflair_enquiry_for" placeholder="Message" rows="2" required></textarea>
  </div>
  <div class="reg-full">
    <div class="reg-full">
      <?php
      $captcha_enable = get_site_option( 'iflair_cruise_theme_captcha_enable' );
      if($captcha_enable=="on"){
      ?>
      <div class="g-recaptcha" data-sitekey="<?php echo get_site_option( 'iflair_cruise_theme_site_key' ); ?>"></div>
      <input type="hidden" class="hiddenRecaptcha required" name="hiddenRecaptcha" required id="hiddenRecaptcha">
      <?php
      }
      ?>
      <input type="submit" id="shipenquirysubmit" class="enquirysubmit" value="Make Enquiry" <?php if($captcha_enable=="on"){ ?>style="margin-top: -45px;" <?php } ?> >
      <label class="error error1" for="hiddenRecaptcha" generated="true"></label>
    </div>
  </div>

  <div class="loader1" style="display:none;">
    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader.gif" style="width: 50px;">
  </div>
</form>
<div id="the-list"></div>


<?php
}
add_action('wp_ajax_shipenquirysendmail', 'shipenquirysendmail');
add_action('wp_ajax_nopriv_shipenquirysendmail', 'shipenquirysendmail');
function shipenquirysendmail() {
global $wpdb;

$captcha_enable = "off";
$captcha_enable = get_site_option( 'iflair_cruise_theme_captcha_enable' );
if($captcha_enable=="on"){
  //echo "enable";
}
if(isset($_POST['g-recaptcha-response']) || $captcha_enable!="on")
{
    //var_dump($_POST);

  if($captcha_enable=="on"){
    $secret = get_site_option( 'iflair_cruise_theme_secret_key' );
    //echo $secret."<- secret key";
    $ip= $_SERVER['REMOTE_ADDR'];
    $captcha=$_POST['g-recaptcha-response'];
    $response=file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$secret."&response=".$captcha."&remoteip=".$_SERVER['REMOTE_ADDR']);

    $arr = json_decode($response,TRUE);
  }

  if($arr['success'] || $captcha_enable!="on")
  {
      
    ob_start();

    $site_id=($_POST['iflair_site_id']);
    $cruise_id=($_POST['iflair_enquiry_cruise_id']);
    $cruise_operator_name=($_POST['iflair_enquiry_cruise_operator_name']);
    $cruise_title=($_POST['iflair_enquiry_cruise_title']);
    $ship_title=($_POST['iflair_enquiry_ship_title']);
    $date=($_POST['iflair_enquiry_cruise_date']);
    $page_url=($_POST['iflair_enquiry_page_url']);
    $name=($_POST['iflair_enquiry_name']);
    $email=($_POST['iflair_enquiry_email']);
    $people=($_POST['iflair_enquiry_people']);
    $phone=($_POST['iflair_enquiry_phone']);
    /*$postcode=($_POST['iflair_enquiry_postcode']);*/
    $enquiry_for=($_POST['iflair_enquiry_for']);
    $call_me=($_POST['iflair_enquiry_call_me']);
    $cabin_type=($_POST['iflair_enquiry_cabin_type']);
    
    add_filter('wp_mail_content_type',create_function('', 'return "text/html"; '));
    $bodyemail = "";
    $bodyemail.="Hello Admin ,<br><br>";
    $bodyemail.="Ship Name :- <a href=".DETAIL_PAGE."/?cruise_id=$cruise_id>$cruise_title - $ship_title</a>";
    $bodyemail.="<br>Departure Date :- $date";
    $bodyemail.="<br>Name :- $name";
    $bodyemail.="<br>Email :- $email";
    $bodyemail.="<br>How many people :- $people";
    $bodyemail.="<br>Phone :- $phone";
    $bodyemail.="<br>postcode :- $postcode";
    $bodyemail.="<br>call me at :- $call_me";
    $bodyemail.="<br>cabin type :- $cabin_type";
    $bodyemail.="<br>Message :- $enquiry_for";


    $bodyemail1 = "";
    $bodyemail1.="Hello $name ,<br><br>";
    $bodyemail1.="Thank you for your for the <a href=".DETAIL_PAGE."/?cruise_id=$cruise_id>$cruise_title - $ship_title</a> on Departure Date $date .";
    $bodyemail1.="<br>Submitted details are mentioned below .<br>";
    $bodyemail1.="<br>Name :- $name";
    $bodyemail1.="<br>Email :- $email";
    $bodyemail1.="<br>How many people :- $people";
    $bodyemail1.="<br>Phone :- $phone";
    $bodyemail1.="<br>postcode :- $postcode";
    $bodyemail1.="<br>call me at :- $call_me";
    $bodyemail1.="<br>cabin type :- $cabin_type";
    $bodyemail1.="<br>Message :- $enquiry_for";
    
    $to = get_site_option('iflair_cruise_theme_email_address');
    $to1 = $email;
    /*$to = array(
        get_site_option('iflair_cruise_theme_email_address'),
        $email
    );*/

    $subject = 'New Enquiry for '."$cruise_title - $ship_title";
    
    $admin_email = get_option('mail_from');
    //$bcc = "maulik.panchal@iflair.com";
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type:text/html; charset=utf-8\n";
    $headers .= "From: ".get_option('mail_from_name')."  <".$admin_email.">\n";
    //$headers .= "Bcc: ".$bcc."\n";
    $headers .= "X-Priority: 3\n";
    $headers .= "X-MSMail-Priority: Normal\n";
    $headers .= "Importance: 3\n";
    /*echo "<pre>";
    print_r($bodyemail);
    exit;
    *///wp_mail( $to, $subject, $body, $headers );
    
    //print_r($to);
    $to_loop = array();
    $to_loop = explode(';', $to);
    if(count($to_loop)>1){
      //print_r($to_loop);
      for ($mail_to_array=0; $mail_to_array < count($to_loop) ; $mail_to_array++) { 
        //echo $to_loop[$mail_to_array]."<br> num";
        if(wp_mail( $to_loop[$mail_to_array], $subject, $bodyemail, $headers )){}
        else {}
      }
    }
    else{
      //echo $to."its one .<br>";
      if(wp_mail( $to, $subject, $bodyemail, $headers )){}
      else {}
    }

    /*if(wp_mail( $to1, $subject, $bodyemail1, $headers )){}
    else {}*/

    ob_clean();
    global $wpdb,$mydb;
    $today = date("j/n/Y");
    $table_name = "ship_enquiry_data";

      $mydb->insert($table_name, array(
        'site_id'=>$site_id,
        'cruise_id'=>$cruise_id,
        'cruise_operator_name'=>$cruise_operator_name,
        'cruise_title'=>$cruise_title,
        'ship_title'=>$ship_title,
        'departure_date'=>$date,
        'page_url'=>$page_url,
        'name'=>$name,
        'email'=>$email,
        'people'=>$people,
        'phone'=>$phone,
        'postcode'=>$postcode,
        'call_me'=>$call_me,
        'cabin_type'=>$cabin_type,
        'enquiry_for'=>$enquiry_for,
        'enquiry_date'=> $today
      ),
    array(
      '%s',
      '%s',
      '%s',
      '%s',
      '%s',
      '%s',
      '%s',
      '%s',
      '%s',
      '%s',
      '%s',
      '%s',
      '%s',
      '%s',
      '%s'   
      )
    );
      echo '<div class="ajax_success">';
      echo 'Thank you for your enquiry. We will contact you shortly.';
      echo '</div>';
      ?>
      <script type="text/javascript">
      jQuery('#iflair_enquiry_name').val('');
      jQuery('#iflair_enquiry_email').val('');
      jQuery('#iflair_enquiry_people').val('');
      jQuery('#iflair_enquiry_phone').val('');
      /*jQuery('#iflair_enquiry_postcode').val('');*/
      jQuery('#iflair_enquiry_call_me').val('');
      jQuery('#iflair_enquiry_cabin_type').val('');
      jQuery('#iflair_enquiry_for').val('');
      //jQuery('.reg-full').hide();
      //grecaptcha.reset();
      jQuery('.loader1').css('display','none');

      jQuery(function() {
        // setTimeout() function will be fired after page is loaded
        // it will wait for 5 sec. and then will fire
        // $("#successMessage").hide() function
        setTimeout(function() {
            jQuery(".ajax_success").hide('blind', {}, 500);
            //alert("hnf");
            jQuery('.modal').modal('toggle');
            callback();
        }, 5000);
      });

      </script>
      <?php 
    
      die();

  }
  else
  {
      echo '<div class="ajax_error" >';
      echo 'Your Captcha is not valid Or empty.';
      echo '</div>';
      ?>
      <script type="text/javascript">
      jQuery('.reg-full').show();
      jQuery('.loader1').css('display','none');
      </script>
      <?php
      die();
  }
}
  else
  {
      echo '<div class="ajax_error" >';
      echo 'Your Captcha is not valid Or empty.';
      echo '</div>';
      ?>
      <script type="text/javascript">
      jQuery('.reg-full').show();
      jQuery('.loader1').css('display','none');
      </script>
      <?php
      die();
  }

  
}
?>
<?php 

  if(trim($erromsg)!=""){
    echo '<div style="color:#000;padding:20px;font-weight:bold;">';
    echo $erromsg;
    $erromsg='';
    echo '</div>';
  }

function shipenquirydetail(){
  global $wpdb, $mydb;
  $get_enquery = $mydb->get_row("SELECT * FROM ship_enquiry_data WHERE enquiry_id = ".$_GET['enquiry_id']." ");
  //print_r($get_enquery);
  ?>
  <table>
    <tr>
      <th width="150">Operator Name</th><td><?php echo $get_enquery->cruise_operator_name; ?></td>
    </tr>
    <tr>
      <th>Page URL</th><td><a href="<?php echo $get_enquery->page_url; ?>" target="__blank"><?php echo $get_enquery->page_url; ?></a></td>  
    </tr>
    <tr>
      <th>Departure Date</th><td><?php echo $get_enquery->departure_date; ?></td>  
    </tr>
    <tr>
      <th>Name</th><td><?php echo $get_enquery->name; ?></td>  
    </tr>
    <tr>
      <th>Email ID</th><td><?php echo $get_enquery->email; ?></td>  
    </tr>
    <tr>
      <th>Call Me At</th><td><?php if(!$get_enquery->call_me){ echo "-"; } else{ echo $get_enquery->call_me; } ?></td>  
    </tr>
    <tr>
      <th>Cabin Type</th><td><?php if(!$get_enquery->cabin_type){ echo "-"; } else{ echo $get_enquery->cabin_type; } ?></td>  
    </tr>
    <tr>
      <th>How Many People ?</th><td><?php echo $get_enquery->people; ?></td>  
    </tr>
    <tr>
      <th>Phone</th><td><?php echo $get_enquery->phone; ?></td>  
    </tr>
    <tr>
      <th>Postcode</th><td><?php echo $get_enquery->postcode; ?></td>  
    </tr>
    <tr>
      <th>Enquiery For</th><td><?php echo $get_enquery->enquiry_for; ?></td>  
    </tr>
  </table>
  <?php
  die();
}


?>