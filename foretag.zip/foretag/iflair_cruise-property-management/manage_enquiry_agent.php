<?php
$table_name = "ship_enquiry_data";
function iflair_manage_ship_enquiry(){
  add_menu_page('Ship Enquiry', 'Ship Enquiry', 8, 'manage_ship_enquiry', 'iflair_manage_ship_enquiry_list');
   global $wpdb,$mydb;
}
?>
<?php

global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
$mainsiteprefix='cm_';
  $agentsiteurl=get_option('siteurl');
  $agentsitedetail=iflair_get_subsite_id($agentsiteurl);
  $agentsiteid=$agentsitedetail->id;
  $agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
  //$getdetails_email=$mydb->get_results("SELECT * FROM ship_enquiry_data"."");

  if ( empty( $per_page ) || $per_page < 1 )
    $per_page = 15;
  //-------------------------------Code For Paging
  
  $pagenum = 1;
  // if $_GET['page'] defined, use it as page number
  if(isset($_GET['pagenum'])){
    $pagenum = abs( (int) $_GET['pagenum'] );
  }
  // counting the offset
  $getdetails_email_pag="SELECT * FROM ship_enquiry_data";

  if($_POST['iflair_filter_operator']!="" || $_GET['operator']!=""){
      $operator = $_POST['iflair_filter_operator'];
      $getdetails_email_pag .=" WHERE site_id = '$agentsiteid'"; 
      $getdetails_email_pag .=" AND cruise_operator_name = '$operator'";
    }
  else {
      $getdetails_email_pag .=" WHERE site_id = '$agentsiteid'";
  }
  //echo $getdetails_email_pag;
  $offset = ($pagenum - 1) * $per_page;
  //echo $getdetails_email_pag;
  $res_total = $mydb->get_results($getdetails_email_pag);
    
  $num_rows=count($res_total);
  //echo $getdetails_email_pag;
  $getdetails_email_pag .=" ORDER BY enquiry_id DESC LIMIT ".$offset.", ".$per_page."";

  $getdetails_email=$mydb->get_results($getdetails_email_pag);
  //echo $getdetails_email_pag;
  ?>
  <div class="wrap">
<h2>Manage Enquiry</h2><br>

<div class="operator_filter">

<form action="./admin.php?page=iflair_enquirymanagement" method="post" >
  <div class="alignleft actions" style="display: inline-flex;">

  <?php
  $cruise_ship_style =" SELECT cc.cruise_operator_name,co.operator_app_id FROM cruise_cruise AS cc INNER JOIN cruise_operators as co ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id IN($agent_assign_operator) GROUP BY cc.cruise_operator_name ORDER BY cc.cruise_operator_name"; 
  $select_cruise_ship_style = $mydb->get_results($cruise_ship_style);
  echo "<select name='iflair_filter_operator' id='iflair_filter_operator'>";
  echo "<option value=''>Select Tour Operator</option>";
  for($i=0;$i<count($select_cruise_ship_style);$i++)
      {
        ?><option <?php if( $operator == $select_cruise_ship_style[$i]->operator_app_id ){ echo "selected"; } ?> value="<?php echo $select_cruise_ship_style[$i]->operator_app_id; ?>" ><?php echo $select_cruise_ship_style[$i]->cruise_operator_name; ?></option><?php
      }
  echo "</select>";
  ?>
    <input type="submit" value="Filter" class="button" id="iflair_filter_apply" name="iflair_filter_apply">
  </div>
</form>
</div>

<?php 

  if(trim($erromsg)!=""){
    echo '<div style="color:#000;padding:20px;font-weight:bold;">';
    echo $erromsg;
    $erromsg='';
    echo '</div>';
  }
?>
<?php 
if ( empty($pagenum) )
    $pagenum = 1;
    $iflair_operator = $_POST['iflair_filter_operator'];
    $num_pages = ceil($num_rows / $per_page);
    if(isset($iflair_operator) && $iflair_operator!=""){
      $page_links = paginate_links( array(
        'base' => add_query_arg( array('pagenum' => '%#%', 'operator' => str_replace(' ','+',$operator) ) ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => $num_pages,
        'current' => $pagenum
      ));
    }
    else{
      $page_links = paginate_links( array(
        'base' => add_query_arg( 'pagenum', '%#%' ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => $num_pages,
        'current' => $pagenum
      ));
    }
    echo '<div class="paginate">';
    echo  $page_links;
    echo '</div>';
?>
</div>

<table class="widefat fixed" cellspacing="0" style="text-align: left; width: 98%;">
<thead>
<tr class="thead"><th><b>Operator-Ship Name</b></th>
<th><b>Name</b></th>
<th><b>Email Address</b></th>
<th><b>Phone No.</b></th>
<th><b>Call Me At</b></th>
<th><b>Enquiry Date</b></th>
<th width="40"></th>
</tr>
</thead>
<?php 
//echo count($getdetails_email)."count";
//print_r($getdetails_email);

  if(count($getdetails_email)=="" || count($getdetails_email)== "0"){
    echo '<tr>';
    echo '<td colspan="5">No result Found ...</td>';
    echo '</tr>';
  }
  else{
    for($i=0; $i<count($getdetails_email);$i++){
      echo '<tr>';
      echo '<span id="hidden_title_'.$i.'" style="display:none;">'.$getdetails_email[$i]->ship_title.' on board The '.$getdetails_email[$i]->cruise_title.'</span>';
      echo '<td><a href="'.$getdetails_email[$i]->page_url.'">'.$getdetails_email[$i]->cruise_operator_name.' - '.$getdetails_email[$i]->cruise_title.'</a></td>';
      echo '<td>'.$getdetails_email[$i]->name.'</td>';
      echo '<td><a href="mailto:'.$getdetails_email[$i]->email.'">'.$getdetails_email[$i]->email.'</a></td>';
      echo '<td>'.$getdetails_email[$i]->phone.'</td>';
      if(!$getdetails_email[$i]->call_me){
        echo '<td> - </td>';
      }else{
        echo '<td>'.$getdetails_email[$i]->call_me.'</td>';
      }
      echo '<td>'.$getdetails_email[$i]->enquiry_date.'</td>';
      echo '<td><a title="Popup Title" class="thickbox player_name'.$i.'">View</a></td>';
      echo '</tr>';
        $ajax_url = add_query_arg( 
        array( 
            'action' => 'shipenquirydetail',
            'enquiry_id'=> $getdetails_email[$i]->enquiry_id
        ), 
          admin_url( 'admin-ajax.php' ) 
        );
        ?>
        <script type="text/javascript">
          jQuery(document).ready(function() {
            jQuery(".player_name<?php echo $i; ?>").click(function() {
              tb_show('<?php echo $getdetails_email[$i]->cruise_title - $getdetails_email[$i]->ship_title; ?>', '<?php echo $ajax_url; ?>' );
              var title=jQuery('#hidden_title_<?php echo $i; ?>').html();
              //var title=jQuery('#TB_ajaxWindowTitle').html();
              //alert(title);
              jQuery('#TB_ajaxWindowTitle').html(title);
            });

          });
        </script>
      <?php
    }
  }
?>
</table>
<?php 
?>