<?php
/**
*Plugin Name: iFlair Multiple Port Management
*Plugin URI: http://www.iflair.com/
*Description: This Plugin is used to manage Cruise
*Author: Keshav Kansara
*Version: 1.0
*Author URI: http://www.iflair.com/
*/
global $wpdb,$mydb;
add_action('admin_menu', 'iflair_miltplecruise_management_infinitycruises' );
add_action('wp_ajax_iflair_cruisejourney_get_cruise', 'iflair_cruisejourney_get_cruise');
add_action('wp_ajax_iflair_shipjourney_get_ship', 'iflair_shipjourney_get_ship');
add_action('wp_ajax_iflair_shipjourney_get_ship_edit', 'iflair_shipjourney_get_ship_edit');
add_action('wp_ajax_iflair_cruisejourney_get_cruise_edit', 'iflair_cruisejourney_get_cruise_edit');
add_action('wp_ajax_iflair_delete_removed_entry', 'iflair_delete_removed_entry');

wp_enqueue_script('jquery-ui-datepicker');
wp_enqueue_style('jquery-ui-css', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.2/themes/smoothness/jquery-ui.css');



// Add menu to admin panel
function iflair_miltplecruise_management_infinitycruises()
{
    global $wpdb;
    
    add_menu_page('All Port', 'Port', 'manage_options', 'iflair-list-port' , 'iflair_list_port');
    add_submenu_page( 'iflair-list-port', 'Add New', 'Add New', 'manage_options', 'iflair-manage-port', 'iflair_manage_port');
    add_submenu_page( '', 'Add New', 'Add New', 'manage_options', 'iflair-edit-port', 'iflair_manage_port_edit');
}

// Add port
function iflair_manage_port()
{
    global $mydb,$wpdb,$agentsiteid,$mainsiteprefix,$agent_assign_operator; 
    $plugins_url = plugin_dir_url( __FILE__ );
    ?>

    <link rel="stylesheet" type="text/css" href="<?php echo $plugins_url; ?>/css/styles.css" />

    <?php
    if($_POST['submit_port'])
    {
        $count = count($_POST['p_port_name']);

        $wpdb->insert($wpdb->prefix.'port_management', array( 
            'operator_id' => $_POST['cruise_tour_operator'], 
            'cruise_response_id' => $_POST['cruise_tour_cruise'],
            'cruise_id' => $_POST['cruise_tour_ship']
        ));
        
        $lastid = $wpdb->insert_id;
        $wpdb->last_query;

        for ($i=0; $i <$count; $i++) 
        {
            $port_code = strtoupper(substr(str_replace(" ", "",$_POST['p_port_name'][$i]), 0, 3));
            $wpdb->insert($wpdb->prefix.'port_list', array( 
            'port_id' => $lastid,
            'port_name' => $_POST['p_port_name'][$i],
            'port_code' => $port_code,
            'arrives_on' => $_POST['p_arrives_on'][$i],
            'location' => $_POST['p_location'][$i],
            'description' => stripslashes($_POST['cruise_description'][$i]),
            'display_location' => $_POST['display_location'][$i],
            ));
        }
        
        $success_msg = "Port has been inserted successfully.";
    }

    $results_get_cruise_operator = $wpdb->get_row( 'SELECT * FROM '.$wpdb->prefix.'port_management WHERE p_id = "'.$_GET['p_id'].'" ', OBJECT );

    $cruise_detail = $mydb->get_results( 'SELECT * FROM cruise_cruise WHERE cruise_response_id = "'.$results_get_cruise_operator->cruise_response_id.'" ', OBJECT );
    
    $cruise_detail_for_ship = $mydb->get_results( 'SELECT * FROM cruise_cruise WHERE cruise_id = "'.$results_get_cruise[0]->cruise_cruise.'" ', OBJECT );
    
    $plugins_url = plugin_dir_url( __FILE__ );
    ?>

    <script type="text/javascript">
        jQuery(document).on('click', '.addnew', function(){
            var num     = jQuery('.newadd').length;
            var newNum  = new Number(num + 1);
            var controldiv = jQuery('.controls'),
            currentEntry = jQuery(this).parents('.newadd:first'),
            newEntry = jQuery(currentEntry.clone()).appendTo(controldiv);
            var temp = jQuery('.hidden_date').val();
            var newNum  = parseInt(temp) + 1;
            jQuery('.hidden_date').val(newNum);

            newEntry.find('input[type=text]').val('');
            newEntry.find('.custom_date').removeClass('hasDatepicker');
            newEntry.find('.custom_date').attr('id', 'custom_date_' + newNum);
            newEntry.find('.p_port_name').attr('id', 'p_port_name' + newNum);
            controldiv.find('.newadd:not(:first) .addnew')
                .removeClass('addnew').addClass('removenew')
                .val('remove');
            }).on('click', '.removenew', function(e)
            {
                jQuery(this).parents('.newadd:first').remove();

                var newNum     = jQuery('.newadd').length;
                
                e.preventDefault();
                return false;
            });
    </script>

    <div class="wrap">
    <h1>Manage Multiple Port</h1>
    <?php if($success_msg != ''){ ?>
    <div class='updated below-h2' id='message'><p><?php echo $success_msg; ?></p></div>
    <?php } ?>
    <form method="post" name="add_cruise" id="add_cruise">
        <input type="hidden" name="hidden_date" value="1" class="hidden_date">
        <div class="form-group">
            <label for="name">Operator:</label>
            <?php 
                $results = $mydb->get_results( 'SELECT * FROM cruise_operators ', OBJECT );
                echo $results_get_cruise_operator->operator_title;
            ?>
             <select name="cruise_tour_operator" id="cruise_tour_operator" required="" onchange="return iflair_select_touroperator(this.value);">
                <option value="">Select Operator</option>
                <?php foreach($results as $key => $value){ ?>
                    <option <?php if($results_get_cruise_operator->operator_id == $results[$key]->operator_id){ echo "selected"; } ?> value="<?php echo $results[$key]->operator_id; ?>"><?php echo $results[$key]->operator_title; ?></option>
                <?php } ?>
             </select>
        </div>
        <div class="form-group">
            <label for="name">Ship:</label>
            <select name="cruise_tour_cruise" id="cruise_tour_cruise" required="" onchange="return iflair_select_tourcruise(this.value);">
                <option value="">Select Ship</option>
            </select>
        </div>
            
        <div id="allships" class="form-group"></div>
        <div class="controls">
            <div class="newadd" id="1">
                <div class="form-group">
                    <div><input type="button" name="addnew" class="addnew" value="Add New"></div> 
                </div>
                
                <div class="form-group">
                    <label for="name">Port Name</label>
                    <input type="text" name="p_port_name[]" class="p_port_name" id="p_port_name" value="<?php if($_GET['p_id']){ echo $results_get_cruise_operator->port_name; } ?>">
                </div>

                <div class="form-group adddata">
                    <label for="name">Arrives On</label>
                    <input type="text" name="p_arrives_on[]" readonly="" id="custom_date_1" class="custom_date" value="<?php if($_GET['p_id']){ echo $results_get_cruise_operator->arrives_on; } ?>">
                    
                </div>

                <div class="form-group">
                    <label for="name">Location</label>
                    <input type="text" name="p_location[]" value="<?php if($_GET['p_id']){ echo $results_get_cruise_operator->location; } ?>">
                </div>
                
                <div class="form-group">
                    <label for="name">Description</label>
                        <textarea name="cruise_description[]"><?php if($_GET['p_id']){ echo $results_get_cruise_operator->description; } ?></textarea>
                </div>
                    
                <div class="form-group">
                    <label for="">Display Location</label>
                    <select name="display_location[]" >
                        <option selected value="0"> -- Select Display Location -- </option>
                        <option value="1"> Pre Port </option>
                        <option value="2"> Post Port </option>
                    </select>
                </div>
            </div>
        </div>
        <div class="form-group">
            <input type="submit" name="submit_port" id="submit_port" value="Submit" onclick="return onsubmitClick();" class="button button-primary button-large">
        </div>
    </form>

    </div>

    <script type="text/javascript">
        
        jQuery(document).on('focus', '.custom_date', function () {
            jQuery(this).datepicker({
                dateFormat : 'dd-mm-yy'
            });
        });

        jQuery(document).ready(function() {

            iflair_select_touroperator_edit();
            iflair_select_tourcruise_edit();
        });

        // Check for error message on form submit
        function onsubmitClick()
        {
            var msg = document.getElementById("errormessage").value;
            if(msg != '')
            {
                return false;
            }
        }

        // Tour operator ajax call
        function iflair_select_touroperator(id){
            jQuery.ajax({
                type: "POST",
                url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
                data: ({
                    action: 'iflair_cruisejourney_get_cruise',
                    id: id
                }),
                success: function (response) {
                    jQuery('#cruise_tour_cruise').html(response);
                }
            });
        }

        // Tour operator data edit ajax call
        function iflair_select_touroperator_edit(){
            id = "<?php echo $results_get_cruise_operator->operator_id ?>";
            cruiseid = "<?php echo $results_get_cruise_operator->cruise_response_id; ?>";
            if(id != '')
            {
                jQuery.ajax({
                    type: "POST",
                    url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
                    data: ({
                        action: 'iflair_cruisejourney_get_cruise_edit',
                        id: id,
                        cruiseid: cruiseid
                    }),
                    success: function (response) {
                        //console.log(response);
                        jQuery('#cruise_tour_cruise').html(response);
                    }
                });
            }
        }

        // Cruise data ajax call
        function iflair_select_tourcruise(id,operatorname){
            jQuery.ajax({
                type: "POST",
                url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
                data: ({
                    action: 'iflair_shipjourney_get_ship',
                    id: id,
                    operatorname: operatorname
                }),
                success: function (response) {
                    //console.log(response);
                    jQuery('#allships').html(response);
                }
            });
        }

        // Cruise data edit ajax call
        function iflair_select_tourcruise_edit(){
            id = "<?php echo $results_get_cruise_operator->operator_id ?>";
            cruise_id = "<?php echo $results_get_cruise_operator->cruise_id ?>";
            
            if(cruise_id != '')
            {
                jQuery.ajax({
                    type: "POST",
                    url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
                    data: ({
                        action: 'iflair_shipjourney_get_ship_edit',
                        id: id,
                        cruise_id: cruise_id
                    }),
                    success: function (response) {
                        //console.log(response);
                        jQuery('#allships').html(response);
                    }
                });
            }
        }

    </script>
    <?php
}

//Edit port
function iflair_manage_port_edit()
{
    global $mydb,$wpdb,$agentsiteid,$mainsiteprefix,$agent_assign_operator; 
    $plugins_url = plugin_dir_url( __FILE__ );
    ?>

    <link rel="stylesheet" type="text/css" href="<?php echo $plugins_url; ?>/css/styles.css" />
    <?php
    if($_GET['p_id'])
    {
        if($_POST['submit_port'])
        {

            /*echo "<pre>";
            print_r($_POST);
            echo "</pre>";*/
            $count = count($_POST['p_port_name']);
                
                $wpdb->update( 
                    $wpdb->prefix.'port_management', array(
                        'operator_id' => $_POST['cruise_tour_operator'], 
                        'cruise_response_id' => $_POST['cruise_tour_cruise'],
                        'cruise_id' => $_POST['cruise_tour_ship']
                        ),
                        array( 'p_id' => $_GET['p_id'])
                );
                //echo $wpdb->last_query;

            $wpdb->delete( $wpdb->prefix.'port_list', array( 'port_id' => $_GET['p_id'] ) );    
            
            for ($i=0; $i <$count; $i++)
            { 
                $port_code = strtoupper(substr(str_replace(" ", "",$_POST['p_port_name'][$i]), 0, 3));
            
                $wpdb->insert($wpdb->prefix.'port_list', array( 
                    'port_id' => $_GET['p_id'],
                    'port_name' => $_POST['p_port_name'][$i],
                    'port_code' => $port_code,
                    'arrives_on' => $_POST['p_arrives_on'][$i],
                    'location' => $_POST['p_location'][$i],
                    'description' => stripslashes($_POST['cruise_description'][$i]),
                    'display_location' => $_POST['display_location'][$i],
                ));
            }

            $success_msg = "Port has been updated successfully.";
        }
    }

    $results_get_cruise_operator = $wpdb->get_row( 'SELECT * FROM '.$wpdb->prefix.'port_management WHERE p_id = "'.$_GET['p_id'].'" ', OBJECT );

    $p_id_rec = $wpdb->get_results( 'SELECT * FROM '.$wpdb->prefix.'port_management WHERE p_id = "'.$results_get_cruise_operator->p_id.'"', OBJECT );
    $p_id_rec_all = $wpdb->get_results( 'SELECT * FROM '.$wpdb->prefix.'port_list WHERE port_id = "'.$results_get_cruise_operator->p_id.'"', OBJECT );
    
    $rs_count = count($p_id_rec_all);

    $cruise_detail = $mydb->get_results( 'SELECT * FROM cruise_cruise WHERE cruise_response_id = "'.$results_get_cruise_operator->cruise_response_id.'" ', OBJECT );
    
    $plugins_url = plugin_dir_url( __FILE__ );
    ?>

    <script type="text/javascript">
        
        jQuery(document).on('click', '.addnew', function(){
            var num     = jQuery('.newadd').length;
            var newNum  = new Number(num + 1);
            var controldiv = jQuery('.controls'),
            currentEntry = jQuery(this).parents('.newadd:first'),
            newEntry = jQuery(currentEntry.clone()).appendTo(controldiv);
            var temp = jQuery('.hidden_date').val();
            var newNum  = parseInt(temp) + 1;
            jQuery('.hidden_date').val(newNum);

            newEntry.find('input[type=text]').val('');
            newEntry.find('.custom_date').removeClass('hasDatepicker');
            newEntry.find('.custom_date').attr('id', 'custom_date_' + newNum);

            
            newEntry.find('textarea').val('');
            newEntry.find('.hiddneid').val('');
            newEntry.find('.addnew').removeClass('con_delete');
            newEntry.find('.p_port_name').attr('id', 'p_port_name' + newNum);
            controldiv.find('.newadd:not(:first) .addnew')
                .removeClass('addnew').addClass('removenew')
                .val('remove');
            }).on('click', '.removenew', function(e)
            {
                if(jQuery(this).hasClass('con_delete')){
                    var hidid = jQuery(this).parent().find('.hiddneid').val();
                    
                    if(confirm('Are you sure you want to remove?'))
                    {
                        iflair_delete_removed_data(hidid)
                        jQuery(this).parents('.newadd:first').remove();
                        var newNum = jQuery('.newadd').length;
                        e.preventDefault();
                        return false;
                    }
                }
                else{
                    jQuery(this).parents('.newadd:first').remove();
                    var newNum = jQuery('.newadd').length;
                    e.preventDefault();
                    return false;
                }
            });

        </script>

    <div class="wrap">
    <h1>Manage Multiple Port</h1>
    <?php if($success_msg != ''){ ?>
    <div class='updated below-h2' id='message'><p><?php echo $success_msg; ?></p></div>
    <?php } ?>
    <form method="post" name="add_cruise" id="add_cruise">
        <input type="hidden" name="hidden_date" value="<?php echo $rs_count; ?>" class="hidden_date">
        <input type="hidden" name="port_id" value="<?php echo $_GET['p_id']; ?>" class="">
        <div class="form-group">
            <label for="name">Operator:</label>
            <?php $results = $mydb->get_results( 'SELECT * FROM cruise_operators ', OBJECT );

            echo $results_get_cruise_operator->operator_title;

             ?>
             <select name="cruise_tour_operator" id="cruise_tour_operator" required="" onchange="return iflair_select_touroperator(this.value);">
                <option value="">Select Operator</option>
                <?php foreach($results as $key => $value){ ?>
                    <option <?php if($results_get_cruise_operator->operator_id == $results[$key]->operator_id){ echo "selected"; } ?> value="<?php echo $results[$key]->operator_id; ?>"><?php echo $results[$key]->operator_title; ?></option>
                <?php } ?>
             </select>
        </div>
        <div class="form-group">
            <label for="name">Ship:</label>
            <select name="cruise_tour_cruise" id="cruise_tour_cruise" required="" onchange="return iflair_select_tourcruise(this.value);">
                <option value="">Select Ship</option>
            </select>
        </div>
            
        <div id="allships" class="form-group"></div>
        
        <div class="controls">
            <?php
            //echo $rs_count;
             for ($i=0; $i < $rs_count ; $i++) { ?>
                
                <div class="newadd" id="newadd_1">
                    <div class="form-group">
                        <div class="del-parent">
                            <?php if($i == 0 ){ ?>
                                <input type="button" name="addnew" class="addnew con_delete" value="Add New">
                            <?php } else{ ?>
                                <input type="button" name="addnew" class="removenew con_delete" value="Remove">
                            <?php } ?>
                            <input type="hidden" name="hiddneid[]" class="hiddneid" value="<?php echo $p_id_rec_all[$i]->id; ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="name">Port Name</label>
                        <input type="text" name="p_port_name[]" class="p_port_name" id="p_port_name" value="<?php if($_GET['p_id']){ echo $p_id_rec_all[$i]->port_name; } ?>">
                    </div>

                    <div class="form-group">
                        <label for="name">Arrives On</label>
                        <input type="text" readonly="" name="p_arrives_on[]" id="custom_date_<?php echo $i; ?>" class="custom_date" value="<?php if($_GET['p_id']){ echo $p_id_rec_all[$i]->arrives_on; } ?>">
                    </div>

                    <div class="form-group">
                        <label for="name">Location</label>
                        <input type="text" name="p_location[]" value="<?php if($_GET['p_id']){ echo $p_id_rec_all[$i]->location; } ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="name">Description</label>
                        <textarea name="cruise_description[]"><?php if($_GET['p_id']){ echo $p_id_rec_all[$i]->description; } ?></textarea>
                            
                    </div>
                    
                    <div class="form-group">
                    <label for="">Display Location</label>
                    <select name="display_location[]" >
                        <option <?php if($p_id_rec_all[$i]->display_location==0){ echo " selected"; } ?> value="0"> -- Select Display Location -- </option>
                        <option  <?php if($p_id_rec_all[$i]->display_location==1){ echo " selected"; } ?> value="1"> Pre Port </option>
                        <option  <?php if($p_id_rec_all[$i]->display_location==2){ echo " selected"; } ?> value="2"> Post Port </option>
                    </select>
                    </div>
                </div>
            <?php } ?>
        </div>
        <div class="form-group">
            <input type="submit" name="submit_port" id="submit_port" value="Submit" onclick="return onsubmitClick();" class="button button-primary button-large">
        </div>
    </form>

    </div>

    <script type="text/javascript">
        jQuery(document).on('focus', '.custom_date', function () {
            jQuery(this).datepicker({
                dateFormat : 'dd-mm-yy'
            });
        });
        jQuery(document).ready(function() {
            
            iflair_select_touroperator_edit();
            iflair_select_tourcruise_edit();
        });

        // Check for error message on form submit
        function onsubmitClick()
        {
            var msg = document.getElementById("errormessage").value;
            if(msg != '')
            {
                return false;
            }
        }

        // Tour operator ajax call
        function iflair_select_touroperator(id){
            jQuery.ajax({
                type: "POST",
                url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
                data: ({
                    action: 'iflair_cruisejourney_get_cruise',
                    id: id
                }),
                success: function (response) {
                    jQuery('#cruise_tour_cruise').html(response);
                }
            });
        }

        // Tour operator data edit ajax call
        function iflair_select_touroperator_edit(){
            id = "<?php echo $results_get_cruise_operator->operator_id ?>";
            cruiseid = "<?php echo $results_get_cruise_operator->cruise_response_id; ?>";
            if(id != '')
            {
                jQuery.ajax({
                    type: "POST",
                    url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
                    data: ({
                        action: 'iflair_cruisejourney_get_cruise_edit',
                        id: id,
                        cruiseid: cruiseid
                    }),
                    success: function (response) {
                        //console.log(response);
                        jQuery('#cruise_tour_cruise').html(response);
                    }
                });
            }
        }

        // Cruise data ajax call
        function iflair_select_tourcruise(id,operatorname){
            jQuery.ajax({
                type: "POST",
                url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
                data: ({
                    action: 'iflair_shipjourney_get_ship',
                    id: id,
                    operatorname: operatorname
                }),
                success: function (response) {
                    //console.log(response);
                    jQuery('#allships').html(response);
                }
            });
        }

        // Cruise data edit ajax call
        function iflair_select_tourcruise_edit(){
            id = "<?php echo $results_get_cruise_operator->operator_id ?>";
            cruise_id = "<?php echo $results_get_cruise_operator->cruise_id ?>";
            
            if(cruise_id != '')
            {
                jQuery.ajax({
                    type: "POST",
                    url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
                    data: ({
                        action: 'iflair_shipjourney_get_ship_edit',
                        id: id,
                        cruise_id: cruise_id
                    }),
                    success: function (response) {
                        jQuery('#allships').html(response);
                    }
                });
            }
        }

        // Tour operator data edit ajax call
        function iflair_delete_removed_data(id){
            if(id != '')
            {
                jQuery.ajax({
                    type: "POST",
                    url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
                    data: ({
                        action: 'iflair_delete_removed_entry',
                        id: id,
                    }),
                    success: function (response) {
                    }
                });
            }
        }

    </script>
    <?php
}

// Get Cruise data
function iflair_cruisejourney_get_cruise()
{
    
    global $mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;

    $results_operator = $mydb->get_row( 'SELECT * FROM cruise_operators WHERE operator_id = "'.$_POST['id'].'" ', OBJECT );

    $results = $mydb->get_results( 'SELECT * FROM cruise_cruise WHERE cruise_operator_name = "'.$results_operator->operator_title.'" ', OBJECT );

    echo $mydb->last_query;
    ?>

    <select name="cruise_tour_cruise" id="cruise_tour_cruise" onchange="return iflair_select_tourcruise(this.value,'<?php echo $_POST['id']; ?>');">
        <option value="">Select Ship</option>
        <?php foreach($results as $key => $value){ ?>
            <option value="<?php echo $results[$key]->cruise_response_id; ?>"><?php echo $results[$key]->cruise_title; ?></option>
        <?php } ?>
    </select>

    <?php
}

// Get Cruise edit
function iflair_cruisejourney_get_cruise_edit()
{

    if($_POST['cruiseid'])
    {
        global $mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
        $results = $mydb->get_row( 'SELECT * FROM cruise_cruise WHERE cruise_response_id = "'.$_POST['cruiseid'].'" ', OBJECT );

    ?>
        
                <select name="cruise_tour_cruise" id="cruise_tour_cruise" onchange="return iflair_select_tourcruise(this.value);">
                    <option value="">Select Ship</option>
                    <?php /*foreach($results as $key => $value){*/ ?>
                        <option <?php if($_POST['cruiseid'] == $results->cruise_response_id) { echo "selected"; } ?> value="<?php echo $results->cruise_response_id; ?>"><?php echo $results->cruise_title; ?></option>
                    <?php /*}*/ ?>
                </select>
        
    <?php 
    }
    die();
}

// Get ship data
function iflair_shipjourney_get_ship()
{
    global $mydb,$wpdb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
    
    $get_existing_cruise = $mydb->get_results('SELECT * FROM cruise_ship_cruise where ship_id = "'.$_POST['id'].'" AND ship_starts_on BETWEEN NOW() AND DATE_ADD( NOW() , INTERVAL +12 MONTH) ');
    
    if($get_existing_cruise != "")
    {
    ?>
        <label for="name">Cruise:</label>
            <select name="cruise_tour_ship" id="cruise_tour_ship" required="">
                <option value="">Select Cruise</option>
                <?php foreach($get_existing_cruise as $key => $value){ ?>
                    <option value="<?php echo $get_existing_cruise[$key]->cruise_id; ?>"><?php echo $get_existing_cruise[$key]->ship_name." ( ".date('d M Y',strtotime($get_existing_cruise[$key]->ship_starts_on))." - ".$get_existing_cruise[$key]->cruise_id." )"; ?></option>
                <?php } ?>
            </select>
    <?php
    }
    die();
}

// Get ship data edit
function iflair_shipjourney_get_ship_edit()
{
    global $mydb,$wpdb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;

    if($_POST['cruise_id']){

        $get_cruise_id = $mydb->get_row('SELECT * FROM cruise_ship_cruise where cruise_id = "'.$_POST['cruise_id'].'" AND ship_starts_on BETWEEN NOW() AND DATE_ADD( NOW() , INTERVAL +12 MONTH) ');
        
        if($get_cruise_id != "")
        {
        ?>
            <label>Cruise:</label>
            <select name="cruise_tour_ship" id="cruise_tour_ship" required="">
                    <option value="">Select Cruise</option>
                    <option <?php if($_POST['cruise_id'] == $get_cruise_id->cruise_id) { echo "selected"; } ?> value="<?php echo $get_cruise_id->cruise_id; ?>"><?php echo $get_cruise_id->ship_name; ?></option>
            </select>
        <?php
        }
    }
    die();
}

// List Port
function iflair_list_port()
{
    global $mydb,$wpdb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
    if($_GET['delete'])
    {
        //$wpdb->delete( $wpdb->prefix.'port_management', array( 'p_id' => $_GET['delete'] ) );
        $pid = $_GET['delete'];
        $wpdb->query('DELETE FROM '.$wpdb->prefix.'port_management WHERE p_id = "'.$pid.'"');
        $wpdb->query('DELETE FROM '.$wpdb->prefix.'port_list WHERE port_id = "'.$pid.'"');

        /*echo $wpdb->last_query;*/

        $delete_msg = "Port has been deleted successfully";
    }
    $plugins_url = plugin_dir_url( __FILE__ );
    $edit_icon = $plugins_url.'/icon/edit-validated-icon.png';
    $delete_icon = $plugins_url.'/icon/delete-icon.png';
    
    ?>

    <script src="<?php echo $plugins_url; ?>/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo $plugins_url; ?>/js/dataTables.bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo $plugins_url; ?>/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $plugins_url; ?>/css/dataTables.bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $plugins_url; ?>/css/styles.css" />

    <script type="text/javascript">
        jQuery(document).ready(function() {
            jQuery('#continent').DataTable( {
                "aoColumnDefs": [
                    { 'bSortable': false, 'aTargets': [ 1 ,2] }
                ]
            });
        } );
    </script>

    <div class="wrap">
        <h1>List Multiple Cruise</h1>
        <?php if($delete_msg != ''){ ?>
        <div class='updated below-h2' id='message'><p><?php echo $delete_msg; ?></p></div>
        <?php } ?>
        <table id="continent" class="table table-striped table-bordered" cellspacing="0" style="width: 100%;">
            <thead>
                <tr>             
                    <th>Operator</th>               
                    <th>Cruise</th>
                    <th>Ship</th>
                    <!-- <th>Port Name</th>
                    <th>Arrives On</th>
                    <th>Location</th> -->
                    <th>Action</th>
                </tr>
            </thead>       
            <tbody>
            <?php 
                $results_port = $wpdb->get_results( 'SELECT * FROM '.$wpdb->prefix.'port_management', OBJECT );
                /*echo $wpdb->last_query;*/
                foreach($results_port as $ke => $val){
                
                $operator_name = $mydb->get_row( 'SELECT * FROM cruise_operators WHERE operator_id = "'.$val->operator_id.'" ', OBJECT );
                $cruise_name = $mydb->get_row( 'SELECT * FROM cruise_cruise WHERE cruise_response_id = "'.$val->cruise_response_id.'" ', OBJECT );
                $ship_name = $mydb->get_row( 'SELECT * FROM cruise_ship_cruise WHERE cruise_id = "'.$val->cruise_id.'" AND ship_starts_on BETWEEN NOW() AND DATE_ADD( NOW() , INTERVAL +12 MONTH)  ', OBJECT );
                    
                ?>
                    <tr>
                        <td><?php echo $operator_name->operator_title; ?></td>
                        <td><?php echo $cruise_name->cruise_title; ?></td>
                        <td><?php echo $ship_name->ship_name; ?></td>
                        <?php /*<td><?php echo $val->port_name; ?></td>
                        <td><?php echo $val->arrives_on; ?></td>
                        <td><?php echo $val->location; ?></td>
                        */?>
                        <td><a href= "admin.php?page=iflair-edit-port&p_id=<?php echo $val->p_id; ?>" name="Edit" id="p_id"><img src="<?php echo $edit_icon;?>"></a>
                        <a href= "admin.php?page=iflair-list-port&delete=<?php echo $val->p_id; ?>" name="Delete" id="p_id" onclick="return confirm('Are you sure you want to delete?')"><img src="<?php echo $delete_icon;?>"></a></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>


    </div>
    
    <?php 
}

function iflair_delete_removed_entry()
{
    global $mydb,$wpdb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
    if($_POST['id'] != "")
    {
        $wpdb->delete( $wpdb->prefix.'port_list', array( 'id' => $_POST['id'] ) );    
    }
}

?>