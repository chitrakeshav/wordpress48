<?php
/**
 * Twenty Thirteen functions and definitions
 *
 * Sets up the theme and provides some helper functions, which are used in the
 * theme as custom template tags. Others are attached to action and filter
 * hooks in WordPress to change core functionality.
 *
 * When using a child theme (see https://codex.wordpress.org/Theme_Development
 * and https://codex.wordpress.org/Child_Themes), you can override certain
 * functions (those wrapped in a function_exists() call) by defining them first
 * in your child theme's functions.php file. The child theme's functions.php
 * file is included before the parent theme's file, so the child theme
 * functions would be used.
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are
 * instead attached to a filter or action hook.
 *
 * For more information on hooks, actions, and filters, @link https://codex.wordpress.org/Plugin_API
 *
 * @package WordPress
 * @subpackage Twenty_Thirteen
 * @since Twenty Thirteen 1.0
 */

/*
 * Set up the content width value based on the theme's design.
 *
 * @see twentythirteen_content_width() for template-specific adjustments.
 */
if ( ! isset( $content_width ) )
	$content_width = 604;

/**
 * Add support for a custom header image.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Twenty Thirteen only works in WordPress 3.6 or later.
 */
if ( version_compare( $GLOBALS['wp_version'], '3.6-alpha', '<' ) )
	require get_template_directory() . '/inc/back-compat.php';

/**
 * Twenty Thirteen setup.
 *
 * Sets up theme defaults and registers the various WordPress features that
 * Twenty Thirteen supports.
 *
 * @uses load_theme_textdomain() For translation/localization support.
 * @uses add_editor_style() To add Visual Editor stylesheets.
 * @uses add_theme_support() To add support for automatic feed links, post
 * formats, and post thumbnails.
 * @uses register_nav_menu() To add support for a navigation menu.
 * @uses set_post_thumbnail_size() To set a custom post thumbnail size.
 *
 * @since Twenty Thirteen 1.0
 */
function twentythirteen_setup() {
	/*
	 * Makes Twenty Thirteen available for translation.
	 *
	 * Translations can be added to the /languages/ directory.
	 * If you're building a theme based on Twenty Thirteen, use a find and
	 * replace to change 'twentythirteen' to the name of your theme in all
	 * template files.
	 */
	load_theme_textdomain( 'twentythirteen', get_template_directory() . '/languages' );

	/*
	 * This theme styles the visual editor to resemble the theme style,
	 * specifically font, colors, icons, and column width.
	 */
	add_editor_style( array( 'css/editor-style.css', 'genericons/genericons.css', twentythirteen_fonts_url() ) );

	// Adds RSS feed links to <head> for posts and comments.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Switches default core markup for search form, comment form,
	 * and comments to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
	) );

	/*
	 * This theme supports all available post formats by default.
	 * See https://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'aside', 'audio', 'chat', 'gallery', 'image', 'link', 'quote', 'status', 'video'
	) );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menu( 'primary', __( 'Navigation Menu', 'twentythirteen' ) );

	/*
	 * This theme uses a custom image size for featured images, displayed on
	 * "standard" posts and pages.
	 */
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 604, 270, true );

	// This theme uses its own gallery styles.
	add_filter( 'use_default_gallery_style', '__return_false' );
}
add_action( 'after_setup_theme', 'twentythirteen_setup' );

/**
 * Return the Google font stylesheet URL, if available.
 *
 * The use of Source Sans Pro and Bitter by default is localized. For languages
 * that use characters not supported by the font, the font can be disabled.
 *
 * @since Twenty Thirteen 1.0
 *
 * @return string Font stylesheet or empty string if disabled.
 */
add_filter('show_admin_bar', '__return_false');
function twentythirteen_fonts_url() {
	$fonts_url = '';

	/* Translators: If there are characters in your language that are not
	 * supported by Source Sans Pro, translate this to 'off'. Do not translate
	 * into your own language.
	 */
	$source_sans_pro = _x( 'on', 'Source Sans Pro font: on or off', 'twentythirteen' );

	/* Translators: If there are characters in your language that are not
	 * supported by Bitter, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$bitter = _x( 'on', 'Bitter font: on or off', 'twentythirteen' );

	if ( 'off' !== $source_sans_pro || 'off' !== $bitter ) {
		$font_families = array();

		if ( 'off' !== $source_sans_pro )
			$font_families[] = 'Source Sans Pro:300,400,700,300italic,400italic,700italic';

		if ( 'off' !== $bitter )
			$font_families[] = 'Bitter:400,700';

		$query_args = array(
			'family' => urlencode( implode( '|', $font_families ) ),
			'subset' => urlencode( 'latin,latin-ext' ),
		);
		$fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
	}

	return $fonts_url;
}

/**
 * Enqueue scripts and styles for the front end.
 *
 * @since Twenty Thirteen 1.0
 */
function twentythirteen_scripts_styles() {
	/*
	 * Adds JavaScript to pages with the comment form to support
	 * sites with threaded comments (when in use).
	 */
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );

	// Adds Masonry to handle vertical alignment of footer widgets.
	if ( is_active_sidebar( 'sidebar-1' ) )
		wp_enqueue_script( 'jquery-masonry' );

	// Loads JavaScript file with functionality specific to Twenty Thirteen.
	wp_enqueue_script( 'twentythirteen-script', get_template_directory_uri() . '/js/functions.js', array( 'jquery' ), '20150330', true );

	// Add Source Sans Pro and Bitter fonts, used in the main stylesheet.
	wp_enqueue_style( 'twentythirteen-fonts', twentythirteen_fonts_url(), array(), null );

	// Add Genericons font, used in the main stylesheet.
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/genericons/genericons.css', array(), '3.03' );

	// Loads our main stylesheet.
	wp_enqueue_style( 'twentythirteen-style', get_stylesheet_uri(), array(), '2013-07-18' );

	// Loads the Internet Explorer specific stylesheet.
	wp_enqueue_style( 'twentythirteen-ie', get_template_directory_uri() . '/css/ie.css', array( 'twentythirteen-style' ), '2013-07-18' );
	wp_style_add_data( 'twentythirteen-ie', 'conditional', 'lt IE 9' );
}
add_action( 'wp_enqueue_scripts', 'twentythirteen_scripts_styles' );

/**
 * Filter the page title.
 *
 * Creates a nicely formatted and more specific title element text for output
 * in head of document, based on current view.
 *
 * @since Twenty Thirteen 1.0
 *
 * @param string $title Default title text for current view.
 * @param string $sep   Optional separator.
 * @return string The filtered title.
 */
function twentythirteen_wp_title( $title, $sep ) {
	global $paged, $page;

	if ( is_feed() )
		return $title;

	// Add the site name.
	$title .= get_bloginfo( 'name', 'display' );

	// Add the site description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		$title = "$title $sep $site_description";

	// Add a page number if necessary.
	if ( ( $paged >= 2 || $page >= 2 ) && ! is_404() )
		$title = "$title $sep " . sprintf( __( 'Page %s', 'twentythirteen' ), max( $paged, $page ) );

	return $title;
}
add_filter( 'wp_title', 'twentythirteen_wp_title', 10, 2 );

/**
 * Register two widget areas.
 *
 * @since Twenty Thirteen 1.0
 */
function twentythirteen_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Main Widget Area', 'twentythirteen' ),
		'id'            => 'sidebar-1',
		'description'   => __( 'Appears in the footer section of the site.', 'twentythirteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Secondary Widget Area', 'twentythirteen' ),
		'id'            => 'sidebar-2',
		'description'   => __( 'Appears on posts and pages in the sidebar.', 'twentythirteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Blank Widget Area', 'twentythirteen' ),
		'id'            => 'sidebar-blank',
		'description'   => __( 'Appears on Blank Template page in the sidebar.', 'twentythirteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => __( 'Newsletter', 'twentythirteen' ),
		'id'            => 'newsletter',
		'description'   => __( 'Newsletter in the sidebar.', 'twentythirteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'twentythirteen_widgets_init' );

if ( ! function_exists( 'twentythirteen_paging_nav' ) ) :
/**
 * Display navigation to next/previous set of posts when applicable.
 *
 * @since Twenty Thirteen 1.0
 */
function twentythirteen_paging_nav() {
	global $wp_query;

	// Don't print empty markup if there's only one page.
	if ( $wp_query->max_num_pages < 2 )
		return;
	?>
	<nav class="navigation paging-navigation" role="navigation">
		<h1 class="screen-reader-text"><?php _e( 'Posts navigation', 'twentythirteen' ); ?></h1>
		<div class="nav-links">

			<?php if ( get_next_posts_link() ) : ?>
			<div class="nav-previous"><?php next_posts_link( __( '<span class="meta-nav">&larr;</span> Older posts', 'twentythirteen' ) ); ?></div>
			<?php endif; ?>

			<?php if ( get_previous_posts_link() ) : ?>
			<div class="nav-next"><?php previous_posts_link( __( 'Newer posts <span class="meta-nav">&rarr;</span>', 'twentythirteen' ) ); ?></div>
			<?php endif; ?>

		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
}
endif;

if ( ! function_exists( 'twentythirteen_post_nav' ) ) :
/**
 * Display navigation to next/previous post when applicable.
*
* @since Twenty Thirteen 1.0
*/
function twentythirteen_post_nav() {
	global $post;

	// Don't print empty markup if there's nowhere to navigate.
	$previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
	$next     = get_adjacent_post( false, '', false );

	if ( ! $next && ! $previous )
		return;
	?>
	<nav class="navigation post-navigation" role="navigation">
		<h1 class="screen-reader-text"><?php _e( 'Post navigation', 'twentythirteen' ); ?></h1>
		<div class="nav-links">

			<?php previous_post_link( '%link', _x( '<span class="meta-nav">&larr;</span> %title', 'Previous post link', 'twentythirteen' ) ); ?>
			<?php next_post_link( '%link', _x( '%title <span class="meta-nav">&rarr;</span>', 'Next post link', 'twentythirteen' ) ); ?>

		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
}
endif;

if ( ! function_exists( 'twentythirteen_entry_meta' ) ) :
/**
 * Print HTML with meta information for current post: categories, tags, permalink, author, and date.
 *
 * Create your own twentythirteen_entry_meta() to override in a child theme.
 *
 * @since Twenty Thirteen 1.0
 */
function twentythirteen_entry_meta() {
	if ( is_sticky() && is_home() && ! is_paged() )
		echo '<span class="featured-post">' . esc_html__( 'Sticky', 'twentythirteen' ) . '</span>';

	if ( ! has_post_format( 'link' ) && 'post' == get_post_type() )
		twentythirteen_entry_date();

	// Translators: used between list items, there is a space after the comma.
	$categories_list = get_the_category_list( __( ', ', 'twentythirteen' ) );
	if ( $categories_list ) {
		echo '<span class="categories-links">' . $categories_list . '</span>';
	}

	// Translators: used between list items, there is a space after the comma.
	$tag_list = get_the_tag_list( '', __( ', ', 'twentythirteen' ) );
	if ( $tag_list ) {
		echo '<span class="tags-links">' . $tag_list . '</span>';
	}

	// Post author
	if ( 'post' == get_post_type() ) {
		printf( '<span class="author vcard"><a class="url fn n" href="%1$s" title="%2$s" rel="author">%3$s</a></span>',
			esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
			esc_attr( sprintf( __( 'View all posts by %s', 'twentythirteen' ), get_the_author() ) ),
			get_the_author()
		);
	}
}
endif;

if ( ! function_exists( 'twentythirteen_entry_date' ) ) :
/**
 * Print HTML with date information for current post.
 *
 * Create your own twentythirteen_entry_date() to override in a child theme.
 *
 * @since Twenty Thirteen 1.0
 *
 * @param boolean $echo (optional) Whether to echo the date. Default true.
 * @return string The HTML-formatted post date.
 */
function twentythirteen_entry_date( $echo = true ) {
	if ( has_post_format( array( 'chat', 'status' ) ) )
		$format_prefix = _x( '%1$s on %2$s', '1: post format name. 2: date', 'twentythirteen' );
	else
		$format_prefix = '%2$s';

	$date = sprintf( '<span class="date"><a href="%1$s" title="%2$s" rel="bookmark"><time class="entry-date" datetime="%3$s">%4$s</time></a></span>',
		esc_url( get_permalink() ),
		esc_attr( sprintf( __( 'Permalink to %s', 'twentythirteen' ), the_title_attribute( 'echo=0' ) ) ),
		esc_attr( get_the_date( 'c' ) ),
		esc_html( sprintf( $format_prefix, get_post_format_string( get_post_format() ), get_the_date() ) )
	);

	if ( $echo )
		echo $date;

	return $date;
}
endif;

if ( ! function_exists( 'twentythirteen_the_attached_image' ) ) :
/**
 * Print the attached image with a link to the next attached image.
 *
 * @since Twenty Thirteen 1.0
 */
function twentythirteen_the_attached_image() {
	/**
	 * Filter the image attachment size to use.
	 *
	 * @since Twenty thirteen 1.0
	 *
	 * @param array $size {
	 *     @type int The attachment height in pixels.
	 *     @type int The attachment width in pixels.
	 * }
	 */
	$attachment_size     = apply_filters( 'twentythirteen_attachment_size', array( 724, 724 ) );
	$next_attachment_url = wp_get_attachment_url();
	$post                = get_post();

	/*
	 * Grab the IDs of all the image attachments in a gallery so we can get the URL
	 * of the next adjacent image in a gallery, or the first image (if we're
	 * looking at the last image in a gallery), or, in a gallery of one, just the
	 * link to that image file.
	 */
	$attachment_ids = get_posts( array(
		'post_parent'    => $post->post_parent,
		'fields'         => 'ids',
		'numberposts'    => -1,
		'post_status'    => 'inherit',
		'post_type'      => 'attachment',
		'post_mime_type' => 'image',
		'order'          => 'ASC',
		'orderby'        => 'menu_order ID',
	) );

	// If there is more than 1 attachment in a gallery...
	if ( count( $attachment_ids ) > 1 ) {
		foreach ( $attachment_ids as $attachment_id ) {
			if ( $attachment_id == $post->ID ) {
				$next_id = current( $attachment_ids );
				break;
			}
		}

		// get the URL of the next image attachment...
		if ( $next_id )
			$next_attachment_url = get_attachment_link( $next_id );

		// or get the URL of the first image attachment.
		else
			$next_attachment_url = get_attachment_link( reset( $attachment_ids ) );
	}

	printf( '<a href="%1$s" title="%2$s" rel="attachment">%3$s</a>',
		esc_url( $next_attachment_url ),
		the_title_attribute( array( 'echo' => false ) ),
		wp_get_attachment_image( $post->ID, $attachment_size )
	);
}
endif;

/**
 * Return the post URL.
 *
 * @uses get_url_in_content() to get the URL in the post meta (if it exists) or
 * the first link found in the post content.
 *
 * Falls back to the post permalink if no URL is found in the post.
 *
 * @since Twenty Thirteen 1.0
 *
 * @return string The Link format URL.
 */
function twentythirteen_get_link_url() {
	$content = get_the_content();
	$has_url = get_url_in_content( $content );

	return ( $has_url ) ? $has_url : apply_filters( 'the_permalink', get_permalink() );
}

if ( ! function_exists( 'twentythirteen_excerpt_more' ) && ! is_admin() ) :
/**
 * Replaces "[...]" (appended to automatically generated excerpts) with ...
 * and a Continue reading link.
 *
 * @since Twenty Thirteen 1.4
 *
 * @param string $more Default Read More excerpt link.
 * @return string Filtered Read More excerpt link.
 */
function twentythirteen_excerpt_more( $more ) {
	$link = sprintf( '<a href="%1$s" class="more-link">%2$s</a>',
		esc_url( get_permalink( get_the_ID() ) ),
			/* translators: %s: Name of current post */
			sprintf( __( 'Continue reading %s <span class="meta-nav">&rarr;</span>', 'twentythirteen' ), '<span class="screen-reader-text">' . get_the_title( get_the_ID() ) . '</span>' )
		);
	return ' &hellip; ' . $link;
}
add_filter( 'excerpt_more', 'twentythirteen_excerpt_more' );
endif;

/**
 * Extend the default WordPress body classes.
 *
 * Adds body classes to denote:
 * 1. Single or multiple authors.
 * 2. Active widgets in the sidebar to change the layout and spacing.
 * 3. When avatars are disabled in discussion settings.
 *
 * @since Twenty Thirteen 1.0
 *
 * @param array $classes A list of existing body class values.
 * @return array The filtered body class list.
 */
function twentythirteen_body_class( $classes ) {
	if ( ! is_multi_author() )
		$classes[] = 'single-author';

	if ( is_active_sidebar( 'sidebar-2' ) && ! is_attachment() && ! is_404() )
		$classes[] = 'sidebar';

	if ( ! get_option( 'show_avatars' ) )
		$classes[] = 'no-avatars';

	return $classes;
}
add_filter( 'body_class', 'twentythirteen_body_class' );

/**
 * Adjust content_width value for video post formats and attachment templates.
 *
 * @since Twenty Thirteen 1.0
 */
function twentythirteen_content_width() {
	global $content_width;

	if ( is_attachment() )
		$content_width = 724;
	elseif ( has_post_format( 'audio' ) )
		$content_width = 484;
}
add_action( 'template_redirect', 'twentythirteen_content_width' );

/**
 * Add postMessage support for site title and description for the Customizer.
 *
 * @since Twenty Thirteen 1.0
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function twentythirteen_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
}
add_action( 'customize_register', 'twentythirteen_customize_register' );

/**
 * Enqueue Javascript postMessage handlers for the Customizer.
 *
 * Binds JavaScript handlers to make the Customizer preview
 * reload changes asynchronously.
 *
 * @since Twenty Thirteen 1.0
 */
function twentythirteen_customize_preview_js() {
	wp_enqueue_script( 'twentythirteen-customizer', get_template_directory_uri() . '/js/theme-customizer.js', array( 'customize-preview' ), '20141120', true );
}
add_action( 'customize_preview_init', 'twentythirteen_customize_preview_js' );
add_action('wp_ajax_iflair_ajax_response_cruise_operators', 'iflair_ajax_response_cruise_operators'); // Logged-in users
add_action('wp_ajax_nopriv_iflair_ajax_response_cruise_operators', 'iflair_ajax_response_cruise_operators'); // Guest users
add_action('wp_ajax_iflair_ajax_response_combo_cruise_operators', 'iflair_ajax_response_combo_cruise_operators'); // Logged-in users
add_action('wp_ajax_nopriv_iflair_ajax_response_combo_cruise_operators', 'iflair_ajax_response_combo_cruise_operators'); // Guest users

function iflair_ajax_response_cruise_operators(){
global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;

	$mainsiteprefix='cm_';
	$agentsiteurl=get_option('siteurl');
	$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
	$agentsiteid=$agentsitedetail->id;
	$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
	$agent_assign_operator;

	$pagenum=$_POST['pagenumb'];
	if($_POST['pagenumb']==""){
		$per_page = 10;
		$page='1';
		$start='0';
	}
	else {
		$per_page = 10;
		$page=$_POST['pagenumb'];	
		$start=($page-1)*$per_page;
	}
					
					
	//echo $start = $page * $per_page;
					/* latecard pagination*/	
						
?>
<div id="replace_query_ajax">
	<?php
	if($_POST['str1'] !="" && $_POST['str2'] != "" ){
		$select_ship_query = "SELECT cc.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name WHERE 1=1  AND $_POST[str1] = '$_POST[str2]' GROUP BY cc.cruise_id ORDER BY cc.cruise_operator_name";
		

		
	}
	else{
		//print_r($_POST);
		$select_ship_query = "";
		$select_ship_query .= "SELECT * FROM cruise_cruise ";
		$whereClauses = array();
		if (! empty($_POST['touroperator'])){ 
			$q0 = $mydb->get_var("SELECT operator_title FROM cruise_operators WHERE operator_id='$_POST[touroperator]'"); 
			$whereClauses[] ="cruise_operator_name='".$q0."'";
		}
		if (! empty($_POST['shipsize'])){ 
			$q1 = $mydb->get_var("SELECT size_title FROM cruise_ship_size WHERE size_id='$_POST[shipsize]'"); 
			$whereClauses[] ="cruise_ship_size='".$q1."'";
		}
		if (! empty($_POST['shipstyle'])){ 
			$q2 = $mydb->get_var("SELECT style_title FROM cruise_ship_style WHERE style_id='$_POST[shipstyle]'"); 
			$whereClauses[] ="crusie_ship_style='".$q2."'";
		}
		if (! empty($_POST['shiplanguage'])){ 

			$whereClauses[] ="cruise_language='".$_POST[shiplanguage]."'";
		}
		$where = '';
		if (count($whereClauses) > 0) { $where = ' WHERE '.implode(' AND ',$whereClauses); }
			$select_ship_query = "SELECT * FROM cruise_cruise".$where; 
			/*echo "<pre>";
			print_r($select_ship);
			echo "</pre>";*/
	}
	cruise_pagging($page,$per_page,$select_ship_query);
	$select_ship_query .= " LIMIT $start,$per_page";
	
	//exit();
	
	//echo $select_ship_query;
	$select_ship = $mydb->get_results($select_ship_query);
	//echo count($select_ship);
	if(count($select_ship) == 0)
	{
		echo "No Search result Found for :- ".$q0." , ".$q1." , ".$q2." , ".$q3." ";
	}
	else
	{
		for($i=0;$i<count($select_ship);$i++)
		{
		?>
		<div class="mediter-box m-24 clearfix">
			<div class="medi-left">
				<img src="<?php echo esc_url( get_template_directory_uri() )."/images/loader.gif"; ?>" data-original="<?php if($select_ship[$i]->cruise_cover_image_href!=""){ echo $select_ship[$i]->cruise_cover_image_href; }else{ echo esc_url( get_template_directory_uri() )."/images/no-property-image.jpg"; } ?>" class="img-responsive lazy">
  				<script>jQuery("img.lazy").lazyload();</script>

			</div>
			<div class="medi-mid">
				<h3><?php echo $select_ship[$i]->cruise_operator_name; ?></h3>
				<!-- 
				<p>Date <span>-  - <?php /*$time = strtotime($select_ship[$i]->ship_created_date); $newformat = date('j M Y',$time); echo $newformat; */?></span></p>
				<p>No of NIghts <span>- - </span></p> -->

				<p>Ship <span>- <?php echo $select_ship[$i]->cruise_title; ?></span></p>
			</div>
			<div class="medi-right">
				<h2>Guide Price Range</h2>
				<p><?php echo html_entity_decode(substr($select_ship[$i]->cruise_introduction,0,100)); if(strlen($select_ship[$i]->cruise_introduction)>100){ ?><span>...</span><?php } ?></p>
				<div class="clearfix right">
					<a href="<?php echo esc_url(home_url('/'));?>ship-details/?ship_id=<?php echo $select_ship[$i]->cruise_id; ?>" class="info-bt-a">VIEW MORE INFORMATION</a>
				</div>
			</div>
		</div>
		<?php
		}
	}
	?>
	<script type="text/javascript">	
					jQuery(document).ready(function(){
						jQuery("#pagination li").click(function(){
							jQuery('.loader').css('display','block');
							var pageNum = this.id;
							
	    					var touroperator = '<?php echo $_POST["touroperator"]; ?>';
							var shipsize = '<?php echo $_POST["shipsize"]; ?>';
							var shipstyle = '<?php echo $_POST["shipstyle"]; ?>';
							var shiplanguage = '<?php echo $_POST["shiplanguage"]; ?>';
							var str1='<?php echo $_POST["str1"]; ?>';
                			var str2='<?php echo $_POST["str2"]; ?>';
							
						        jQuery.ajax({
						            type: "POST",
						            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
						            data: ({
						                action: 'iflair_ajax_response_cruise_operators',
						                touroperator: touroperator,
						                shipsize:shipsize,
						                shipstyle:shipstyle,
						                shiplanguage:shiplanguage,
						                str1: str1,
                						str2: str2,
						                pagenumb:pageNum
						            }),
						            success: function (response) {
						                //alert(response);
						                jQuery('#replace_query_ajax').html(response);
						            	jQuery('.loader').css('display','none');
						            }
						        });
							
						});
					});


				</script>
<script>
jQuery( document ).ready(function() {
//alert("1358");
	jQuery('.iflair_template_value_reseter').click(function(){
	    jQuery('#iflair_template_cruise_operators').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_ship_size').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_ship_style').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_language').prop('selectedIndex',0);
	    iflair_ajax_cruise_operators();
	});
	jQuery('#iflair_template_cruise_operators').click(function(){
	    jQuery('#iflair_template_cruise_ship_size').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_ship_style').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_language').prop('selectedIndex',0);
	});
	jQuery('.iflair_template_value_cruiseship').click(function(){
		jQuery('#iflair_template_cruise_operators').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_ship_size').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_ship_style').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_language').prop('selectedIndex',0);
	    iflair_ajax_cruise_operators();

	});

});


</script>
	<?php
	die();
?>
</div>
<?php
}

function iflair_ajax_response_combo_cruise_operators(){
global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;

	$mainsiteprefix='cm_';
	$agentsiteurl=get_option('siteurl');
	$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
	$agentsiteid=$agentsitedetail->id;
	$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
	$agent_assign_operator;


	?>
	<span id="second_filter">
		<?php
	    $cruise_ship_size_q = $mydb->get_row("SELECT size_title FROM cruise_ship_size WHERE size_id=$_POST[shipsize]");
	    $cruise_ship_size_v = $cruise_ship_size_q->size_title;
	    $cruise_ship_style_q = $mydb->get_row("SELECT style_title FROM cruise_ship_style WHERE style_id=$_POST[shipstyle]");
	    $cruise_ship_style_v = $cruise_ship_style_q->style_title;
	    $cruise_ship_lang_q = $mydb->get_row("SELECT language_title FROM cruise_language WHERE language_code='$_POST[shiplanguage]'");
	    $cruise_ship_lang_v = $cruise_ship_lang_q->language_title;

		if( $cruise_ship_size_v != "" && $cruise_ship_style_v != "" && $cruise_ship_lang_v != "" ){
    	?>
			<script type="text/javascript">	
				jQuery('#iflair_template_cruise_ship_size,#iflair_template_cruise_ship_style,#iflair_template_cruise_language').click(function() {
					jQuery('#iflair_template_cruise_ship_size').prop('selectedIndex',0);
					jQuery('#iflair_template_cruise_ship_style').prop('selectedIndex',0);
					jQuery('#iflair_template_cruise_language').prop('selectedIndex',0);
			});
			</script>
    	<?php
    	}

		?>
		<div class="btn-group i-1" role="group">
			<select name="iflair_template_cruise_ship_size" id="iflair_template_cruise_ship_size" class="btn btn-default dropdown-toggle text p-2" required onchange="iflair_ajax_second_filter();" >
				<option value="">Select a ship size</option>
			    <?php

			    $cruise_ship_size = "SELECT css.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_size AS css ON co.operator_title = cc.cruise_operator_name WHERE 1=1  AND css.size_title = cc.cruise_ship_size AND co.operator_id = $_POST[touroperator] GROUP BY cc.cruise_ship_size ORDER BY cc.cruise_operator_name";
			    echo $cruise_ship_size;
			    $select_cruise_ship_size = $mydb->get_results($cruise_ship_size);
			    //echo count($select_cruise_ship_size);
			    for($ss=0;$ss<count($select_cruise_ship_size);$ss++){
			    	?>
				   	<option <?php if( $cruise_ship_size_v == $select_cruise_ship_size[$ss]->size_title ){ echo "selected"; } ?> value="<?php echo $select_cruise_ship_size[$ss]->size_id; ?>"><?php echo $select_cruise_ship_size[$ss]->size_title; ?></option>
				   	<?php
			    }
			    ?>
		    </select>
	  	</div>
		<div class="btn-group i-1" role="group">
			<select <?php if(!$_POST['touroperator'] || !$_POST['shipsize'] ){ echo "disabled='true'";} ?> name="iflair_template_cruise_ship_style" id="iflair_template_cruise_ship_style" class="btn btn-default dropdown-toggle text p-2" required onchange="iflair_ajax_second_filter();">
				<option value="">Select a ship style</option>
			    <?php
			    	 //echo "SELECT css.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_style AS css ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id IN (1,2,3,7,9,10,11,12,14,15,16,20,24,28,29,32,112,116) AND css.style_title = cc.crusie_ship_style AND co.operator_id = 7 GROUP BY cc.crusie_ship_style ORDER BY cc.cruise_operator_name";
			    $cruise_ship_style ="";
			    $cruise_ship_style .="SELECT css.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_style AS css ON co.operator_title = cc.cruise_operator_name WHERE 1=1  AND css.style_title = cc.crusie_ship_style AND co.operator_id = $_POST[touroperator]"; 
			    if( $cruise_ship_size_v != "" ){
			    	 $cruise_ship_style .=" AND cruise_ship_size = '$cruise_ship_size_v'";
			    }
			    $cruise_ship_style .=" GROUP BY cc.crusie_ship_style ORDER BY cc.cruise_operator_name"; 
			    echo $cruise_ship_style;
			    $select_cruise_ship_style = $mydb->get_results($cruise_ship_style);
			    foreach ($select_cruise_ship_style as $cruise_ship_style_obj) :
					?>
				   	<option <?php if( $cruise_ship_style_v == $cruise_ship_style_obj->style_title ){ echo "selected"; } ?> value="<?php echo $cruise_ship_style_obj->style_id; ?>"><?php echo $cruise_ship_style_obj->style_title; ?></option>
				   	<?php
				endforeach;
			    ?>
		    </select>
	  	</div>
		<div class="btn-group i-1" role="group">
			<select <?php if(!$_POST['touroperator'] || !$_POST['shipsize']  || !$_POST['shipstyle'] ){ echo "disabled='true'";} ?> name="iflair_template_cruise_language" id="iflair_template_cruise_language" class="btn btn-default dropdown-toggle text p-2" required onchange="iflair_ajax_second_filter();" >
				<option value="">Select a language</option>
			    <?php
			    $cruise_ship_language ="";
			    $cruise_ship_language .="SELECT cl.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_language AS cl ON co.operator_title = cc.cruise_operator_name WHERE 1=1  AND cl.language_code = cc.cruise_language AND co.operator_id = $_POST[touroperator]"; 
			    if( $cruise_ship_size_v != "" ){
			    	 $cruise_ship_language .=" AND cruise_ship_size = '$cruise_ship_size_v'";
			    }
			    if( $cruise_ship_lang_v != "" ){
			    	 $cruise_ship_language .=" AND language_title = '$cruise_ship_lang_v'";
			    }
			    $cruise_ship_language .=" GROUP BY cc.cruise_language ORDER BY cc.cruise_operator_name"; 
			    echo $cruise_ship_language;
			    $select_cruise_language = $mydb->get_results($cruise_ship_language);

				foreach ($select_cruise_language as $cruise_language_obj) :
				   ?>
				   	<option <?php if( $cruise_ship_lang_v == $cruise_language_obj->language_title ){ echo "selected"; } ?> value="<?php echo $cruise_language_obj->language_code; ?>"><?php echo $cruise_language_obj->language_title; ?></option>
				   	<?php
				endforeach;
			    ?>
		    </select>
	  	</div>					
	</span>
	<?php
	die();
}
/* Code started by Arvind */
function iflair_get_subsite_id($agentsiteurl){
	global $wpdb,$mydb,$mainsiteprefix;

	$select_subsite_detail = "SELECT * FROM ".$mainsiteprefix."site_management WHERE site_url='".$agentsiteurl."'";
	$select_subsite = $mydb->get_row($select_subsite_detail);
	
	return $select_subsite;
} 
function iflair_get_tour_operator_assign($agentsiteid){
	global $wpdb,$mydb,$mainsiteprefix,$agentsiteid;
	$select_tour_opertor_detail = "SELECT tour_operator_id FROM ".$mainsiteprefix."tour_operator WHERE site_id='".$agentsiteid."'";
	$select_tour_opertor_assign = $mydb->get_col($select_tour_opertor_detail);
	if(is_array($select_tour_opertor_assign)){
		$get_assign_operator=implode(',', $select_tour_opertor_assign);
	}
	else {
		$get_assign_operator=array();	
	}
	return $get_assign_operator;

}
/* Code started by Arvind */
function cruise_pagging($page="",$numofrec,$select_ship_query){
	global $wpdb,$mydb,$mainsiteprefix;				
	
$start = ($page-1)*$per_page;
$page = $page;
	$cur_page = $page;
	$page -= 1;
	$per_page = $numofrec;
	$previous_btn = true;
	$next_btn = true;
	$first_btn = true;
	$last_btn = true;
	$start = $page * $per_page;
	//$count = $pages;
	//$no_of_paginations = ceil($count / $per_page);

	$select_ship_pag = $mydb->get_results($select_ship_query);
$innercount = count($select_ship_pag);
$no_of_paginations = ceil($innercount/$per_page);

	/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
	if ($cur_page >= 3) {
	    $start_loop = $cur_page - 1;
	    if ($no_of_paginations > $cur_page + 1)
	        $end_loop = $cur_page + 1;
	    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 2) {
	        $start_loop = $no_of_paginations - 2;
	        $end_loop = $no_of_paginations;
	    } else {
	        $end_loop = $no_of_paginations;
	    }
	} else {
	    $start_loop = 1;
	    if ($no_of_paginations > 3)
	        $end_loop = 3;
	    else
	        $end_loop = $no_of_paginations;
	}
	/* ----------------------------------------------------------------------------------------------------------- */
	$msg .= "<div class='pagination-menu'><ul id='pagination'>";

	// FOR ENABLING THE FIRST BUTTON
	if ($first_btn && $cur_page > 1) {
	    $msg .= "<li id='1' class='active'>First</li>";
	} else if ($first_btn) {
	    $msg .= "<li id='1' class='inactive'>First</li>";
	}

	// FOR ENABLING THE PREVIOUS BUTTON
	if ($previous_btn && $cur_page > 1) {
	    $pre = $cur_page - 1;
	    $msg .= "<li id='$pre' class='active'>Previous</li>";
	} else if ($previous_btn) {
	    $msg .= "<li class='inactive'>Previous</li>";
	}
	for ($i = $start_loop; $i <= $end_loop; $i++) {

	    if ($cur_page == $i)
	        $msg .= "<li id='$i' class='active currentdiv'>{$i}</li>";
	    else
	        $msg .= "<li id='$i' class='active'>{$i}</li>";
	}

	// TO ENABLE THE NEXT BUTTON
	if ($next_btn && $cur_page < $no_of_paginations) {
	    $nex = $cur_page + 1;
	    $msg .= "<li id='$nex' class='active'>Next</li>";
	} else if ($next_btn) {
	    $msg .= "<li class='inactive'>Next</li>";
	}

	// TO ENABLE THE END BUTTON
	if ($last_btn && $cur_page < $no_of_paginations) {
	    $msg .= "<li id='$no_of_paginations' class='active'>Last</li>";
	} else if ($last_btn) {
	    $msg .= "<li id='$no_of_paginations' class='inactive'>Last</li>";
	}
	$msg = $msg . "</ul></div>";  // Content for pagination
	echo $msg;
}

/* MK Aded New cruise search */
add_action('wp_ajax_cruise_filter_response', 'cruise_filter_response'); // Logged-in users
add_action('wp_ajax_nopriv_cruise_filter_response', 'cruise_filter_response'); // Guest users
add_action('wp_ajax_iflair_search_filter_response', 'iflair_search_filter_response'); // Logged-in users
add_action('wp_ajax_nopriv_iflair_search_filter_response', 'iflair_search_filter_response'); // Guest users
add_action('wp_ajax_cruise_detail', 'cruise_detail'); // Logged-in users
add_action('wp_ajax_nopriv_cruise_detail', 'cruise_detail'); // Guest users

add_action('wp_ajax_iflair_detail_search_filter_response', 'iflair_detail_search_filter_response'); // Logged-in users
add_action('wp_ajax_nopriv_iflair_detail_search_filter_response', 'iflair_detail_search_filter_response'); // Guest users

add_action('wp_ajax_price_filter_result', 'price_filter_result'); // Logged-in users
add_action('wp_ajax_nopriv_price_filter_result', 'price_filter_result'); // Guest users

add_action('wp_ajax_iflair_get_operator', 'iflair_get_operator'); // Logged-in users
add_action('wp_ajax_nopriv_iflair_get_operator', 'iflair_get_operator'); // Guest users


function iflair_get_operator() {
	global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;

	$opet_name = $_POST['opet_name'];

	if ($opet_name != "") 
	{
		$basepoke_q = "SELECT bl.ship_id,bc.offer_logo,bc.departure_date,bc.cruise_nights,bc.cruise_id,bc.offer_short_summery FROM cc_basepoke_list as bl INNER JOIN cc_basepoke_cruises as bc ON bc.basepoke_id = bl.id WHERE bl.operator_name LIKE '%".$opet_name."%' AND bc.base_cruise_status = 1 AND bc.offer_start_date < curdate() AND departure_date > curdate() AND bc.offer_end_date > curdate() ORDER BY rand() LIMIT 0, 6";
		$basepoke_r = $wpdb->get_results($basepoke_q);
		if(!empty($basepoke_r)){/*
			echo "<pre>";
			print_r($basepoke_r);
			echo "</pre>";*/
			echo "<ul>";
			foreach ($basepoke_r as $basepoke_rkey => $basepoke_rvalue) {
				?>
				<?php
					$opet_logo = "SELECT * FROM cruise_cruise WHERE cruise_response_id = '$basepoke_rvalue->ship_id'";
					$opet_logo_res = $mydb->get_row($opet_logo);
					$opt_detail = "SELECT * FROM cruise_ship_cruise WHERE ship_id = '$basepoke_rvalue->ship_id' AND cruise_id = '".$basepoke_rvalue->cruise_id."' AND ship_starts_on > curdate() ";
					$opt_detail_res = $mydb->get_row($opt_detail);
				?>
				<li>
					<!-- Logo -->
					<div class="operator_image">
						<img src="<?php if($opet_logo_res->cruise_profile_image_href!=""){ echo "http://ekups3e.cloudimg.io/s/resize/170/".str_replace('//www','www',$opet_logo_res->cruise_profile_image_href); } ?>">
					</div>
					<!-- Ship Title -->
					<div class="ship_title">
						<?php 
							echo $opt_detail_res->cruise_title;
						?>
					</div>
					<!-- Destination -->
					<div class="cruise_last_port_name"><?php echo $opt_detail_res->cruise_last_port_name; ?></div>
					<!-- Date Night and Type-->
					<div class="ship_starts_on">
						<?php echo date('d M y',strtotime($opt_detail_res->ship_starts_on)); ?> --
						<?php echo $opt_detail_res->ship_cruise_nights; ?> nts 
						<?php //echo $opet_logo_res->crusie_ship_style; ?>
					</div>
					<div class="cruise_introduction" style="min-height: 60px;">
						<?php
							$port_result_iq = $mydb->get_results("SELECT * FROM `cruise_port` WHERE cruise_id = '".$opt_detail_res->cruise_id."'");
							//print_r($port_result_iq);
							echo $port_result_iq[0]->port_name;
							for ($ipr=1; $ipr < 7 ; $ipr++) { 
								echo ", ".$port_result_iq[$ipr]->port_name;
							}
						?>
					</div>
					<!-- Short Desc -->
					<div class="cruise_introduction" style="color: red; font-weight: bold;">
						<?php
							$op_desc1 = strip_tags(html_entity_decode($basepoke_rvalue->offer_short_summery));
							$pieces1 = explode(" ", $op_desc1);
                            $second_part_op_desc = implode(" ", array_splice($pieces1, 0, 18));
                            echo $second_part_op_desc;
						?>
					</div>
					<!-- Price -->
					<!-- <div class="ship_cruise_only_price"><?php echo $opt_detail_res->ship_cruise_only_price; ?></div> -->
					<!-- Detail page link -->
					<?php
					$cruise_id_p_c = $opt_detail_res->cruise_id;
					$b_query_r = $wpdb->get_row("SELECT offer_price FROM cc_basepoke_cruises WHERE cruise_id = '".$cruise_id_p_c."' ");
					$b_price = $b_query_r->offer_price;
					if(!empty($b_price)){
						$final_price = $b_price;
						?>
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>cruise-detail/?cruise_id=<?php echo $opt_detail_res->cruise_id; ?>">From £<?php echo $final_price; ?>pp</a>
						<?php
					}
					else{
						$b_query_r = $mydb->get_row("SELECT ship_cruise_only_price FROM cruise_ship_cruise WHERE cruise_id = '".$cruise_id_p_c."' ");
						$b_price = $b_query_r->ship_cruise_only_price;
						$final_price = $b_price;
						if($final_price=="0"){
							?>
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>cruise-detail/?cruise_id=<?php echo $opt_detail_res->cruise_id; ?>"> Enquire </a>
							<?php
						}
						else{
							?>
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>cruise-detail/?cruise_id=<?php echo $opt_detail_res->cruise_id; ?>">From £<?php echo $final_price; ?>pp</a>
							<?php
						}
					}
					?>
				</li>
				
			<?php
			}
			echo "</ul>";
		}
		else{
			$cruise_opt = "SELECT cruise_response_id FROM cruise_cruise WHERE cruise_operator_name LIKE '$opet_name' ORDER BY rand() LIMIT 0, 6";
			$cruise_opt_res = $mydb->get_results($cruise_opt);
			$cruise_opt_res_count = count($cruise_opt_res);
			$mc = 0;
			if ($cruise_opt_res_count != "0") 
			{
				
				foreach ($cruise_opt_res as $cruise_opt)
				{
					$rep_id = $cruise_opt->cruise_response_id;
					$opt_detail = "SELECT * FROM cruise_ship_cruise WHERE ship_id = '$rep_id' AND ship_starts_on > curdate() LIMIT 0, 6";
					$opt_detail_res = $mydb->get_results($opt_detail);
					$opt_detail_res_count = count($opt_detail_res);
					if ($opt_detail_res_count != "0") 
					{
						echo "<ul>";
						$j=0;
						foreach ($opt_detail_res as $operator_detail) 
						{ 
							$j++;
							$mc++;
							if($mc<=6){
							/*print "<pre>";
							print_r($operator_detail)*/
							?>
							<?php
								$opet_logo = "SELECT * FROM cruise_cruise WHERE cruise_response_id = '$rep_id'";
								$opet_logo_res = $mydb->get_row($opet_logo);
							?>
							<li>
								<!-- Logo -->
								<div class="operator_image">
									<img src="<?php if($opet_logo_res->cruise_profile_image_href!=""){ echo "http://ekups3e.cloudimg.io/s/resize/170/".str_replace('//www','www',$opet_logo_res->cruise_profile_image_href); } ?>">
								</div>
								<!-- Ship Title -->
								<div class="ship_title">
									<?php 
										echo $operator_detail->cruise_title;
										/*$op_ti = $operator_detail->ship_name;
			                            $cont = strip_tags($op_ti);
			                            $pieces = explode(" ", $op_ti);
			                            $second_part_op = implode(" ", array_splice($pieces, 0, 1));
			                            echo $second_part_op;*/
									?>
								</div>
								<!-- Destination -->
								<div class="cruise_last_port_name"><?php echo $operator_detail->cruise_last_port_name; ?></div>
								<!-- Date Night and Type-->
								<div class="ship_starts_on">
									<?php echo date('d M y',strtotime($operator_detail->ship_starts_on)); ?> --
									<?php echo $operator_detail->ship_cruise_nights; ?> nts 
									<?php //echo $opet_logo_res->crusie_ship_style; ?>
								</div>
								<div class="cruise_introduction" style="min-height: 60px;">
									<?php
										$port_result_iq = $mydb->get_results("SELECT * FROM `cruise_port` WHERE cruise_id = '".$operator_detail->cruise_id."'");
										//print_r($port_result_iq);
										echo $port_result_iq[0]->port_name;
										for ($ipr=1; $ipr < 7 ; $ipr++) { 
											echo ", ".$port_result_iq[$ipr]->port_name;
										}
									?>
								</div>
								<!-- Short Desc -->
								<div class="cruise_introduction" style="color: red; font-weight: bold;">
									<?php
										$op_desc1 = strip_tags(html_entity_decode($opet_logo_res->cruise_introduction));
										$pieces1 = explode(" ", $op_desc1);
			                            $second_part_op_desc = implode(" ", array_splice($pieces1, 0, 18));
			                            echo $second_part_op_desc;
									?>
								</div>
								<!-- Price -->
								<!-- <div class="ship_cruise_only_price"><?php echo $operator_detail->ship_cruise_only_price; ?></div> -->
								<!-- Detail page link -->
									<?php
									$cruise_id_p_c = $operator_detail->cruise_id;
									$b_query_r = $wpdb->get_row("SELECT offer_price FROM cc_basepoke_cruises WHERE cruise_id = '".$cruise_id_p_c."' ");
									$b_price = $b_query_r->offer_price;
									if(!empty($b_price)){
										$final_price = $b_price;
										?>
											<a href="<?php echo esc_url( home_url( '/' ) ); ?>cruise-detail/?cruise_id=<?php echo $operator_detail->cruise_id; ?>">From £<?php echo $final_price; ?>pp</a>
										<?php
									}
									else{
										$b_query_r = $mydb->get_row("SELECT ship_cruise_only_price FROM cruise_ship_cruise WHERE cruise_id = '".$cruise_id_p_c."' ");
										$b_price = $b_query_r->ship_cruise_only_price;
										$final_price = $b_price;
										if($final_price=="0"){
											?>
												<a href="<?php echo esc_url( home_url( '/' ) ); ?>cruise-detail/?cruise_id=<?php echo $operator_detail->cruise_id; ?>"> Enquire </a>
											<?php
										}
										else{
											?>
												<a href="<?php echo esc_url( home_url( '/' ) ); ?>cruise-detail/?cruise_id=<?php echo $operator_detail->cruise_id; ?>">From £<?php echo $final_price; ?>pp</a>
											<?php
										}
									}
								}
								?>
							</li>
							
						<?php
							if ($j>=6) { exit(); }
						}
						echo "</ul>";
					}
								
				}
			}
		}
	}

	exit();
}

function iflair_search_filter_response(){
	global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
	$mainsiteprefix='cm_';
	$agentsiteurl=get_option('siteurl');
	$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
	$agentsiteid=$agentsitedetail->id;
	$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
	$agent_assign_operator;

	/*echo "<pre>";
	print_r($_POST);
	echo "</pre>";*/
	$tab_condition = $_POST['tab_id'];
	if($_POST['region']=="all" ){ $region = ""; }else{ $region = $_POST['region']; }
	if($_POST['operator']=="all" ){ $operator = ""; }else{ $operator = $_POST['operator']; }
	if($_POST['cruise_ship']=="all" ){ $cruise_ship = ""; }else{ $cruise_ship = $_POST['cruise_ship']; }
	if($_POST['ship_fly_in']=="all" ){ $ship_fly_in = ""; }else{ $ship_fly_in = $_POST['ship_fly_in']; }	
	if($_POST['leaving_from']=="all" ){ $leaving_from = ""; }else{ $leaving_from = $_POST['leaving_from']; }
	if($_POST['ship_starts_on']=="all" ){ $ship_starts_on = ""; }else{ $ship_starts_on = $_POST['ship_starts_on']; }
	if($_POST['from_cruise_date']=="all" ){ $from_cruise_date = ""; }else{ $from_cruise_date = $_POST['from_cruise_date']; }
	if($_POST['to_cruise_date']=="all" ){ $to_cruise_date = ""; }else{ $to_cruise_date = $_POST['to_cruise_date']; }
	if($_POST['ship_cruise_nights']=="all" ){ 
		$ship_cruise_nights = ""; 
		$s_nts = "0";
		$e_nts = "999";
	}else{
		$ship_cruise_nights = $_POST['ship_cruise_nights'];
		if($ship_cruise_nights == "1"){
			$s_nts = "0";
			$e_nts = "3";
		}
		elseif($ship_cruise_nights == "2"){
			$s_nts = "4";
			$e_nts = "6";
		}
		elseif($ship_cruise_nights == "3"){
			$s_nts = "7";
			$e_nts = "9";
		}
		elseif($ship_cruise_nights == "4"){
			$s_nts = "10";
			$e_nts = "13";
		}
		elseif($ship_cruise_nights == "5"){
			$s_nts = "14";
			$e_nts = "20";
		}
		elseif($ship_cruise_nights == "6"){
			$s_nts = "21";
			$e_nts = "999";
		}
	}


	if($leaving_from!=""){
		$leaving_from_cruise_id= "SELECT cruise_id FROM cruise_port WHERE port_code='$leaving_from'";
		//echo $leaving_from_cruise_id."<---";
		$select_leaving_from_cruise_id = $mydb->get_results($leaving_from_cruise_id);
			$leaving_from_cruise_id_arr = array();
		foreach ($select_leaving_from_cruise_id as $leaving_from_cruise_id_obj) {
			$leaving_from_cruise_id_arr[] = $leaving_from_cruise_id_obj->cruise_id;
		}
		//print_r($leaving_from_cruise_id_arr);
		$leaving_from_cruise_id = $leaving_from_cruise_id_arr[0];
		//print_r($id_res);
		for($i=1;$i<count($leaving_from_cruise_id_arr);$i++){
			$leaving_from_cruise_id = $leaving_from_cruise_id.",".$leaving_from_cruise_id_arr[$i];
		}
		//echo $leaving_from_cruise_id;
	}


	?>
	<script type="text/javascript">jQuery("img.lazy").lazyload({skip_invisible : true});</script>

		<div class="btn-group i-2 h-2" role="group">
			<?php
				$cruise_operator_title= "SELECT csc.ship_operator_id,csc.ship_operator FROM cruise_ship_cruise AS csc WHERE 1=1 ";
			
				/*if($region != ""){
					$cruise_operator_title .= " AND csc.ship_region = '$region'";
				}
				if($cruise_ship != ""){
					$cruise_operator_title .= " AND csc.ship_id = $cruise_ship";
				}
				if($ship_fly_in != ""){
					$cruise_operator_title .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_starts_on != ""){
					$cruise_operator_title .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
				}
				if($ship_cruise_nights != ""){
					$cruise_operator_title .= " AND csc.ship_cruise_nights = '$ship_cruise_nights'";
				}
				*/
				if($tab_condition == 1){
					$cruise_operator_title .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_operator_title .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_operator_title .= "";
				}
	  				$cruise_operator_title .= " GROUP BY csc.ship_operator ORDER BY csc.ship_operator";
	  			
	  			//echo $cruise_operator_title;
				$select_cruise_operator_title = $mydb->get_results($cruise_operator_title);
				$c2 = count($select_cruise_operator_title);
				$qq="0 value";
			?>
				<!-- <img class="loader_filt new_filter" src="<?php //echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;"> -->
		    <select <?php //if($c2==0){echo 'disabled="true" ';}?> name="cruise_operator" id="cruise_operator" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_search_filter('operator');" >
				<option value="" >Cruise Line</option>
				<option value="all" <?php if($_POST['operator']=="all"){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_operator_title as $cruise_operator_title_obj) :
					?>
					<option value="<?php echo $cruise_operator_title_obj->ship_operator_id; ?>" <?php if($operator == $cruise_operator_title_obj->ship_operator_id ){ echo "selected"; } ?> ><?php echo ucfirst(str_replace("-", " ", $cruise_operator_title_obj->ship_operator)); ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>

	  	<div class="btn-group i-3 h-3" role="group">
	  		<?php
	  			$cruise_cruise_ship="";
	  			$cruise_cruise_ship .= "SELECT csc.ship_id,csc.cruise_title FROM cruise_ship_cruise AS csc WHERE 1=1 ";
				if($operator != ""){
					$cruise_cruise_ship .= " AND csc.ship_operator_id = $operator";
				}
				if($region != ""){
					$cruise_cruise_ship .= " AND csc.ship_region = '$region'";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_fly_in != ""){
					$cruise_cruise_ship .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($ship_starts_on != ""){
					$cruise_cruise_ship .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
				}
				/*if($ship_cruise_nights != ""){
					$cruise_cruise_ship .= " AND csc.ship_cruise_nights BETWEEN ".$s_nts." AND ".$e_nts." ";
				}*/
				if($tab_condition == 1){
					$cruise_cruise_ship .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_cruise_ship .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_cruise_ship .= "";
				}
	  				$cruise_cruise_ship .= " GROUP BY csc.cruise_title ORDER BY csc.cruise_title";
				$select_cruise_ship = $mydb->get_results($cruise_cruise_ship);
				$c3 = count($select_cruise_ship);
				if($c3==0){$cruise_ship="";}
	  		?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c3==0){echo 'disabled="true" ';}?> name="cruise_ship" id="cruise_ship" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_search_filter('cruise_ship');" >
				<option value="" >Ship</option>
				<option value="all" <?php if($_POST['cruise_ship']=="all" ){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_ship as $cruise_ship_obj) :
					?>
					<option value="<?php echo $cruise_ship_obj->ship_id; ?>" <?php if($cruise_ship == $cruise_ship_obj->ship_id ){ echo "selected"; } ?> ><?php echo $cruise_ship_obj->cruise_title; ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>
		<div class="btn-group i-1 h-1" role="group">
			<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select name="cruise_region" id="cruise_region" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_search_filter('region');" >
				<option value="" >Cruise Area</option>
				<?php
				
					$tab_condition = $_POST['tab_id'];
					$cruise_region == "";
					$cruise_region .= "SELECT csc.ship_region , csc.ship_cruise_type , csc.cruise_id FROM `cruise_ship_cruise` as csc WHERE 1=1 ";

					if($operator != ""){
						$cruise_region .= " AND csc.ship_operator_id = $operator";
					}
					if($cruise_ship != ""){
						$cruise_region .= " AND csc.ship_id = $cruise_ship";
					}
					if($ship_fly_in != ""){
						$cruise_region .= " AND csc.ship_fly_in = '$ship_fly_in'";
					}
					if($leaving_from != ""){
						$cruise_region .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
					}
					if($ship_starts_on != ""){
						$cruise_region .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
					}
					/*if($ship_cruise_nights != ""){
						$cruise_region .= " AND csc.ship_cruise_nights BETWEEN ".$s_nts." AND ".$e_nts." ";
					}*/
					
					if($tab_condition == 1){
						$cruise_region .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
					}
					elseif($tab_condition == 2){
						$cruise_region .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
					}
					else{
						$cruise_region .= "";
					}
					$cruise_region .= " GROUP BY csc.ship_region ORDER BY FIND_IN_SET('River', csc.ship_cruise_type),csc.ship_region";
					echo $cruise_region;
					$select_cruise_region_res = $mydb->get_results($cruise_region);


				foreach ($select_cruise_region_res as $cruise_region_prepared_obj) :
					$HiddenRiver = explode(',',$cruise_region_prepared_obj->ship_cruise_type);
				?>
					<option value="<?php echo $cruise_region_prepared_obj->ship_region; ?>" <?php if($region == $cruise_region_prepared_obj->ship_region ){ echo "selected"; } ?> ><?php echo $cruise_region_prepared_obj->ship_region; ?><?php if(in_array('River', $HiddenRiver)){ echo " ( River )"; } ?></option>
				<?php
				endforeach;
				?>
		</select>
	  	</div>

	  	<?php /*
	  	<div class="btn-group i-4 h-4" role="group">
	  		<?php
	  			$cruise_ship_fly_in= "SELECT csc.ship_fly_in FROM cruise_ship_cruise AS csc WHERE 1=1 ";
				if($region != ""){
					$cruise_ship_fly_in .= " AND csc.ship_region = '$region'";
				}
				if($operator != ""){
					$cruise_ship_fly_in .= " AND csc.ship_operator_id = $operator";
				}
				if($cruise_ship != ""){
					$cruise_ship_fly_in .= " AND csc.ship_id = $cruise_ship";
				}
				if($ship_starts_on != ""){
					$cruise_ship_fly_in .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
				}
				if($tab_condition == 1){
					$cruise_ship_fly_in .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_ship_fly_in .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_ship_fly_in .= "";
				}
	  				$cruise_ship_fly_in .= " GROUP BY csc.ship_fly_in ORDER BY csc.ship_fly_in";
	  			
				$select_cruise_ship_fly_in = $mydb->get_results($cruise_ship_fly_in);
				$c4 = count($select_cruise_ship_fly_in);
	  		?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c4==0){echo 'disabled="true" ';}?> name="cruise_ship_fly_in" id="cruise_ship_fly_in" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_search_filter('ship_fly_in');" >
				<option value="" >From</option>
				<option value="all" <?php if($_POST['leaving_from'] == "all" ){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_ship_fly_in as $cruise_ship_fly_in_obj) :
					?>
					<option value="<?php echo $cruise_ship_fly_in_obj->ship_fly_in; ?>" <?php if($ship_fly_in == $cruise_ship_fly_in_obj->ship_fly_in ){ echo "selected"; } ?> ><?php echo $cruise_ship_fly_in_obj->ship_fly_in; ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>

	  	<div class="btn-group i-2 h-5" role="group">
	  		<?php
	  			$todays_date = date('Y-m-d H:i:s');
				$cruise_when= "SELECT csc.ship_starts_on FROM cruise_ship_cruise AS csc WHERE 1=1 ";
					$cruise_when .= " AND csc.ship_starts_on >= '$todays_date'";
				if($region != ""){
					$cruise_when .= " AND csc.ship_region = '$region'";
				}
				if($operator != ""){
					$cruise_when .= " AND csc.ship_operator_id = $operator";
				}
				if($cruise_ship != ""){
					$cruise_when .= " AND csc.ship_id = $cruise_ship";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_fly_in != ""){
					$cruise_when .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($tab_condition == 1){
					$cruise_when .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_when .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_when .= "";
				}
	  				$cruise_when .= " GROUP BY YEAR(csc.ship_starts_on),MONTH(csc.ship_starts_on) ORDER BY csc.ship_starts_on";
	  			
				$select_cruise_when = $mydb->get_results($cruise_when);
				//echo $cruise_when;
				$c5 = count($select_cruise_when);
	  		?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c5==0){echo 'disabled="true" ';}?> name="cruise_ship_starts_on" id="cruise_ship_starts_on" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_search_filter('ship_starts_on');" >
				<option value="" >When</option>
				<option value="all" <?php if($_POST['ship_starts_on']=="all" ){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_when as $cruise_when_obj) :
					?>
					<option value="<?php echo date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ; ?>" <?php if($ship_starts_on == date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ){ echo "selected"; } ?> ><?php $ship_date=$cruise_when_obj->ship_starts_on; echo date('F Y',strtotime($ship_date)); ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>
	  	*/?>

	  	<?php 
	  	$todays_date = date('Y-m-d H:i:s');
		$cruise_when= "SELECT csc.ship_starts_on FROM cruise_ship_cruise AS csc WHERE 1=1 ";
			$cruise_when .= " AND csc.ship_starts_on >= '$todays_date'";
		if($region != ""){
			$cruise_when .= " AND csc.ship_region = '$region'";
		}
		if($operator != ""){
			$cruise_when .= " AND csc.ship_operator_id = $operator";
		}
		if($cruise_ship != ""){
			$cruise_when .= " AND csc.ship_id = $cruise_ship";
		}
		if($leaving_from != ""){
			$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
		}
		if($ship_fly_in != ""){
			$cruise_when .= " AND csc.ship_fly_in = '$ship_fly_in'";
		}
		if($tab_condition == 1){
			$cruise_when .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
		}
		elseif($tab_condition == 2){
			$cruise_when .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
		}
		else{
			$cruise_when .= "";
		}
				$cruise_when .= " GROUP BY csc.ship_starts_on ORDER BY csc.ship_starts_on";
			
		$select_cruise_when = $mydb->get_results($cruise_when);
		?>
	  	<link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/themes/base/jquery-ui.css" type="text/css" media="all">
	  	<script type="text/javascript">
	  		var eventDates = {};
  			<?php
			foreach ($select_cruise_when as $cruise_when_obj) :
				?>eventDates[ new Date( '<?php echo date('d M Y',strtotime($cruise_when_obj->ship_starts_on)); ?>' )] = new Date( '<?php echo date('d M Y',strtotime($cruise_when_obj->ship_starts_on)); ?>' );<?php
			endforeach;
  			?>
			var dateToday = new Date();
			<?php
			if ( $template == 'operator_details.php' ) {
			?>
			var xxw = 0;
			<?php 
			}else{
			?>
			var xxw = 150;
			<?php
			}
			?>
			var dates = jQuery("#from_cruise_date, #to_cruise_date").datepicker({
			    defaultDate: "+1w",
			    changeMonth: true,
    			dateFormat: 'd M yy',
			    beforeShow: function (input, inst) {
			        var rect = input.getBoundingClientRect();
			        setTimeout(function () {
				        inst.dpDiv.css({ top: rect.top + xxw, left: rect.left + 0 });
			        }, 0);
			    },
			    numberOfMonths: 1,
			    beforeShowDay: function( date ) {
			                var highlight = eventDates[date];
			                if( highlight ) {
			                     return [true, "event", highlight];
			                } else {
			                     return [true, '', ''];
			                }
			             },
			    minDate: dateToday,
			    onSelect: function(selectedDate) {
			        var option = this.id == "from_cruise_date" ? "minDate" : "maxDate",
			            instance = jQuery(this).data("datepicker"),
			            date = jQuery.datepicker.parseDate(instance.settings.dateFormat || jQuery.datepicker._defaults.dateFormat, selectedDate, instance.settings);
			        dates.not(this).datepicker("option", option, date);
			    }
			});
	  	</script>
	  	<div class="btn-group i-4 h-4" role="group">
			<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
	  		<input type="text" id="from_cruise_date" value="<?php echo $from_cruise_date; ?>" class="btn btn-default dropdown-toggle text p-2 second_filter_class" placeholder="From" name="from_cruise_date"/> 
	  	</div>
	  	<div class="btn-group i-2 h-5" role="group">
			<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
	  		<input type="text" id="to_cruise_date" value="<?php echo $to_cruise_date; ?>" class="btn btn-default dropdown-toggle text p-2 second_filter_class" placeholder="To" name="to_cruise_date"/>
	  	</div>

	  	<div class="btn-group i-3 h-6" role="group">
	  		<?php
				$cruise_days= "SELECT csc.ship_cruise_nights FROM cruise_ship_cruise AS csc WHERE 1=1 ";
				if($region != ""){
					$cruise_days .= " AND csc.ship_region = '$region'";
				}
				if($operator != ""){
					$cruise_days .= " AND csc.ship_operator_id = $operator";
				}
				if($cruise_ship != ""){
					$cruise_days .= " AND csc.ship_id = $cruise_ship";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_fly_in != ""){
					$cruise_days .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($ship_starts_on != ""){
					$cruise_days .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
				}
				if($tab_condition == 1){
					$cruise_days .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_days .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_days .= "";
				}
	  				$cruise_days .= " GROUP BY csc.ship_cruise_nights ORDER BY csc.ship_cruise_nights";
	  			
				$select_cruise_days = $mydb->get_results($cruise_days);
				$c6 = count($select_cruise_days);
	  		?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c6==0){echo 'disabled="true" ';}?> name="cruise_ship_cruise_nights" id="cruise_ship_cruise_nights" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_search_filter('ship_cruise_nights');" >
				<option value="" >Duration</option>
				<option value="all" <?php if($_POST['ship_cruise_nights']=="all" ){ echo "selected"; } ?>>Any</option>
				<?php
				/*foreach ($select_cruise_days as $cruise_days_obj) :
					?>
					<option value="<?php echo $cruise_days_obj->ship_cruise_nights ; ?>" <?php if($ship_cruise_nights == $cruise_days_obj->ship_cruise_nights ){ echo "selected"; } ?> ><?php echo $cruise_days_obj->ship_cruise_nights ; ?></option>
					<?php
				endforeach;*/
				?>
				<option <?php if($ship_cruise_nights==1){echo "selected";} ?> value="1">1 - 3 Nights</option>
				<option <?php if($ship_cruise_nights==2){echo "selected";} ?> value="2">4 - 6 Nights</option>
				<option <?php if($ship_cruise_nights==3){echo "selected";} ?> value="3">7 - 9 Nights</option>
				<option <?php if($ship_cruise_nights==4){echo "selected";} ?> value="4">10 - 13 Nights</option>
				<option <?php if($ship_cruise_nights==5){echo "selected";} ?> value="5">14 - 20 Nights</option>
				<option <?php if($ship_cruise_nights==6){echo "selected";} ?> value="6">21+ Nights</option>
			</select>
	  	</div>
	  	<input type="hidden" value="<?php echo $tab_condition; ?>" name="tab_id">
		
		<span onclick="iflair_search_filter('search');" class="search-bt-2" style="text-align: center; line-height: 46px;cursor:pointer;">Search</span>

		<!-- <button type="submit" name="submit" class="search-bt-2" style="text-align: center; line-height: 46px;cursor:pointer;">Search</button> -->

	<?php
	exit();
}
function cruise_filter_response(){

global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
$mainsiteprefix='cm_';
$agentsiteurl=get_option('siteurl');
$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
$agentsiteid=$agentsitedetail->id;
$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
$agent_assign_operator;
$sort_val = $_POST['sort_val'];
/*
	$region = $_POST['region'];
	$operator = $_POST['operator'];
	$cruise_ship = $_POST['cruise_ship'];
	$ship_fly_in = $_POST['ship_fly_in'];
	$leaving_from = $_POST['leaving_from'];
	$ship_starts_on = $_POST['ship_starts_on'];
	$ship_cruise_nights = $_POST['ship_cruise_nights'];*/
	if($_POST['region']=="all" ){ $region = ""; }else{ $region = $_POST['region']; }
	if($_POST['operator']=="all" ){ $operator = ""; }else{ $operator = $_POST['operator']; }
	if($_POST['cruise_ship']=="all" ){ $cruise_ship = ""; }else{ $cruise_ship = $_POST['cruise_ship']; }
	if($_POST['ship_fly_in']=="all" ){ $ship_fly_in = ""; }else{ $ship_fly_in = $_POST['ship_fly_in']; }	
	if($_POST['leaving_from']=="all" ){ $leaving_from = ""; }else{ $leaving_from = $_POST['leaving_from']; }
	if($_POST['ship_starts_on']=="all" ){ $ship_starts_on = ""; }else{ $ship_starts_on = $_POST['ship_starts_on']; }
	if($_POST['from_cruise_date']=="all" ){ $from_cruise_date = ""; }else{ $from_cruise_date = $_POST['from_cruise_date']; }
	if($_POST['to_cruise_date']=="all" ){ $to_cruise_date = ""; }else{ $to_cruise_date = $_POST['to_cruise_date']; }
	if($_POST['ship_cruise_nights']=="all" ){ 
		$ship_cruise_nights = ""; 
		$s_nts = "0";
		$e_nts = "999";
	}else{
		$ship_cruise_nights = $_POST['ship_cruise_nights'];
		if($ship_cruise_nights == "1"){
			$s_nts = "0";
			$e_nts = "3";
		}
		elseif($ship_cruise_nights == "2"){
			$s_nts = "4";
			$e_nts = "6";
		}
		elseif($ship_cruise_nights == "3"){
			$s_nts = "7";
			$e_nts = "9";
		}
		elseif($ship_cruise_nights == "4"){
			$s_nts = "10";
			$e_nts = "13";
		}
		elseif($ship_cruise_nights == "5"){
			$s_nts = "14";
			$e_nts = "20";
		}
		elseif($ship_cruise_nights == "6"){
			$s_nts = "21";
			$e_nts = "999";
		}
	}


?>

<div class="d-content clearfix setdataheight">
	<div class="servicewrapper">
<h2 id="filter_title"><?php //echo "Results for ".$string; ?></h2>
<div class="side-bar">								
	<div class="ship-features" style="display: none;">
<?php
	$select_ship_query_left ="";
	$select_ship_query_left .= "SELECT cc.cruise_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1 ";
	$conditional_query ="";
	$conditional_query .="cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1 ";

	if($leaving_from!=""){
		$lq = "SELECT cruise_id FROM cruise_port WHERE port_code = '$leaving_from' GROUP BY cruise_id";
		$select_lq = $mydb->get_results($lq);
		//print_r($select_lq[0]['cruise_id']);
		$leaving_string = $select_lq[0]->cruise_id;
		for($i=1;$i<count($select_lq);$i++)
		{
			//echo $select_lq[$i]->cruise_id;
			$leaving_string = $leaving_string.",".$select_lq[$i]->cruise_id;
		}
		//echo $leaving_string;
		$select_ship_query_left .= " AND csc.cruise_id IN ($leaving_string)";
	}
	/*if($_POST['str1']!="date_departure" ){*/
		if($region != ""){
			$select_ship_query_left .= " AND csc.ship_region = '$region'";
			$conditional_query .= " AND csc.ship_region = '$region'";
		}
		if($operator != ""){
			$select_ship_query_left .= " AND co.operator_id = $operator";
			$conditional_query .= " AND co.operator_id = $operator";
		}
		if($cruise_ship != ""){
			$select_ship_query_left .= " AND csc.ship_id = $cruise_ship";
			$conditional_query .= " AND csc.ship_id = $cruise_ship";
		}
		if($ship_fly_in != ""){
			$select_ship_query_left .= " AND csc.ship_fly_in = '$ship_fly_in'";
			$conditional_query .= " AND csc.ship_fly_in = '$ship_fly_in'";
		}
		if($ship_starts_on != ""){
			$select_ship_query_left .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
			$conditional_query .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
		}
		if($ship_cruise_nights != ""){
			$select_ship_query_left .= " AND csc.ship_cruise_nights BETWEEN ".$s_nts." AND ".$e_nts." ";
			$conditional_query .= " AND csc.ship_cruise_nights BETWEEN ".$s_nts." AND ".$e_nts." ";
		}
	/*}*/

	$select_ship_query_left .= " GROUP BY cc.cruise_title"; /* Comment */
	$select_ship_query_left .= " ORDER BY cc.cruise_title";

	//echo $select_ship_query_left;
	$select_ship_query_left_r = $mydb->get_results($select_ship_query_left);


/* Master Query Start------------------------------- */
	$pagenum=$_POST['pagenumb'];
	if($_POST['pagenumb']==""){
		$per_page = 10;
		$page='1';
		$start='0';
	}
	else {
		$per_page = 10;
		$page=$_POST['pagenumb'];	
		$start=($page-1)*$per_page;
	}

	//echo "Response Found -> ".$_POST['region']."<br>";

	if($_POST['str1'] !="" && $_POST['str2'] != "" ){
		if($_POST['str1']=="date_departure"){
			$date_departure = $_POST['str2'];
			$id_query = "SELECT ship_id FROM cruise_ship_cruise WHERE $_POST[str1] LIKE '%$_POST[str2]%' GROUP BY ship_id";
			$id_res = $mydb->get_results($id_query);
				$ship_id = $id_res[0]->ship_id;
				//print_r($id_res);
				for($i=1;$i<count($id_res);$i++){
					$ship_id = $ship_id.",".$id_res[$i]->ship_id;
				}
				//echo $ship_id; ;
			
			$select_ship_query = "SELECT cc.cruise_operator_name,cc.cruise_cover_image_href,cc.cruise_profile_image_href,csc.ship_name,csc.ship_starts_on,csc.ship_cruise_nights,cc.cruise_title,csc.ship_cruise_only_price,csc.ship_fly_cruise_price, csc.cruise_id AS a, cc.cruise_id AS b FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1  AND csc.ship_starts_on LIKE '%$date_departure%'";
		}
		else{
			$id_query = "SELECT cruise_response_id FROM cruise_cruise WHERE $_POST[str1] = '$_POST[str2]'";
			$id_res = $mydb->get_results($id_query);
				$ship_id = $id_res[0]->cruise_response_id;
				for($i=1;$i<count($id_res);$i++){
					$ship_id = $ship_id.",".$id_res[$i]->cruise_response_id;
				}
			$select_ship_query = "SELECT cc.cruise_operator_name,cc.cruise_cover_image_href,cc.cruise_profile_image_href,csc.ship_name,csc.ship_starts_on,csc.ship_cruise_nights,cc.cruise_title,csc.ship_cruise_only_price,csc.ship_fly_cruise_price, csc.cruise_id AS a, cc.cruise_id AS b FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1  AND csc.ship_id IN ($ship_id)";
		}
			//echo $ship_id;
	}
	else{
		$select_ship_query ="";
		$select_ship_query .= "SELECT cc.cruise_operator_name,cc.cruise_cover_image_href,cc.cruise_profile_image_href,csc.ship_name,csc.ship_starts_on,csc.ship_cruise_nights,cc.cruise_title,csc.ship_cruise_only_price,csc.ship_fly_cruise_price, csc.cruise_id AS a, cc.cruise_id AS b FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1 ";
	}

	if($leaving_from!=""){
		$lq = "SELECT cruise_id FROM cruise_port WHERE port_code = '$leaving_from' GROUP BY cruise_id";
		$select_lq = $mydb->get_results($lq);
		//print_r($select_lq[0]['cruise_id']);
		$leaving_string = $select_lq[0]->cruise_id;
		for($i=1;$i<count($select_lq);$i++)
		{
			//echo $select_lq[$i]->cruise_id;
			$leaving_string = $leaving_string.",".$select_lq[$i]->cruise_id;
		}
		//echo $leaving_string;
		$select_ship_query .= " AND csc.cruise_id IN ($leaving_string)";
		$string .= $leaving_from ;
	}
	/*if($_POST['str1']!="date_departure" ){*/
		$string ="";
		if($region != ""){
			$select_ship_query .= " AND csc.ship_region = '$region'";
			$string .= $region ;
		}
		if($operator != ""){
			$select_ship_query .= " AND co.operator_id = $operator";
			$string .= $operator ;
		}
		if($cruise_ship != ""){
			$select_ship_query .= " AND csc.ship_id = $cruise_ship";
			$string .= $cruise_ship ;
		}
		if($ship_fly_in != ""){
			$select_ship_query .= " AND csc.ship_fly_in = '$ship_fly_in'";
			$string .= $ship_fly_in ;
		}
		if($ship_starts_on != ""){
			$select_ship_query .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
			$string .= $ship_starts_on ;
		}
		if($ship_cruise_nights != ""){
			$select_ship_query .= " AND csc.ship_cruise_nights BETWEEN ".$s_nts." AND ".$e_nts." ";
			$string .= $ship_cruise_nights ;
		}
	/*}*/

	//$select_ship_query .= " GROUP BY csc.ship_name"; /* Comment */
	//$select_ship_query .= " ORDER BY csc.ship_starts_on";
	if(!isset($_GET['start_price']) && !isset($_GET['start_price'])){
		$start_price = $_POST['s'];	
		$end_price = $_POST['e'];
	}
	else{
		$start_price = $_GET['start_price'];	
		$end_price = $_GET['start_price'];	
	}

/* price change start */
//if($start_price != "" && $end_price != "")
if($start_price == 0 && $end_price != ""){
	if($start_price == 0 && $end_price == 10000){
		$select_ship_query .= " AND csc.ship_cruise_only_price  >= 0";
		$price_history = "";
	}
	elseif($start_price == 0 && $end_price == 1000){
		//$price_q_query_unlimit .= " AND csc.ship_cruise_only_price < ".$end_price."";
		$select_ship_query .= " AND csc.ship_cruise_only_price  > 0 AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price < ".$end_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price < ".$end_price.") )";
		$price_history = "in price Below £".number_format($end_price)."";
	}
	else{
		//$select_ship_query = ." AND csc.ship_cruise_only_price < ".$end_price."";
		$select_ship_query .= " AND csc.ship_cruise_only_price  >= 0 AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price < ".$end_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price < ".$end_price.") )";
		$price_history = "in price Below £".number_format($end_price)."";
	}
}
else if($start_price != "" && $end_price == 10000){
	if($start_price == 5000 && $end_price == 10000){
		//$select_ship_query = ." AND csc.ship_cruise_only_price >= ".$start_price."";
		$select_ship_query .= " AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price > ".$start_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price  > ".$start_price.") OR ( csc.ship_cruise_only_price = 0 AND csc.ship_fly_cruise_price = 0 ) ) ";
		$price_history = "in price Bigger than £".number_format($start_price)."";
	}
	else{
		//$select_ship_query = ." AND csc.ship_cruise_only_price >= ".$start_price."";
		$select_ship_query .= " AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price > ".$start_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price  > ".$start_price.") )";
		$price_history = "in price Bigger than £".number_format($start_price)."";
	}
}
elseif($start_price == "" && $end_price == ""){
	$select_ship_query .= " AND csc.ship_cruise_only_price  >= 0";
	$price_history = "";
}
else{
	//$select_ship_query = ." AND csc.ship_cruise_only_price BETWEEN ".$start_price." AND ".$end_price."";
	$select_ship_query .= " AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price BETWEEN ".$start_price." AND ".$end_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price BETWEEN ".$start_price." AND ".$end_price.") )";
	$price_history = "in price range of £".number_format($start_price)." to £".number_format($end_price)."";
}

/* price change end */

	if($from_cruise_date != ""  ){
		$tmp_from = date('Y-m-d H:i:s',strtotime($from_cruise_date));
		$select_ship_query .= " AND csc.ship_starts_on >= '$tmp_from'";
	}
	if($to_cruise_date != ""  ){
		$tmp_to = str_replace('+00:00', '.000Z', gmdate('c',strtotime($to_cruise_date)));
		$select_ship_query .= " AND csc.ship_starts_on <= '$tmp_to'";
	}
	if($from_cruise_date == "" && $to_cruise_date == "" ){
		$todays_date = date('Y-m-d H:i:s');
		$select_ship_query .= " AND csc.ship_starts_on >= '$todays_date'";
	}

	$select_ship_query_unlimit = $select_ship_query;
	
	if($sort_val!=""){
		if($sort_val == "h2l"){
			$select_ship_query .= " ORDER BY IF( csc.ship_cruise_only_price = 0, 1, 0), csc.ship_cruise_only_price DESC , csc.ship_starts_on LIMIT $start,$per_page";
		}
		elseif($sort_val == "l2h"){
			$select_ship_query .= " ORDER BY IF( csc.ship_cruise_only_price = 0, 1, 0), csc.ship_cruise_only_price ASC , csc.ship_starts_on LIMIT $start,$per_page";
		}
		elseif($sort_val == "long"){
			$select_ship_query .= " ORDER BY csc.ship_cruise_nights DESC , csc.ship_starts_on LIMIT $start,$per_page";
		}
		elseif($sort_val == "short"){
			$select_ship_query .= " ORDER BY csc.ship_cruise_nights ASC , csc.ship_starts_on LIMIT $start,$per_page";
		}
		elseif($sort_val == "soon"){
			$select_ship_query .= " ORDER BY csc.ship_starts_on ASC , csc.ship_starts_on LIMIT $start,$per_page";
		}
		elseif($sort_val == "latest"){
			$select_ship_query .= " ORDER BY csc.ship_starts_on DESC , csc.ship_starts_on LIMIT $start,$per_page";
		}
		elseif($sort_val == "c_line"){
			$select_ship_query .= " ORDER BY csc.ship_name ASC , csc.ship_starts_on LIMIT $start,$per_page";
		}
		elseif($sort_val == "c_ship"){
			$select_ship_query .= " ORDER BY csc.cruise_title ASC , csc.ship_starts_on LIMIT $start,$per_page";
		}
	}
	else if( ($start_price != "" && $start_price != "0") && ( $end_price != "" &&  $end_price != "10000") ){
		//$select_ship_query.= " ORDER BY csc.ship_cruise_only_price, csc.ship_fly_cruise_price ASC LIMIT $start,$per_page";
		$select_ship_query.= " ORDER BY IF( csc.ship_cruise_only_price = 0, 1, 0), csc.ship_cruise_only_price LIMIT $start,$per_page";
		//$price_q = $mydb->get_results($select_ship_query." ORDER BY csc.ship_cruise_only_price, csc.ship_fly_cruise_price ASC LIMIT $start,$per_page");
		$price_q = $mydb->get_results($select_ship_query." ORDER BY IF( csc.ship_cruise_only_price = 0, 1, 0), csc.ship_cruise_only_price LIMIT $start,$per_page");
	}
	else{
		$select_ship_query.= " ORDER BY csc.ship_starts_on LIMIT $start,$per_page";
		$price_q = $mydb->get_results($select_ship_query." ORDER BY csc.ship_starts_on LIMIT $start,$per_page");
	}
	$price_q = $mydb->get_results($select_ship_query);

	//echo $string;
	echo "<pre>";
	//print_r($_POST);
	echo $select_ship_query;
	//echo "----";
	//print_r($price_q);
	echo "</pre>";
	$select_ship = $mydb->get_results($select_ship_query);
	//echo count($select_ship);
/* Master Query End--------------------------------------------------------- */
$select_ship_query_unlimit_c = count($mydb->get_results($select_ship_query_unlimit));
echo "<pre id='history' style='display:none;'>";
//print_r($_POST);
$history_str = "";
	//if($_POST['operator']!="" || $_POST['region']!="" || $_POST['cruise_ship']!="" || $_POST['ship_fly_in']!="" || $_POST['ship_starts_on']!="" || $_POST['ship_cruise_nights']!="" ){
		//$history_str .= "Search ";
		$history_str .= "Results Showing ".$select_ship_query_unlimit_c." ";
	//}

	if($_POST['region']=="all" || $_POST['region']==""){ 
		$history_str .= "cruises to Anywhere "; 
	}elseif($_POST['region']!=""){ 
		$history_str .= "cruises to ".$_POST['region']." "; 
	}

	if($_POST['operator']=="all" || $_POST['operator']==""){ 
		$history_str .= "with All Cruiselines "; 
	}elseif($_POST['operator']!=""){
		$val_op = $mydb->get_row("SELECT operator_title FROM cruise_operators WHERE operator_id = ".$_POST['operator']."");
		$history_str .= "with ".$val_op->operator_title." "; 
	}

	if($_POST['cruise_ship']=="all" || $_POST['cruise_ship']==""){ 
		$history_str .= "on Any Ship "; 
	}elseif($_POST['cruise_ship']!=""){
		$val_ship = $mydb->get_row("SELECT cruise_title FROM cruise_cruise WHERE cruise_response_id = ".$_POST['cruise_ship']."");
		$history_str .= "on ".$val_ship->cruise_title." "; 
	}

	if($_POST['ship_fly_in']=="all" || $_POST['ship_fly_in']==""){ 
		$history_str .= "leaving from Any Port "; 
	}elseif($_POST['ship_fly_in']!=""){ 
		$history_str .= "leaving from ".$_POST['ship_fly_in']." "; 
	}

	if($_POST['ship_starts_on']=="all" || $_POST['ship_starts_on']==""){ 
		$history_str .= "in All Months "; 
	}elseif($_POST['ship_starts_on']!=""){ 
		$history_str .= "in ".date('F Y',strtotime($_POST['ship_starts_on']))." "; 
	}

	if($_POST['ship_cruise_nights']=="all" || $_POST['ship_cruise_nights']==""){ 
		$history_str .= "for all Days "; 
	}elseif($_POST['ship_cruise_nights']!=""){ 
		$history_str .= "for ".$_POST['ship_cruise_nights']." Days "; 
	}
	$history_str .= $price_history.".";


$start_price = $_GET['start_price'];	
$end_price = $_GET['end_price'];	
//if($start_price != "" && $end_price != "")
if($start_price == 0 && $end_price != ""){
	if($start_price == 0 && $end_price == 10000){
		$price_history = "";
	}
	else{
		$price_history = "in price Below £".number_format($end_price)."";
	}
}
else if($start_price != "" && $end_price == 10000){
	$price_history = "in price Bigger than £".number_format($start_price)."";
}
elseif($start_price == "" && $end_price == ""){
	$price_history = "";
}
else{
	$price_history = "in price range of £".number_format($start_price)." to £".number_format($end_price)."";
}

echo $history_str."".$price_history;
echo "</pre>";

?>
		<ul>
			<!-- <li><a class="pointer_class iflair_template_value_cruiseship" onclick="iflair_ajax_cruise_operators_left('reset');" >Cruise Lines</a></li> -->
			<li id="sub_list"><a>Cruise Ship<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
				<ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
					<?php
						//echo "SELECT cruise_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_size AS css ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id =$operator GROUP BY cc.cruise_title ORDER BY cruise_title";
				    //$select_cruise_ship_size = $mydb->get_results("SELECT cruise_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_size AS css ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id =$operator GROUP BY cc.cruise_title ORDER BY cruise_title");
				   	if(count($select_ship_query_left_r)==0){
				   		
						$select_cruise_ship_size_all = $mydb->get_results("SELECT cruise_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_size AS css ON co.operator_title = cc.cruise_operator_name GROUP BY cc.cruise_title ORDER BY cruise_title");
						foreach ($select_cruise_ship_size_all as $cruise_ship_size_obj) :
						?>
						<li><a onclick="iflair_ajax_cruise_operators_left('cruise_title','<?php echo $cruise_ship_size_obj->cruise_title; ?>');" class="<?php if($cruise_ship_size_obj->cruise_title==$_COOKIE['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_title; ?></a></li>
						<?php
						endforeach;
				   	}
				   	else{
						foreach ($select_ship_query_left_r as $cruise_ship_size_obj) :
						?>
						<li><a onclick="iflair_ajax_cruise_operators_left('cruise_title','<?php echo $cruise_ship_size_obj->cruise_title; ?>');" class="<?php if($cruise_ship_size_obj->cruise_title==$_COOKIE['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_title; ?></a></li>
						<?php
						endforeach;
				   	}
				    ?>
				</ul>
			</li>
			<li id="sub_list"><a>Ship Size<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
				<ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
					<?php
					$main_size = "";
					$main_size .= "SELECT cc.cruise_ship_size FROM ";
					$main_size .= $conditional_query;
					$main_size .= " GROUP BY cruise_ship_size";
				    $select_cruise_ship_size = $mydb->get_results("$main_size");
				    if(count($select_cruise_ship_size)==0){
				    	$select_cruise_ship_size_all = $mydb->get_results("$main_size");
						foreach ($select_cruise_ship_size_all as $cruise_ship_size_obj) :
						?>
						<li><a onclick="iflair_ajax_cruise_operators_left('cruise_ship_size','<?php echo $cruise_ship_size_obj->cruise_ship_size; ?>');" class="<?php if($cruise_ship_size_obj->cruise_ship_size==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_ship_size; ?></a></li>
						<?php
						endforeach;
				    }
				    else{
						foreach ($select_cruise_ship_size as $cruise_ship_size_obj) :
						?>
						<li><a onclick="iflair_ajax_cruise_operators_left('cruise_ship_size','<?php echo $cruise_ship_size_obj->cruise_ship_size; ?>');" class="<?php if($cruise_ship_size_obj->cruise_ship_size==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_ship_size; ?></a></li>
						<?php
						endforeach;
				    }
				    ?>
				</ul>
			</li>

			<?php /*
			<li id="sub_list">
				<a>Ship Style<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
				<ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
					<?php
						$main_style = "";
						$main_style .= "SELECT cc.crusie_ship_style FROM ";
						$main_style .= $conditional_query;
						$main_style .= " GROUP BY crusie_ship_style";
				   		$select_cruise_ship_style = $mydb->get_results("$main_style");
						if(count($select_cruise_ship_style)==0){
							$select_cruise_ship_style_all = $mydb->get_results("$main_style");
							foreach ($select_cruise_ship_style_all as $cruise_ship_style_obj) :
							?>
							<li><a onclick="iflair_ajax_cruise_operators_left('crusie_ship_style','<?php echo $cruise_ship_style_obj->crusie_ship_style; ?>');" class="<?php if($cruise_ship_style_obj->crusie_ship_style==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_style_obj->crusie_ship_style; ?></a></li>
							<?php
							endforeach;
						}
						else{
							foreach ($select_cruise_ship_style as $cruise_ship_style_obj) :
							?>
							<li><a onclick="iflair_ajax_cruise_operators_left('crusie_ship_style','<?php echo $cruise_ship_style_obj->crusie_ship_style; ?>');" class="<?php if($cruise_ship_style_obj->crusie_ship_style==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_style_obj->crusie_ship_style; ?></a></li>
							<?php
							endforeach;
						}
				    ?>
				</ul>
			</li>
			<li id="sub_list">
				<a>Language<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
				<ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
					<?php
						$select_cruise_language = $mydb->get_results("SELECT cl.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_language AS cl ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id =$operator AND cl.language_code = cc.cruise_language GROUP BY cc.cruise_language ORDER BY cc.cruise_operator_name");
						if(count($select_cruise_language)==0){
							$select_cruise_language_all = $mydb->get_results("SELECT cl.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_language AS cl ON co.operator_title = cc.cruise_operator_name GROUP BY cl.language_code ORDER BY cc.cruise_operator_name");
							foreach ($select_cruise_language_all as $cruise_language_obj) :
							?>
							<li><a onclick="iflair_ajax_cruise_operators_left('cruise_language','<?php echo $cruise_language_obj->language_code; ?>');" class="<?php if($cruise_language_obj->language_code==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_language_obj->language_title; ?></a></li>
							<?php
							endforeach;
						}
						else{
							foreach ($select_cruise_language as $cruise_language_obj) :
							?>
							<li><a onclick="iflair_ajax_cruise_operators_left('cruise_language','<?php echo $cruise_language_obj->language_code; ?>');" class="<?php if($cruise_language_obj->language_code==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_language_obj->language_title; ?></a></li>
							<?php
							endforeach;
						}
				    ?>
				</ul>
			</li>
			*/?>
			<script type="text/javascript">
				jQuery(function() {
				    <?php if(isset($_POST['s'])){ ?>
						var min1 = "<?php echo $_POST['s']; ?>";
						<?php }else{ ?>
						var min1 = 0;
					<?php } ?>
				    <?php if(isset($_POST['e'])){ ?>
						var max1 = "<?php echo $_POST['e']; ?>";
						<?php }else{ ?>
						var max1 = 10000;
					<?php } ?>
				    jQuery( "#slider-range" ).slider({
				      range: true,
				      min: 0,
				      max: 10000,
				      values: [ min1, max1 ],
				      slide: function( event, ui ) {
				        jQuery( "#amount" ).html( "<span class='start_a'>£" + ui.values[ 0 ] + "</span><span class='end_a'>£" + ui.values[ 1 ] +"</span>" );
						jQuery( "#amount1" ).val(ui.values[ 0 ]);
						jQuery( "#amount2" ).val(ui.values[ 1 ]);
				      }
				    });

				    jQuery( "#amount" ).html( "<span class='start_a'>£" + jQuery( "#slider-range" ).slider( "values", 0 ) +
				     "</span><span class='end_a'>£" + jQuery( "#slider-range" ).slider( "values", 1 ) + "</span>" );
				});
				/*function price_filter(){
					alert("price");
				}*/
				jQuery(document).ready(function(){
			        jQuery( ".ui-slider-handle" ).mouseup(function() {


				    //jQuery('input[name="radio_price"]').attr('checked', false);
				    //jQuery('.radio_price').removeAttr('checked');
				    /*jQuery('input[name="radio_price"]').each(function(i) {
					    this.checked = false;
					});*/
					//jQuery('input[name="radio_price"]').prop('checked', false);
					//jQuery('.radio_price').attr('checked', false);
					//alert("12121");
					//jQuery("input[name='radio_price']").prop("checked",false);

			        jQuery('.loader').css('display','block');
			        var s = jQuery("#amount1").val();
			        var e = jQuery("#amount2").val();
			        var pagenumb = jQuery(".currentdiv").attr("id");
				var region = jQuery('#cruise_region').val();
				var operator = jQuery('#cruise_operator').val();
				var cruise_ship = jQuery('#cruise_ship').val();
				var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
				var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
				var ship_cruise_nights = jQuery('#cruise_ship_cruise_nights').val();

var tab_id = jQuery(".active_tab").attr('id');
<?php $listing_page_id = get_site_option( 'iflair_cruise_theme_ship_listing_page' );?>
var newURL = "<?php echo get_permalink($listing_page_id); ?>";
/*if(jQuery(".active_tab").attr('id')=="1"){
	var path = "rivercruise/";
}
else if(jQuery(".active_tab").attr('id')=="2"){
	var path = "oceansearch/";
}
else{*/
	var path = "";
/*}*/
history.pushState({},"URL Rewrite Example",newURL+""+path+"?cruise_region="+region+"&cruise_operator="+operator+"&cruise_ship="+cruise_ship+"&cruise_ship_fly_in="+ship_fly_in+"&cruise_ship_starts_on="+ship_starts_on+"&cruise_ship_cruise_nights="+ship_cruise_nights+"&tab_id="+tab_id+"&start_price="+s+"&end_price="+e);

			        jQuery.ajax({
			            type: "POST",
			            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
			            data: ({
			                action: 'price_filter_result',
			                s: s,
			                e: e,
			                pagenumb:'1',
				            region: region,
				            operator: operator,
				            cruise_ship: cruise_ship,
				            ship_fly_in: ship_fly_in,
				            ship_starts_on: ship_starts_on,
				            ship_cruise_nights: ship_cruise_nights,
			                query:"<?php echo $select_ship_query_unlimit; ?>"
			            }),
			            success: function (response) {
			            	
			                //alert(response);
                			jQuery('.result-part').html(response);
				            var history=jQuery('#history1').html();
				            //alert(history);
				            jQuery("#result_story").html(history);
	                		//alert(s);
	                		//jQuery.cookie('start_price',s, {expires: 1, path:'/' });
							//jQuery.cookie('end_price',e, {expires: 1, path:'/' });
                			jQuery('.loader').css('display','none');
			        		//alert( s+" --- "+e );
							/*
							jQuery(".mCustomScrollbar").slideUp();
							jQuery(".mCustomScrollbar li a").removeClass("active_left");*/

							
			            }
			        });

			        });


			      })
			</script>
			<?php /*echo '<pre>';
			print_r($_GET);
			print_r($_REQUEST);
			echo '</pre>';*/
			 ?>

			<li id="sub_list" class="ui-slider_li"><a>Price Range (per person)</a>
				<div id="slider-range"></div>
				<p id="amount"></p>
				<input type="hidden" name="start_price" value="<?php if(isset($_POST['s'])){ echo $_POST['s'];}else{ echo "0"; }; ?>" id="amount1">
				<input type="hidden" name="end_price" value="<?php if(isset($_POST['e'])){ echo $_POST['e'];}else{ echo "10000"; }; ?>" id="amount2">
				<!-- <span onclick="price_filter();">find</span> -->
			<hr style="margin: 10px 0 0 0;">
				<div class="pricearea">
					<div class="pricerow">
						<div class="priceradio"><input id="1_radio" type="radio" class="radio_price" name="radio_price" value="1" onclick="radio_range(1);"></div>
						<label class="pricerange" for="1_radio">upto £1000</label>  
					</div>
					<div class="pricerow">
						<div class="priceradio"><input id="2_radio" type="radio" class="radio_price" name="radio_price" value="2" onclick="radio_range(2);"></div>
						<label class="pricerange" for="2_radio"> £1000 - £1500</label>  
					</div>
					<div class="pricerow">
						<div class="priceradio"><input id="3_radio" type="radio" class="radio_price" name="radio_price" value="3" onclick="radio_range(3);"></div>
						<label class="pricerange" for="3_radio"> £1500 - £2000</label>  
					</div>
					<div class="pricerow">
						<div class="priceradio"><input id="4_radio" type="radio" class="radio_price" name="radio_price" value="4" onclick="radio_range(4);"></div>
						<label class="pricerange" for="4_radio"> £2000- £3000</label>  
					</div>
					<div class="pricerow">
						<div class="priceradio"><input id="5_radio" type="radio" class="radio_price" name="radio_price" value="5" onclick="radio_range(5);"></div>
						<label class="pricerange" for="5_radio"> £3000 - £4000</label>  
					</div>
					<div class="pricerow">
						<div class="priceradio"><input id="6_radio" type="radio" class="radio_price" name="radio_price" value="6" onclick="radio_range(6);"></div>
						<label class="pricerange" for="6_radio"> £4000 - £5000</label>  
					</div>
					<div class="pricerow">
						<div class="priceradio"><input id="7_radio" type="radio" class="radio_price" name="radio_price" value="7" onclick="radio_range(7);"></div>
						<label class="pricerange" for="7_radio"> over £5000</label>  
					</div>
				</div>
				<script type="text/javascript">
					function radio_range(str){
						if(str==1){
							jQuery("#amount1").val(0);
							jQuery("#amount2").val(1000);
							var min1 = 0;
							var max1 = 1000;	
						}
						else if(str==2){
							jQuery("#amount1").val(1000);
							jQuery("#amount2").val(1500);
							var min1 = 1000;
							var max1 = 1500;	
						}
						else if(str==3){
							jQuery("#amount1").val(1500);
							jQuery("#amount2").val(2000);	
							var min1 = 1500;
							var max1 = 2000;
						}
						else if(str==4){
							jQuery("#amount1").val(2000);
							jQuery("#amount2").val(3000);	
							var min1 = 2000;
							var max1 = 3000;
						}
						else if(str==5){
							jQuery("#amount1").val(3000);
							jQuery("#amount2").val(4000);	
							var min1 = 3000;
							var max1 = 4000;
						}
						else if(str==6){
							jQuery("#amount1").val(4000);
							jQuery("#amount2").val(5000);	
							var min1 = 4000;
							var max1 = 5000;
						}
						else if(str==7){
							jQuery("#amount1").val(5000);
							jQuery("#amount2").val(10000);	
							var min1 = 5000;
							var max1 = 10000;
						}

				    
					    jQuery( "#slider-range" ).slider({
					      range: true,
					      min: 0,
					      max: 10000,
					      values: [ min1, max1 ],
					      slide: function( event, ui ) {
					        jQuery( "#amount" ).html( "<span class='start_a'>£" + ui.values[ 0 ] + "</span><span class='end_a'>£" + ui.values[ 1 ] +"</span>" );
							jQuery( "#amount1" ).val(ui.values[ 0 ]);
							jQuery( "#amount2" ).val(ui.values[ 1 ]);
					      }
					    });
					    jQuery( "#amount" ).html( "<span class='start_a'>£" + jQuery( "#slider-range" ).slider( "values", 0 ) +
					     "</span><span class='end_a'>£" + jQuery( "#slider-range" ).slider( "values", 1 ) + "</span>" );
						jQuery(".ui-slider-handle").trigger("mouseup");
						//var checked_val = jQuery(this).value;
						//jQuery("input[name='radio_price']").filter("[value=checked_val]").prop("checked",true);
					}
				</script>
			</li>

		</ul>
	</div>
	
</div>

		<div class="result-part">
<?php
	
	if(count($select_ship) == 0)
	{
		echo "<div class='no_result_area'>No Cruise Found ..<div>";
	}
	else
	{
		//echo $page;
		//echo $per_page;
		//echo $select_ship_query;
		cruise_pagging($page,$per_page,$select_ship_query_unlimit);
		?>
		<div class="sortable_filter_area" style="">
			<select onchange="sort_search_filter();" name="sort" id="sort">
				<option value=""> -- Sort Order -- </option>
				<option <?php if(!empty($sort_val) && $sort_val == "c_line" ){ echo "selected"; }; ?> value="c_line">Cruise Line</option>
				<option <?php if(!empty($sort_val) && $sort_val == "c_ship" ){ echo "selected"; }; ?> value="c_ship">Cruise Ship</option>
			  <optgroup label="Departure">
			    <option <?php if(!empty($sort_val) && $sort_val == "soon" ){ echo "selected"; }; ?> value="soon">Soonest</option>
			    <option <?php if(!empty($sort_val) && $sort_val == "latest" ){ echo "selected"; }; ?> value="latest">Latest</option>
			  </optgroup>
			  <optgroup label="Price">
			    <option <?php if(!empty($sort_val) && $sort_val == "h2l" ){ echo "selected"; }; ?> value="h2l">Highest Price</option>
			    <option <?php if(!empty($sort_val) && $sort_val == "l2h" ){ echo "selected"; }; ?> value="l2h">Lowest Price</option>
			  </optgroup>
			  <optgroup label="Duration">
			    <option <?php if(!empty($sort_val) && $sort_val == "long" ){ echo "selected"; }; ?> value="long">Longest</option>
			    <option <?php if(!empty($sort_val) && $sort_val == "short" ){ echo "selected"; }; ?> value="short">Shortest</option>
			  </optgroup>
			</select>
		</div>
		<?php
		echo "<div class='package_cruise'>";
		echo "</div>";

		for($i=0;$i<count($select_ship);$i++)
		{
			/*print "<pre>";
			print_r($select_ship[$i]);*/
		?>

<div class="mediter-box clearfix">
	<div class="medi-left">
		<div class="newtablecruiseimg">
			<div class="netablecellcruiseimg">
				<img src="<?php if($select_ship[$i]->cruise_profile_image_href!=""){ echo "http://ekups3e.cloudimg.io/s/resize/100/".str_replace('//www','www',$select_ship[$i]->cruise_profile_image_href); }else{ echo esc_url( get_template_directory_uri() )."/images/noImageAvailable.png"; } ?>" class="img-responsive">
			</div>
		</div>
		<div class="newtableimg">
			<div class="netablecellimg">
				<img src="<?php if($select_ship[$i]->cruise_cover_image_href!=""){ echo "http://ekups3e.cloudimg.io/s/crop/300x200/".str_replace('//www','www',$select_ship[$i]->cruise_cover_image_href); }else{ echo esc_url( get_template_directory_uri() )."/images/noImageAvailable.png"; } ?>" class="img-responsive">
			</div>
		</div>
		<?php /*<img src="<?php if($select_ship[$i]->cruise_cover_image_href!=""){ echo "http://ekups3e.cloudimg.io/s/resize/200/".$select_ship[$i]->cruise_cover_image_href; }else{ echo esc_url( get_template_directory_uri() )."/images/no-property-image.jpg"; } ?>" class="img-responsive"> */?>
		<?php
		/*
		<img src="<?php echo esc_url( get_template_directory_uri() )."/images/loader.gif"; ?>" data-original="http://ekups3e.cloudimg.io/s/resize/200/<?php if($select_ship[$i]->cruise_cover_image_href!=""){ echo $select_ship[$i]->cruise_cover_image_href; }else{ echo esc_url( get_template_directory_uri() )."/images/no-property-image.jpg"; } ?>" class="img-responsive lazy<?php echo $i; ?>">
					<script>
						jQuery( document ).ready(function() {
							jQuery("img.lazy<?php echo $i; ?>").lazyload({skip_invisible : true});
						});
					</script>
		*/
		?>
	</div>
	<div class="medi-mid mid-mid-two">
	<?php
	$offer_query = "SELECT * FROM ".BASEPOKE_LIST." as bl INNER JOIN ".BASEPOKE_CRUISES." as bc ON bl.id = bc.basepoke_id WHERE bc.offer_start_date < curdate() and bc.offer_end_date > curdate() AND bc.cruise_id = '".$select_ship[$i]->a."'";
	$found_offer = $wpdb->get_row($offer_query);
	?>
		<h3><?php /*if($found_offer->extra_info != ""){ echo $found_offer->extra_info; }else{*/ echo $select_ship[$i]->ship_name; /*}*/ ?></h3>
		<?php if($found_offer->cabin_info!=""){ ?>
		<span class="package_class"><?php echo $found_offer->cabin_info; ?></span>
		<?php } ?>
		<p class="date_new_site"><?php if($found_offer->departure_date != ""){ echo date('d M Y',strtotime($found_offer->departure_date)); }else{ $ship_date=$select_ship[$i]->ship_starts_on; echo date('d M Y',strtotime($ship_date)); } ?></p>
		<p class="day_new_site daytotal"><?php /*if($found_offer->cruise_nights != ""){ echo $found_offer->cruise_nights; }else{*/ echo $select_ship[$i]->ship_cruise_nights; /*}*/ ?> Nights</p>
		<p class="ship_new_site"><div class="tool"></div> <div class="shiptitle">Ship</div><span class="toolname">: <?php echo $select_ship[$i]->cruise_title; ?></span></p>
		<?php if($found_offer->offer_short_summery != ""){ echo "<div class='offer_short_summery'>".$found_offer->offer_short_summery."</div>"; } ?>
		<div class="itecolor_parent" id="itecolor_<?php echo $i; ?>">
			<p class="itinerary_new_site">
				<span class="itecolor">itinerary</span>
			</p>
			<div class="itecolor-detail">
				<p class="itinerary_new_site">
					<?php
					/*if($found_offer->ports_visited != ""){ echo str_replace(","," <i class='fa fa-caret-right'></i> ",$found_offer->ports_visited); }
					else{ */
						$select_itinerary_query ="";
						$select_itinerary_query .= "SELECT port_name FROM cruise_port WHERE cruise_id = '";
						$select_itinerary_query .= $select_ship[$i]->a;
						$select_itinerary_query .= "' ORDER BY id";
						//echo $select_itinerary_query;
						$select_itinerary = $mydb->get_results($select_itinerary_query);
						$itinerary_count = count($select_itinerary);
						if($itinerary_count!="0"){
							echo $select_itinerary[0]->port_name;
							for($i1=1;$i1<count($select_itinerary);$i1++)
							{
								//echo "<pre>";
								//print_r($select_port);
								//echo "</pre>";
								?> <i class="fa fa-caret-right"></i>
								<?php echo $select_itinerary[$i1]->port_name;
								?>
							<?php
							}
						}
					/*}*/

					?>
				</p>
			</div>
		</div>
	</div>
	<div class="medi-main-new">
		<?php
			/*echo "<pre>";
			print_r($found_offer);
			echo "</pre>";*/
			if(!empty($found_offer)){
				$offer_class = '<div class="offer_class"></div>';
				$offer_class2 = " offer_class2";
				//echo '<div class="'.$offer_class.'"><img src="'.esc_url( get_template_directory_uri() ).'/images/superdeal.png" ></div>';
			}
			else{
				$offer_class = "";
				$offer_class2 = "";
			}
		?>
	<?php
		$price1 = $select_ship[$i]->ship_cruise_only_price;
		$price2 = $select_ship[$i]->ship_fly_cruise_price;
		
		if ($price1 != "0") 
		{
	?>
	<div class="medi-right">
		<?php echo $offer_class; ?>
		<div class="main_added_text">
		<?php 
		//print_r($found_offer);
		if(!empty($found_offer->offer_price)){
			?>
			<h2>Cruise Only</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>From <span class="textbld">£<?php echo number_format($found_offer->offer_price); ?></span>  per person</p>
			<?php
		}
		else if($price1=="0"){
			?>
			<h2>Cruise Only</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>Enquire</p>
			<?php
		}
		else{
			?>
			<h2>Cruise Only</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>From <span class="textbld">£<?php echo number_format($price1); ?></span>  per person</p>
			<?php
		}
		/*elseif($price1=="0" && $price2=="0")
		{
			?>
			<h2>Cruise Only</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>Please enquire for today’s price</p>
			<?php
		}
		elseif( ( $price1!="0" && $price1 < $price2 ) || $price2== "0" )
		{
			?>
			<h2>Cruise Only</h2>
			<?php echo $found_offer->package_summary; ?>
			<p><span class="textbld">£<?php echo number_format($price1); ?></span> PP</p>
			<?php
		}
		elseif( ( $price2!="0" && $price1 > $price2 ) || $price1== "0" )
		{
			?>
			<h2>Cruise Only</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>From <span class="textbld">£<?php echo number_format($price2); ?></span>  per person</p>
			<?php
		}*/
		/*elseif( ( $price1!="0" && $price2!="0" ) && $price1==$price2 )
		{
			?>
			<h2>Cruise Only</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>From <span class="textbld">£<?php echo number_format($price1); ?></span>  per person</p>
			<?php
		}*/
		/*else{
			?>
			<!-- <h2>Cruise Only</h2> -->
			<?php echo $found_offer->package_summary; ?>
			<p class="text1">Please enquire for today’s price</p>
			<?php
		}*/
		echo '<div class="'.$offer_class2.'"></div>';
		?>
		</div>
		<?php $detail_page_id = get_site_option( 'iflair_cruise_theme_ship_detail_page' );?>
		<div class="added_img">
			<a target="_blank" href="<?php echo get_page_link($detail_page_id);?>?cruise_id=<?php echo $select_ship[$i]->a; ?>&cruise_type=cruiseonly" class="info-bt new_btn_blue new_detail_btn"> Get live price <i class="fa fa-caret-down"></i></a>
					<!-- <script>jQuery("img.lazy").lazyload();</script> -->
			<a onclick="cruise_detail_of('<?php echo $select_ship[$i]->cruise_id; ?>');" class="new_btn_blue fa fa-caret-down itinerary_btn">Itinerary <i class=""></i></a>
		</div>
	</div>
	<?php } ?>

	<div class="medi-right">
		<?php //echo $offer_class; ?>
		<div class="main_added_text">
			<h2>Fly Cruise</h2>
			<p>Enquire</p>
		</div>

		<?php 
			$detail_page_id = get_site_option( 'iflair_cruise_theme_ship_detail_page' );

			/*print "<pre>";
			print_r($select_ship[$i]);
			print "</pre>";*/
		?>
		<div class="added_img">
			<!-- <a target="_blank" href="<?php echo get_page_link($detail_page_id);?>?cruise_id=<?php echo $select_ship[$i]->a; ?>" class="info-bt new_btn_blue new_detail_btn"> Click Here <i class="fa fa-caret-down"></i></a> -->
			<!-- <button type="button" class="btn btn-primary btn-lg manual_model_slide" id="manual_model_slide" data-toggle="modal" data-target="#slide_down_div" cuiseid="<?php echo $select_ship[$i]->a; ?>">Click Here</button> -->
			<a target="_blank" href="<?php echo get_page_link($detail_page_id);?>?cruise_id=<?php echo $select_ship[$i]->a; ?>&cruise_type=fly" class="info-bt new_btn_blue new_detail_btn"> Click here  <i class="fa fa-caret-down"></i></a>
					<!-- <script>jQuery("img.lazy").lazyload();</script> -->
			<a onclick="cruise_detail_of('<?php echo $select_ship[$i]->cruise_id; ?>');" class="new_btn_blue fa fa-caret-down itinerary_btn">Itinerary <i class=""></i></a>
		</div>

		<?php /*
		<div class="slide_down_div" style="display: none;" id="slide_down_div_<?php echo $select_ship[$i]->a; ?>" >
			<div class="modal-dialog" role="document">
				<div class="modal-content enquiry-down
							    ">
					<div class="modal-header">
							<button type="button" class="close" onclick="close_me('<?php echo $select_ship[$i]->a; ?>');"><span aria-hidden="true">&times;</span></button>
							
							<h4 class="modal-title" id="myModalLabel" style="text-align:left;"><?php $arrival=$select_ship[$i]->ship_starts_on; echo $select_ship[$i]->cruise_title." | ".$select_ship[$i]->ship_name." | ".date('d M Y',strtotime($arrival)); ?></h4>
					</div>
					<div class="modal-body ">
						<?php echo do_shortcode("[shipenquiryform ship_name='".$select_ship[$i]->ship_name."' cruise_name='".$select_ship[$i]->cruise_title."' date='".date('d M Y',strtotime($arrival))."']"); ?>
						
						<div style="clear:both;"></div>
		      		</div>

		    	</div>
		  	</div>
		</div>
		*/?>

	</div>
	</div>
	<div class="medi-right">
		<div class="added_img">
			<!-- <button type="button" class="btn btn-primary btn-lg manual_model_slide modal-test" id="manual_model_slide" data-toggle="modal" data-target="#slide_down_div" --> <!-- 
			<button type="button" class="btn btn-primary btn-lg manual_model_slide modal-test" id="manual_model_slide_<?php //echo $select_ship[$i]->a; ?>" onclick="open_enq('<?php //echo $select_ship[$i]->a; ?>');" cuiseid="<?php //echo $select_ship[$i]->a; ?>">ENQUIRY</button> -->
			<?php
			?>
			<button type="button" class="btn btn-primary btn-lg manual_model_slide modal-test" id="manual_model_slide_<?php echo $select_ship[$i]->a; ?>" onclick="listing_inq('<?php echo $select_ship[$i]->ship_name; ?>','<?php echo $select_ship[$i]->ship_starts_on; ?>','<?php echo $select_ship[$i]->cruise_title; ?>','<?php echo $select_ship[$i]->a; ?>','<?php echo $select_ship[$i]->cruise_operator_name; ?>');" id="listing_inq_<?php echo $select_ship[$i]->a; ?>" >ENQUIRY</button>

		</div>
	</div>
</div>
<div class="cruse-information clearfix">
	<div class="above_map_area"><h2 class="above_map_title">Cruise Itinerary</h2>
	<a target="_blank" href="<?php echo get_page_link($detail_page_id);?>?cruise_id=<?php echo $select_ship[$i]->a; ?>" class="info-bt new_btn_blue above_map"> VIEW DETAILS <i class="fa fa-caret-down"></i></a></div>
	<div class="scroll<?php echo $select_ship[$i]->cruise_id; ?> scroll_empty">
		<div class="loader_1" style="display:none;text-align: center; padding: 0px 0px 30px;">
			<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader_1.gif">
		</div>
	</div>

	<?php
	/*echo "<pre>";
	print_r($select_ship[$i]);
	echo "</pre>";*/
	?>
	<div class="clearfix right">
		<?php /*<a href="<?php echo get_page_link($detail_page_id);?>?ship_id=<?php echo $select_ship[$i]->b; ?>" class="info-bt new_btn_blue">VIEW MORE INFORMATION</a> */?>
	</div>
</div>

		<?php
		}
		echo "<br>";
		cruise_pagging($page,$per_page,$select_ship_query_unlimit);
	}
	?>
<script type="text/javascript">
	
	jQuery(".content").mCustomScrollbar();
	var item = jQuery(".active_left");
	//var item = jQuery('ul li.sub_list').find('li').children('ul.sub_list');
	//alert(item);
    item.parent().parent().css('display','block');
    item.parent().parent().parent().parent().css('display','block');

	var dateToday = new Date();
    jQuery("#cruise_ship_departure_date").datepicker({ 
      minDate: dateToday ,
      dateFormat: 'yy-mm-dd'
    });

	jQuery(this).next('ul').slideUp();
	jQuery('#sub_list a').on('click',function(){
		jQuery(this).next('ul').slideToggle();
	});

function iflair_ajax_cruise_operators_left(str1,str2){  
		jQuery('.loader').css('display','block');	
		var pagenumb='1';
		var str1 = str1;
		//alert(str1);	
		/*if(str1=='date_departure'){
			var str2 =jQuery('#cruise_ship_departure_date').val();
			jQuery('#cruise_region').prop('selectedIndex',0);
			jQuery('#cruise_operator').prop('selectedIndex',0);
			jQuery('#cruise_ship').prop('selectedIndex',0);
			jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
			jQuery('#cruise_leaving_from').prop('selectedIndex',0);
			jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
			jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
		}*/
		if(str1=='reset'){
			jQuery('#cruise_region').prop('selectedIndex',0);
			jQuery('#cruise_operator').prop('selectedIndex',0);
			jQuery('#cruise_ship').prop('selectedIndex',0);
			jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
			jQuery('#cruise_leaving_from').prop('selectedIndex',0);
			jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
			jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
		}
		else{
			var str2 = str2;
			/*jQuery('#cruise_region').prop('selectedIndex',0);
			jQuery('#cruise_operator').prop('selectedIndex',0);
			jQuery('#cruise_ship').prop('selectedIndex',0);
			jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
			jQuery('#cruise_leaving_from').prop('selectedIndex',0);
			jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
			jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);*/
		}

		jQuery.cookie('str1', str1,{expires: 1,path: "/" });
		jQuery.cookie('str2', str2,{expires: 1,path: "/" });

		//alert(str2);
		var operator = jQuery('#cruise_operator').val();
		var region = jQuery('#cruise_region').val();
		var pagenumb=pagenumb;
		var touroperator = jQuery('#iflair_template_cruise_operators').val();
		//alert(jQuery("#iflair_template_cruise_operators option:selected").text());
		var shipsize = jQuery('#iflair_template_cruise_ship_size').val();
		var shipstyle = jQuery('#iflair_template_cruise_ship_style').val();
		var shiplanguage = jQuery('#iflair_template_cruise_language').val();
		var s = jQuery('#amount1').val();
		var e = jQuery('#amount2').val();
	var from_cruise_date = jQuery('#from_cruise_date').val();
	var to_cruise_date = jQuery('#to_cruise_date').val();
		var sort_val = jQuery("#sort").val();
        jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'cruise_filter_response',
                str1: str1,
                str2: str2,
            	operator: operator,
				region: region,
                pagenumb:pagenumb,
	            from_cruise_date:from_cruise_date,
	            to_cruise_date:to_cruise_date,
				sort_val:sort_val,
                s: s,
                e: e
            }),
            success: function (response) {
        		jQuery(".new_design_homepage .home_page_area").remove();
                //alert(response);
                jQuery('#replace_query_ajax').html(response);
	                jQuery(".content").mCustomScrollbar();
			    /*jQuery("#cruise_ship_departure_date").datepicker({ 
			      minDate: dateToday ,
			      dateFormat: 'yy-mm-dd'
			    });*/
			    if(s=="0" && e=="10000"){

			    }
			    else if(e=="1000"){
					jQuery('#1_radio').prop('checked',true);
			    }
			    else if(e=="1500"){
					jQuery('#2_radio').prop('checked',true);
			    }
			    else if(e=="2000"){
					jQuery('#3_radio').prop('checked',true);
			    }
			    else if(e=="3000"){
					jQuery('#4_radio').prop('checked',true);
			    }
			    else if(e=="4000"){
					jQuery('#5_radio').prop('checked',true);
			    }
			    else if(e=="5000"){
					jQuery('#6_radio').prop('checked',true);
			    }
			    else if(s!="0" && e=="10000"){
					jQuery('#7_radio').prop('checked',true);
			    }
            	jQuery('.loader').css('display','none');
			    
            }
        });
}

		jQuery(document).ready(function(){

			jQuery(".modal-test").click(function(){
				var cuiseid = jQuery(this).attr('cuiseid');
				//alert(cuiseid);
				jQuery("#slide_down_div_"+cuiseid+" #iflair_enquiry_cruise_id").val(cuiseid);
			})

			jQuery(".itecolor-detail").hide();
			jQuery(".itecolor").click(function(){
				var ParentId = jQuery(this).parents(".itecolor_parent").attr("id");
				jQuery("#"+ParentId+" .itecolor-detail").toggle("slow");
			});

			var check = jQuery(".active_tab").attr('id');		
				if(check=="1" || check=="2" || check=="3" ){
					var tab_id = check;
				}
				else{
					var tab_id = jQuery(".active_tab").attr('id');
				}

			jQuery("#pagination li").click(function(){
				jQuery('.loader').css('display','block');
				var pageNum = this.id;
				var region = jQuery('#cruise_region').val();
				var operator = jQuery('#cruise_operator').val();
				var cruise_ship = jQuery('#cruise_ship').val();
				var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
				var leaving_from = jQuery('#cruise_leaving_from').val();
				var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
				var ship_cruise_nights = jQuery('#cruise_ship_cruise_nights').val();
				var s = jQuery('#amount1').val();
				var e = jQuery('#amount2').val();

	var from_cruise_date = jQuery('#from_cruise_date').val();
	var to_cruise_date = jQuery('#to_cruise_date').val();
		var sort_val = jQuery("#sort").val();

				    jQuery.ajax({
			            type: "POST",
			            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
			            data: ({
			                action: 'cruise_filter_response',
				            <?php if($_COOKIE['str1']!=""){ ?>str1: <?php echo "'".$_COOKIE['str1']."',"; } ?>
				            <?php if($_COOKIE['str2']!=""){ ?>str2: <?php echo "'".$_COOKIE['str2']."',"; } ?>
				            region: region,
				            tab_id : tab_id,
				            operator: operator,
				            cruise_ship: cruise_ship,
				            ship_fly_in: ship_fly_in,
				            leaving_from: leaving_from,
				            ship_starts_on: ship_starts_on,
				            ship_cruise_nights: ship_cruise_nights,
				            from_cruise_date:from_cruise_date,
				            to_cruise_date:to_cruise_date,
							sort_val:sort_val,
				            s:s,
				            e:e,
			                pagenumb:pageNum
			            }),
			            success: function (response) {
        					jQuery(".new_design_homepage .home_page_area").remove();
			                //alert(response);
			                jQuery('#replace_query_ajax').html(response);
			                //jQuery('#filter_title').empty();
				            //var filter_title=jQuery('#filter_title_tmp').html();
				            //alert(filter_title);
				            //jQuery('#filter_title-new').html(filter_title);
	                		jQuery(".content").mCustomScrollbar();

			    if(s=="0" && e=="10000"){

			    }
			    else if(e=="1000"){
					jQuery('#1_radio').prop('checked',true);
			    }
			    else if(e=="1500"){
					jQuery('#2_radio').prop('checked',true);
			    }
			    else if(e=="2000"){
					jQuery('#3_radio').prop('checked',true);
			    }
			    else if(e=="3000"){
					jQuery('#4_radio').prop('checked',true);
			    }
			    else if(e=="4000"){
					jQuery('#5_radio').prop('checked',true);
			    }
			    else if(e=="5000"){
					jQuery('#6_radio').prop('checked',true);
			    }
			    else if(s!="0" && e=="10000"){
					jQuery('#7_radio').prop('checked',true);
			    }
			            	jQuery('.loader').css('display','none');
			            }
			        });
				
			});
		});

		jQuery(document).ready(function(){
			jQuery('.itinerary_btn').click(function(){
				//jQuery(this).parent().parent().parent().next('.cruse-information').slideToggle();
				if(jQuery(this).parent().parent().parent().next('.cruse-information').hasClass("a1")){
					jQuery(this).parent().parent().parent().next('.cruse-information').removeClass("a1");
					jQuery(this).parent().parent().parent().next('.cruse-information').slideUp();
				}
				else{
					jQuery('.cruse-information').removeClass("a1");
					jQuery('.cruse-information').slideUp();
					jQuery(this).parent().parent().parent().next('.cruse-information').slideDown();
					jQuery(this).parent().parent().parent().next('.cruse-information').addClass("a1");
				}
			});
			/*jQuery('.itinerary_btn').click(function(){
				if(jQuery(this).parent().parent().parent().hasClass("active_information")){
					jQuery(this).parent().parent().parent().slideUp();
					jQuery(this).parent().parent().parent().removeClass("active_information");
					jQuery('.active_information').slideUp();
				}
				else{
					jQuery(this).parent().addClass('active_itinerary');
					jQuery(this).parent().parent().parent().removeClass("active_information");
					jQuery(this).parent().parent().parent().next('.cruse-information').slideDown();
					jQuery(this).parent().parent().parent().slideDown();
					jQuery(this).parent().parent().parent().addClass("active_information");
					jQuery('.active_information').slideDown();
				}
			});*/
		});

		function cruise_detail_of(cruise_id){
			var check = jQuery(".active_tab").attr('id');
			if(check=="1" || check=="2" || check=="3" ){
				var tab_id = check;
			}
	        jQuery('.loader_1').css('display','block');
			var id = id;
			var ship_name = ship_name;
			var cruise_id = cruise_id;
			var region = jQuery('#cruise_region').val();
			var operator = jQuery('#cruise_operator').val();
			var cruise_ship = jQuery('#cruise_ship').val();
			var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
			var leaving_from = jQuery('#cruise_leaving_from').val();
			var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
			var ship_cruise_nights = jQuery('#cruise_ship_cruise_nights').val();
			jQuery.ajax({
	            type: "POST",
	            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
	            data: ({
	                action: 'cruise_detail',
		            region: region,
		            tab_id : tab_id,
		            operator: operator,
		            cruise_ship: cruise_ship,
		            ship_fly_in: ship_fly_in,
		            leaving_from: leaving_from,
		            ship_starts_on: ship_starts_on,
		            ship_cruise_nights: ship_cruise_nights,
		            id: id,
		            ship_name: ship_name,
		            cruise_id: cruise_id
	            }),
	            success: function (response) {
	                //alert(response);
	            	//jQuery('.scroll_empty').empty();
	                jQuery('.scroll'+cruise_id).html(response);
	                jQuery(".content").mCustomScrollbar();
	            	jQuery('.loader_1').css('display','none');
	            }
	        });
		}


</script>
	</div>
</div>
	<?php
	exit();
}
function cruise_detail(){
global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
$mainsiteprefix='cm_';
$agentsiteurl=get_option('siteurl');
$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
$agentsiteid=$agentsitedetail->id;
$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
$agent_assign_operator;

$cruise_id = $_POST['cruise_id'];

$select_port_query ="";
$select_port_query .= "SELECT port_name,arrives_on,location FROM cruise_port WHERE cruise_id = '";
$select_port_query .= $cruise_id;
$select_port_query .= "' ORDER BY id";
//echo $select_cruise_query;
$select_port = $mydb->get_results($select_port_query);
//echo count($select_ship);

if(count($select_port) == 0)
{
	echo "<span>No Port Details Found</span><br><br>";
}
else
{
	?>
	<div class="scroll">
		<div class="clearfix content mCustomScrollbar" style="max-height:200px;text-align: left;" id="content-<?php echo $cruise_id; ?>">
			<div class="c-row">
				<div class="c-1">Destination</div>
				<div class="c-2">Arrival</div>
				<div class="c-3">Location</div>
			</div>
			<?php
			for($i1=0;$i1<count($select_port);$i1++)
			{
				//echo "<pre>";
				//print_r($select_port);
				//echo "</pre>";
			?>
			<div class="info-row">
				<div class=" c-1 f-detail"><?php echo $select_port[$i1]->port_name; ?></div>
				<div class=" c-2 f-detail"><?php $port_arrival=$select_port[$i1]->arrives_on; echo date('d M Y',strtotime($port_arrival)); ?></div>
				<div class=" c-3 f-detail"><?php echo $select_port[$i1]->location; ?></div>
			</div>
			<?php
				$loc = $select_port[$i1]->port_name;
				$loc_ary = "'".$loc."',".$loc_ary;
			}
			?>
		</div>
			<div id="map" class="map_list"></div>
	</div>
 
	<script type="text/javascript">
	var marker;
	var delay = 100;
	var infowindow = new google.maps.InfoWindow();
	var latlng = new google.maps.LatLng(21.0000, 78.0000);
	var mapOptions = {
scrollwheel: false,
navigationControl: true,
mapTypeControl: true,
scaleControl: false,
draggable: false,
	zoom: 20,
	center: latlng,
	mapTypeId: google.maps.MapTypeId.ROADMAP
	}
	var geocoder = new google.maps.Geocoder(); 
	var map = new google.maps.Map(document.getElementById("map"), mapOptions);
	var bounds = new google.maps.LatLngBounds();

	function geocodeAddress(address, next) {
	geocoder.geocode({address:address}, function (results,status)
	  { 
	     if (status == google.maps.GeocoderStatus.OK) {
	      var p = results[0].geometry.location;
	      var lat=p.lat();
	      var lng=p.lng();
	      createMarker(address,lat,lng);
	    }
	    else {
	       if (status == google.maps.GeocoderStatus.OVER_QUERY_LIMIT) {
	        nextAddress--;
	        delay++;
	      } else {
	                    }   
	    }
	    next();
	  }
	);
	}
	function createMarker(add,lat,lng) {
	var contentString = add;
	marker = new google.maps.Marker({
	 position: new google.maps.LatLng(lat,lng),
	 map: map,
	       });

	google.maps.event.addListener(marker, 'click', function() {
	 infowindow.setContent(contentString); 
	 infowindow.open(map,marker);
	});

	bounds.extend(marker.position);

	}
	var locations = [<?php echo $loc_ary; ?>];
	var nextAddress = 0;
	function theNext() {
	if (nextAddress < locations.length) {
	  setTimeout('geocodeAddress("'+locations[nextAddress]+'",theNext)', delay);
	  nextAddress++;
	} else {
	  map.fitBounds(bounds);
	}
	}
	theNext();
	/*google.maps.event.addListener(map,'center_changed',function() {
	  window.setTimeout(function() {
	    map.panTo(marker.getPosition());
	  },3000);
	});*/
	google.maps.event.addListener(map,'click',function() {
		this.setOptions({scrollwheel:false});
		this.setOptions({draggable:true});
		this.setOptions({scaleControl:true});
	});
	</script>

	<?php
}

exit();
}


/* ----------- MK Detail with get --------- */

function iflair_detail_search_filter_response(){
	global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
	$mainsiteprefix='cm_';
	$agentsiteurl=get_option('siteurl');
	$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
	$agentsiteid=$agentsitedetail->id;
	$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
	$agent_assign_operator;

	/*echo "<pre>";
	print_r($_POST);
	echo "</pre>";*/
	if($_POST['region']=="all" ){ $region = ""; }else{ $region = $_POST['region']; }
	if($_POST['operator']=="all" ){ $operator = ""; }else{ $operator = $_POST['operator']; }
	if($_POST['cruise_ship']=="all" ){ $cruise_ship = ""; }else{ $cruise_ship = $_POST['cruise_ship']; }
	if($_POST['ship_fly_in']=="all" ){ $ship_fly_in = ""; }else{ $ship_fly_in = $_POST['ship_fly_in']; }	
	if($_POST['leaving_from']=="all" ){ $leaving_from = ""; }else{ $leaving_from = $_POST['leaving_from']; }
	if($_POST['ship_starts_on']=="all" ){ $ship_starts_on = ""; }else{ $ship_starts_on = $_POST['ship_starts_on']; }
	if($_POST['from_cruise_date']=="all" ){ $from_cruise_date = ""; }else{ $from_cruise_date = $_POST['from_cruise_date']; }
	if($_POST['to_cruise_date']=="all" ){ $to_cruise_date = ""; }else{ $to_cruise_date = $_POST['to_cruise_date']; }
	if($_POST['ship_cruise_nights']=="all" ){ 
		$ship_cruise_nights = "";
		$s_nts = "0";
		$e_nts = "999"; 
	}else{ 
		$ship_cruise_nights = $_POST['ship_cruise_nights'];
		if($ship_cruise_nights == "1"){
			$s_nts = "0";
			$e_nts = "3";
		}
		elseif($ship_cruise_nights == "2"){
			$s_nts = "4";
			$e_nts = "6";
		}
		elseif($ship_cruise_nights == "3"){
			$s_nts = "7";
			$e_nts = "9";
		}
		elseif($ship_cruise_nights == "4"){
			$s_nts = "10";
			$e_nts = "13";
		}
		elseif($ship_cruise_nights == "5"){
			$s_nts = "14";
			$e_nts = "20";
		}
		elseif($ship_cruise_nights == "6"){
			$s_nts = "21";
			$e_nts = "999";
		}
	}	


	if($leaving_from!=""){
		$leaving_from_cruise_id= "SELECT cruise_id FROM cruise_port WHERE port_code='$leaving_from'";
		//echo $leaving_from_cruise_id."<---";
		$select_leaving_from_cruise_id = $mydb->get_results($leaving_from_cruise_id);
			$leaving_from_cruise_id_arr = array();
		foreach ($select_leaving_from_cruise_id as $leaving_from_cruise_id_obj) {
			$leaving_from_cruise_id_arr[] = $leaving_from_cruise_id_obj->cruise_id;
		}
		//print_r($leaving_from_cruise_id_arr);
		$leaving_from_cruise_id = $leaving_from_cruise_id_arr[0];
		//print_r($id_res);
		for($i=1;$i<count($leaving_from_cruise_id_arr);$i++){
			$leaving_from_cruise_id = $leaving_from_cruise_id.",".$leaving_from_cruise_id_arr[$i];
		}
		//echo $leaving_from_cruise_id;
	}


	?>
	<div class="form-field form-field-cruise">
				
		<div class="btn-group i-2 h-2" role="group">
			<?php
				$cruise_operator_title= "SELECT csc.ship_operator_id,csc.ship_operator FROM cruise_ship_cruise AS csc WHERE 1=1 ";
			
				/*if($region != ""){
					$cruise_operator_title .= " AND csc.ship_region = '$region'";
				}
				if($cruise_ship != ""){
					$cruise_operator_title .= " AND csc.ship_id = $cruise_ship";
				}
				if($ship_fly_in != ""){
					$cruise_operator_title .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_starts_on != ""){
					$cruise_operator_title .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
				}
				if($ship_cruise_nights != ""){
					$cruise_operator_title .= " AND csc.ship_cruise_nights = '$ship_cruise_nights'";
				}
				*/
				if($tab_condition == 1){
					$cruise_operator_title .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_operator_title .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_operator_title .= "";
				}
	  				$cruise_operator_title .= " GROUP BY csc.ship_operator ORDER BY csc.ship_operator";
	  			
	  			//echo $cruise_operator_title;
				$select_cruise_operator_title = $mydb->get_results($cruise_operator_title);
				$c2 = count($select_cruise_operator_title);
				$qq="0 value";
			?>
				<!-- <img class="loader_filt new_filter" src="<?php //echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;"> -->
		    <select <?php //if($c2==0){echo 'disabled="true" ';}?> name="cruise_operator" id="cruise_operator" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_detail_search_filter('operator');" >
				<option value="" >Cruise Line</option>
				<option value="all" <?php if($_POST['operator']=="all"){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_operator_title as $cruise_operator_title_obj) :
					?>
					<option value="<?php echo $cruise_operator_title_obj->ship_operator_id; ?>" <?php if($operator == $cruise_operator_title_obj->ship_operator_id ){ echo "selected"; } ?> ><?php echo ucfirst(str_replace("-", " ", $cruise_operator_title_obj->ship_operator)); ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>

	  	<div class="btn-group i-3 h-3" role="group">
	  		<?php
	  			$cruise_cruise_ship="";
	  			$cruise_cruise_ship .= "SELECT csc.ship_id,csc.cruise_title FROM cruise_ship_cruise AS csc WHERE 1=1 ";
				if($operator != ""){
					$cruise_cruise_ship .= " AND csc.ship_operator_id = $operator";
				}
				if($region != ""){
					$cruise_cruise_ship .= " AND csc.ship_region = '$region'";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_fly_in != ""){
					$cruise_cruise_ship .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($ship_starts_on != ""){
					$cruise_cruise_ship .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
				}
				/*if($ship_cruise_nights != ""){
					$cruise_cruise_ship .= " AND csc.ship_cruise_nights BETWEEN ".$s_nts." AND ".$e_nts." ";
				}*/
				if($tab_condition == 1){
					$cruise_cruise_ship .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_cruise_ship .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_cruise_ship .= "";
				}
	  				$cruise_cruise_ship .= " GROUP BY csc.cruise_title ORDER BY csc.cruise_title";
				$select_cruise_ship = $mydb->get_results($cruise_cruise_ship);
				$c3 = count($select_cruise_ship);
				if($c3==0){$cruise_ship="";}
	  		?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c3==0){echo 'disabled="true" ';}?> name="cruise_ship" id="cruise_ship" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_detail_search_filter('cruise_ship');" >
				<option value="" >Ship</option>
				<option value="all" <?php if($_POST['cruise_ship']=="all" ){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_ship as $cruise_ship_obj) :
					?>
					<option value="<?php echo $cruise_ship_obj->ship_id; ?>" <?php if($cruise_ship == $cruise_ship_obj->ship_id ){ echo "selected"; } ?> ><?php echo $cruise_ship_obj->cruise_title; ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>
		<div class="btn-group i-1 h-1" role="group">
			<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select name="cruise_region" id="cruise_region" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_detail_search_filter('region');" >
				<option value="" >Cruise Area</option>
				<?php
				
					$tab_condition = $_POST['tab_id'];
					$cruise_region == "";
					$cruise_region .= "SELECT csc.ship_region , csc.ship_cruise_type , csc.cruise_id FROM `cruise_ship_cruise` as csc WHERE 1=1 ";

					if($operator != ""){
						$cruise_region .= " AND csc.ship_operator_id = $operator";
					}
					if($cruise_ship != ""){
						$cruise_region .= " AND csc.ship_id = $cruise_ship";
					}
					if($ship_fly_in != ""){
						$cruise_region .= " AND csc.ship_fly_in = '$ship_fly_in'";
					}
					if($leaving_from != ""){
						$cruise_region .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
					}
					if($ship_starts_on != ""){
						$cruise_region .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
					}
					/*if($ship_cruise_nights != ""){
						$cruise_region .= " AND csc.ship_cruise_nights BETWEEN ".$s_nts." AND ".$e_nts." ";
					}*/
					
					if($tab_condition == 1){
						$cruise_region .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
					}
					elseif($tab_condition == 2){
						$cruise_region .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
					}
					else{
						$cruise_region .= "";
					}
					$cruise_region .= " GROUP BY csc.ship_region ORDER BY FIND_IN_SET('River', csc.ship_cruise_type),csc.ship_region";
					echo $cruise_region;
					$select_cruise_region_res = $mydb->get_results($cruise_region);


				foreach ($select_cruise_region_res as $cruise_region_prepared_obj) :
					$HiddenRiver = explode(',',$cruise_region_prepared_obj->ship_cruise_type);
				?>
					<option value="<?php echo $cruise_region_prepared_obj->ship_region; ?>" <?php if($region == $cruise_region_prepared_obj->ship_region ){ echo "selected"; } ?> ><?php echo $cruise_region_prepared_obj->ship_region; ?><?php if(in_array('River', $HiddenRiver)){ echo " ( River )"; } ?></option>
				<?php
				endforeach;
				?>
		</select>
	  	</div>

	  	<?php /*
	  	<div class="btn-group i-4 h-4" role="group">
	  		<?php
	  			$cruise_ship_fly_in= "SELECT csc.ship_fly_in FROM cruise_ship_cruise AS csc WHERE 1=1 ";
				if($region != ""){
					$cruise_ship_fly_in .= " AND csc.ship_region = '$region'";
				}
				if($operator != ""){
					$cruise_ship_fly_in .= " AND csc.ship_operator_id = $operator";
				}
				if($cruise_ship != ""){
					$cruise_ship_fly_in .= " AND csc.ship_id = $cruise_ship";
				}
				if($ship_starts_on != ""){
					$cruise_ship_fly_in .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
				}
				if($tab_condition == 1){
					$cruise_ship_fly_in .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_ship_fly_in .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_ship_fly_in .= "";
				}
	  				$cruise_ship_fly_in .= " GROUP BY csc.ship_fly_in ORDER BY csc.ship_fly_in";
	  			
				$select_cruise_ship_fly_in = $mydb->get_results($cruise_ship_fly_in);
				$c4 = count($select_cruise_ship_fly_in);
	  		?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c4==0){echo 'disabled="true" ';}?> name="cruise_ship_fly_in" id="cruise_ship_fly_in" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_detail_search_filter('ship_fly_in');" >
				<option value="" >From</option>
				<option value="all" <?php if($_POST['leaving_from'] == "all" ){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_ship_fly_in as $cruise_ship_fly_in_obj) :
					?>
					<option value="<?php echo $cruise_ship_fly_in_obj->ship_fly_in; ?>" <?php if($ship_fly_in == $cruise_ship_fly_in_obj->ship_fly_in ){ echo "selected"; } ?> ><?php echo $cruise_ship_fly_in_obj->ship_fly_in; ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>

	  	<div class="btn-group i-2 h-5" role="group">
	  		<?php
	  			$todays_date = date('Y-m-d H:i:s');
				$cruise_when= "SELECT csc.ship_starts_on FROM cruise_ship_cruise AS csc WHERE 1=1 ";
					$cruise_when .= " AND csc.ship_starts_on >= '$todays_date'";
				if($region != ""){
					$cruise_when .= " AND csc.ship_region = '$region'";
				}
				if($operator != ""){
					$cruise_when .= " AND csc.ship_operator_id = $operator";
				}
				if($cruise_ship != ""){
					$cruise_when .= " AND csc.ship_id = $cruise_ship";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_fly_in != ""){
					$cruise_when .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($tab_condition == 1){
					$cruise_when .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_when .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_when .= "";
				}
	  				$cruise_when .= " GROUP BY YEAR(csc.ship_starts_on),MONTH(csc.ship_starts_on) ORDER BY csc.ship_starts_on";
	  			
				$select_cruise_when = $mydb->get_results($cruise_when);
				//echo $cruise_when;
				$c5 = count($select_cruise_when);
	  		?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c5==0){echo 'disabled="true" ';}?> name="cruise_ship_starts_on" id="cruise_ship_starts_on" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_detail_search_filter('ship_starts_on');" >
				<option value="" >When</option>
				<option value="all" <?php if($_POST['ship_starts_on']=="all" ){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_when as $cruise_when_obj) :
					?>
					<option value="<?php echo date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ; ?>" <?php if($ship_starts_on == date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ){ echo "selected"; } ?> ><?php $ship_date=$cruise_when_obj->ship_starts_on; echo date('F Y',strtotime($ship_date)); ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>
	  	*/?>

	  	<?php 
	  	$todays_date = date('Y-m-d H:i:s');
		$cruise_when= "SELECT csc.ship_starts_on FROM cruise_ship_cruise AS csc WHERE 1=1 ";
			$cruise_when .= " AND csc.ship_starts_on >= '$todays_date'";
		if($region != ""){
			$cruise_when .= " AND csc.ship_region = '$region'";
		}
		if($operator != ""){
			$cruise_when .= " AND csc.ship_operator_id = $operator";
		}
		if($cruise_ship != ""){
			$cruise_when .= " AND csc.ship_id = $cruise_ship";
		}
		if($leaving_from != ""){
			$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
		}
		if($ship_fly_in != ""){
			$cruise_when .= " AND csc.ship_fly_in = '$ship_fly_in'";
		}
		if($tab_condition == 1){
			$cruise_when .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
		}
		elseif($tab_condition == 2){
			$cruise_when .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
		}
		else{
			$cruise_when .= "";
		}
				$cruise_when .= " GROUP BY csc.ship_starts_on ORDER BY csc.ship_starts_on";
			
		$select_cruise_when = $mydb->get_results($cruise_when);

		?>
	  	<link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/themes/base/jquery-ui.css" type="text/css" media="all">
	  	<script type="text/javascript">
	  		var eventDates = {};
  			<?php
			foreach ($select_cruise_when as $cruise_when_obj) :
				?>eventDates[ new Date( '<?php echo date('d M Y',strtotime($cruise_when_obj->ship_starts_on)); ?>' )] = new Date( '<?php echo date('d M Y',strtotime($cruise_when_obj->ship_starts_on)); ?>' );<?php
			endforeach;
  			?>
			var dateToday = new Date();
			var dates = jQuery("#from_cruise_date, #to_cruise_date").datepicker({
			    defaultDate: "+1w",
			    changeMonth: true,
    			dateFormat: 'd M yy',
			    beforeShow: function (input, inst) {
			        var rect = input.getBoundingClientRect();
			        setTimeout(function () {
				        inst.dpDiv.css({ top: rect.top + 40, left: rect.left + 0 });
			        }, 0);
			    },
			    numberOfMonths: 1,
			    beforeShowDay: function( date ) {
			                var highlight = eventDates[date];
			                if( highlight ) {
			                     return [true, "event", highlight];
			                } else {
			                     return [true, '', ''];
			                }
			             },
			    minDate: dateToday,
			    onSelect: function(selectedDate) {
			        var option = this.id == "from_cruise_date" ? "minDate" : "maxDate",
			            instance = jQuery(this).data("datepicker"),
			            date = jQuery.datepicker.parseDate(instance.settings.dateFormat || jQuery.datepicker._defaults.dateFormat, selectedDate, instance.settings);
			        dates.not(this).datepicker("option", option, date);
			    }
			});
	  	</script>
	  	<div class="btn-group i-4 h-4" role="group">
			<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
	  		<input type="text" id="from_cruise_date" value="<?php echo $from_cruise_date; ?>" class="btn btn-default dropdown-toggle text p-2 second_filter_class" placeholder="From" name="from_cruise_date"/> 
	  	</div>
	  	<div class="btn-group i-2 h-5" role="group">
			<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
	  		<input type="text" id="to_cruise_date" value="<?php echo $to_cruise_date; ?>" class="btn btn-default dropdown-toggle text p-2 second_filter_class" placeholder="To" name="to_cruise_date"/>
	  	</div>
	  	<div class="btn-group i-3 h-6" role="group">
	  		<?php
				$cruise_days= "SELECT csc.ship_cruise_nights FROM cruise_ship_cruise AS csc WHERE 1=1 ";
				if($region != ""){
					$cruise_days .= " AND csc.ship_region = '$region'";
				}
				if($operator != ""){
					$cruise_days .= " AND csc.ship_operator_id = $operator";
				}
				if($cruise_ship != ""){
					$cruise_days .= " AND csc.ship_id = $cruise_ship";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_fly_in != ""){
					$cruise_days .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($ship_starts_on != ""){
					$cruise_days .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
				}
				if($tab_condition == 1){
					$cruise_days .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_days .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_days .= "";
				}
	  				$cruise_days .= " GROUP BY csc.ship_cruise_nights ORDER BY csc.ship_cruise_nights";
	  			
				$select_cruise_days = $mydb->get_results($cruise_days);
				$c6 = count($select_cruise_days);
	  		?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c6==0){echo 'disabled="true" ';}?> name="cruise_ship_cruise_nights" id="cruise_ship_cruise_nights" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_detail_search_filter('ship_cruise_nights');" >
				<option value="" >Duration</option>
				<option value="all" <?php if($_POST['ship_cruise_nights']=="all" ){ echo "selected"; } ?>>Any</option>
				<?php
				/*foreach ($select_cruise_days as $cruise_days_obj) :
					?>
					<option value="<?php echo $cruise_days_obj->ship_cruise_nights ; ?>" <?php if($ship_cruise_nights == $cruise_days_obj->ship_cruise_nights ){ echo "selected"; } ?> ><?php echo $cruise_days_obj->ship_cruise_nights ; ?></option>
					<?php
				endforeach;*/
				?>
				<option <?php if($ship_cruise_nights==1){echo "selected";} ?> value="1">1 - 3 Nights</option>
				<option <?php if($ship_cruise_nights==2){echo "selected";} ?> value="2">4 - 6 Nights</option>
				<option <?php if($ship_cruise_nights==3){echo "selected";} ?> value="3">7 - 9 Nights</option>
				<option <?php if($ship_cruise_nights==4){echo "selected";} ?> value="4">10 - 13 Nights</option>
				<option <?php if($ship_cruise_nights==5){echo "selected";} ?> value="5">14 - 20 Nights</option>
				<option <?php if($ship_cruise_nights==6){echo "selected";} ?> value="6">21+ Nights</option>
			</select>
	  	</div>
	  	<input type="hidden" value="<?php if($_GET['tab_id']!=""){ echo $_GET['tab_id']; }elseif($_POST['tab_id']!=""){ echo $_POST['tab_id']; }else{ echo "undefined"; } ?>" name="tab_id">
		<!-- 
		<span onclick="iflair_detail_search_filter('search');" class="search-bt-2" style="text-align: center; line-height: 46px;cursor:pointer;">Search</span>
 -->
			<button class="search-bt-2" style="text-align: center; line-height: 46px;cursor:pointer;" type="submit" value="Submit" >Submit</button>

			</div>

	<?php
	exit();
}

define('MY_WORDPRESS_FOLDER',$_SERVER['DOCUMENT_ROOT']);
define('MY_THEME_FOLDER',str_replace("\\",'/',dirname(__FILE__)));
define('MY_THEME_PATH','/' . substr(MY_THEME_FOLDER,stripos(MY_THEME_FOLDER,'wp-content')));
add_action('admin_init','my_meta_init');
function my_meta_init()
{
// review the function reference for parameter details
// http://codex.wordpress.org/Function_Reference/wp_enqueue_script
// http://codex.wordpress.org/Function_Reference/wp_enqueue_style
//wp_enqueue_script('my_meta_js', MY_THEME_PATH . '/custom/meta.js', array('jquery'));
//wp_enqueue_style('my_meta_css', MY_THEME_PATH . '/custom/meta.css');
// review the function reference for parameter details
// http://codex.wordpress.org/Function_Reference/add_meta_box
// add a meta box for each of the wordpress page types: posts and pages
foreach (array('post','page') as $type) 
{
add_meta_box('my_all_meta', 'Select Option', 'my_meta_setup', $type, 'normal', 'high');
}
// add a callback function to save any data a user enters in
add_action('save_post','my_meta_save');
}
function my_meta_setup()
{
global $post;
// using an underscore, prevents the meta variable
// from showing up in the custom fields section
$meta = get_post_meta($post->ID,'_my_meta',TRUE);
// instead of writing HTML here, lets do an include
include(MY_THEME_FOLDER . '/meta.php');
// create a custom nonce for submit verification later
echo '<input type="hidden" name="my_meta_noncename" value="' . wp_create_nonce(__FILE__) . '" />';
}
function my_meta_save($post_id) 
{
// authentication checks
// make sure data came from our meta box
if (!wp_verify_nonce($_POST['my_meta_noncename'],__FILE__)) return $post_id;
// check user permissions
if ($_POST['post_type'] == 'page') 
{
if (!current_user_can('edit_page', $post_id)) return $post_id;
}
else
{
if (!current_user_can('edit_post', $post_id)) return $post_id;
}
// authentication passed, save data
// var types
// single: _my_meta[var]
// array: _my_meta[var][]
// grouped array: _my_meta[var_group][0][var_1], _my_meta[var_group][0][var_2]
$current_data = get_post_meta($post_id, '_my_meta', TRUE);  
$new_data = $_POST['_my_meta'];
my_meta_clean($new_data);
if ($current_data) 
{
if (is_null($new_data)) delete_post_meta($post_id,'_my_meta');
else update_post_meta($post_id,'_my_meta',$new_data);
}
elseif (!is_null($new_data))
{
add_post_meta($post_id,'_my_meta',$new_data,TRUE);
}
return $post_id;
}
function my_meta_clean(&$arr)
{
if (is_array($arr))
{
foreach ($arr as $i => $v)
{
if (is_array($arr[$i])) 
{
my_meta_clean($arr[$i]);
if (!count($arr[$i])) 
{
unset($arr[$i]);
}
}
else
{
if (trim($arr[$i]) == '') 
{
unset($arr[$i]);
}
}
}
if (!count($arr)) 
{
$arr = NULL;
}
}
}

/* Operator detailpage ajax for accommodation & all tab... */
add_action('wp_ajax_operator_detail_feature_tab', 'operator_detail_feature_tab'); // Logged-in users
add_action('wp_ajax_nopriv_operator_detail_feature_tab', 'operator_detail_feature_tab'); // Guest users

function operator_detail_feature_tab(){
global $wpdb,$mydb;
if($_POST['tab_name']=="enrichment_types"){
	$tab_name = "crusie_".$_POST['tab_name'];
}
else{
	$tab_name = "cruise_".$_POST['tab_name'];
}
if($_POST['tab_name']=="deckplans"){
	$img_prefix = "http://ekups3e.cloudimg.io/s/resize/1200/";
}
else{
	$img_prefix = "http://ekups3e.cloudimg.io/s/resize/750/";
}
$response_id = $_POST['response_id'];
$query_all = "SELECT name,image_name,image_href,description,stats FROM ".$tab_name." WHERE ship_response_id=".$response_id." GROUP BY index_val ";
$query_result = $mydb->get_results($query_all);
$count_val = count($query_result);
	if($count_val!=0){
		for($rc=0;$rc<$count_val;$rc++){
		?>
		<div class="acoodetail" id="<?php echo str_replace(" ","_",$query_result[$rc]->name); ?>">
				<?php
				if($query_result[$rc]->image_name!=""){
					?>
					<div class="accodetail">
						<img title="<?php echo $query_result[$rc]->name; ?>" src="<?php echo $img_prefix.''.str_replace('//www','http://www',$query_result[$rc]->image_href); ?>" alt="<?php echo $query_result[$rc]->image_name; ?>" class="img-responsive">
					</div>
					<div class="accdescrptipon">
					<?php
				}
				else{
					?>
					<div class="accdescrptipon" style="width: 100%;">
					<?php
				}
				?>
				<h2><?php echo $query_result[$rc]->name; ?></h2>
				<?php echo html_entity_decode($query_result[$rc]->description); ?>
				<?php if($query_result[$rc]->stats!=""){ echo "<b>Stats</b>"; } ?>
				<?php echo html_entity_decode($query_result[$rc]->stats); ?> 
			</div>
		</div>
		<?php
		}
	}
	else{
		//echo "No details Found...";
	}
	exit();
}
function price_filter_result(){
global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;


$query_price_all = explode(" AND ( (csc.ship_cruise_only_pri" , $_POST['query']);
//echo "<pre>";
//print_r($query_price_all);
//echo "</pre>";
$query_price = $query_price_all[0];
	$pagenum=$_POST['pagenumb'];
	if($_POST['pagenumb']==""){
		$per_page = 10;
		$page='1';
		$start='0';
	}
	else {
		$per_page = 10;
		$page=$_POST['pagenumb'];	
		$start=($page-1)*$per_page;
	}


$start_price = $_POST['s'];	
$end_price = $_POST['e'];	
//if($start_price != "" && $end_price != "")
if($start_price == 0 && $end_price != ""){
	if($start_price == 0 && $end_price == 10000){
		$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price  >= 0";
		$price_history = "";
	}
	elseif($start_price == 0 && $end_price == 1000){
		//$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price < ".$end_price."";
		$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price  > 0 AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price < ".$end_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price < ".$end_price.") )";
		$price_history = "in price Below £".number_format($end_price)."";
	}
	else{
		//$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price < ".$end_price."";
		$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price  >= 0 AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price < ".$end_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price < ".$end_price.") )";
		$price_history = "in price Below £".number_format($end_price)."";
	}
}
else if($start_price != "" && $end_price == 10000){

	if($start_price == 5000 && $end_price == 10000){
		//$select_ship_query = ." AND csc.ship_cruise_only_price >= ".$start_price."";
		$price_q_query_unlimit .= str_replace("\\",'',$query_price)." AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price > ".$start_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price  > ".$start_price.") OR ( csc.ship_cruise_only_price = 0 AND csc.ship_fly_cruise_price = 0 ) )";
		$price_history = "in price Bigger than £".number_format($start_price)."";
	}
	else{
		//$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price > ".$start_price."";
		$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price > ".$start_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price  > ".$start_price.") )";
		$price_history = "in price Bigger than £".number_format($start_price)."";
	}
}
elseif($start_price == "" && $end_price == ""){
	$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price  >= 0";
	$price_history = "";
}
else{
	//$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price BETWEEN ".$start_price." AND ".$end_price."";
	$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price BETWEEN ".$start_price." AND ".$end_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price BETWEEN ".$start_price." AND ".$end_price.") )";
	$price_history = "in price range of £".number_format($start_price)." to £".number_format($end_price)."";
}
	if( $start_price == "0" &&  $end_price == "10000" ){
		$price_q_query_limit.= $price_q_query_unlimit." ORDER BY csc.ship_starts_on LIMIT $start,$per_page";
	}
	else{
		if($end_price == 10000){
			$price_q_query_limit = $price_q_query_unlimit." ORDER BY IF( (csc.ship_cruise_only_price AND csc.ship_fly_cruise_price) = 0, 1, 0) LIMIT $start,$per_page";
		}
		else{
			$price_q_query_limit = $price_q_query_unlimit." ORDER BY csc.ship_cruise_only_price ASC LIMIT $start,$per_page";
		}
	}
	$price_q = $mydb->get_results($price_q_query_limit);
	/*echo "<pre>";
	echo $price_q_query_limit;
	//print_r($price_q);
	echo "</pre>";*/


echo "<pre id='history1' style='display:none;'>";
//print_r($_POST);
$history_str = "";
	//if($_POST['operator']!="" || $_POST['region']!="" || $_POST['cruise_ship']!="" || $_POST['ship_fly_in']!="" || $_POST['ship_starts_on']!="" || $_POST['ship_cruise_nights']!="" ){
		//$history_str .= "Search ";
		$history_str .= "Results Showing ".count($mydb->get_results($price_q_query_limit))." ";
	//}

	if($_POST['region']=="all" || $_POST['region']==""){ 
		$history_str .= "cruises to Anywhere "; 
	}elseif($_POST['region']!=""){ 
		$history_str .= "cruises to ".$_POST['region']." "; 
	}

	if($_POST['operator']=="all" || $_POST['operator']==""){ 
		$history_str .= "with All Cruiselines "; 
	}elseif($_POST['operator']!=""){
		$val_op = $mydb->get_row("SELECT operator_title FROM cruise_operators WHERE operator_id = ".$_POST['operator']."");
		$history_str .= "with ".$val_op->operator_title." "; 
	}

	if($_POST['cruise_ship']=="all" || $_POST['cruise_ship']==""){ 
		$history_str .= "on Any Ship "; 
	}elseif($_POST['cruise_ship']!=""){
		$val_ship = $mydb->get_row("SELECT cruise_title FROM cruise_cruise WHERE cruise_response_id = ".$_POST['cruise_ship']."");
		$history_str .= "on ".$val_ship->cruise_title." "; 
	}

	if($_POST['ship_fly_in']=="all" || $_POST['ship_fly_in']==""){ 
		$history_str .= "leaving from Any Port "; 
	}elseif($_POST['ship_fly_in']!=""){ 
		$history_str .= "leaving from ".$_POST['ship_fly_in']." "; 
	}

	if($_POST['ship_starts_on']=="all" || $_POST['ship_starts_on']==""){ 
		$history_str .= "in All Months "; 
	}elseif($_POST['ship_starts_on']!=""){ 
		$history_str .= "in ".date('F Y',strtotime($_POST['ship_starts_on']))." "; 
	}

	if($_POST['ship_cruise_nights']=="all" || $_POST['ship_cruise_nights']==""){ 
		$history_str .= "for all Days"; 
	}elseif($_POST['ship_cruise_nights']!=""){ 
		$history_str .= "for ".$_POST['ship_cruise_nights']." Days"; 
	}

echo $history_str."".$price_history.".";
echo "</pre>";


	if(count($price_q) == 0)
	{
		echo "<div class='no_result_area'>No Cruise Found ..<div>";
	}
	else
	{
		//echo $page;
		//echo $per_page;
		//echo $select_ship_query;
		cruise_pagging($page,$per_page,$price_q_query_unlimit);

		for($i=0;$i<count($price_q);$i++)
		{
		?>

<div class="mediter-box clearfix">
	<div class="medi-left">
		<div class="newtableimg">
			<div class="netablecellimg">
				<img src="<?php if($price_q[$i]->cruise_cover_image_href!=""){ echo "http://ekups3e.cloudimg.io/s/crop/300x200/".str_replace('//www','www',$price_q[$i]->cruise_cover_image_href); }else{ echo esc_url( get_template_directory_uri() )."/images/noImageAvailable.png"; } ?>" class="img-responsive">
			</div>
		</div>
	</div>
	<div class="medi-mid mid-mid-two">
	<?php
	$offer_query = "SELECT * FROM ".BASEPOKE_LIST." as bl INNER JOIN ".BASEPOKE_CRUISES." as bc ON bl.id = bc.basepoke_id WHERE bc.offer_start_date < curdate() and bc.offer_end_date > curdate() AND bc.cruise_id = '".$price_q[$i]->a."'";
	$found_offer = $wpdb->get_row($offer_query);
	?>
		<h3><?php /*if($found_offer->extra_info != ""){ echo $found_offer->extra_info; }else{*/ echo $price_q[$i]->ship_name; /*}*/ ?></h3>
		<?php if($found_offer->cabin_info!=""){ ?>
		<span class="package_class"><?php echo $found_offer->cabin_info; ?></span>
		<?php } ?>
		<p class="date_new_site"><?php if($found_offer->departure_date != ""){ echo date('d M Y',strtotime($found_offer->departure_date)); }else{ $ship_date=$price_q[$i]->ship_starts_on; echo date('d M Y',strtotime($ship_date)); } ?></p>
		<p class="day_new_site daytotal"><?php /*if($found_offer->cruise_nights != ""){ echo $found_offer->cruise_nights; }else{*/ echo $price_q[$i]->ship_cruise_nights; /*}*/ ?> Nights</p>
		
		<p class="ship_new_site"><div class="tool"></div> <div class="shiptitle">Ship</div><span class="toolname">: <?php echo $price_q[$i]->cruise_title; ?></span></p>
		<?php if($found_offer->offer_short_summery != ""){ echo "<div class='offer_short_summery'>".$found_offer->offer_short_summery."</div>"; } ?>
		<p class="itinerary_new_site">
		<span class="itecolor">itinerary : </span>

		<?php
		/*if($found_offer->ports_visited != ""){ echo str_replace(","," <i class='fa fa-caret-right'></i> ",$found_offer->ports_visited); }
		else{ */
			$select_itinerary_query ="";
			$select_itinerary_query .= "SELECT port_name FROM cruise_port WHERE cruise_id = '";
			$select_itinerary_query .= $price_q[$i]->a;
			$select_itinerary_query .= "' GROUP BY port_name ORDER BY id";
			//echo $select_itinerary_query;
			$select_itinerary = $mydb->get_results($select_itinerary_query);
			$itinerary_count = count($select_itinerary);
			if($itinerary_count!="0"){
				echo $select_itinerary[0]->port_name;
				for($i1=1;$i1<count($select_itinerary);$i1++)
				{
					//echo "<pre>";
					//print_r($select_port);
					//echo "</pre>";
					?> <i class="fa fa-caret-right"></i>
					<?php echo $select_itinerary[$i1]->port_name;
					?>
				<?php
				}
			}
		/*}*/
		?>
		</p>
	</div>
		<?php
			/*echo "<pre>";
			print_r($found_offer);
			echo "</pre>";*/
			if(!empty($found_offer)){
				$offer_class = '<div class="offer_class"></div>';
				$offer_class2 = " offer_class2";
				//echo '<div class="'.$offer_class.'"><img src="'.esc_url( get_template_directory_uri() ).'/images/superdeal.png" ></div>';
			}
			else{
				$offer_class = "";
				$offer_class2 = "";
			}
		?>
	<div class="medi-right">
		<?php echo $offer_class; ?>
		<div class="main_added_text">
		<?php 
		$price1 = $price_q[$i]->ship_cruise_only_price;
		$price2 = $price_q[$i]->ship_fly_cruise_price;
		
		if(!empty($found_offer)){
			?>
			<h2>Cruise Package Price</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>From <span class="textbld">£<?php echo number_format($found_offer->offer_price); ?></span>  per person</p>
			<?php
		}
		elseif($price1=="0" && $price2=="0")
		{
			?>
			<h2>Cruise Only</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>Please enquire for today’s price</p>
			<?php
		}
		elseif( ( $price1!="0" && $price1 < $price2 ) || $price2== "0" )
		{
			?>
			<h2>Cruise Only</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>From <span class="textbld">£<?php echo number_format($price1); ?></span>  per person</p>
			<?php
		}
		elseif( ( $price2!="0" && $price1 > $price2 ) || $price1== "0" )
		{
			?>
			<h2>Cruise Only</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>From <span class="textbld">£<?php echo number_format($price2); ?></span>  per person</p>
			<?php
		}
		elseif( ( $price1!="0" && $price2!="0" ) && $price1==$price2 )
		{
			?>
			<h2>Cruise Only</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>From <span class="textbld">£<?php echo number_format($price1); ?></span>  per person</p>
			<?php
		}
		else{
			?>
			<!-- <h2>Cruise Only</h2> -->
			<?php echo $found_offer->package_summary; ?>
			<p class="text1">Please enquire for today’s price</p>
			<?php
		}
		echo '<div class="'.$offer_class2.'"></div>';
		?>
		</div>
		<?php $detail_page_id = get_site_option( 'iflair_cruise_theme_ship_detail_page' );?>
		<div class="added_img">
			<a target="_blank" href="<?php echo get_page_link($detail_page_id);?>?cruise_id=<?php echo $price_q[$i]->a; ?>" class="info-bt new_btn_blue new_detail_btn"> VIEW DETAILS <i class="fa fa-caret-down"></i></a>
					<!-- <script>jQuery("img.lazy").lazyload();</script> -->
			<a onclick="cruise_detail_of('<?php echo $price_q[$i]->cruise_id; ?>');" class="new_btn_blue fa fa-caret-down itinerary_btn">Itinerary <i class=""></i></a>
		</div>
	</div>
</div>
<div class="cruse-information clearfix">
	<div class="above_map_area"><h2 class="above_map_title">Cruise Itinerary</h2>
	<a target="_blank" href="<?php echo get_page_link($detail_page_id);?>?cruise_id=<?php echo $price_q[$i]->a; ?>" class="info-bt new_btn_blue above_map">MORE DETAILS / ENQUIRE <i class="fa fa-caret-down"></i></a></div>
	<div class="scroll<?php echo $price_q[$i]->cruise_id; ?> scroll_empty">
		<div class="loader_1" style="display:none;text-align: center; padding: 0px 0px 30px;">
			<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader_1.gif">
		</div>
	</div>

	<?php
	/*echo "<pre>";
	print_r($select_ship[$i]);
	echo "</pre>";*/
	?>
	<div class="clearfix right">
		<?php /*<a href="<?php echo get_page_link($detail_page_id);?>?ship_id=<?php echo $select_ship[$i]->b; ?>" class="info-bt new_btn_blue">VIEW MORE INFORMATION</a> */?>
	</div>
</div>
<br>
		<?php
		}
		cruise_pagging($page,$per_page,$price_q_query_unlimit);
	}
	?>
<script type="text/javascript">
	
		jQuery(document).ready(function(){
			jQuery("#pagination li").click(function(){
				jQuery('.loader').css('display','block');
				var pageNum = this.id;
				var query = "<?php echo $query_price; ?>";
				var s = "<?php echo $start_price; ?>";
				var e = "<?php echo $end_price; ?>";
				    jQuery.ajax({
			            type: "POST",
			            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
			            data: ({
			                action: 'price_filter_result',
				            <?php if($_COOKIE['str1']!=""){ ?>str1: <?php echo "'".$_COOKIE['str1']."',"; } ?>
				            <?php if($_COOKIE['str2']!=""){ ?>str2: <?php echo "'".$_COOKIE['str2']."',"; } ?>
				            query: query,
				            s:s,
				            e:e,
			                pagenumb:pageNum
			            }),
			            success: function (response) {

			                //alert(response);
			                jQuery('.result-part').html(response);
			                //jQuery('#filter_title').empty();
				            //var filter_title=jQuery('#filter_title_tmp').html();
				            //alert(filter_title);
				            //jQuery('#filter_title-new').html(filter_title);
	                		jQuery(".content").mCustomScrollbar();
			            	jQuery('.loader').css('display','none');
			            }
			        });
				
			});
		});

		jQuery(document).ready(function(){
			jQuery('.itinerary_btn').click(function(){
				//jQuery(this).parent().parent().parent().next('.cruse-information').slideToggle();
				if(jQuery(this).parent().parent().parent().next('.cruse-information').hasClass("a1")){
					jQuery(this).parent().parent().parent().next('.cruse-information').removeClass("a1");
					jQuery(this).parent().parent().parent().next('.cruse-information').slideUp();
				}
				else{
					jQuery('.cruse-information').removeClass("a1");
					jQuery('.cruse-information').slideUp();
					jQuery(this).parent().parent().parent().next('.cruse-information').slideDown();
					jQuery(this).parent().parent().parent().next('.cruse-information').addClass("a1");
				}
			});
			/*jQuery('.itinerary_btn').click(function(){
				if(jQuery(this).parent().parent().parent().hasClass("active_information")){
					jQuery(this).parent().parent().parent().slideUp();
					jQuery(this).parent().parent().parent().removeClass("active_information");
					jQuery('.active_information').slideUp();
				}
				else{
					jQuery(this).parent().addClass('active_itinerary');
					jQuery(this).parent().parent().parent().removeClass("active_information");
					jQuery(this).parent().parent().parent().next('.cruse-information').slideDown();
					jQuery(this).parent().parent().parent().slideDown();
					jQuery(this).parent().parent().parent().addClass("active_information");
					jQuery('.active_information').slideDown();
				}
			});*/
		});

		function cruise_detail_of(cruise_id){
	        jQuery('.loader_1').css('display','block');
			var id = id;
			var ship_name = ship_name;
			var cruise_id = cruise_id;
			var region = jQuery('#cruise_region').val();
			var operator = jQuery('#cruise_operator').val();
			var cruise_ship = jQuery('#cruise_ship').val();
			var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
			var leaving_from = jQuery('#cruise_leaving_from').val();
			var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
			var ship_cruise_nights = jQuery('#cruise_ship_cruise_nights').val();
			jQuery.ajax({
	            type: "POST",
	            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
	            data: ({
	                action: 'cruise_detail',
		            region: region,
		            operator: operator,
		            cruise_ship: cruise_ship,
		            ship_fly_in: ship_fly_in,
		            leaving_from: leaving_from,
		            ship_starts_on: ship_starts_on,
		            ship_cruise_nights: ship_cruise_nights,
		            id: id,
		            ship_name: ship_name,
		            cruise_id: cruise_id
	            }),
	            success: function (response) {
	                //alert(response);
	            	//jQuery('.scroll_empty').empty();
	                jQuery('.scroll'+cruise_id).html(response);
	                jQuery(".content").mCustomScrollbar();
	            	jQuery('.loader_1').css('display','none');
	            }
	        });
		}


</script>
	<?php
	exit();
}


// Creating the widget 
class scf_widget extends WP_Widget {

	function __construct() {
		parent::__construct(
		// Base ID of your widget
		'scf_widget', 

		// Widget name will appear in UI
		__('Why Book', 'Why Book'), 

		// Widget description
		array( 'description' => __( 'Why Book', 'why_book' ), ) 
		);
	}

	// Creating widget front-end
	public function widget() {
		//echo '<div style="text-align: center;"><img src="'.esc_url( get_template_directory_uri() ).'/images/sprites_why_book_vertical.png" style="margin: 0px 0px 24px; display: table-row;"></div>';
	}

} // Class scf_widget ends here

// Register and load the widget
function cruise_search_widget() {
	register_widget( 'scf_widget' );
}
add_action( 'widgets_init', 'cruise_search_widget' );

add_action('wp_ajax_port_breif_res', 'port_breif_res'); // Logged-in users
add_action('wp_ajax_nopriv_port_breif_res', 'port_breif_res'); // Guest users

function truncateStringWords($str, $maxlen)
{
    if (strlen($str) <= $maxlen) return $str;

    $newstr = substr($str, 0, $maxlen);
    if (substr($newstr, -1, 1) != ' ') $newstr = substr($newstr, 0, strrpos($newstr, " "));

    return $newstr;
}

function port_breif_res(){
global $mydb;
$port_code = $_POST['port_code'];
$port_b_q = "SELECT port_description,port_name,port_tovisit FROM port_extra_information WHERE port_code = '".$port_code."'";
$port_b_r = $mydb->get_row($port_b_q);
echo "<div class='port_breif_details'>";
echo "<div class='port_breif_details_inner'>";
if($port_b_r->port_tovisit!=""){echo "<span class='first_title_span'> <b>Highlights - </b>".$port_b_r->port_tovisit."</span><br>"; }
echo "<p> About ".$port_b_r->port_name."</p>";
echo "<span class='less_c_".$port_code."'>".truncateStringWords(strip_tags($port_b_r->port_description), 300)." <a>more >></a></span>";
echo "<span class='more_c_".$port_code."'>".strip_tags($port_b_r->port_description,'<p>')." <a><< less</a></span>";
echo "</div>";
echo "</div>";
?>
<script type="text/javascript">
jQuery(".more_c_<?php echo $port_code;?>").hide();
jQuery(".less_c_<?php echo $port_code;?> a").click(function(){
	jQuery(".more_c_<?php echo $port_code;?>").slideDown();
	jQuery(".less_c_<?php echo $port_code;?>").hide();
});
jQuery(".more_c_<?php echo $port_code;?> a").click(function(){
	jQuery(".less_c_<?php echo $port_code;?>").slideDown();
	jQuery(".more_c_<?php echo $port_code;?>").hide();
});
</script>
<?php
exit();
}


add_action('wp_ajax_listing_inq_ajax', 'listing_inq_ajax'); // Logged-in users
add_action('wp_ajax_nopriv_listing_inq_ajax', 'listing_inq_ajax'); // Guest users
function listing_inq_ajax(){
?>
<div id="slide_down_div">
	<div class="modal-dialog" role="document">
		<div class="modal-content enquiry-down">
		  <div class="modal-header">
		    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		    <h4 class="modal-title" id="myModalLabel" style="text-align:left;"><?php $arrival=$_POST['ship_starts_on']; echo $_POST['cruise_title']." | ".$_POST['ship_name']." | ".date('d M Y',strtotime($arrival)); ?></h4>
		  </div>
		  <div class="modal-body ">
		   <?php echo do_shortcode("[shipenquiryform ship_name='".$_POST['ship_name']."' cruise_name='".$_POST['cruise_title']."' date='".date('d M Y',strtotime($arrival))."' cruise_id='".$_POST['cruise_id']."' ship_operator='".$_POST['ship_operator']."']"); ?>
		   <div style="clear:both;"></div>
		  </div>
		</div>
	</div>
</div>
<script type="text/javascript">
jQuery("#listing_inq_modal .close").click(function(){	
  jQuery( '#listing_inq_modal .modal-dialog' ).effect( "explode", 800, callback );
});
</script>
<?php
exit();
}

?>