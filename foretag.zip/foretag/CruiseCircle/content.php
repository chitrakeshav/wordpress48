<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package WordPress
 * @subpackage Twenty_Thirteen
 * @since Twenty Thirteen 1.0
 */
?>
<div class="blofull">
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php
	?>
	

	<header class="entry-header">
		<?php
			if ( is_single() ) :
				the_title( '<h1 class="entry-title">', '</h1>' );
			else :
				the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
			endif;
		?>
	</header><!-- .entry-header -->
	<footer class="entry-footer">
		<?php //twentythirteen_entry_meta(); ?>
		<?php //edit_post_link( __( 'Edit', 'twentythirteen' ), '<span class="edit-link">', '</span>' ); ?>
	</footer><!-- .entry-footer -->
	
	<div class="entry-content">
	<div class="blogarea">
	<div class="blog_img fl">
		<?php if ( has_post_thumbnail() && ! post_password_required() && ! is_attachment() ) { ?>
		
			<?php the_post_thumbnail(array(260,220)); ?>

		<?php }else{
			?>
			<img height="163" width="260" class="attachment-260x220 size-260x220 wp-post-image" src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/no_prev.png" style="height: 200px;">
			<?php
		} ?>
		
	</div>
	<div class="blog_content fr">
		<?php
			/* translators: %s: Name of current post */
			/* the_content( sprintf(
				__( 'Continue reading %s', 'twentythirteen' ),
				the_title( '<span class="screen-reader-text">', '</span>', false )
			) ); */
			$content = get_the_content();
      $content = strip_tags($content);
      echo "<p>".substr($content, 0, 210)."</p>";
?><a class="more-link" href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>">Read More</a><?php 

			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentythirteen' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'twentythirteen' ) . ' </span>%',
				'separator'   => '<span class="screen-reader-text">, </span>',
			) );
		?></div>
		<div class="clr"></div>
	</div>
	</div><!-- .entry-content -->

	<?php
		// Author bio.
		if ( is_single() && get_the_author_meta( 'description' ) ) :
			get_template_part( 'author-bio' );
		endif;
	?>



</article><!-- #post-## -->
</div>
