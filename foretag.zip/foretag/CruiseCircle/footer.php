<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Thirteen
 * @since Twenty Thirteen 1.0
 */
?><!--
<div class="footerlogoslist">
	<div class="servicewrapper">
		<div class="logolist">
			<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/f44.png"></a>
			<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/f42.png"></a>
			<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/f41.png"></a>
			<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/f46.png"></a>
			<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/f45.png"></a>
			<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/f43.png"></a>
		</div>
	</div>	
</div>-->
	<div class="main-footer">
			
		<!--	<div class="footermenuarea">
				<div class="servicewrapper">
					<div class="footermenu fl">
						<h4>Company Information</h4>
					<?php $footer_theme_menu_id = get_site_option('footer_menu_id'); 
						wp_nav_menu( array( 'menu' => $footer_theme_menu_id , 'menu_class' => 'footer-menu' ) ); 
					?>
					</div>
					<div class="paymentaccept fl">
						<h4>Payment We Accept</h4>
							<div class="paymentimg">
								<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/11.png"></a>
								<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/12.png"></a>
								<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/13.png"></a>
								<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/14.png"></a>
								
							</div>
							<div class="first_r fl secfooter">
								<h4>Book With Confidence</h4>
								<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/h2.png"></a>
								<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/h1.png"></a>
								
								<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/h3.png"></a>

							</div>
					</div>
					<div class="contus fl">
						<h4>Opening Hours</h4>
						<div class="openingtime">
							8am to 8pm - Mon to Fri <br>
							9am to 6pm - Sat & Sun
						</div>
						<div class="cntdetails">
							<h4>Contact Detail</h4>
							<div class="calandmail">
								<a href="tel:020 8782 4495">020 8782 4495</a>
								<a href="mailto:sales@worldwidecruisesuk.com" class="mail">sales@worldwidecruisesuk.com</a>
							</div>
						</div>
					</div>
					<div class="clr"></div>
				</div>
			</div>-->
			<div class="footerclarea">
				<div class="servicewrapper">
					<div class="fullimage"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/f111.png"></div>
				</div>
			</div>
			<div class="footermainlogo">
				<div class="servicewrapper">
					
					<div class="third_r fl secfooter" id="footer-center">
								<?php
								if(get_site_option( 'footer_left_part_content' )==""){
									?>
										<div class="full_width_footer">
										
											<p><?php echo html_entity_decode(stripslashes(get_site_option( 'footer_right_part_content' ))); ?></p>
									    </div>
									<?php
								}
								elseif(get_site_option( 'footer_right_part_content' )==""){
									?>
										<div class="full_width_footer">
										
											<p><?php echo html_entity_decode(stripslashes(get_site_option( 'footer_left_part_content' ))); ?></p>
										</div>
									<?php
								}
								else{
									?>
										<div id="footer_column_one">
											
											<p><?php echo get_site_option( 'footer_left_part_content' ); ?></p>
										</div>
										
										<div id="footer_column_three">
										
											<p><?php echo get_site_option( 'footer_right_part_content' ); ?></p>
									    </div>
									<?php
								}
								?>
					</div>
			<!-- 	<div class="sec_r fr secfooter">
					<div class="cinfo ">
						<h6>LINES OPEN LATE 7 DAYS A WEEK</h6>
						<a href="tel:020 8782 4567" class="callus">020 8782 4567</a>
						<p>We accept the following payments:</p>
						<div class="paymentimg">
						<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/11.png"></a>
						<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/12.png"></a>
						<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/13.png"></a>
						<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/14.png"></a>
						<a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/15.png"></a>
						</div>
					</div>

				</div> -->
				<div class="clr"></div>
			</div>
			</div>
	</div>

</div>
	
	

<script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/slidebars.min.js"></script>
		
<script>
    jQuery(document).ready(function() {
      jQuery.slidebars();
    });
</script>		

<script>

	         jQuery.support.placeholder = ('placeholder' in document.createElement('input'));
	     

	     //fix for IE7 and IE8
	     jQuery(function () {
	         if (!jQuery.support.placeholder) {
	             jQuery("[placeholder]").focus(function () {
	                 if (jQuery(this).val() == jQuery(this).attr("placeholder")) jQuery(this).val("");
	             }).blur(function () {
	                 if (jQuery(this).val() == "") jQuery(this).val(jQuery(this).attr("placeholder"));
	             }).blur();

	             jQuery("[placeholder]").parents("form").submit(function () {
	                 jQuery(this).find('[placeholder]').each(function() {
	                     if (jQuery(this).val() == jQuery(this).attr("placeholder")) {
	                         jQuery(this).val("");
	                     }
	                 });
	             });
	         }
	     });//
	</script>
	<script type="text/javascript">
		jQuery('#myTabs a').click(function (e) {
		  e.preventDefault()
		  jQuery(this).tab('show')
		})
	</script>

 <script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.placeholder.min.js"></script>
		<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.dlmenu.js"></script>
		<script>
			jQuery(document).ready(function() {
				jQuery( '#dl-menu' ).dlmenu();
			});
		</script>
	</div><!-- #main -->

<script type="text/javascript">
jQuery( document ).ready(function() {

    /*jQuery(".detail_open_search").slideUp();
    jQuery("#change_detail_search").click(function(){
    	jQuery(".detail_open_search").slideToggle();
    });*/

});

function open_enq(str){
	jQuery("#slide_down_div_"+str).show();
	/*jQuery("#slide_down_div_"+str).click(function(){
		jQuery("#slide_down_div_"+str).hide();
	});*/
}

function close_me(str){
	jQuery("#slide_down_div_"+str).hide();
	jQuery(".ajax_success").empty();
}

function port_breif(self,port_code,class_name){
		var port_code = port_code;
        var class_name = class_name;
        if(jQuery(self).hasClass('active_port')) {
            jQuery('#'+class_name).slideUp();
            jQuery(self).removeClass('active_port');
        }
        else{
            jQuery.ajax({
                type: "POST",
                url: ('<?php echo admin_url( 'admin-ajax.php' ); ?>'),
                data: ({
                    action: 'port_breif_res',
                    port_code: port_code,
                    class_name: class_name
                }),
                success: function (response) {
                    //alert(response);
                    jQuery('#'+class_name).slideDown();
                    jQuery(self).addClass('active_port');
                    jQuery('#'+class_name).html(response);
                }
            });
        }
    }

function iflair_detail_search_filter(str){
	var region_page = "<?php if(!is_page(4467)){ echo '1'; } else{ echo '0'; } ?>";
	var pagenumb='1';
	var check = str;
	var region = jQuery('#cruise_region').val();
	var operator = jQuery('#cruise_operator').val();
	var cruise_ship = jQuery('#cruise_ship').val();
	var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
	var leaving_from = jQuery('#cruise_leaving_from').val();
	var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
	var from_cruise_date = jQuery('#from_cruise_date').val();
	var to_cruise_date = jQuery('#to_cruise_date').val();
	var ship_cruise_nights = jQuery('#cruise_ship_cruise_nights').val();
	if(check=="reset"){
		jQuery('#cruise_region').prop('selectedIndex',0);
		jQuery('#cruise_operator').prop('selectedIndex',0);
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    	jQuery('.loader_filt').css('display','block');

		jQuery.cookie('str1', '', {expires: 1 });
		jQuery.cookie('str2', '', {expires: 1 });

		return false;
	}
	if(check=="region"){
		jQuery('#cruise_operator').prop('selectedIndex',0);
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_detail_search_filter();
	}
	if(check=="operator"){
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_detail_search_filter();
	}
	if(check=="cruise_ship"){
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_detail_search_filter();
	}
	if(check=="ship_fly_in"){
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_detail_search_filter();
	}
	if(check=="leaving_from"){
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_detail_search_filter();
	}
	if(check=="ship_starts_on"){
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_detail_search_filter();
	}
	if(check=="ship_cruise_nights"){
			//iflair_detail_search_filter();
    jQuery('.loader_filt').css('display','block');
	}
	if(check=="search"){

		jQuery.cookie('str1', '', {expires: 1 });
		jQuery.cookie('str2', '', {expires: 1 });

		/*if(region==""){
			jQuery('#cruise_region').focus();
			alert("Where do you want to go?");
			return false;
		}
		if(operator==""){
			jQuery('#cruise_operator').focus();
			alert("Who would you like to Cruise with?");
			return false;
		}*/
		var width_res = jQuery(".header").width();
		if(width_res<768){
			jQuery('.input-form.wrraper').slideToggle();
		}
		jQuery('.loader').css('display','block');
		jQuery('.search_header').addClass('searched');
		jQuery('.search_header').addClass('searched_image');
		jQuery('#replace_query_ajax').addClass('replace_query_class');
		//cruise_filter();
	}
	//alert(str);
	jQuery.ajax({
        type: "POST",
        url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
        data: ({
            action: 'iflair_detail_search_filter_response',
            region: region,
            region_page:region_page,
            operator: operator,
            cruise_ship: cruise_ship,
            ship_fly_in: ship_fly_in,
            leaving_from: leaving_from,
            ship_starts_on: ship_starts_on,
            from_cruise_date:from_cruise_date,
            to_cruise_date:to_cruise_date,
            ship_cruise_nights: ship_cruise_nights
        }),
        success: function (response) {
        	jQuery('.loader').css('display','none');
        	jQuery('.loader_filt').css('display','none');
            //alert(response);
            jQuery('.form-field-cruise').html(response);
                /*if(jQuery(".form-field-cruise").next("form-field-cruise")){
                    jQuery(".form-field-cruise").removeClass();
                }*/
            var dateToday = new Date();
            var dates = jQuery("#from_cruise_date, #to_cruise_date").datepicker({
                defaultDate: "+1w",
                changeMonth: true,
                dateFormat: 'd M yy',
                beforeShow: function (input, inst) {
                    var rect = input.getBoundingClientRect();
                    setTimeout(function () {
                        inst.dpDiv.css({ top: rect.top + 40, left: rect.left + 0 });
                    }, 0);
                },
                numberOfMonths: 1,
                /*beforeShowDay: function( date ) {
                    var highlight = eventDates[date];
                    if( highlight ) {
                         return [true, "event", highlight];
                    } else {
                         return [true, '', ''];
                    }
                 },*/
                minDate: dateToday,
                onSelect: function(selectedDate) {
                    var option = this.id == "from_cruise_date" ? "minDate" : "maxDate",
                        instance = jQuery(this).data("datepicker"),
                        date = jQuery.datepicker.parseDate(instance.settings.dateFormat || jQuery.datepicker._defaults.dateFormat, selectedDate, instance.settings);
                    dates.not(this).datepicker("option", option, date);
                }
            });
        }
    });
    //cruise_filter();
}

function sort_search_filter(){
	jQuery('.loader').css('display','block');
	cruise_filter();
}

function listing_inq(ship_name,ship_starts_on,cruise_title,cruise_id,ship_operator){
	jQuery( '#listing_inq_modal' ).remove();
	/*alert(ship_name);
	alert(ship_starts_on);
	alert(cruise_title);
	alert(cruise_id);*/
  	
	jQuery("#manual_model_slide_"+cruise_id).after( '<div id="listing_inq_modal"><img src="http://37.220.92.242/~cruisecircleco/wp-content/themes/CruiseCircle/images/loader.gif" class="extra_img_load"></div>' );
	jQuery.ajax({
        type: "POST",
        url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
        data: ({
            action: 'listing_inq_ajax',
            ship_name: ship_name,
            ship_starts_on: ship_starts_on,
            cruise_title: cruise_title,
            cruise_id: cruise_id,
            ship_operator:ship_operator
        }),
        success: function (response) {
        	//alert(response);
        	jQuery('.loader').css('display','none');
            jQuery('#listing_inq_modal').html(response);
            //jQuery('.modal-body').effect( "shake" ,55 );
		}
    });
}

function callback() {
	jQuery( '#listing_inq_modal' ).fadeOut();
  setTimeout(function() {
 	jQuery( '#listing_inq_modal' ).remove();
  }, 1000 );
};
</script>
<style type="text/css">
#listing_inq_modal {
  background: rgba(0, 0, 0, 0.5) none repeat scroll 0 0;
  height: 100%;
  opacity: 1;
  overflow-y: scroll;
  position: fixed;
  right: 0;
  top: 0;
  width: 100%;
  z-index: 1;
}
.header.wrraper.search_header.searched.searched_image {
  margin: 0;
  width: auto;
}
</style>
<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery-ui.js"></script>
<?php wp_footer(); ?>
</body>
</html>