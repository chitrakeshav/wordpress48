<div class="my_meta_control">
<?php
	global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
	$mainsiteprefix='cm_';
	$agentsiteurl=get_option('siteurl');
	$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
	$agentsiteid=$agentsitedetail->id;
	$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
	$agent_assign_operator;
	if(!empty($agent_assign_operator)){
		$operator_condition_old_tbl = " cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id ";
		$operator_condition_old = " co.operator_id IN ($agent_assign_operator) AND csc.ship_starts_on BETWEEN NOW() AND DATE_ADD( NOW() , INTERVAL +12 MONTH) ";
	}
	else{
		$operator_condition_old_tbl = " cruise_cruise AS cc INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id ";
		$operator_condition_old = " csc.ship_starts_on BETWEEN NOW() AND DATE_ADD( NOW() , INTERVAL +12 MONTH)";
	}

$template = get_page_template_slug() ;
if ( $template == 'operator_details.php' ) {
				$cruise_operator_title= "SELECT co.operator_id,co.operator_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE".$operator_condition_old."";
	  			$cruise_operator_title .= " GROUP BY co.operator_title ORDER BY co.operator_title";
	  			
				$select_cruise_operator_title = $mydb->get_results($cruise_operator_title);
				$c2 = count($select_cruise_operator_title);
				$qq="0 value";
			?>
		    <select <?php //if($c2==0){echo 'disabled="true" ';}?> name="_my_meta[operator]" id="iflair_cruise_operator" class="btn btn-default dropdown-toggle text p-2 second_filter_class" >
				<option value="" >Which Cruise Line?</option>
				<option value="all" <?php if($_POST['operator']=="all"){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_operator_title as $cruise_operator_title_obj) :
					echo $cruise_operator_title_obj->operator_id;
					?>
					<option value="<?php echo $cruise_operator_title_obj->operator_id; ?>" <?php if(!empty($meta['operator'])) { if($meta['operator'] == $cruise_operator_title_obj->operator_id ){ echo "selected"; } } ?> ><?php echo $cruise_operator_title_obj->operator_title; ?></option>
					<?php
				endforeach;
				?>
			</select>
<?php
}
else if ( $template == 'destination_page.php' ) {

				$cruise_region= "SELECT csc.ship_region FROM".$operator_condition_old_tbl."WHERE".$operator_condition_old."";
	  			$cruise_region .= " GROUP BY csc.ship_region ORDER BY csc.ship_region";
	  			$select_cruise_region = $mydb->get_results($cruise_region);
				$c2 = count($select_cruise_region);
				$qq="0 value";
			?>
		    <select name="_my_meta[ship_region]" id="iflair_cruise_operator" class="btn btn-default dropdown-toggle text p-2 second_filter_class" >
				<option value="" >Select Destination</option>
				<option value="all" <?php if($_POST['ship_region']=="all"){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_region as $cruise_region_obj) :
					?>
					<option value="<?php echo $cruise_region_obj->ship_region; ?>" <?php if(!empty($meta['ship_region'])) { if($meta['ship_region'] == $cruise_region_obj->ship_region ){ echo "selected"; } } ?> ><?php echo $cruise_region_obj->ship_region; ?></option>
					<?php
				endforeach;
				?>
			</select>
<?php
}
else{}

			?>
</div>