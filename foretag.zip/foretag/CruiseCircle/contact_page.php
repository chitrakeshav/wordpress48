<?php
/*
Template Name: Contact Page
*/
get_header();
?>
<div class="servicewrapper">
<div class="fullarea">
<div class="leftside">
	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">
			<div class="servicewrapper">
			<?php /* The loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					

					<div class="entry-content">
						<?php the_content(); ?>
						<?php wp_link_pages( array( 'before' => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentythirteen' ) . '</span>', 'after' => '</div>', 'link_before' => '<span>', 'link_after' => '</span>' ) ); ?>
					</div><!-- .entry-content -->

					<footer class="entry-meta">
						<?php edit_post_link( __( 'Edit', 'twentythirteen' ), '<span class="edit-link">', '</span>' ); ?>
					</footer><!-- .entry-meta -->
				</article><!-- #post -->

				<?php comments_template(); ?>
			<?php endwhile; ?>
			</div>
		</div><!-- #content -->
	</div><!-- #primary -->
</div>
<div class="sidebararea">
<?php get_sidebar(); ?>
</div>
</div>
</div>
<?php
get_footer(); 
?>