<?php
/**
 * The Header for our theme
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */
?><!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, user-scalable=no" />
	<title><?php wp_title( '|', true, 'right' ); ?></title>
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
		<link rel="shortcut icon" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/circle-orange.ico" type="images/x-icon">
	<!--[if lt IE 9]>
	<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js"></script>
	<![endif]-->
	
	<?php wp_head(); ?>
	
  <!--  	<link href='https://fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic&subset=latin,greek,greek-ext,vietnamese,cyrillic-ext,latin-ext,cyrillic' rel='stylesheet' type='text/css'> -->
    <link rel="shortcut icon" type="image/gif" sizes="16x16" href="<?php echo esc_url( get_template_directory_uri() ); ?>/logo2.ico">

    <link rel="stylesheet" type="text/css" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/slidebars.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/responsive.css">
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/component.css">		
    
    <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/LazyLoad.js"></script>  
    <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/modernizr.custom.js"></script>      
    <script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/bootstrap.js"></script>
    <script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/cookie.js"></script>
 		<link rel="stylesheet" type="text/css" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/style-menu-res.css">
   

    <script type="text/javascript">
	jQuery(document).ready(function(){
		//jQuery(".nav.menu ul li.menu-item-has-children > a").addClass(fa);
		//jQuery(".nav.menu ul li.menu-item-has-children > a").addClass(fa-caret-down);
		jQuery( ".toggle-menu-header" ).click(function() {
			jQuery( ".newheadermenu" ).slideToggle( "slow", function() {
			});
		});

		//jQuery.cookie('str1', '', {expires: 1 });
		//jQuery.cookie('str2', '', {expires: 1 });

		jQuery(".dl-menu .sub-menu").each(function(){
			jQuery(this).removeClass('sub-menu');
			jQuery(this).addClass('dl-submenu');
		});

		}); 
	</script>
</head>

<body <?php body_class(); ?>>
		<div id="dl-menu" class="dl-menuwrapper">
						<button class="dl-trigger">Open Menu</button>

			<?php $theme_menu_id = get_site_option('header_menu_id'); 
			wp_nav_menu( array( 'menu' => $theme_menu_id ,'theme_location' => 'primary', 'menu_class' => 'dl-menu' ,'container' => false ) ); ?>
						
					</div>
<?php 
	global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
	$mainsiteprefix='cm_';
	$agentsiteurl=get_option('siteurl');
	$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
	$agentsiteid=$agentsitedetail->id;
	$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
?>
<div class="main_header">
	
	<div class="servicewrapper">
		<?php 
		if(get_site_option( 'iflair_cruise_theme_phone_number' ) && get_site_option( 'iflair_cruise_theme_phone_number' ) != "00000 00000"){
		?>
		<div class="callanswer">
					<a href="tel:<?php echo get_site_option( 'iflair_cruise_theme_phone_number' ); ?>" class="callme"></a>
		</div>
		<?php } ?>
        <div class="logoheader">
			<a href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/hlogo.png" alt=""></a>
			
		</div>
        <div class="header-right">
		
		<!--  <div class="buttons">
					<button class="nav-toggler toggle-slide-left">Slide Menu Left</button>
		</div> -->
		
		<div class="HeaderText">
					<?php 
					if(get_site_option( 'iflair_cruise_theme_phone_number' ) && get_site_option( 'iflair_cruise_theme_phone_number' ) != "00000 00000"){
						?>
							<p class="tel"><a><?php echo get_site_option( 'iflair_cruise_theme_phone_number' ); ?></a></p>
						<?php
					} 
					?>
					<h2>
						<?php echo get_site_option( 'header_content' ); ?>
					</h2>
					<?php /*
					<div class="HeaderSocial">
						<?php
							if(get_site_option( 'iflair_cruise_theme_facebook_url' ) != "" && get_site_option( 'iflair_cruise_theme_facebook_url' ) != "#"){
								?>
								<a target="_blank" href="<?php echo get_site_option( 'iflair_cruise_theme_facebook_url' ); ?>" rel="nofollow">
									<img src="<?php echo get_site_option( 'iflair_cruise_theme_facebook_icon' ); ?>" style="max-width:40px" />
								</a>
								<?php
							}
						?>
						<?php
							if(get_site_option( 'iflair_cruise_theme_twitter_url' ) != "" && get_site_option( 'iflair_cruise_theme_twitter_url' ) != "#"){
								?>
								<a target="_blank" href="<?php echo get_site_option( 'iflair_cruise_theme_twitter_url' ); ?>" rel="nofollow">
									<img src="<?php echo get_site_option( 'iflair_cruise_theme_twitter_icon' ); ?>" style="max-width:40px" />
								</a>
								<?php
							}
						?>
						<?php
							if(get_site_option( 'iflair_cruise_theme_google_plus_url' ) != "" && get_site_option( 'iflair_cruise_theme_google_plus_url' ) != "#"){
								?>
								<a target="_blank" href="<?php echo get_site_option( 'iflair_cruise_theme_google_plus_url' ); ?>" rel="nofollow">
									<img src="<?php echo get_site_option( 'iflair_cruise_theme_google_plus_icon' ); ?>" style="max-width:40px" />
								</a>
								<?php
							}
						?>
						<?php
							if(get_site_option( 'iflair_cruise_theme_linked_in_url' ) != "" && get_site_option( 'iflair_cruise_theme_linked_in_url' ) != "#"){
								?>
								<a target="_blank" href="<?php echo get_site_option( 'iflair_cruise_theme_linked_in_url' ); ?>" rel="nofollow">
									<img src="<?php echo get_site_option( 'iflair_cruise_theme_linked_in_icon' ); ?>" style="max-width:40px" />
								</a>
								<?php
							}
						?>
					</div>
					*/ ?>
             <div class="alarea">
                    <a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/abta-logo.png" alt=""></a>
                    <a href="<?php echo get_permalink('4483'); ?>"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/clia-logo.png" alt=""></a>
				    <a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/atol-logo.png" alt=""></a>
                </div>  
				</div>
                 
            </div>
	</div>	
</div>
<div class="menubar">
	<div class="servicewrapper">
			<nav>
			<?php $theme_menu_id = get_site_option('header_menu_id'); 
						wp_nav_menu( array( 'menu' => $theme_menu_id ,'theme_location' => 'primary', 'menu_class' => 'nav-menu' ) ); ?>
			</nav>
	</div>
</div>
<div class="scroll_header" style="display:none;">
	<div class="container">
		<div class="scroll_logo">
			<a href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/header-logo.jpg" alt="<?php echo get_site_option( 'blogname' ); ?>" /></a>
		</div>
		<div class="scroll_menu">
			<?php $theme_menu_id = get_site_option('header_menu_id'); 
			wp_nav_menu( array( 'menu' => $theme_menu_id ,'theme_location' => 'primary', 'menu_class' => 'nav-menu' ) ); ?>
		</div>
	</div>
</div>
<div id="page" class="hfeed site">


