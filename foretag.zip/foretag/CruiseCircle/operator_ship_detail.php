<?php
/*
Template Name: Operator Ship Detail Page
*/
get_header(); 
?>
<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/jquery.mCustomScrollbar.css">
<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/lazyYT.css">
<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.mCustomScrollbar.concat.min.js"></script>
<link href="<?php echo esc_url( get_template_directory_uri() ); ?>/dist/css/lightgallery.css" rel="stylesheet">
<script type="text/javascript">
    jQuery(window).load(function(){
		jQuery('body').css("height","100%").delay(100);
    });
	//jQuery(".main_header").css("background-color","#0969B3");
    function scrolltofunction(tab_id) {
		jQuery('body').css("height","auto");
	    //jQuery.scrollTo(jQuery('#'+tab_id), 1000);
		/*jQuery('html, body').animate({
			scrollTop: jQuery('#'+tab_id).offset().top
		}, 700);
    	jQuery('#'+tab_id+'_div').slideDown();*/

    	var visible = jQuery('#'+tab_id+'_div').is(":visible");
    		jQuery(".accomodareatwo").slideUp();
		    jQuery(".accomodarea h4").removeClass('valid_tick');
        if (!visible) {
        	//alert(tab_id+'_div');
        	//jQuery('#'+tab_id+'_div').slideDown();


		    if(jQuery('#'+tab_id).hasClass('valid_tick')) {
	    		jQuery('#'+tab_id).next().slideUp();
		        jQuery('#'+tab_id).removeClass('valid_tick');
		    } else {
	    		jQuery('#'+tab_id).next().slideDown();
		        jQuery('#'+tab_id).addClass('valid_tick');
		    };

        	setTimeout(function(){ 
        		//alert(jQuery('#'+tab_id).offset().top);
        		jQuery('html, body').animate({
	                scrollTop: jQuery('#'+tab_id).offset().top
	            }, 300);
        	}, 500);
            
        }

    	//jQuery('#'+tab_id).css("background-image","none");

	}
    function operator_detail_feature_tab(tab_name,response_id,tab_id,check){
        jQuery('.loader_feature_tab').css('display','block');
    	var tab_name = tab_name;
    	var tab_id = tab_id;
    	var check = check;
	    jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'operator_detail_feature_tab',
	            tab_name: tab_name,
	            response_id:response_id,
	            tab_id:tab_id
            }),
            success: function (response) {
            	jQuery('.loader_feature_tab').css('display','none');
                //alert(event.result);
                jQuery('.'+tab_name+' div').html(response);
        		jQuery(".accomodation").addClass("searched");
        		if(response=="" && check=="0"){
        			//alert("1010");
					//jQuery(this).addClass("empty");

					//var empty_id = jQuery('#'+tab_id+'_div > .empty').parent().attr('id');
					jQuery('#'+tab_id+'_div > div:empty').addClass("empty");
					//alert(empty_id);
					jQuery('#'+tab_id+'_div').parent().hide();
					jQuery('.'+tab_id+'_div').hide();
        		}
    			//jQuery(".shipmenu ul li:nth-child(2)").hide();
    			//jQuery(".shipmenu ul li:nth-child(3)").hide();
    			//jQuery("#tab2_div").parent().hide();
            }
        });
    }
    
</script>
<?php
global $wpdb,$mydb;
$site_detail_result = $mydb->get_row("SELECT csc.cruise_id,csc.ship_id,cc.* FROM `cruise_ship_cruise` as csc INNER JOIN `cruise_cruise` as cc ON csc.ship_id = cc.cruise_response_id WHERE cc.cruise_response_id = '$_GET[cruise_id]'");
/*echo "<pre>";
print_r($site_detail_result);
echo "</pre>";*/

if(!$site_detail_result){
?>
<div class="header wrraper search_header" style="background:rgba(0, 0, 0, 0) url(<?php $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo $feat_image; ?>) no-repeat scroll center top / cover ">
	<div class= "mobile-top wrapper clearfix">
			<a href="#" class="w-arrow"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/white-arrow.png"></a>
		</div>
	<div class="container">					
		<div class="grey-box-wrraper clearfix">
			<div class="grey-box">
				<h1>No Cruise Details Found</h1>	
				<a href="<?php echo get_page_link($listing_page_id); ?>" class="cruise">BACK TO CRUISE LIST</a>	
			</div>					
		</div>
	</div>
</div>
<?php
}
else{
?>


<?php
}
?>


	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">

			<div class="shipop">
				<div class="shipfix">
				<div class="shipheaderarea">
				<div class="container">
					
						<div class="shipthumb">
							<img src="<?php bloginfo( 'template_url' ); ?>/images/thumb.png" alt="">
						</div>
						<div class="shititle">
							<?php echo $site_detail_result->cruise_title; ?>
						</div>
						<a href="javascript:history.go(-1)" class="bacclass">
							<img src="<?php bloginfo( 'template_url' ); ?>/images/back.png" alt="">
						</a>
					</div>
				</div>
				<div class="shimenuarea">
				<div class="container">
					<div class="shipmenu">
						<ul>
							<li><a onclick="scrolltofunction('tab-1');" href="javascript:void(0)">Overview</a></li>
							<?php if($site_detail_result->cruise_unique_feature!=""){ ?><li><a onclick="scrolltofunction('tab0');" class="tab0_div" href="javascript:void(0)">unique-feature</a></li><?php } ?>
							<li class="tab1_div"><a onclick="scrolltofunction('tab1');" href="javascript:void(0)">Accommodation</a></li>
							<li class="tab2_div"><a onclick="scrolltofunction('tab2');" href="javascript:void(0)">decks </a></li>
							<li class="tab3_div"><a onclick="scrolltofunction('tab3');" href="javascript:void(0)">dining</a></li>
							<li class="tab4_div"><a onclick="scrolltofunction('tab4');" href="javascript:void(0)">entertaiment</a></li>
							<li class="tab5_div"><a onclick="scrolltofunction('tab5');" href="javascript:void(0)">health & fitness</a></li>
							<li class="tab6_div"><a onclick="scrolltofunction('tab6');" href="javascript:void(0)">kids & teens</a></li>
							<li class="tab7_div"><a onclick="scrolltofunction('tab7');" href="javascript:void(0)">Enrichment</a></li>
							<li><a href="javascript:history.go(-1)">Cruises</a></li>

						</ul>
					</div>
				</div>
					</div>
				</div>
						<div class="shipopimg" style="background-image: url('http://ekups3e.cloudimg.io/s/resize/1800/<?php echo str_replace('//www','http://www',$site_detail_result->cruise_cover_image_href); ?>');"></div>
				<div class="container">
		
				<div class="shipopdetail">
					<div class="shipleft">
						<?php echo html_entity_decode($site_detail_result->cruise_introduction); ?>
						<?php
							if($site_detail_result->cruise_video_url!=""){
								$url = $site_detail_result->cruise_video_url;
								$step1=explode('v=', $url);
								$step2 =explode('&',$step1[1]);
								//print_r($step2);
								if(empty($step2[0])){
									//echo "dfgjdkgj";
									$url = $site_detail_result->cruise_video_url;
									$step1=explode('/', $url);
									//print_r($step1);
									$vedio_id = $step1[3];
								}
								else{
									$vedio_id = $step2[0];
								}
								if($site_detail_result->cruise_video_url!="")
								{ 
									$headers = get_headers('http://www.youtube.com/oembed?url=http://www.youtube.com/watch?v='.$vedio_id);
									if (strpos($headers[0], '200')) 
									{
									?>
									<div class="js-lazyYT" data-width="724" data-height="424" data-youtube-id="<?php echo $vedio_id; ?>"></div>
									<?php
									}
								}
							}
						?>

					
					</div>
					<div class="shiprightside" id="tab-1">
						<div class="shipdetaillogo">
							<a href="javascript:history.go(-1)">
								<img src="http://ekups3e.cloudimg.io/s/resize/300/<?php echo str_replace('//www','http://www',$site_detail_result->cruise_profile_image_href); ?>" alt="">
							</a>
						</div>
						<!--div class="downonloadbro">
							<?php
							$get_cruise_operator = $mydb->get_row("SELECT operator_id FROM cruise_operators WHERE operator_title = '".$site_detail_result->cruise_operator_name."' ");
							$get_brochure = $mydb->get_row("SELECT * FROM operator_brochure WHERE operator_id = ".$get_cruise_operator->operator_id." ");
							//print_r($get_brochure);
							?>
							<a href="<?php echo $get_brochure->brochure_href; ?>" title="<?php echo $get_brochure->brochure_name; ?>" target="_blank" >download brochure</a>
						</div-->
						<div class="specificationarea">
							<h4>specifications</h4>
							<div class="shipnumber">
								<div class="Llydno">
									<div class="ly">Llyd No</div>
								</div>
								<div class="lyno">
									<?php echo $site_detail_result->cruise_imo; ?>
								</div>
							</div>	
							<div class="startspce">
								<div class="spacrowspace">
								<div class="spacerow">
									<div class="spcificatiodetail">
											<div class="spimge">
												<img src="<?php bloginfo( 'template_url' ); ?>/images/1.png" alt="">
											</div>
											<div class="specdta">size</div>
									</div>
									<div class="spacefull">
										<?php if($site_detail_result->cruise_ship_size==""){ echo "-"; } else{ echo $site_detail_result->cruise_ship_size; }; ?>
									</div>
								</div>
								<div class="spacerow">
									<div class="spcificatiodetail">
											<div class="spimge">
												<img src="<?php bloginfo( 'template_url' ); ?>/images/2.png" alt="">
											</div>
											<div class="specdta">Style</div>
									</div>
									<div class="spacefull">
										<?php if($site_detail_result->crusie_ship_style==""){ echo "-"; } else{ echo $site_detail_result->crusie_ship_style; }; ?>
									</div>
								</div>
								<div class="spacerow">
									<div class="spcificatiodetail">
											<div class="spimge">
												<img src="<?php bloginfo( 'template_url' ); ?>/images/3.png" alt="">
											</div>
											<div class="specdta">Type</div>
									</div>
									<div class="spacefull">
										<?php if($site_detail_result->crusie_ship_type==""){ echo "-"; } else{ echo $site_detail_result->crusie_ship_type; }; ?>
									</div>
								</div>
							</div>
							<div class="spacrowspace">
								<div class="spacerow ">
									<div class="spcificatiodetail">
											<div class="spimge">
												<img src="<?php bloginfo( 'template_url' ); ?>/images/4.png" alt="">
											</div>
											<div class="specdta">Year of Launch</div>
									</div>
									<div class="spacefull">
										<?php $launch_year = unserialize($site_detail_result->cruise_ship_facts); 
								if($launch_year[launch_year]==""){ echo "-"; }else{ echo $launch_year[launch_year]; } ?>
									</div>
								</div>
								<div class="spacerow ">
									<div class="spcificatiodetail">
											<div class="spimge">
												<img src="<?php bloginfo( 'template_url' ); ?>/images/5.png" alt="">
											</div>
											<div class="specdta">Year of last refit</div>
									</div>
									<div class="spacefull">
										<?php $refit_year = unserialize($site_detail_result->cruise_ship_facts); 
								if($refit_year[refit_year]==""){ echo "-"; }else{ echo $refit_year[refit_year]; } ?>
									</div>
								</div>
							</div>
							<div class="spacrowspace">
								<div class="spacerow">
									<div class="spcificatiodetail">
											<div class="spimge">
												<img src="<?php bloginfo( 'template_url' ); ?>/images/6.png" alt="">
											</div>
											<div class="specdta">Gross tonnage</div>
									</div>
									<div class="spacefull">
										<?php $gross_tonnage = unserialize($site_detail_result->cruise_ship_facts); 
									if($gross_tonnage[gross_tonnage]==""){ echo "-"; }else{ echo $gross_tonnage[gross_tonnage]."t"; } ?>
									</div>
								</div><div class="spacerow">
									<div class="spcificatiodetail">
											<div class="spimge">
												<img src="<?php bloginfo( 'template_url' ); ?>/images/7.png" alt="">
											</div>
											<div class="specdta">length</div>
									</div>
									<div class="spacefull">
										<?php $length = unserialize($site_detail_result->cruise_ship_facts); 
									if($length[length]==""){ echo "-"; }else{ echo $length[length]."m"; } ?>
									</div>
								</div>
								<div class="spacerow">
									<div class="spcificatiodetail">
											<div class="spimge">
												<img src="<?php bloginfo( 'template_url' ); ?>/images/8.png" alt="">
											</div>
											<div class="specdta">width</div>
									</div>
									<div class="spacefull">
										<?php $width = unserialize($site_detail_result->cruise_ship_facts); 
									if($width[width]==""){ echo "-"; }else{ echo $width[width]."m"; } ?>
									</div>
								</div>
								<div class="spacerow">
									<div class="spcificatiodetail">
											<div class="spimge">
												<img src="<?php bloginfo( 'template_url' ); ?>/images/9.png" alt="">
											</div>
											<div class="specdta">speed</div>
									</div>
									<div class="spacefull">
										<?php $speed = unserialize($site_detail_result->cruise_ship_facts); 
									if($speed[speed]==""){ echo "-"; }else{ echo $speed[speed]."kts"; } ?>
									</div>
								</div>
								<div class="spacerow">
									<div class="spcificatiodetail">
											<div class="spimge">
												<img src="<?php bloginfo( 'template_url' ); ?>/images/10.png" alt="">
											</div>
											<div class="specdta">decks</div>
									</div>
									<div class="spacefull">
										<?php $deck_count = unserialize($site_detail_result->cruise_ship_facts); 
									if($deck_count[deck_count]==""){ echo "-"; }else{ echo $deck_count[deck_count].""; } ?>
									</div>
								</div>
								<div class="spacerow">
									<div class="spcificatiodetail">
											<div class="spimge">
												<img src="<?php bloginfo( 'template_url' ); ?>/images/111.png" alt="">
											</div>
											<div class="specdta">language</div>
									</div>
									<div class="spacefull">
										<?php $language = unserialize($site_detail_result->cruise_ship_facts); 
								if($language[language]==""){ echo "-"; }else{ echo $language[language]; } ?>
									</div>
								</div>
								<div class="spacerow">
									<div class="spcificatiodetail">
											<div class="spimge">
												<img src="<?php bloginfo( 'template_url' ); ?>/images/121.png" alt="">
											</div>
											<div class="specdta">currency</div>
									</div>
									<div class="spacefull">
										<?php $currency = unserialize($site_detail_result->cruise_ship_facts); 
								if($currency[currency]==""){ echo "-"; }else{ echo $currency[currency]; } ?>
									</div>
								</div>
							</div>
							<div class="spacrowspace">
								<div class="spacerow">
									<div class="spcificatiodetail">
											<div class="spimge">
												<img src="<?php bloginfo( 'template_url' ); ?>/images/131.png" alt="">
											</div>
											<div class="specdta">No of Passsengers</div>
									</div>
									<div class="spacefull">
										<?php $capacity = unserialize($site_detail_result->cruise_ship_facts); 
									if($capacity[capacity]==""){ echo "-"; }else{ echo $capacity[capacity]; } ?>
								</div>
								
								</div>
								<div class="spacerow">
									<div class="spcificatiodetail">
											<div class="spimge">
												<img src="<?php bloginfo( 'template_url' ); ?>/images/141.png" alt="">
											</div>
											<div class="specdta">No of Crew</div>
									</div>
									<div class="spacefull">
										<?php $crew_count = unserialize($site_detail_result->cruise_ship_facts); 
									if($crew_count[crew_count]==""){ echo "-"; }else{ echo $crew_count[crew_count].""; } ?>
									</div>
								</div>
							</div>	
								<div class="spacerow">
									<div class="spcificatiodetail">
											<div class="spimge">
												<img src="<?php bloginfo( 'template_url' ); ?>/images/151.png" alt="">
											</div>
											<div class="specdta">No of Cabins</div>
									</div>
									<div class="spacefull">
										<?php $cabin_count = unserialize($site_detail_result->cruise_ship_facts); 
									if($cabin_count[cabin_count]==""){ echo "-"; }else{ echo $cabin_count[cabin_count].""; } ?>
									</div>
								</div>
								<div class="spacerow">
									<div class="spcificatiodetail">
											<div class="spimge">
												<img src="<?php bloginfo( 'template_url' ); ?>/images/161.png" alt="">
											</div>
											<div class="specdta">wheelchair access</div>
									</div>
									<div class="spacefull">
										<?php $wheelchair_cabin_count = unserialize($site_detail_result->cruise_ship_facts); 
									if($wheelchair_cabin_count[wheelchair_cabin_count]==""){ echo "-"; }else{ echo $wheelchair_cabin_count[wheelchair_cabin_count].""; } ?>
									</div>
								</div>
								<div class="spacerow spacerowlast">
									
								</div>

						</div>

					</div>
				</div>
				<?php if($site_detail_result->cruise_unique_feature!=""){ ?>
				<div class="uniquefeaturearea">
						<h4 id="tab0">unique features</h4>
						<div class="unidetailarea">
							<div class="unidetail" style="width: 100%;">
								<?php echo html_entity_decode($site_detail_result->cruise_unique_feature); ?>
							</div><!-- 
							<div class="uniqpic">
									<img src="<?php bloginfo( 'template_url' ); ?>/images/122.png" alt="">
							</div> -->
						</div>
				</div>
				<?php } ?>
				<div class="facilityarea">
					<div class="gratutiesarea">

						<h4>gratuties</h4>
						<div class="gratutiesareatwo">
						<?php echo html_entity_decode($site_detail_result->cruise_gratuities); ?>
					</div>
					</div>
					<div class="facilitmain">
						<h4>facilities</h4>
						<ul>
							<?php if($site_detail_result->cruise_adults_only=="kids_allowed"){ ?><li class="adults">Adults only </li><?php } ?>
							<?php if($site_detail_result->cruise_childrens_facilities=="available"){ ?><li class="child"> children facilities</li><?php } ?>
							<?php if($site_detail_result->cruise_smoking=="some"){ ?><li class="smoke">smoking (<?php echo $site_detail_result->cruise_smoking; ?>) </li><?php } ?>
							<?php if($site_detail_result->cruise_nursery=="nursery"){ ?><li class="nursery"><?php echo $site_detail_result->cruise_nursery; ?></li><?php } ?>
						</ul>
					</div>
				</div>
				<div class="accomodarea">
					<h4 id="tab1">accommodation</h4>
					<div class="accomodareatwo accomodation_types" id="tab1_div">
					<?php
						$check="0";
					?>
						<div>
						<script type="text/javascript">
							jQuery( document ).ready(function() {
								operator_detail_feature_tab("accomodation_types","<?php echo $_GET['cruise_id'] ?>",'tab1',"<?php echo $check; ?>");
							});
						</script>
						</div>
					</div>
				</div>
				<div class="accomodarea">
					<h4 id="tab2">Deck</h4>
					<div class="accomodareatwo deckplans" id="tab2_div">
					<?php
						$check="0";
					?>
						<div>
						<script type="text/javascript">
							jQuery( document ).ready(function() {
								operator_detail_feature_tab("deckplans","<?php echo $_GET['cruise_id'] ?>",'tab2',"<?php echo $check; ?>");
							});
						</script>
						</div>
					</div>
				</div>
				<div class="accomodarea">
					<h4 id="tab3">dining</h4>
					<div class="accomodareatwo dining_options" id="tab3_div">
					<?php echo html_entity_decode($site_detail_result->cruise_dining_intro); ?>
					<?php
						if($site_detail_result->cruise_dining_intro!==""){ $check="1"; } else{ $check="0"; }
					?>
						<div>
						<script type="text/javascript">
							jQuery( document ).ready(function() {
								operator_detail_feature_tab("dining_options","<?php echo $_GET['cruise_id'] ?>",'tab3',"<?php echo $check; ?>");
							});
						</script>
						</div>
					</div>
				</div>
				<div class="accomodarea">
					<h4 id="tab4">entertainment</h4>
					<div class="accomodareatwo entertainment_types" id="tab4_div">
					<?php echo html_entity_decode($site_detail_result->cruise_entertainment_intro); ?>
					<?php
						if($site_detail_result->cruise_entertainment_intro!==""){ $check="1"; } else{ $check="0"; }
					?>
						<div>
						<script type="text/javascript">
							jQuery( document ).ready(function() {
								operator_detail_feature_tab("entertainment_types","<?php echo $_GET['cruise_id'] ?>",'tab4',"<?php echo $check; ?>");
							});
						</script>
						</div>
					</div>
				</div>
				<div class="accomodarea">
					<h4 id="tab5">health fitness</h4>
					<div class="accomodareatwo health_fitness_types" id="tab5_div">
					<?php echo html_entity_decode($site_detail_result->cruise_health_and_fitness_intro); ?>
					<?php
						if($site_detail_result->cruise_health_and_fitness_intro!==""){ $check="1"; } else{ $check="0"; }
					?>
						<div>
						<script type="text/javascript">
							jQuery( document ).ready(function() {
								operator_detail_feature_tab("health_fitness_types","<?php echo $_GET['cruise_id'] ?>",'tab5',"<?php echo $check; ?>");
							});
						</script>
						</div>
					</div>
				</div>
				<div class="accomodarea">
					<h4 id="tab6">kid & teen</h4>
					<div class="accomodareatwo kid_teen_types" id="tab6_div">
					<?php echo html_entity_decode($site_detail_result->cruise_kids_and_teens_intro); ?>
					<?php
						if($site_detail_result->cruise_kids_and_teens_intro!==""){ $check="1"; } else{ $check="0"; }
					?>
						<div>
						<script type="text/javascript">
							jQuery( document ).ready(function() {
								operator_detail_feature_tab("kid_teen_types","<?php echo $_GET['cruise_id'] ?>",'tab6',"<?php echo $check; ?>");
							});
						</script>
						</div>
					</div>
				</div>
				<div class="accomodarea">
					<h4 id="tab7">enrichment</h4>
					<div class="accomodareatwo enrichment_types" id="tab7_div">
					<?php echo html_entity_decode($site_detail_result->cruise_enrichment_intro); ?>
					<?php
						if($site_detail_result->cruise_enrichment_intro!==""){ $check="1"; } else{ $check="0"; }
					?>
						<div>
						<script type="text/javascript">
							jQuery( document ).ready(function() {
								operator_detail_feature_tab("enrichment_types","<?php echo $_GET['cruise_id'] ?>",'tab7',"<?php echo $check; ?>");
							});
						</script>
						</div>
					</div>
				</div>
			</div>
		</div><!-- #content -->
	</div><!-- #primary -->

<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/lazyYT.js"></script>
<script type="text/javascript">
jQuery( document ).ready(function() {
    jQuery('.js-lazyYT').lazyYT();
    
    // Pass some parameters
    jQuery('.js-lazyYT').lazyYT({
      loading_text: 'It is loading!...',
      default_ratio: '16:9'
    });

    jQuery(".accomodareatwo").slideUp();
   /* jQuery(".accomodarea h4").click(function(){
    	jQuery(".accomodareatwo").slideUp();
    	//jQuery(".accomodareatwo").slideUp();
    	jQuery(this).next().slideToggle();
    	jQuery(this).css("background-image","none");
		/*jQuery('html, body').animate({
			scrollTop: jQuery(this).offset().top
		}, 700);
    });*/

	jQuery(".accomodarea h4").click(function() {
		jQuery(".accomodareatwo").slideUp();
	    if(jQuery(this).hasClass('valid_tick')) {
    		jQuery(this).next().slideUp();
	        jQuery(".accomodarea h4").removeClass('valid_tick');
	    } else {
    		jQuery(this).next().slideDown();
	        jQuery(this).addClass('valid_tick');
	    };
	});

});
</script>
<?php
get_footer(); 
?>