<?php
/*
Template Name: Destination Page
*/
get_header();

while ( have_posts() ) : the_post();
$my_meta = get_post_meta($post->ID,'_my_meta',TRUE);
if(!empty($my_meta['ship_region'])){
	$my_selected_operator = $my_meta['ship_region'];
}
else{
	$my_selected_operator = "";	
}
endwhile;
?>
<a href="#replace_query_ajax" class="replace_query_ajax_c"></a>
<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/jquery.mCustomScrollbar.css">
<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/cookie.js"></script>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script>
jQuery( document ).ready(function() {
	iflair_search_filter();
});

function destination_layout_changer(){
	var str = '';
	jQuery("#pagination").append(str);

      jQuery(".grid_layout").click(function(){
        //alert("grid");
        jQuery(".list_layout").removeClass("active_layout");
        jQuery(".grid_layout").addClass("active_layout");
        //jQuery(".destination_replace").removeClass("list_layout_box");
        //jQuery(".destination_replace").addClass("grid_layout_box");

        jQuery(".destination_replace").removeClass("list_layout_box").delay(200).queue(function(next){
            jQuery(".destination_replace").addClass("grid_layout_box");
            next();
        });

      });
      jQuery(".list_layout").click(function(){
        //alert("list");
        jQuery(".grid_layout").removeClass("active_layout");
        jQuery(".list_layout").addClass("active_layout");
        //jQuery(".destination_replace").removeClass("grid_layout_box");
        //jQuery(".destination_replace").addClass("list_layout_box");

        jQuery(".destination_replace").removeClass("grid_layout_box").delay(200).queue(function(next){
            jQuery(".destination_replace").addClass("list_layout_box");
            next();
        });
      });

	jQuery(".destination_area").children().removeClass("container");
	jQuery("#replace_query_ajax").children().removeClass("d-content");
	jQuery("#replace_query_ajax").addClass("destination_replace");
	jQuery("#replace_query_ajax").children().children().removeClass("servicewrapper");
	jQuery( ".second_filter_class" ).change(function() {
		//alert( "Handler for .change() called." );
		window.location.href = "#replace_query_ajax";
		jQuery(".loader").show();
		//jQuery( ".replace_query_ajax_c" ).trigger( "click" );
		/*jQuery("html, body").delay(2000).animate({
			scrollTop: jQuery('.result-part').offset().top 
		}, 500);*/
	});
}

function iflair_search_filter(str){
	var pagenumb='1';
	var check = str;
	var region = "<?php echo $my_selected_operator;?>";
	//var region = jQuery('#cruise_region').val();
	var operator = jQuery('#cruise_operator').val();
	var cruise_ship = jQuery('#cruise_ship').val();
	var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
	var leaving_from = jQuery('#cruise_leaving_from').val();
	var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
	var ship_vacation_days = jQuery('#cruise_ship_vacation_days').val();
	if(check=="reset"){
		jQuery('#cruise_region').prop('selectedIndex',0);
		jQuery('#cruise_operator').prop('selectedIndex',0);
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);
    	jQuery('.loader_filt').css('display','block');

		jQuery.cookie('str1', '', {expires: 1 });
		jQuery.cookie('str2', '', {expires: 1 });

		return false;
	}
	//alert(check);
	if(check=="region"){
		jQuery('#cruise_operator').prop('selectedIndex',0);
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="operator"){
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="cruise_ship"){
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="ship_fly_in"){
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="leaving_from"){
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="ship_starts_on"){
		jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="ship_vacation_days"){
			//iflair_search_filter();
    jQuery('.loader_filt').css('display','block');
	}
	if(check=="search"){

		jQuery(".home-journey").hide();

		<?php $listing_page_id = get_site_option( 'iflair_cruise_theme_ship_listing_page' );?>
		var newURL = "<?php echo get_permalink($listing_page_id); ?>";

		if(jQuery('#amount1').val()=="undefined"){
			var s = "0";
		}
		else{
			var s =jQuery('#amount1').val();
		}
		if(jQuery('#amount2').val()=="undefined"){
			var e = "10000";
		}
		else{
			var e = jQuery('#amount2').val();
		}
		//alert(start_price);
		
		if( region == "" && operator == "" && cruise_ship == "" && ship_fly_in == "" && ship_starts_on == "" && ship_vacation_days == "" ){	
		    var s = "0";
		    var e = "1000";
		}

        //history.pushState({},"URL Rewrite Example",newURL+"?cruise_region="+region+"&cruise_operator="+operator+"&cruise_ship="+cruise_ship+"&cruise_ship_fly_in="+ship_fly_in+"&cruise_ship_starts_on="+ship_starts_on+"&cruise_ship_vacation_days="+ship_vacation_days+"&start_price="+s+"&end_price="+e);

		jQuery.cookie('str1', '', {expires: 1 });
		jQuery.cookie('str2', '', {expires: 1 });

		var width_res = jQuery(".header").width();
		if(width_res<768){
			jQuery('.input-form.wrraper').slideToggle();
		}
		jQuery('.loader').css('display','block');
		jQuery('.search_header').addClass('searched');
		jQuery('.search_header').addClass('searched_image');
		jQuery('#replace_query_ajax').addClass('replace_query_class');

		//history.pushState({},"URL Rewrite Example",newURL+""+path+"?cruise_region="+region+"&cruise_operator="+operator+"&cruise_ship="+cruise_ship+"&cruise_ship_fly_in="+ship_fly_in+"&cruise_ship_starts_on="+ship_starts_on+"&cruise_ship_vacation_days="+ship_vacation_days+"&start_price="+s+"&end_price="+e);

		cruise_filter();

	}
	jQuery.ajax({
        type: "POST",
        url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
        data: ({
            action: 'iflair_search_filter_response',
            region: region,
            operator: operator,
            cruise_ship: cruise_ship,
            ship_fly_in: ship_fly_in,
            leaving_from: leaving_from,
            ship_starts_on: ship_starts_on,
            ship_vacation_days: ship_vacation_days,
            pagenumb:pagenumb
        }),
        success: function (response) {
        	//alert(response);
        	jQuery('.loader').css('display','none');
        	jQuery('.loader_filt').css('display','none');
            jQuery('.form-field').html(response);
	        jQuery(".content").mCustomScrollbar();
	        jQuery('#mCSB_1_scrollbar_vertical').remove();
	        jQuery('#mCSB_3_scrollbar_vertical').remove();
	        if(region!=""){
				cruise_filter();
	        }
        }
    });
}


function cruise_filter(str){
	jQuery('.loader').css('display','block');
	var pagenumb='1';
	var check = jQuery(".active_tab").attr('id');
	if(check=="1" || check=="2" || check=="3" ){
		var tab_id = check;
	}
	if(str=="get_ajaxer"){
		jQuery(".home-journey").hide();
		<?php if(isset($_GET['cruise_region'])){ ?>;
			var region = "<?php echo $_GET['cruise_region']; ?>";
		<?php }else{ ?>
		<?php } ?>
		<?php if(isset($my_selected_operator)){ ?>;
			var operator = "<?php echo $my_selected_operator; ?>";
		<?php } else if(isset($_GET['cruise_operator'])){ ?>;
			var operator = "<?php echo $_GET['cruise_operator']; ?>";
		<?php }
			else { ?>
			var operator = "";
		<?php } ?>
		<?php if(isset($_GET['cruise_ship'])){ ?>;
			var cruise_ship = "<?php echo $_GET['cruise_ship']; ?>";
		<?php }else{ ?>
		<?php } ?>
		<?php if(isset($_GET['cruise_ship_starts_on'])){ ?>;
			var ship_starts_on = "<?php echo $_GET['cruise_ship_starts_on']; ?>";
		<?php }else{ ?>
		<?php } ?>
		<?php if(isset($_GET['cruise_ship_vacation_days'])){ ?>;
			var ship_vacation_days = "<?php echo $_GET['cruise_ship_vacation_days']; ?>";
		<?php }else{ ?>
		<?php } ?>
	
		<?php if(isset($_GET['start_price'])){ ?>;
			<?php if($_GET['start_price']=="undefined"){ ?>;
			var s = "0";
			<?php }else{ ?>
			var s = "<?php echo $_GET['start_price']; ?>";
			<?php } ?>
		<?php }else{ ?>
		var s = "0";
		<?php } ?>
		<?php if(isset($_GET['end_price'])){ ?>;
			<?php if($_GET['end_price']=="undefined"){ ?>;
			var e = "10000";
			<?php }else{ ?>
			var e = "<?php echo $_GET['end_price']; ?>";
			<?php } ?>
		<?php }else{ ?>
		var e = "10000";
		<?php } ?>
	}
	else{
		var region = jQuery('#cruise_region').val();
		var operator = jQuery('#cruise_operator').val();
		var cruise_ship = jQuery('#cruise_ship').val();
		//var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
		var leaving_from = jQuery('#cruise_leaving_from').val();
		var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
		var ship_vacation_days = jQuery('#cruise_ship_vacation_days').val();
	}
	jQuery('body').addClass('loader_body');
	jQuery('#replace_query_ajax').addClass('loader_replace_query');
	
	if( region == "" && operator == "" && cruise_ship == "" && ship_starts_on == "" && ship_vacation_days == "" ){	
	    var s = "0";
	    var e = "1000";
	}
	jQuery("#full_slider_1").hide();
	var sort_val = jQuery("#sort").val();
	jQuery.ajax({
        type: "POST",
        url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
        data: ({
            action: 'cruise_filter_response',
            <?php if($_COOKIE['str1']!=""){ ?>str1: <?php echo "'".$_COOKIE['str1']."',"; } ?>
            <?php if($_COOKIE['str2']!=""){ ?>str2: <?php echo "'".$_COOKIE['str2']."',"; } ?>
            region: region,
            tab_id : tab_id,
            operator: operator,
            cruise_ship: cruise_ship,
            //ship_fly_in: ship_fly_in,
            leaving_from: leaving_from,
            ship_starts_on: ship_starts_on,
            ship_vacation_days: ship_vacation_days,
            s:s,
            e:e,
			sort_val:sort_val,
            pagenumb:pagenumb
        }),
        success: function (response) {
        	jQuery(".new_design_homepage .home_page_area").remove();
        	//alert(response);
			jQuery('body').removeClass('loader_body');
			//jQuery("#full_slider_1").hide();
			jQuery(".i-1").parent().parent().addClass("destination_area");
			//jQuery('.main-footer').removeClass('loader_footer');
			jQuery('#replace_query_ajax').removeClass('loader_replace_query');
			
			if(s=="0" && e=="10000"){

		    }
		    else if(e=="1000"){
				jQuery('#1_radio').prop('checked',true);
		    }
		    else if(e=="1500"){
				jQuery('#2_radio').prop('checked',true);
		    }
		    else if(e=="2000"){
				jQuery('#3_radio').prop('checked',true);
		    }
		    else if(e=="3000"){
				jQuery('#4_radio').prop('checked',true);
		    }
		    else if(e=="4000"){
				jQuery('#5_radio').prop('checked',true);
		    }
		    else if(e=="5000"){
				jQuery('#6_radio').prop('checked',true);
		    }
		    else if(s!="0" && e=="10000"){
				jQuery('#7_radio').prop('checked',true);
		    }

        	jQuery('.loader').css('display','none');
            jQuery('#replace_query_ajax').html(response);
			destination_layout_changer();
		}
    });
}

</script>


<?php
	$listing_page_id = get_site_option( 'iflair_cruise_theme_ship_listing_page' );
?>
<div class="servicewrapper">
<div class="fullarea">
	<div class="leftsidesmall">
		<div class="bgimage-tag new_tmplt destination_page_main">
			<div class="loader" style="display:none;">
				<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader.gif">
			</div>

			<div class="container">
				<div class="form-field"></div>
			</div>	
		</div>
	</div>
<div class="rightbigger">
	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">
			<div class="servicewrapper">
			<?php /* The loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<header class="entry-header">
						<?php if ( has_post_thumbnail() && ! post_password_required() ) : ?>
						<div class="entry-thumbnail">
							<?php the_post_thumbnail(); ?>
						</div>
						<?php endif; ?>

						<h1 class="entry-title"><?php //the_title(); ?></h1>
					</header><!-- .entry-header -->

					<div class="entry-content">
						<?php the_content(); ?>
						<?php wp_link_pages( array( 'before' => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentythirteen' ) . '</span>', 'after' => '</div>', 'link_before' => '<span>', 'link_after' => '</span>' ) ); ?>
					</div><!-- .entry-content -->

					<footer class="entry-meta">
						<?php edit_post_link( __( 'Edit', 'twentythirteen' ), '<span class="edit-link">', '</span>' ); ?>
					</footer><!-- .entry-meta -->
				</article><!-- #post -->

				<?php comments_template(); ?>
			<?php endwhile; ?>
				<div id="replace_query_ajax">
				</div>
			</div>
		</div><!-- #content -->
	</div><!-- #primary -->
</div>
<style type="text/css">
	.side-bar{
		display: none;
	}
</style>
</div>
</div>
<script type="text/javascript">
jQuery( document ).ajaxStop(function() {
	jQuery('#cruise_region').attr("disabled", true); 
});
</script>
<?php
get_footer(); 