<?php
/*
Template Name: Operator Details
*/
get_header(); 
?>
<?php
global $wpdb,$mydb;
while ( have_posts() ) : the_post();
$my_meta = get_post_meta($post->ID,'_my_meta',TRUE);
$my_selected_operator = $my_meta['operator'];
$operator_query = "SELECT cc.cruise_response_id,cc.cruise_operator_name,cc.cruise_profile_image_href,cc.cruise_cover_image_href,cc.cruise_video_url FROM cruise_cruise as cc INNER JOIN cruise_operators as co ON cc.cruise_operator_name = co.operator_title WHERE co.operator_id =".$my_selected_operator." LIMIT 1";
$operator_result = $mydb->get_row($operator_query);
/*echo "<pre>";
print_r($operator_result);
echo "</pre>";*/
$detail_page_id =get_site_option( 'iflair_cruise_theme_ship_detail_page' );
$operator_detail_page =get_site_option( 'iflair_cruise_theme_operator_detail_page' );
?>
<style type="text/css">
.cruise_search_operator #cruise_region ,
.cruise_search_operator .side-bar {
    display: none !important;
}
</style>
<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/jquery.mCustomScrollbar.css">
<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/lazyYT.css">
<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.mCustomScrollbar.concat.min.js"></script>

<link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script>
	//jQuery(".main_header").css("background-color","#0969B3");
	/*jQuery(function() {
		jQuery( "#cruise_ship_starts_on" ).datepicker();
	});*/


	var dateToday = new Date();    
	/*jQuery(function () {
	    jQuery("#cruise_ship_starts_on").datepicker({ 
	      minDate: dateToday ,
	      dateFormat: 'yy-mm-dd'
	    });
	});*/
jQuery(function () {
	 jQuery('.cruise_ship_title.toggle_title').click(function(){
       jQuery(this).toggleClass('minus');

    });

});
		/*jQuery(function () {
			jQuery("#cruise_ship_starts_on").datepicker({
				showButtonPanel: false,  
				minDate: dateToday ,
				dateFormat: 'yy-mm-dd',
				beforeShow: function( input ) { 
    				setTimeout(function() { 
						var buttonPane = jQuery( input )  
						.datepicker( "widget" )  
						.find( ".ui-datepicker-buttonpane" );  

						var btn = jQuery('<button class="ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all" type="button">Whole Month</button>');  
						btn  
						.unbind("click")  
						.bind("click", function () {
							alert("123");
						});
						btn.appendTo( buttonPane );
    				}, 1 );  
				}  
			}); 
		});*/
</script>
<script>
    jQuery(window).load(function(){
	    jQuery(".content").mCustomScrollbar();
    });

	function resize_f(){
		jQuery("body").scroll(function() {  
			//alert("111111111");
			if(navigator.userAgent.indexOf("Chrome") != -1 )
		    {
		        var nav = jQuery('.detail-left'),
				navOff  = nav.offset();
				var gl_height = jQuery(".demo-gallery").height();
				//alert(gl_height);
					if (jQuery(this).scrollTop() > navOff.top) {
				//jQuery(".detail-right-fixed").addClass('fixed_right');
				jQuery(".scroll_header").css("display","block");

				} else {
					jQuery(".detail-right-fixed").removeClass('fixed_right');
				jQuery(".scroll_header").css("display","none");
				}
		    }
					 else if(navigator.userAgent.indexOf("Firefox") != -1 ) 
		    {
		        var scroll = jQuery("body").scrollTop();    
				//alert(scroll);
				var gl_height = jQuery(".demo-gallery").height();
				if(scroll > gl_height + 98){
					//alert('hi');
					//jQuery(".detail-right-fixed").addClass('fixed_right');
					jQuery(".scroll_header").css("display","block");

				}
				else{
					jQuery(".detail-right-fixed").removeClass('fixed_right');
					jQuery(".scroll_header").css("display","none");

				}
		    }
		    else
		    {
		        var scroll = jQuery("body").scrollTop();    
				//alert(scroll);
				var gl_height = jQuery(".demo-gallery").height();
				if(scroll > gl_height + 98){
					//alert('hi');
					//jQuery(".detail-right-fixed").addClass('fixed_right');

				}
				else{
					jQuery(".detail-right-fixed").removeClass('fixed_right');

				}
		    }
		});
	}
	jQuery(document).ready(function(){

		jQuery(".toggle_content").slideDown();
		jQuery(".toggle_title").click(function(){
			jQuery(".toggle_content").slideToggle();
		});

		var w = window.innerWidth;
		if(w>"1024"){
			var gl_height = jQuery(".demo-gallery").height();	
			var h_hh = gl_height-420;
			//jQuery('html, body').animate({scrollTop:h_hh}, 'slow');
		}
			jQuery(window).on('load resize', function(){
				resize_f();
			});
	
		jQuery('.loader').css('display','block');
		var pageNum = 1;
		<?php if(isset($_GET['cruise_region'])){ ?>;
		var region = "<?php echo $_GET['cruise_region']; ?>";
		<?php }else{ ?>
		var region = "";
		<?php } ?>
		<?php if(isset($my_selected_operator)){ ?>;
		var operator = "<?php echo $my_selected_operator; ?>";
		<?php }else{ ?>
		var operator = "";
		<?php } ?>
		<?php if(isset($_GET['cruise_ship'])){ ?>;
		var cruise_ship = "<?php echo $_GET['cruise_ship']; ?>";
		<?php }else{ ?>
		var cruise_ship = "";
		<?php } ?>
		<?php if(isset($_GET['cruise_ship_fly_in'])){ ?>;
		var ship_fly_in = "<?php echo $_GET['cruise_ship_fly_in']; ?>";
		<?php }else{ ?>
		var ship_fly_in = "";
		<?php } ?>
		<?php if(isset($_GET['cruise_ship_starts_on'])){ ?>;
		var ship_starts_on = "<?php echo $_GET['cruise_ship_starts_on']; ?>";
		<?php }else{ ?>
		var ship_starts_on = "";
		<?php } ?>
		<?php if(isset($_GET['cruise_ship_cruise_nights'])){ ?>;
		var ship_cruise_nights = "<?php echo $_GET['cruise_ship_cruise_nights']; ?>";
		<?php }else{ ?>
		var ship_cruise_nights = "";
		<?php } ?>
	    jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'iflair_search_filter_response',
	            region: region,
	            operator: operator,
	            cruise_ship: cruise_ship,
	            ship_fly_in: ship_fly_in,
	            ship_starts_on: ship_starts_on,
	            ship_cruise_nights: ship_cruise_nights,
                pagenumb:pageNum
            }),
            success: function (response) {
            	jQuery('.loader').css('display','none');
                //alert(response);
                jQuery('.form-field').html(response);
                //jQuery('#filter_title').empty();
	            //var filter_title=jQuery('#filter_title_tmp').html();
	            //alert(filter_title);
	            //jQuery('#filter_title-new').html(filter_title);
        		jQuery(".content").mCustomScrollbar();
        		cruise_filter();
        		jQuery(".search_header").addClass("searched");
        		jQuery(".search_header").addClass("searched_image");
            }
        });
	});
</script>
<link href="<?php echo esc_url( get_template_directory_uri() ); ?>/dist/css/lightgallery.css" rel="stylesheet">
<?php 
if($operator_result->cruise_cover_image_href!=""){
	$src_i = "http://ekups3e.cloudimg.io/s/resize/1800/".str_replace('//www','www',$operator_result->cruise_cover_image_href);
}
else{ 
	$src_i = wp_get_attachment_image_src( get_post_thumbnail_id($page->ID), array(1910, 553) ); 
}
?>
<div class="demo_main_gallery">
<div class="demo-gallery">
    <ul id="lightgallery" class="list-unstyled">
      <li class="" data-src="<?php echo $src_i; ?>" style="background: url( <?php echo $src_i; ?> ) no-repeat scroll center center;" data-sub-html="<h4><?php echo $operator_result->cruise_title; ?></h4>">
            <a href="">
                <img class="img-responsive" src="<?php echo $src_i; ?>">
            </a>
        </li>
        
    </ul>
</div>
</div>
<script type="text/javascript">
jQuery(document).ready(function(){
    //jQuery('#lightgallery').lightGallery();
});
</script>


	<div class="content-d clearfix">
		<div class="container">
			<div class="detail-left">
				<div class="about-this clearfix">
					<div class="cruise_title">
						Cruising With <?php echo $operator_result->cruise_operator_name; ?>
					</div>
					<div class="cruise_details cruise_op_details">
						<?php the_content();?>
					</div>
					<div class="cruise_search_operator">	
						<div class="cruise_latest_title">
							Latest Cruise with <?php echo $operator_result->cruise_operator_name; ?>
						</div>
						<div class="loader">
							<img src="<?php echo esc_url( get_template_directory_uri() )."/images/loader.gif"; ?>">		
						</div>							
						<div class="form-field form-field-cruise" style="height: 52px;">
							
						</div>

						<div class="package_cruise_res" style="display: none;">
						<?php 
						//echo $my_selected_operator;

$op_name = $mydb->get_row("SELECT operator_app_id FROM cruise_operators WHERE operator_id =".$my_selected_operator."");
$rebates = $mydb->get_results("SELECT ship_id FROM cruise_ship_cruise WHERE ship_operator ='".$op_name->operator_app_id."' GROUP BY ship_id");
$resultset = array();
foreach($rebates as $data) {
$resultset[] = $data->ship_id;
}
$comma_separated = implode(",", $resultset);
//echo $comma_separated;

$select_ship_in = $wpdb->get_results("SELECT * FROM ".BASEPOKE_LIST." as bl INNER JOIN ".BASEPOKE_CRUISES." as bc ON bl.id = bc.basepoke_id WHERE bc.offer_start_date < curdate() and bc.offer_end_date > curdate() AND bl.ship_id IN (".$comma_separated.")");
$resultset1 = array();
foreach($select_ship_in as $data1) {
$resultset1[] = $data1->cruise_id;
}
$comma_separated1 = implode("','", $resultset1);
//echo "SELECT cc.cruise_cover_image_href,csc.ship_name,csc.ship_starts_on,csc.ship_cruise_nights,cc.cruise_title,csc.ship_cruise_only_price,csc.ship_fly_cruise_price, csc.cruise_id AS a, cc.cruise_id AS b FROM cruise_cruise AS cc INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id  WHERE csc.cruise_id IN ('".$comma_separated1."')";

$select_ship = $mydb->get_results("SELECT cc.cruise_cover_image_href,csc.ship_name,csc.ship_starts_on,csc.ship_cruise_nights,cc.cruise_title,csc.ship_cruise_only_price,csc.ship_fly_cruise_price, csc.cruise_id AS a, cc.cruise_id AS b FROM cruise_cruise AS cc INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id  WHERE csc.cruise_id IN ('".$comma_separated1."') GROUP BY csc.cruise_id");
for($i=0;$i<count($select_ship);$i++)
{
	$offer_query = "SELECT * FROM ".BASEPOKE_LIST." as bl INNER JOIN ".BASEPOKE_CRUISES." as bc ON bl.id = bc.basepoke_id WHERE bc.offer_start_date < curdate() and bc.offer_end_date > curdate() AND bc.cruise_id = '".$select_ship[$i]->a."'";
	$found_offer = $wpdb->get_row($offer_query);
?>

<div class="mediter-box clearfix">
	<div class="medi-left">
		<div class="newtableimg">
			<div class="netablecellimg">
				<img src="<?php if($select_ship[$i]->cruise_cover_image_href!=""){ echo "http://ekups3e.cloudimg.io/s/crop/300x200/".str_replace('//www','www',$select_ship[$i]->cruise_cover_image_href); }else{ echo esc_url( get_template_directory_uri() )."/images/noImageAvailable.png"; } ?>" class="img-responsive">
			</div>
		</div>
	</div>
	<div class="medi-mid mid-mid-two">
		<h3><?php if($found_offer->extra_info != ""){ echo $found_offer->extra_info; }else{ echo $select_ship[$i]->ship_name; } ?></h3>
		<?php if($found_offer->cabin_info!=""){ ?>
		<span class="package_class"><?php echo $found_offer->cabin_info; ?></span>
		<?php } ?>
		<p class="date_new_site"><?php if($found_offer->departure_date != ""){ echo date('d M Y',strtotime($found_offer->departure_date)); }else{ $ship_date=$select_ship[$i]->ship_starts_on; echo date('d M Y',strtotime($ship_date)); } ?></p>
		<p class="day_new_site daytotal"><?php if($found_offer->cruise_nights != ""){ echo $found_offer->cruise_nights; }else{ echo $select_ship[$i]->ship_cruise_nights; } ?> Nights</p>
		<p class="ship_new_site"><div class="tool"></div> <div class="shiptitle">Ship</div><span class="toolname">: <?php echo $select_ship[$i]->cruise_title; ?></span></p>
		
		<div class="itecolor_parent" id="itecolor_<?php echo $i; ?>">
			<p class="itinerary_new_site">
				<span class="itecolor">itinerary</span>
			</p>
			<div class="itecolor-detail">
				<p class="itinerary_new_site">
					<?php
					/*if($found_offer->ports_visited != ""){ echo str_replace(","," <i class='fa fa-caret-right'></i> ",$found_offer->ports_visited); }
					else{ */
						$select_itinerary_query ="";
						$select_itinerary_query .= "SELECT port_name FROM cruise_port WHERE cruise_id = '";
						$select_itinerary_query .= $select_ship[$i]->a;
						$select_itinerary_query .= "' GROUP BY port_name ORDER BY id";
						//echo $select_itinerary_query;
						$select_itinerary = $mydb->get_results($select_itinerary_query);
						$itinerary_count = count($select_itinerary);
						if($itinerary_count!="0"){
							echo $select_itinerary[0]->port_name;
							for($i1=1;$i1<count($select_itinerary);$i1++)
							{
								//echo "<pre>";
								//print_r($select_port);
								//echo "</pre>";
								?> <i class="fa fa-caret-right"></i>
								<?php echo $select_itinerary[$i1]->port_name;
								?>
							<?php
							}
						}
					/*}*/

					?>
				</p>
			</div>
		</div>

	</div>
		<?php
			/*echo "<pre>";
			print_r($found_offer);
			echo "</pre>";*/
			if(!empty($found_offer)){
				$offer_class = '<div class="offer_class"></div>';
				$offer_class2 = " offer_class2";
				//echo '<div class="'.$offer_class.'"><img src="'.esc_url( get_template_directory_uri() ).'/images/superdeal.png" ></div>';
			}
			else{
				$offer_class = "";
				$offer_class2 = "";
			}
		?>
	<div class="medi-right">
		<?php echo $offer_class; ?>
		<div class="main_added_text">
		<?php 
		$price1 = $select_ship[$i]->ship_cruise_only_price;
		$price2 = $select_ship[$i]->ship_fly_cruise_price;
		
		if(!empty($found_offer)){
			?>
			<h2>Cruise Package Price</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>From <span class="textbld">£<?php echo number_format($found_offer->offer_price); ?></span>  per person</p>
			<?php
		}
		elseif($price1=="0" && $price2=="0")
		{
			?>
			<h2>Cruise Only Price</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>Please enquire for today’s price</p>
			<?php
		}
		elseif( ( $price1!="0" && $price1 < $price2 ) || $price2== "0" )
		{
			?>
			<h2>Cruise Only Price</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>From <span class="textbld">£<?php echo number_format($price1); ?></span>  per person</p>
			<?php
		}
		elseif( ( $price2!="0" && $price1 > $price2 ) || $price1== "0" )
		{
			?>
			<h2>Cruise Only Price</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>From <span class="textbld">£<?php echo number_format($price2); ?></span>  per person</p>
			<?php
		}
		elseif( ( $price1!="0" && $price2!="0" ) && $price1==$price2 )
		{
			?>
			<h2>Cruise Only Price</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>From <span class="textbld">£<?php echo number_format($price1); ?></span>  per person</p>
			<?php
		}
		else{
			?>
			<!-- <h2>Cruise Only Price</h2> -->
			<?php echo $found_offer->package_summary; ?>
			<p class="text1">Please enquire for today’s price</p>
			<?php
		}
		echo '<div class="'.$offer_class2.'"></div>';
		?>
		</div>
		<?php $detail_page_id = get_site_option( 'iflair_cruise_theme_ship_detail_page' );?>
		<div class="added_img">
			<a target="_blank" href="<?php echo get_page_link($detail_page_id);?>?cruise_id=<?php echo $select_ship[$i]->a; ?>" class="info-bt new_btn_blue new_detail_btn"> VIEW DETAILS <i class="fa fa-caret-down"></i></a>
					<!-- <script>jQuery("img.lazy").lazyload();</script> -->
			<a onclick="cruise_detail_of('<?php echo $select_ship[$i]->cruise_id; ?>');" class="new_btn_blue fa fa-caret-down itinerary_btn">Itinerary <i class=""></i></a>
		</div>
	</div>
</div>
<div class="cruse-information clearfix">
	<div class="above_map_area"><h2 class="above_map_title">Cruise Itinerary</h2>
	<a target="_blank" href="<?php echo get_page_link($detail_page_id);?>?cruise_id=<?php echo $select_ship[$i]->a; ?>" class="info-bt new_btn_blue above_map">VIEW DETAILS<i class="fa fa-caret-down"></i></a></div>
	<div class="scroll<?php echo $select_ship[$i]->cruise_id; ?> scroll_empty">
		<div class="loader_1" style="display:none;text-align: center; padding: 0px 0px 30px;">
			<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader_1.gif">
		</div>
	</div>

	<?php
	/*echo "<pre>";
	print_r($select_ship[$i]);
	echo "</pre>";*/
	?>
	<div class="clearfix right">
		<?php /*<a href="<?php echo get_page_link($detail_page_id);?>?ship_id=<?php echo $select_ship[$i]->b; ?>" class="info-bt new_btn_blue">VIEW MORE INFORMATION</a> */?>
	</div>
</div>
<?php
}
						?>
							</div>
							<script type="text/javascript">
								jQuery(document).ajaxComplete(function(){
									var id = jQuery(".currentdiv").attr("id");
									if(id=="1"){
										var con = jQuery(".package_cruise_res").html();
										jQuery(".package_cruise").html(con);
									}
								});
							</script>
						<div id="replace_query_ajax">
						</div>
					</div>
				</div>
			</div>
			<div class="detail-right clearfix" >
				<div class="detail-right-fixed cruiseleftfix">
					<div class="cruise_details cruise_detailsimg">
						<img src="http://ekups3e.cloudimg.io/s/resize/93/<?php echo str_replace('//www','www',$operator_result->cruise_profile_image_href); ?>">
					</div>
					<?php
					if($operator_result->cruise_video_url!=""){
						$url = $operator_result->cruise_video_url;
						$step1=explode('v=', $url);
						$step2 =explode('&',$step1[1]);
						//print_r($step2);
						if(empty($step2[0])){
							//echo "dfgjdkgj";
							$url = $operator_result->cruise_video_url;
							$step1=explode('/', $url);
							//print_r($step1);
							$vedio_id = $step1[3];
						}
						else{
							$vedio_id = $step2[0];
						}
						if($operator_result->cruise_video_url!="")
						{ 
							$headers = get_headers('http://www.youtube.com/oembed?url=http://www.youtube.com/watch?v='.$vedio_id);
							if (strpos($headers[0], '200')) 
							{
							?>
							<div class="js-lazyYT" data-width="350" data-height="250" data-youtube-id="<?php echo $vedio_id; ?>"></div>
							<?php
							}
						}
					}
					?>

					<div class="cruise_ship_side_area">
						<div class="cruise_ship_title toggle_title">
						Cruise Ship
						</div>
						<div class="cruise_ship_list toggle_content">
							<ul style="width: 100%; float: left;" class="clearfix content ">
							<?php
							$operator_query_r = "SELECT cc.cruise_title,cc.cruise_response_id FROM cruise_cruise as cc INNER JOIN cruise_operators as co ON cc.cruise_operator_name = co.operator_title INNER JOIN cruise_ship_cruise as csc ON csc.ship_id = cc.cruise_response_id WHERE co.operator_id =".$my_selected_operator." GROUP BY cc.cruise_title";
							$operator_result_r = $mydb->get_results($operator_query_r);
							/*echo "<pre>";
							print_r($operator_result_r);
							echo "</pre>";*/
							$count_os = count($operator_result_r);
							for ($os=0; $os < $count_os ; $os++) { 
								?>
								<li><a href="<?php echo get_permalink($operator_detail_page); ?>?cruise_id=<?php echo $operator_result_r[$os]->cruise_response_id; ?>"><?php echo $operator_result_r[$os]->cruise_title; ?></a></li>
								<?php
							}
							?>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>	



		
<?php endwhile; ?>
<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/lazyYT.js"></script>
<script>
jQuery( document ).ready(function() {
    jQuery('.js-lazyYT').lazyYT();
    
    // Pass some parameters
    jQuery('.js-lazyYT').lazyYT({
      loading_text: 'It is loading!...',
      default_ratio: '16:9'
    });

    jQuery(".itecolor-detail").hide();
	jQuery(".itecolor").click(function(){
		var ParentId = jQuery(this).parents(".itecolor_parent").attr("id");
		jQuery("#"+ParentId+" .itecolor-detail").toggle("slow");
	});

});



function iflair_detail_search_filter(str){
    var pagenumb='1';
    var check = str;
    var region = jQuery('#cruise_region').val();
    var operator = jQuery('#cruise_operator').val();
    var cruise_ship = jQuery('#cruise_ship').val();
    var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
    var leaving_from = jQuery('#cruise_leaving_from').val();
    var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
    var ship_cruise_nights = jQuery('#cruise_ship_cruise_nights').val();
    if(check=="reset"){
        jQuery('#cruise_region').prop('selectedIndex',0);
        jQuery('#cruise_operator').prop('selectedIndex',0);
        jQuery('#cruise_ship').prop('selectedIndex',0);
        jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
        jQuery('#cruise_leaving_from').prop('selectedIndex',0);
        jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
        jQuery('.loader_filt').css('display','block');

        jQuery.cookie('str1', '', {expires: 1 });
        jQuery.cookie('str2', '', {expires: 1 });

        return false;
    }
    if(check=="region"){
        jQuery('#cruise_operator').prop('selectedIndex',0);
        jQuery('#cruise_ship').prop('selectedIndex',0);
        jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
        jQuery('#cruise_leaving_from').prop('selectedIndex',0);
        jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
            //iflair_detail_search_filter();
    }
    if(check=="operator"){
        jQuery('#cruise_ship').prop('selectedIndex',0);
        jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
        jQuery('#cruise_leaving_from').prop('selectedIndex',0);
        jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
            //iflair_detail_search_filter();
    }
    if(check=="cruise_ship"){
        jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
        jQuery('#cruise_leaving_from').prop('selectedIndex',0);
        jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
            //iflair_detail_search_filter();
    }
    if(check=="ship_fly_in"){
        jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
            //iflair_detail_search_filter();
    }
    if(check=="leaving_from"){
        jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
            //iflair_detail_search_filter();
    }
    if(check=="ship_starts_on"){
        jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
            //iflair_detail_search_filter();
    }
    if(check=="ship_cruise_nights"){
            //iflair_detail_search_filter();
    jQuery('.loader_filt').css('display','block');
    }
    if(check=="search"){

        jQuery.cookie('str1', '', {expires: 1 });
        jQuery.cookie('str2', '', {expires: 1 });

        /*if(region==""){
            jQuery('#cruise_region').focus();
            alert("Where do you want to go?");
            return false;
        }
        if(operator==""){
            jQuery('#cruise_operator').focus();
            alert("Who would you like to Cruise with?");
            return false;
        }*/
        var width_res = jQuery(".header").width();
        if(width_res<768){
            jQuery('.input-form.wrraper').slideToggle();
        }
        jQuery('.loader').css('display','block');
        jQuery('.search_header').addClass('searched');
        jQuery('.search_header').addClass('searched_image');
        jQuery('#replace_query_ajax').addClass('replace_query_class');
        //cruise_filter();
    }
    //alert(str);
    jQuery.ajax({
        type: "POST",
        url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
        data: ({
            action: 'iflair_detail_search_filter_response',
            region: region,
            operator: operator,
            cruise_ship: cruise_ship,
            ship_fly_in: ship_fly_in,
            leaving_from: leaving_from,
            ship_starts_on: ship_starts_on,
            ship_cruise_nights: ship_cruise_nights
        }),
        success: function (response) {
            //jQuery('.loader').css('display','none');
            jQuery('.loader_filt').css('display','none');
            //alert(response);
            jQuery('.form-field-cruise').html(response);
        }
    });
    //cruise_filter();
}

function iflair_search_filter(str){
	var pagenumb='1';
	var check = str;
	var tab_id = jQuery(".active_tab").attr('id');
	if(check=="1" || check=="undefined" || check=="2"){
	//var tab_id = <?php if(isset($_GET['tab_id']) && $_GET['tab_id'] != "undefined"){ ?>"<?php echo $_GET['tab_id']; ?>"<?php }else{ ?>jQuery(".active_tab").attr('id')<?php } ?>;

	var region = <?php if(isset($_GET['cruise_region'])){ echo '"'.$_GET['cruise_region'].'"'; }else{?>jQuery('#cruise_region').val();<?php } ?>;
	var operator = <?php if(isset($_GET['cruise_operator'])){ echo '"'.$_GET['cruise_operator'].'"'; }else{?>jQuery('#cruise_operator').val();<?php } ?>;
	var cruise_ship = <?php if(isset($_GET['cruise_ship'])){ echo '"'.$_GET['cruise_ship'].'"'; }else{?>jQuery('#cruise_ship').val();<?php } ?>;
	var ship_fly_in = <?php if(isset($_GET['cruise_ship_fly_in'])){ echo '"'.$_GET['cruise_ship_fly_in'].'"'; }else{?>jQuery('#cruise_ship_fly_in').val();<?php } ?>;
	var ship_starts_on = <?php if(isset($_GET['cruise_ship_starts_on'])){ echo '"'.$_GET['cruise_ship_starts_on'].'"'; }else{?>jQuery('#cruise_ship_starts_on').val();<?php } ?>;
	var ship_cruise_nights = <?php if(isset($_GET['cruise_ship_cruise_nights'])){ echo '"'.$_GET['cruise_ship_cruise_nights'].'"'; }else{?>jQuery('#cruise_ship_cruise_nights').val();<?php } ?>;

	<?php if(isset($_GET['start_price'])){ ?>;
		<?php if($_GET['start_price']=="undefined"){ ?>;
		var s = "0";
		<?php }else{ ?>
		var s = "<?php echo $_GET['start_price']; ?>";
		<?php } ?>
	<?php }else{ ?>
	var s = "0";
	<?php } ?>
	<?php if(isset($_GET['end_price'])){ ?>;
		<?php if($_GET['end_price']=="undefined"){ ?>;
		var e = "10000";
		<?php }else{ ?>
		var e = "<?php echo $_GET['end_price']; ?>";
		<?php } ?>
	<?php }else{ ?>
	var e = "10000";
	<?php } ?>
	

	}
	else{
	var region = jQuery('#cruise_region').val();
	var operator = jQuery('#cruise_operator').val();
	var cruise_ship = jQuery('#cruise_ship').val();
	var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
	var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
	var from_cruise_date = jQuery('#from_cruise_date').val();
	var to_cruise_date = jQuery('#to_cruise_date').val();
	var ship_cruise_nights = jQuery('#cruise_ship_cruise_nights').val();
    var s = jQuery("#amount1").val();
    var e = jQuery("#amount2").val();
	
	}
	if(check=="reset"){
		jQuery('#cruise_region').prop('selectedIndex',0);
		jQuery('#cruise_operator').prop('selectedIndex',0);
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    	jQuery('.loader_filt').css('display','block');

		jQuery.cookie('str1', '',{expires: 1,path: "/" });
		jQuery.cookie('str2', '',{expires: 1,path: "/" });

		return false;
	}
	if(check=="region"){
		jQuery('#cruise_operator').prop('selectedIndex',0);
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="operator"){
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="cruise_ship"){
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="ship_fly_in"){
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="leaving_from"){
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="ship_starts_on"){
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="ship_cruise_nights"){
			//iflair_search_filter();
    jQuery('.loader_filt').css('display','block');
	}
	if(check=="search"){

		//var newURL = window.location.href;
<?php $listing_page_id = get_site_option( 'iflair_cruise_theme_ship_listing_page' );?>
var newURL = "<?php echo get_permalink($listing_page_id); ?>";
		//alert(newURL);
		/*var url_1 = window.location.pathname;
		alert(url_1);*/
		if(jQuery(".active_tab").attr('id')=="1"){
			var path = "";
		}
		else if(jQuery(".active_tab").attr('id')=="2"){
			var path = "";
		}
		else{
			var path = "";
		}

		if(jQuery('#amount1').val()=="undefined"){
			var s = "0";
		}
		else{
			var s =jQuery('#amount1').val();
		}
		if(jQuery('#amount2').val()=="undefined"){
			var e = "10000";
		}
		else{
			var e = jQuery('#amount2').val();
		}
		//alert(start_price);
		
		if( region == "" && operator == "" && cruise_ship == "" && ship_fly_in == "" && ship_starts_on == "" && ship_cruise_nights == "" ){	
		    var s = "0";
		    var e = "1000";
		}

        history.pushState({},"URL Rewrite Example",newURL+""+path+"?cruise_region="+region+"&from_cruise_date="+from_cruise_date+"&to_cruise_date="+to_cruise_date+"&cruise_operator="+operator+"&cruise_ship="+cruise_ship+"&cruise_ship_cruise_nights="+ship_cruise_nights+"&tab_id="+tab_id+"&start_price="+s+"&end_price="+e);

		jQuery.cookie('str1', '',{expires: 1,path: "/" });
		jQuery.cookie('str2', '',{expires: 1,path: "/" });

		/*if(region==""){
			jQuery('#cruise_region').focus();
			alert("Where do you want to go?");
			return false;
		}
		if(operator==""){
			jQuery('#cruise_operator').focus();
			alert("Who would you like to Cruise with?");
			return false;
		}*/
		var width_res = jQuery(".header").width();
		if(width_res<768){
			jQuery('.input-form.wrraper').slideToggle();
		}
		jQuery('.loader').css('display','block');
		jQuery('.search_header').addClass('searched');
		jQuery('.search_header').addClass('searched_image');
		jQuery('#replace_query_ajax').addClass('replace_query_class');
		jQuery(".blackback").addClass("home_searched");
		cruise_filter("ajaxer");
	}
	//alert(str);
	jQuery.ajax({
        type: "POST",
        url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
        data: ({
            action: 'iflair_search_filter_response',
            tab_id : tab_id,
            region: region,
            operator: operator,
            cruise_ship: cruise_ship,
            ship_fly_in: ship_fly_in,
            //leaving_from: leaving_from,
            ship_starts_on: ship_starts_on,
            ship_cruise_nights: ship_cruise_nights,
            from_cruise_date:from_cruise_date,
            to_cruise_date:to_cruise_date,
            s:s,
            e:e,
            pagenumb:pagenumb
        }),
        success: function (response) {
            //alert(response);
            jQuery('.form-field').html(response);
			jQuery("#tab_loader").hide();
			jQuery('.input-form').slideDown();
        	//jQuery('.loader').css('display','none');
        	if(s=="0" && e=="10000"){

		    }
		    else if(e=="1000"){
				jQuery('#1_radio').prop('checked',true);
		    }
		    else if(e=="1500"){
				jQuery('#2_radio').prop('checked',true);
		    }
		    else if(e=="2000"){
				jQuery('#3_radio').prop('checked',true);
		    }
		    else if(e=="3000"){
				jQuery('#4_radio').prop('checked',true);
		    }
		    else if(e=="4000"){
				jQuery('#5_radio').prop('checked',true);
		    }
		    else if(e=="5000"){
				jQuery('#6_radio').prop('checked',true);
		    }
		    else if(s!="0" && e=="10000"){
				jQuery('#7_radio').prop('checked',true);
		    }
		    
        	jQuery('.loader_filt').css('display','none');
			//jQuery(".main_tab_loader").hide();
	        jQuery(".main_tab_loader").hide();
        }
    });
}


function cruise_filter(){
	jQuery('.loader').css('display','block');
	var pagenumb='1';
	var region = jQuery('#cruise_region').val();
	var operator = jQuery('#cruise_operator').val();
	var cruise_ship = jQuery('#cruise_ship').val();
	var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
	var leaving_from = jQuery('#cruise_leaving_from').val();
	var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
	var ship_cruise_nights = jQuery('#cruise_ship_cruise_nights').val();
	//alert(operator);
	var from_cruise_date = jQuery('#from_cruise_date').val();
	var to_cruise_date = jQuery('#to_cruise_date').val();
	jQuery.ajax({
        type: "POST",
        url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
        data: ({
            action: 'cruise_filter_response',
            <?php if($_COOKIE['str1']!=""){ ?>str1: <?php echo "'".$_COOKIE['str1']."',"; } ?>
            <?php if($_COOKIE['str2']!=""){ ?>str2: <?php echo "'".$_COOKIE['str2']."',"; } ?>
            region: region,
            operator: operator,
            cruise_ship: cruise_ship,
            ship_fly_in: ship_fly_in,
            leaving_from: leaving_from,
            ship_starts_on: ship_starts_on,
            ship_cruise_nights: ship_cruise_nights,
            from_cruise_date:from_cruise_date,
            to_cruise_date:to_cruise_date,
            pagenumb:pagenumb
        }),
        success: function (response) {
        	jQuery(".new_design_homepage .home_page_area").remove();
        	jQuery('.loader').css('display','none');
            jQuery('#replace_query_ajax').html(response);
            jQuery(".content").mCustomScrollbar();
            jQuery("img.lazy").lazyload({skip_invisible : true});
	                
		}
    });
}

</script>
<?php
get_footer(); 
?>	