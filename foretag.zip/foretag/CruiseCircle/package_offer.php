<?php
/*
Template Name: Package Offer Page
*/
get_header();
?>
<div class="servicewrapper">
<div class="fullarea">
	<div class="leftside">
	<div class="entry-content">
	<h1>Offers</h1>
	</div>
	<div class="sidebar_filter_offer_area">
		<a class="display_offer">Back to search results</a>
		<!-- <div class="sidebar_filter_offer_detail"><div class="sidebar_filter_offer"></div></div> -->
	</div>
	<script type="text/javascript">
		jQuery(".sidebar_filter_offer_detail").slideUp();
		jQuery(".display_offer").click(function(){
			jQuery(".display_offer").toggleClass("active_toggle_offer");
			jQuery(".sidebar_filter_offer_detail").slideToggle();
		});

jQuery( document ).ajaxComplete(function() {
	if(jQuery( document ).width()>="767"){
		jQuery(".sidebar_filter_offer_area").remove();
	}
	else{
		jQuery(".sidebararea .sidebar_filter").remove();
	}
});
	</script>
	<style type="text/css">
	.active_toggle_offer{
		background: #1e4299 none repeat scroll 0 0 !important;
		text-decoration: none;
	}
	</style>
	<?php /* The loop */ ?>
	<?php /* while ( have_posts() ) : the_post();?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<header class="entry-header">
				<?php if ( has_post_thumbnail() && ! post_password_required() ) : ?>
				<div class="entry-thumbnail">
					<?php the_post_thumbnail(); ?>
				</div>
				<?php endif; ?>

				<h1 class="entry-title"><?php the_title(); ?></h1>
			</header><!-- .entry-header -->

			<div class="entry-content">
				<?php the_content(); ?>
				<?php wp_link_pages( array( 'before' => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentythirteen' ) . '</span>', 'after' => '</div>', 'link_before' => '<span>', 'link_after' => '</span>' ) ); ?>
			</div><!-- .entry-content -->

			<footer class="entry-meta">
				<?php edit_post_link( __( 'Edit', 'twentythirteen' ), '<span class="edit-link">', '</span>' ); ?>
			</footer><!-- .entry-meta -->
		</article><!-- #post -->

		<?php comments_template(); ?>
	<?php endwhile; */?>
	<?php echo do_shortcode("[package_offer per_page='10' layout='both']"); ?>
	</div>
	<div class="sidebararea">
		<?php get_sidebar(); ?>
	</div>
<div class="clr"></div>
		</div><!-- #content -->
	</div><!-- #primary -->

<?php
get_footer(); 
?>