<?php
/*
Template Name: Home Page
*/
get_header();
$river_page_id = get_site_option( 'iflair_cruise_theme_river_page' );
$ocean_page_id = get_site_option( 'iflair_cruise_theme_ocean_page' );
?>
<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/jquery.mCustomScrollbar.css">
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.mCustomScrollbar.concat.min.js"></script>

<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/jquery-ui.css">
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>

<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/bootstrap.min.css">
<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/bootstrap.min.js"></script>
<style>
.carousel-inner > .item > img,
.carousel-inner > .item > a > img {
  width: 70%;
  margin: auto;
}
</style>

<!-- bxSlider Javascript file -->
<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.bxslider.min.js"></script>
<!-- bxSlider CSS file -->
<link href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/jquery.bxslider.css" rel="stylesheet" />
<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery('.bxslider').bxSlider({
			auto: true,
			autoControls: true,
			infiniteLoop: true,
			pager: true,
			speed: 1000,
			pause: 7000
		});
	});
</script>

	<div class=" blackback  col-sm-3">
	<div class="open_search servicewrapper">
		<a class="manage_search" >Back to search results</a>
	</div>
	<!-- 
	<div class="tabing fl">
		<a class="active_tab tsb-tab" id="1">River Cruises</a>
		<a id="2" class="tsb-tab">Cruise Liners</a>
		<a id="3" class="tsb-tab">Fly Cruises</a>
	</div> -->
	<div class="clr"></div>
		<div class="open_search clearfix" style="display: block;">
			<div class="container">
				<div class="headertwobtn fl">
					<a class="tsb-tab" id="2">Ocean Cruises</a>
					<a class="tsb-tab" id="1">River Cruises</a>
				</div>
				<div class="main_tab_loader" style="display:none;"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/progress-bar.gif"></div>
				<p id="result_story"></p>
			</div>
		</div>
	<div class="input-form wrraper clearfix backmake">
		<div class="servicewrapper  clearfix">
		<?php
			$listing_page_id = get_site_option( 'iflair_cruise_theme_ship_listing_page' );
		?>
		<!-- <form action="<?php //echo get_page_link($listing_page_id); ?>" method="get" name="rearange_filter" id="rearange_filter"> -->
			<div class="form-field">

			</div>
		<!-- </form> -->
		</div>
	</div>
</div>
<div class="header wrraper search_header col-sm-9">
	<?php
		$banner_loop = CFS()->get( 'banner' );
		if(empty($banner_loop)){
			?><div class="backgroundimages"></div><?php
		}
		else{
			$count_banner = count($banner_loop);
			//print_r($banner_loop);
			if($count_banner == "1"){
				foreach ( $banner_loop as $field ) {
				?>
				<a href="<?php echo $field['banner_url']; ?>" class="backgroundimages" style="background: url(<?php echo $field['banner_image']; ?>) no-repeat scroll center center / cover;"></a>
					<?php if($field['banner_content'] != ""){ ?>
						<div class="banner_cont">
							<?php echo $field['banner_content']; ?>
						</div>
					<?php } ?>
				<?php
				}
			}
			else{
			?><ul class="bxslider"><?php
				foreach ( $banner_loop as $field ) {
				?>
					<li class="backgroundimages" style="background: url(<?php echo $field['banner_image']; ?>) no-repeat scroll center center / cover;">
						<a href="<?php echo $field['banner_url']; ?>">
							<?php if($field['banner_content'] != ""){ ?>
								<div class="banner_cont">
									<?php echo $field['banner_content']; ?>
								</div>
							<?php } ?>
						</a>
					</li>
				<?php
				}
			?></ul><?php
			}
		}
	?>
	
	  
	<div class= "mobile-top wrapper clearfix ">
		<a href="#" class="w-arrow"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/white-arrow.png"></a>
	</div>

	<div class="banner-position">
		<div class="bannertext">
			<div class="banner-cell">
				<!-- <div class="grey-box-wrraper clearfix">
					<div class="grey-box">
						<h1>FIND YOUR CRUISE</h1>
						<p>Go anywhere, anyplace, anytime with 1000’s of cruises to choose from</p>				
						<h3>Search your cruise holiday here</h3>		
					</div>		
				</div> -->
				<div class="loader" style="display:none;">
					<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader.gif">
				</div>
			</div>
		</div>
	</div>
</div>

<div id="replace_query_ajax">
</div>
<div class="new_design_homepage">
<div class="home_page_area">
	<div class="servicewrapper">
		<div class="homtwo">
			<div class="leftsidearea fl">
			</div>
			<div class="rightsider fl">
				<!-- Group offers by Cruiseline Start -->
				<?php
					$gt_ope_list = $wpdb->get_results("SELECT tour_operator_name FROM cc_tour_operator");
					$gt_ope_list_count = count($gt_ope_list);
					if ($gt_ope_list_count != "0") 
					{
				?>
						<div class="container">
							<div id="Cruiseline_Left">
								<?php
									echo "<ul class='operator_name'>";
									foreach ($gt_ope_list as $gt_ope_name) 
									{
								?>
										<li class="operator"><a onclick="iflair_operator(this.text);"><?php echo $gt_ope_name->tour_operator_name; ?></a></li>
								<?php }
									echo "</ul>";

								?>
							</div>
							<div class="loader" style="display:none;">
								<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader.gif">
							</div>
							<div id="Cruiseline_Right">
								
							</div>
						</div>
				<?php } ?>
				<!-- Group offers by Cruiseline End -->
			</div>
			<div class="clear"></div>
		</div>
	</div>
</div>
</div>
<script>

function iflair_operator(str){
	jQuery('.loader').css('display','block');
	jQuery.ajax({
        type: "POST",
        url: ('<?php echo admin_url( 'admin-ajax.php' ); ?>'),
        data: ({
            action: 'iflair_get_operator',
            opet_name: str,
        }),
        success: function (response) {
           jQuery('.container #Cruiseline_Right').html(response);
           jQuery('.loader').css('display','none');
        }
    });
}

jQuery( document ).ready(function() {

	var ope_one_name = jQuery("#Cruiseline_Left ul.operator_name li:first-child").text();
	<?php if(is_page('4683')){ ?>
    jQuery.ajax({
        type: "POST",
        url: ('<?php echo admin_url( 'admin-ajax.php' ); ?>'),
        data: ({
            action: 'iflair_get_operator',
            opet_name: ope_one_name,
        }),
        success: function (response) {
           jQuery('.container #Cruiseline_Right').html(response);
           jQuery('.loader').css('display','none');
        }
    });
    <?php } ?>

    jQuery("#Cruiseline_Left ul.operator_name li:first-child").addClass("ope-active");

    jQuery("#Cruiseline_Left ul.operator_name li a").click(function(){
    	jQuery("#Cruiseline_Left ul.operator_name li").removeClass("ope-active");
    	jQuery(this).parent().addClass("ope-active");
    });

	jQuery('.loader').css('display','block');
	jQuery('.form-field').css('border','none');
		var pageNum = 1;
		<?php if(isset($_GET['cruise_region'])){ ?>;
		var region = "<?php echo $_GET['cruise_region']; ?>";
		<?php }else{ ?>
		var region = "";
		<?php } ?>
		<?php if(isset($my_selected_operator)){ ?>;
		var operator = "<?php echo $my_selected_operator; ?>";
		<?php }else{ ?>
		var operator = "";
		<?php } ?>
		<?php if(isset($_GET['cruise_ship'])){ ?>;
		var cruise_ship = "<?php echo $_GET['cruise_ship']; ?>";
		<?php }else{ ?>
		var cruise_ship = "";
		<?php } ?>
		<?php if(isset($_GET['cruise_ship_fly_in'])){ ?>;
		var ship_fly_in = "<?php echo $_GET['cruise_ship_fly_in']; ?>";
		<?php }else{ ?>
		var ship_fly_in = "";
		<?php } ?>
		<?php if(isset($_GET['cruise_ship_starts_on'])){ ?>;
		var ship_starts_on = "<?php echo $_GET['cruise_ship_starts_on']; ?>";
		<?php }else{ ?>
		var ship_starts_on = "";
		<?php } ?>
		<?php if(isset($_GET['cruise_ship_cruise_nights'])){ ?>;
		var ship_cruise_nights = "<?php echo $_GET['cruise_ship_cruise_nights']; ?>";
		<?php }else{ ?>
		var ship_cruise_nights = "";
		<?php } ?>
		<?php if(isset($_GET['start_price'])){ ?>;
		var s = "<?php echo $_GET['start_price']; ?>";
		<?php }else{ ?>
		var s = "0";
		<?php } ?>
		<?php if(isset($_GET['end_price'])){ ?>;
		var e = "<?php echo $_GET['end_price']; ?>";
		<?php }else{ ?>
		var e = "10000";
		<?php } ?>

		if( region == "" && operator == "" && cruise_ship == "" && ship_fly_in == "" && ship_starts_on == "" && ship_cruise_nights == "" ){	
		    var s = "0";
		    var e = "1000";
		}
		jQuery(".main_tab_loader").show();
	    jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'iflair_search_filter_response',
	            region: region,
	            operator: operator,
	            cruise_ship: cruise_ship,
	            ship_fly_in: ship_fly_in,
	            ship_starts_on: ship_starts_on,
	            ship_cruise_nights: ship_cruise_nights,
	            s:s,
	            e:e,
                pagenumb:pageNum
            }),
            success: function (response) {
                jQuery('.form-field').html(response);
				jQuery('.input-form.wrraper').slideDown();
				jQuery(".main_tab_loader").hide();

				if(s=="0" && e=="10000"){

			    }
			    else if(e=="1000"){
					jQuery('#1_radio').prop('checked',true);
			    }
			    else if(e=="1500"){
					jQuery('#2_radio').prop('checked',true);
			    }
			    else if(e=="2000"){
					jQuery('#3_radio').prop('checked',true);
			    }
			    else if(e=="3000"){
					jQuery('#4_radio').prop('checked',true);
			    }
			    else if(e=="4000"){
					jQuery('#5_radio').prop('checked',true);
			    }
			    else if(e=="5000"){
					jQuery('#6_radio').prop('checked',true);
			    }
			    else if(s!="0" && e=="10000"){
					jQuery('#7_radio').prop('checked',true);
			    }

            	jQuery('.loader').css('display','none');
				//jQuery('.form-field').css('border','1px solid rgb(185, 181, 181)');
            }
        });


	<?php if(is_page($river_page_id)){
		?>
		setTimeout(function() {
			jQuery("#1").trigger('click');
	    },10);
		<?php
	}
	elseif(is_page($ocean_page_id)){
		?>
		setTimeout(function() {
			jQuery("#2").trigger('click');
	    },10);
		<?php
	} ?>

	jQuery(".tsb-tab").click(function(){
		jQuery(".main_tab_loader").show();
		jQuery(".tsb-tab").removeClass("active_tab");
		jQuery(this).addClass("active_tab");
		var tab_id = jQuery(".active_tab").attr('id');
		jQuery("#tab_loader").show();
		jQuery('#cruise_region').prop('selectedIndex',0);
		jQuery('#cruise_operator').prop('selectedIndex',0);
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
		iflair_search_filter(tab_id);
	});

	jQuery(this).next('ul').slideUp();
	jQuery('#sub_list a').on('click',function(){
		jQuery(this).next('ul').slideToggle();
	});


	var w = window.innerWidth;
	if(w<"768"){
		//alert("slide");
			jQuery('.search-bt-2').on('click',function(){
				jQuery('.side-bar').slideToggle();
			});
		jQuery('.open_search').on('click',function(){
			jQuery('.input-form.wrraper').slideToggle();
			jQuery('.side-bar').slideToggle();
		});
	}
	else{
		//jQuery('.input-form.wrraper').slideDown();
		jQuery('.open_search').on('click',function(){
			jQuery('.searched .input-form.wrraper').slideToggle();
			//alert("change search now");
		});
	}

	jQuery('#cruise_region').prop('selectedIndex',0);
	jQuery('#cruise_operator').prop('selectedIndex',0);
	jQuery('#cruise_ship').prop('selectedIndex',0);
	jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
	jQuery('#cruise_leaving_from').prop('selectedIndex',0);
	jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
	jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);

});

function iflair_search_filter(str){
	var pagenumb='1';
	var check = str;

	var tab_id = jQuery(".active_tab").attr('id');
	if(check=="1" || check=="undefined" || check=="2"){
	//var tab_id = <?php if(isset($_GET['tab_id']) && $_GET['tab_id'] != "undefined"){ ?>"<?php echo $_GET['tab_id']; ?>"<?php }else{ ?>jQuery(".active_tab").attr('id')<?php } ?>;

	var region = <?php if(isset($_GET['cruise_region'])){ echo '"'.$_GET['cruise_region'].'"'; }else{?>jQuery('#cruise_region').val();<?php } ?>;
	var operator = <?php if(isset($_GET['cruise_operator'])){ echo '"'.$_GET['cruise_operator'].'"'; }else{?>jQuery('#cruise_operator').val();<?php } ?>;
	var cruise_ship = <?php if(isset($_GET['cruise_ship'])){ echo '"'.$_GET['cruise_ship'].'"'; }else{?>jQuery('#cruise_ship').val();<?php } ?>;
	var ship_fly_in = <?php if(isset($_GET['cruise_ship_fly_in'])){ echo '"'.$_GET['cruise_ship_fly_in'].'"'; }else{?>jQuery('#cruise_ship_fly_in').val();<?php } ?>;
	var ship_starts_on = <?php if(isset($_GET['cruise_ship_starts_on'])){ echo '"'.$_GET['cruise_ship_starts_on'].'"'; }else{?>jQuery('#cruise_ship_starts_on').val();<?php } ?>;
	var ship_cruise_nights = <?php if(isset($_GET['cruise_ship_cruise_nights'])){ echo '"'.$_GET['cruise_ship_cruise_nights'].'"'; }else{?>jQuery('#cruise_ship_cruise_nights').val();<?php } ?>;
	var s = <?php if(isset($_GET['start_price'])){ echo '"'.$_GET['start_price'].'"'; } else   if (isset($_POST['start_price'])){ echo trim($_POST['start_price']); }else{
	echo '0'; } ?>;
	var e = <?php if(isset($_GET['end_price'])){ echo '"'.$_GET['end_price'].'"'; } else   if (isset($_POST['end_price'])){ echo trim($_POST['end_price']); }else{
	echo '10000'; } ?>;
	

	}
	else{
	var region = jQuery('#cruise_region').val();
	var operator = jQuery('#cruise_operator').val();
	var cruise_ship = jQuery('#cruise_ship').val();
	var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
	var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
	var from_cruise_date = jQuery('#from_cruise_date').val();
	var to_cruise_date = jQuery('#to_cruise_date').val();
	var ship_cruise_nights = jQuery('#cruise_ship_cruise_nights').val();
    var s = jQuery("#amount1").val();
    var e = jQuery("#amount2").val();
	
	}
	if(check=="reset"){
		jQuery('#cruise_region').prop('selectedIndex',0);
		jQuery('#cruise_operator').prop('selectedIndex',0);
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    	jQuery('.loader_filt').css('display','block');

		jQuery.cookie('str1', '', {expires: 1 });
		jQuery.cookie('str2', '', {expires: 1 });

		return false;
	}
	if(check=="region"){
		jQuery('#cruise_operator').prop('selectedIndex',0);
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="operator"){
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="cruise_ship"){
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="ship_fly_in"){
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="leaving_from"){
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="ship_starts_on"){
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="ship_cruise_nights"){
			//iflair_search_filter();
    jQuery('.loader_filt').css('display','block');
	}
	if(check=="search"){

		//var newURL = window.location.href;
		<?php $listing_page_id = get_site_option( 'iflair_cruise_theme_ship_listing_page' );?>
		var newURL = "<?php echo get_permalink($listing_page_id); ?>";
		//alert(newURL);
		/*var url_1 = window.location.pathname;
		alert(url_1);*/
		if(jQuery(".active_tab").attr('id')=="1"){
			var path = "";
		}
		else if(jQuery(".active_tab").attr('id')=="2"){
			var path = "";
		}
		else{
			var path = "";
		}

		if(jQuery('#amount1').val()=="undefined"){
			var s = "0";
		}
		else{
			var s =jQuery('#amount1').val();
		}
		if(jQuery('#amount2').val()=="undefined"){
			var e = "10000";
		}
		else{
			var e = jQuery('#amount2').val();
		}
		//alert(start_price);
		
		if( region == "" && operator == "" && cruise_ship == "" && ship_fly_in == "" && ship_starts_on == "" && ship_cruise_nights == "" ){	
		    var s = "0";
		    var e = "1000";
		}

        history.pushState({},"URL Rewrite Example",newURL+""+path+"?cruise_region="+region+"&from_cruise_date="+from_cruise_date+"&to_cruise_date="+to_cruise_date+"&cruise_operator="+operator+"&cruise_ship="+cruise_ship+"&cruise_ship_cruise_nights="+ship_cruise_nights+"&start_price="+s+"&end_price="+e);

		jQuery.cookie('str1', '', {expires: 1 });
		jQuery.cookie('str2', '', {expires: 1 });

		/*if(region==""){
			jQuery('#cruise_region').focus();
			alert("Where do you want to go?");
			return false;
		}
		if(operator==""){
			jQuery('#cruise_operator').focus();
			alert("Who would you like to Cruise with?");
			return false;
		}*/
		var width_res = jQuery(".header").width();
		if(width_res<768){
			jQuery('.input-form.wrraper').slideToggle();
		}
		jQuery('.loader').css('display','block');
		jQuery('.search_header').addClass('searched');
		jQuery('.search_header').addClass('searched_image');
		jQuery('#replace_query_ajax').addClass('replace_query_class');
		jQuery('#replace_query_ajax').addClass('col-sm-9');

		jQuery(".backgroundimages").hide();
		jQuery(".bx-wrapper").hide();
		jQuery(".grey-box-wrraper").hide();
		jQuery(".blackback").addClass("home_searched");

		cruise_filter();
	}
	if(check=="1" || check=="2" || check=="3" ){
		var tab_id = check;
	}
	else{
		var tab_id = jQuery(".active_tab").attr('id');
	}
	//alert(str);
	jQuery.ajax({
        type: "POST",
        url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
        data: ({
            action: 'iflair_search_filter_response',
            tab_id : tab_id,
            region: region,
            operator: operator,
            cruise_ship: cruise_ship,
            ship_fly_in: ship_fly_in,
            ship_starts_on: ship_starts_on,
            ship_cruise_nights: ship_cruise_nights,
            from_cruise_date:from_cruise_date,
            to_cruise_date:to_cruise_date,
            s:s,
            e:e,
            pagenumb:pagenumb
        }),
        success: function (response) {
        	//jQuery('.loader').css('display','none');
        	jQuery('.loader_filt').css('display','none');
            //alert(response);
            jQuery('.form-field').html(response);

            if(s=="0" && e=="10000"){

		    }
		    else if(e=="1000"){
				jQuery('#1_radio').prop('checked',true);
		    }
		    else if(e=="1500"){
				jQuery('#2_radio').prop('checked',true);
		    }
		    else if(e=="2000"){
				jQuery('#3_radio').prop('checked',true);
		    }
		    else if(e=="3000"){
				jQuery('#4_radio').prop('checked',true);
		    }
		    else if(e=="4000"){
				jQuery('#5_radio').prop('checked',true);
		    }
		    else if(e=="5000"){
				jQuery('#6_radio').prop('checked',true);
		    }
		    else if(s!="0" && e=="10000"){
				jQuery('#7_radio').prop('checked',true);
		    }

			jQuery("#tab_loader").hide();
	        jQuery(".main_tab_loader").hide();
        }
    });
    //cruise_filter();
}

function cruise_filter(){
	jQuery('.loader').css('display','block');
	var pagenumb='1';
	var check = jQuery(".active_tab").attr('id');
	if(check=="1" || check=="2" || check=="3" ){
		var tab_id = check;
	}
	var region = jQuery('#cruise_region').val();
	var operator = jQuery('#cruise_operator').val();
	var cruise_ship = jQuery('#cruise_ship').val();
	var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
	var leaving_from = jQuery('#cruise_leaving_from').val();
	var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
	var ship_cruise_nights = jQuery('#cruise_ship_cruise_nights').val();

	jQuery('body').addClass('loader_body');
	jQuery('.main-footer').addClass('loader_footer');
	jQuery('#replace_query_ajax').addClass('loader_replace_query');
	
	if( region == "" && operator == "" && cruise_ship == "" && ship_fly_in == "" && ship_starts_on == "" && ship_cruise_nights == "" ){	
	    var s = "0";
	    var e = "1000";
	}

	var from_cruise_date = jQuery('#from_cruise_date').val();
	var to_cruise_date = jQuery('#to_cruise_date').val();
	var sort_val = jQuery("#sort").val();
	jQuery.ajax({
        type: "POST",
        url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
        data: ({
            action: 'cruise_filter_response',
            <?php if($_COOKIE['str1']!=""){ ?>str1: <?php echo "'".$_COOKIE['str1']."',"; } ?>
            <?php if($_COOKIE['str2']!=""){ ?>str2: <?php echo "'".$_COOKIE['str2']."',"; } ?>
            region: region,
            tab_id : tab_id,
            operator: operator,
            cruise_ship: cruise_ship,
            ship_fly_in: ship_fly_in,
            leaving_from: leaving_from,
            ship_starts_on: ship_starts_on,
            ship_cruise_nights: ship_cruise_nights,
            from_cruise_date:from_cruise_date,
            to_cruise_date:to_cruise_date,
            sort_val:sort_val,
            s:s,
            e:e,
            pagenumb:pagenumb
        }),
        success: function (response) {
        	jQuery(".new_design_homepage .home_page_area").remove();

			jQuery('body').removeClass('loader_body');
			jQuery('.main-footer').removeClass('loader_footer');
			jQuery('#replace_query_ajax').removeClass('loader_replace_query');
			
			if(s=="0" && e=="10000"){

		    }
		    else if(e=="1000"){
				jQuery('#1_radio').prop('checked',true);
		    }
		    else if(e=="1500"){
				jQuery('#2_radio').prop('checked',true);
		    }
		    else if(e=="2000"){
				jQuery('#3_radio').prop('checked',true);
		    }
		    else if(e=="3000"){
				jQuery('#4_radio').prop('checked',true);
		    }
		    else if(e=="4000"){
				jQuery('#5_radio').prop('checked',true);
		    }
		    else if(e=="5000"){
				jQuery('#6_radio').prop('checked',true);
		    }
		    else if(s!="0" && e=="10000"){
				jQuery('#7_radio').prop('checked',true);
		    }

        	jQuery('.loader').css('display','none');
            jQuery('#replace_query_ajax').html(response);
	                
		}
    });
}

</script>
<?php
get_footer(); 
?>