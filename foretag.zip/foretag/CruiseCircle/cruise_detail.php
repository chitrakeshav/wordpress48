<?php
/*
Template Name: Cruise Detail
*/
get_header();
?>

	<?php $listing_page_id = get_site_option( 'iflair_cruise_theme_ship_listing_page' ); ?>
	
	<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/jquery.mCustomScrollbar.css">
	<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/lazyYT.css">
	<!-- <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/owl.carousel.min.css"> -->
	<!-- <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/owl.theme.default.min.css"> -->
	<!--<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/owl.carousel.js"></script>-->
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.mCustomScrollbar.concat.min.js"></script>
	
	<script type="text/javascript">
	    function resize_f(){
			jQuery("body").scroll(function() {  
				//alert("111111111");
				if(navigator.userAgent.indexOf("Chrome") != -1 )
			    {
			        var nav = jQuery('.detail-left'),
					navOff  = nav.offset();
					var gl_height = jQuery(".demo-gallery").height()+jQuery(".menubar").height();
					//alert(gl_height);
						if (jQuery(this).scrollTop() > navOff.top) {
					jQuery(".detail-right-fixed").addClass('fixed_right');
					jQuery(".show_title").show();
					jQuery(".content-d_scroll").addClass('search_scroll_fix');
					jQuery(".scroll_header").css("display","block");

					} else {
						jQuery(".detail-right-fixed").removeClass('fixed_right');
					jQuery(".show_title").hide();
						jQuery(".content-d_scroll").removeClass('search_scroll_fix');
					jQuery(".scroll_header").css("display","none");
					}
			    }
				else if(navigator.userAgent.indexOf("Firefox") != -1 ) 
			    {
			        var scroll = jQuery("body").scrollTop();    
					//alert(scroll);
					var gl_height = jQuery(".demo-gallery").height()+jQuery(".menubar").height();
					if(scroll > gl_height + 98){
						//alert('hi');
						jQuery(".detail-right-fixed").addClass('fixed_right');
					jQuery(".show_title").show();
					jQuery(".content-d_scroll").addClass('search_scroll_fix');
						jQuery(".scroll_header").css("display","block");

					}
					else{
						jQuery(".detail-right-fixed").removeClass('fixed_right');
					jQuery(".show_title").hide();
						jQuery(".content-d_scroll").removeClass('search_scroll_fix');
						jQuery(".scroll_header").css("display","none");

					}
			    }
			    else
			    {
			        var scroll = jQuery("body").scrollTop();    
					//alert(scroll);
					var gl_height = jQuery(".demo-gallery").height()+jQuery(".menubar").height();
					if(scroll > gl_height + 98){
						//alert('hi');
						jQuery(".detail-right-fixed").addClass('fixed_right');
					jQuery(".show_title").show();
					jQuery(".content-d_scroll").addClass('search_scroll_fix');

					}
					else{
						jQuery(".detail-right-fixed").removeClass('fixed_right');
					jQuery(".show_title").hide();
						jQuery(".content-d_scroll").removeClass('search_scroll_fix');

					}
			    }
			});
		}
		
		jQuery(document).ready(function(){
			var w = window.innerWidth;
			//alert(w);
			if(w>1024){
				var gl_height = jQuery(".demo-gallery").height();	
				var h_hh = gl_height-200;
				//alert(h_hh);
				jQuery('body').css("height","auto");
				jQuery('html, body').animate({scrollTop:h_hh}, 'slow');
			}
			else if(w>768){
				var gl_height = jQuery(".demo-gallery").height();	
				var h_hh = gl_height-170;
				//alert(h_hh);
				jQuery('html, body').animate({scrollTop:h_hh}, 'slow');
			}
			else{
				var gl_height = jQuery(".demo-gallery").height();	
				var h_hh = gl_height+150;
				//alert(h_hh);
				jQuery('html, body').animate({scrollTop:h_hh}, 'slow');
			}
				jQuery(window).on('load resize', function(){
					resize_f();
				});

			/*jQuery('.cruise_detail_images').owlCarousel({
			    loop:true,
			    nav:false,
			    autoplay:true,
			    responsive:{
			        0:{
			            items:1
			        },
			        600:{
			            items:3
			        },
			        1000:{
			            items:5
			        }
			    }
			})*/
		});

	</script>
	<script type="text/javascript">
	
	
	</script>

	<!-- <link href="<?php echo esc_url( get_template_directory_uri() ); ?>/dist/css/lightgallery.css" rel="stylesheet"> -->
	<?php
		global $wpdb,$mydb;
		$site_detail_result = $mydb->get_results("SELECT * FROM `cruise_ship_cruise` as csc INNER JOIN `cruise_cruise` as cc ON csc.ship_id = cc.cruise_response_id WHERE csc.cruise_id = '$_GET[cruise_id]' AND csc.ship_starts_on >= curdate() ");

		$listing_page_id = get_site_option( 'iflair_cruise_theme_ship_listing_page' );
		$port_result = $mydb->get_results("SELECT * FROM `cruise_port` WHERE cruise_id = '$_GET[cruise_id]'");

		$offer_result = $wpdb->get_row("SELECT * FROM ".BASEPOKE_LIST." as bl INNER JOIN ".BASEPOKE_CRUISES." as bc ON bl.id = bc.basepoke_id WHERE bc.offer_start_date <= curdate() and bc.offer_end_date > curdate() and bc.cruise_id = '$_GET[cruise_id]' AND bl.basepoke_status = 1 AND bc.base_cruise_status = 1");
		$offer_count = count($offer_result);
		/*echo "<pre>";
		print_r($offer_result);
		echo "</pre>";*/

		if(!$port_result || empty($site_detail_result))
		{
		?>
			<div class="header wrraper search_header" style="background:rgba(0, 0, 0, 0) url(<?php $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo $feat_image; ?>) no-repeat scroll center top / cover ">
				<div class= "mobile-top wrapper clearfix">
						<a href="#" class="w-arrow"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/white-arrow.png"></a>
					</div>
				<div class="container">					
					<div class="grey-box-wrraper clearfix" style="margin-top: 10px;">
						<div class="grey-box">
							<h1>No Cruise Details Found</h1>
							<a href="<?php echo esc_url(home_url('/')); ?>" class="cruise">BACK TO CRUISE LIST</a>	
						</div>					
					</div>
				</div>
			</div>
		<?php
		}
		else
		{
			/* All table's query */

			$room_accomodation_query_all = "SELECT * FROM cruise_accomodation_types WHERE ship_response_id=".$site_detail_result[0]->cruise_response_id."";
			$room_accomodation_query_result_all = $mydb->get_results($room_accomodation_query_all."  ORDER BY index_val");
			$room_accomodation_query_result = $mydb->get_results($room_accomodation_query_all." GROUP BY index_val ORDER BY index_val");


			$cruise_dining_options_query_all = "SELECT * FROM cruise_dining_options WHERE ship_response_id=".$site_detail_result[0]->cruise_response_id."";
			$cruise_dining_options_query_result_all = $mydb->get_results($cruise_dining_options_query_all."  ORDER BY index_val");
			$cruise_dining_options_query_result = $mydb->get_results($cruise_dining_options_query_all." GROUP BY index_val ORDER BY index_val");



			$cruise_entertainment_options_query_all = "SELECT * FROM cruise_entertainment_types WHERE ship_response_id=".$site_detail_result[0]->cruise_response_id."";
			$cruise_entertainment_options_query_result_all = $mydb->get_results($cruise_entertainment_options_query_all."  ORDER BY index_val");
			$cruise_entertainment_options_query_result = $mydb->get_results($cruise_entertainment_options_query_all." GROUP BY index_val ORDER BY index_val");



			$cruise_health_and_fitness_options_query_all = "SELECT * FROM cruise_health_fitness_types WHERE ship_response_id=".$site_detail_result[0]->cruise_response_id."";
			$cruise_health_and_fitness_options_query_result_all = $mydb->get_results($cruise_health_and_fitness_options_query_all." ORDER BY index_val");
			$cruise_health_and_fitness_options_query_result = $mydb->get_results($cruise_health_and_fitness_options_query_all." GROUP BY index_val ORDER BY index_val");



			$cruise_enrichment_options_query_all = "SELECT * FROM crusie_enrichment_types WHERE ship_response_id=".$site_detail_result[0]->cruise_response_id."";
			$cruise_enrichment_options_query_result_all = $mydb->get_results($cruise_enrichment_options_query_all." ORDER BY index_val");
			$cruise_enrichment_options_query_result = $mydb->get_results($cruise_enrichment_options_query_all." GROUP BY index_val ORDER BY index_val");




			$cruise_kids_and_teens_options_query_all = "SELECT * FROM cruise_kid_teen_types WHERE ship_response_id=".$site_detail_result[0]->cruise_response_id."";
			$cruise_kids_and_teens_options_query_result_all = $mydb->get_results($cruise_kids_and_teens_options_query_all." ORDER BY index_val");
			$cruise_kids_and_teens_options_query_result = $mydb->get_results($cruise_kids_and_teens_options_query_all." GROUP BY index_val ORDER BY index_val");



			$cruise_deckplans_options_query_all = "SELECT * FROM cruise_deckplans WHERE ship_response_id=".$site_detail_result[0]->cruise_response_id."";
			$cruise_deckplans_options_query_result_all = $mydb->get_results($cruise_deckplans_options_query_all." ORDER BY index_val");
			$cruise_deckplans_options_query_result = $mydb->get_results($cruise_deckplans_options_query_all." GROUP BY index_val ORDER BY index_val");
		?>
		<?php 
			if(!$site_detail_result[0]->cruise_cover_image_href)
			{  
			} 
			else 
			{ ?>

				<script type="text/javascript">
			        /*jQuery(document).ready(function(){
			            jQuery('#lightgallery').lightGallery();
			        });*/
		        </script>
        
		        <!--<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/picturefill.min.js"></script>
		        <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/dist/js/lightgallery.js"></script>
		        <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/dist/js/lg-thumbnail.js"></script>
		        <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/dist/js/lg-pager.js"></script>-->

			<?php } ?>

			<div class="content-d clearfix" style="background-color:#fff;">
				<div class="container">
					
					<!-- <div class="detail-left">
						<a class="manage_search" id="change_detail_search">Back to search results</a>
						
						<div class="detail_open_search" style="display:none;">	
							<form action="<?php echo get_page_link($listing_page_id); ?>" name="detail_search" id="detail_search" method="get" >
								<div class="form-field form-field-cruise">
								</div>
							</form>
						</div>
					</div> -->
					
					<!--<script type="text/javascript">
						jQuery("#change_detail_search").click(function(){
							jQuery(".detail_open_search").slideToggle();
						});
					</script>-->
				</div>
			</div>
		</div>
	
		<div class="content-d content-d_scroll clearfix">
			<div class="container">
				<div class="title_image">
						<div class="cruse-head" style="background: transparent url('') no-repeat scroll left center / 85px 70px;">
							<?php 
								if($offer_result->extra_info == ""){
									if($site_detail_result[0]->ship_name ){ echo $site_detail_result[0]->ship_name." - on board The "; }else{} if($site_detail_result[0]->cruise_title ){ echo $site_detail_result[0]->cruise_title; }else{} 
								}else{
									echo $offer_result->offer_title;
								}
							?>
						</div>
						<div class="s_imgae"><img src="http://ekups3e.cloudimg.io/s/resize/300/<?php echo str_replace("//www","www",$site_detail_result[0]->cruise_profile_image_href);?>" style="height: auto; width: auto;" alt="#" class="img-responsive detail_result_img"></div>
				</div>
				<div class="border-div border_div_new">
					<div class="detail-left">
						<div class="about-this clearfix">
							
							
							<?php 
							if(!empty($offer_result))
							{
							?>
								<div class="cruse-left">
									<div class="c-detail-left">
										<li class="clearfix"><h3>Cruise Date: </h3><p><?php $ship_date=$offer_result->departure_date; echo date('d M Y',strtotime($ship_date))." (".$offer_result->cruise_nights." Nights)"; ?></p></li>
										<li class="clearfix"><h3>Cruise Line: </h3><p><?php echo $offer_result->operator_name; ?></p></li>
										<li class="clearfix"><h3>Cruise Ship: </h3><p><?php echo $site_detail_result[0]->cruise_title; ?></p></li>
										
										<li class="clearfix"><h3>Cruise Type: </h3>
											<p>
											<?php
											if(isset($_GET['cruise_type']) && $_GET['cruise_type'] == "cruiseonly" ){
												echo "Cruise Only";
											}
											else if(isset($_GET['cruise_type']) && $_GET['cruise_type'] == "fly" ){
												echo "Fly Cruise";
											}
											else{
												echo "Cruise Only";
											}
											?>
											</p>
										</li>
										<li class="clearfix add_red"><h3>Highlights: </h3>
											<?php
											$cruise_custom_information_deal=$offer_result->offer_description;
											echo "<div class='space-nowrap' style='color:red;font-weight:bold;'>".substr(wpautop(stripslashes($cruise_custom_information_deal)),0,90)."...</div>";
											?>
										</li>
									</div>
								</div>
							<?php 
							}
							else
							{
							?>
								<div class="cruse-left">
									<div class="c-detail-left">
										<li class="clearfix"><h3>Cruise Date: </h3><p><?php $ship_date=$site_detail_result[0]->ship_starts_on; echo date('d M Y',strtotime($ship_date))." (".$site_detail_result[0]->ship_cruise_nights." Nights)"; ?></p></li>
										<li class="clearfix"><h3>Cruise Line: </h3><p><?php echo ucfirst(str_replace("-", " ", $site_detail_result[0]->ship_operator)); ?></p></li>
										<li class="clearfix"><h3>Cruise Ship: </h3><p><?php echo $site_detail_result[0]->cruise_title; ?></p></li>
										
										<li class="clearfix"><h3>Cruise Type: </h3>
											<p>
											<?php
											if(isset($_GET['cruise_type']) && $_GET['cruise_type'] == "cruiseonly" ){
												echo "Cruise Only";
											}
											else if(isset($_GET['cruise_type']) && $_GET['cruise_type'] == "fly" ){
												echo "Fly Cruise";
											}
											else if(!isset($_GET['cruise_type']) && $site_detail_result[0]->ship_cruise_only_price!= "0"){
												echo "Cruise Only";
											}
											else if(!isset($_GET['cruise_type']) && $site_detail_result[0]->ship_fly_cruise_price!= "0"){
												echo "Fly Cruise";
											}
											else{
												echo "Cruise Only";
											}
											?>
											</p>
										</li>
										<!-- <li class="clearfix"><h3>Highlights: </h3>
											<p class="scport">
												<?php
												/*if($offer_result->ports_visited != ""){ echo $offer_result->ports_visited;}
												else{ echo $port_result[0]->port_name;
													for($p=1;$p<count($port_result);$p++){
														echo ", ".$port_result[$p]->port_name;
													}//echo "etc..";
												}*/
												?>
											</p>
										</li> -->
									</div>
								</div>
							<?php 
								/*
							?>
								<div class="cruse-left">
									<div class="c-detail-left">
										<li class="clearfix"><h3>Departure Date</h3><p><?php if($offer_result->departure_date !=""){ echo date('d M Y',strtotime($offer_result->departure_date)); }else{ $ship_date=$site_detail_result[0]->ship_starts_on; echo date('d M Y',strtotime($ship_date)); } ?></p></li>
										<li class="clearfix"><h3>Region </h3><p><?php if($site_detail_result[0]->ship_region ==""){ echo "-"; } else{ echo $site_detail_result[0]->ship_region; }; ?></p></li>
										<li class="clearfix"><h3>Vacation Days </h3><p><?php if($offer_result->cruise_nights ==""){ if($site_detail_result[0]->ship_vacation_days==""){ echo "-"; } else{ echo $site_detail_result[0]->ship_vacation_days; }; }else{ echo $offer_result->cruise_nights-1; }?></p></li>
										
										<li class="clearfix"><h3>Cruise Nights</h3><p><?php if($offer_result->cruise_nights ==""){ if($site_detail_result[0]->ship_cruise_nights==""){ echo "-"; } else{ echo $site_detail_result[0]->ship_cruise_nights; }; }else{ echo $offer_result->cruise_nights; }?></p></li>
										<li class="clearfix"><h3>Post Cruise</h3><p><?php echo $offer_result->post_cruise; ?></p></li>
									</div>
								</div>
								<div class="cruse-right">
									<div class="c-detail-left">
										<li class="clearfix">
											<h3>Embark at</h3>
											<p>
												<?php 
												if($offer_result->embark_at ==""){ if($site_detail_result[0]->ship_fly_in ==""){ echo "-"; } 
												else{ echo $site_detail_result[0]->ship_fly_in; }; }
												else{ echo $offer_result->embark_at; }?>
											</p>
										</li>
										<li class="clearfix">
											<h3>Disembark at</h3>
											<p>
												<?php
												if($offer_result->disembark_at ==""){ if($site_detail_result[0]->ship_fly_out ==""){ echo "-"; }
												else{ echo $site_detail_result[0]->ship_fly_out; }; }
												else{ echo $offer_result->disembark_at; }?></p></li>	
										<li class="clearfix"><h3 class="scporttitle">Ports Visited </h3><br />
											<p class="scport">
												<?php
												if($offer_result->ports_visited != ""){ echo $offer_result->ports_visited;}
												else{ echo $port_result[0]->port_name;
													for($p=1;$p<count($port_result);$p++){
														echo ", ".$port_result[$p]->port_name;
													}//echo "etc..";
												}
												?>
											</p>
										</li>	
									</div>
								</div>
							<?php 
							*/
							} ?>

							<div class="detail-right clearfix mobile_view_class"  >
				
								<h1><?php echo $site_detail_result[0]->cruise_title; if($site_detail_result[0]->ship_cruise_only_price!="0"){ /* echo  "From £".number_format($site_detail_result[0]->ship_cruise_only_price); */ } ?></h1>
								
								<div class="enquiry">
									<img src="http://ekups3e.cloudimg.io/s/resize/300/<?php echo str_replace("//www","www",$site_detail_result[0]->cruise_profile_image_href);?>" style="height: 60px; width: auto;" alt="#" class="img-responsive detail_result_img">
					
									<?php 
										$price1 = $site_detail_result[0]->ship_cruise_only_price;
										$price2 = $site_detail_result[0]->ship_fly_cruise_price;
										if(!empty($offer_result->offer_price)){
											?>
											<h2>Cruise Package Price</h2>
											<p class="text1">From </p><p class="textbld">£<?php echo number_format($offer_result->offer_price); ?><span class="text2"> per person</span></p>
											<?php
										}
										elseif($price1=="0" && $price2=="0")
										{
											?>
											<?php
										}
										elseif($price1==$price2)
										{
											?>
											<h2 style="font-size: 21px; line-height: 35px;"><!-- Price For Cruise Only : £<?php //echo number_format($price1); ?> per person -->Cruise Only price £<?php echo number_format($price1); ?> per person</h2>
											<?php
										}
										elseif( ( $price1!="0" && $price1 < $price2 ) || $price2== "0" )
										{
											?>
											<h2 style="font-size: 21px; line-height: 35px;"><!-- Price For Cruise Only : £<?php //echo number_format($price1); ?> per person -->Cruise Only price £<?php echo number_format($price1); ?> per person</h2>
											<?php
										}
										elseif( ( $price2!="0" && $price1 > $price2 ) || $price1== "0" )
										{
											?>
											<h2 style="font-size: 21px; line-height: 35px;"><!-- Price For Fly Cruise : £<?php //echo number_format($price2); ?> per person -->Fly Cruise Price £<?php echo number_format($price2); ?> per person</h2>
											<?php
										}
									?>
							
									<!-- <h2>Cabin type</h2> -->
									<p style="font-size: 12px;">Please contact us for prices on other cabin types </p>
									<a href="tel:<?php if($offer_result->contact_number != ""){ echo $offer_result->contact_number; }else{ echo "0800 023 1273"; } ?>" class="callhere"><?php if($offer_result->contact_number != ""){ echo $offer_result->contact_number; }else{ echo "0800 023 1273"; } ?></a>
								
									<button type="button" class="btn btn-primary btn-lg" id="manual_model_slide" data-toggle="modal" data-target="#slide_down_div"><i class="fa fa-envelope" aria-hidden="true"></i> MAKE AN ENQUIRY</button>
									<div class="listatol">
										<p class="fp">Financial Protection:</p>
										<p>Your Holiday is fully ATOL Protected. Our Atol Number is 3448 </p>
										<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/h11.png" alt="">
										<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/h22.png" alt="">
										<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/h33.png" alt="">
									</div>
								</div>
					
								<script>
									jQuery(document).ready(function(){
										jQuery("#manual_model_slide").click(function(){
										    jQuery("#manual_model").slideToggle();
										});
									});
								</script>

							</div>
							<div class="grey_bar">
								<div class="desktop_view">
									<a class="callhere " > <?php if($offer_result->contact_number != ""){ echo $offer_result->contact_number; }else{ echo "0800 023 1273"; } ?> </a>
								</div>
								<div class="mobile_view">
									<a href="tel:<?php if($offer_result->contact_number != ""){ echo $offer_result->contact_number; }else{ echo "0800 023 1273"; } ?>" class="callhere "><?php if($offer_result->contact_number != ""){ echo $offer_result->contact_number; }else{ echo "0800 023 1273"; } ?></a>
								</div>
								
								<?php if ($_GET[cruise_id] != "") 
								{ ?>
									
									<div class="cruise-ref">
										<p><strong>Cruise reference:</strong> CC-<?php echo $_GET[cruise_id]; ?></p>
									</div>

								<?php } ?>
							</div>
							<?php 

								if(!empty($offer_result->offer_price)){
									?><div class="price_bar"><?php
									echo "<span>From:</span> £".$offer_result->offer_price. " pp";
									?></div><?php
								}
								else if ($_GET[cruise_type] != "")
								{
							?>
								<div class="price_bar <?php if($site_detail_result[0]->ship_fly_cruise_price == "" || $site_detail_result[0]->ship_cruise_only_price == ""){ echo "noprice"; } ?>">
									<?php
									if ($_GET[cruise_type] == "fly")
									{
										if ($site_detail_result[0]->ship_fly_cruise_price != "" && $site_detail_result[0]->ship_fly_cruise_price != "0") 
										{
											echo "<span>From:</span> £".$site_detail_result[0]->ship_fly_cruise_price. " pp";
										}
										else
										{
											echo "<span>From</span> £ Enquire";
										}
									}
									elseif($_GET[cruise_type] == "cruiseonly")
									{
										if ($site_detail_result[0]->ship_cruise_only_price != "" && $site_detail_result[0]->ship_cruise_only_price != "0") 
										{
											echo "<span>From:</span> £".$site_detail_result[0]->ship_cruise_only_price. " pp";
										}
										else
										{
											echo "<span>From</span> £ Enquire";
										}
									}
									?>

								</div>
							<?php 
							}else{
							?>
								<div class="price_bar <?php if($site_detail_result[0]->ship_fly_cruise_price == "" || $site_detail_result[0]->ship_cruise_only_price == ""){ echo "noprice"; } ?>">
									<?php
										if ($site_detail_result[0]->ship_cruise_only_price != "" && $site_detail_result[0]->ship_cruise_only_price != "0") 
										{
											echo "<span>From:</span> £".$site_detail_result[0]->ship_cruise_only_price. " pp";
										}
										else
										{
											echo "<span>From:</span> £ Enquire";
										}
									?>

								</div>
							<?php 
							}
							?>

							<?php
							/*print "<pre>";
							print_r($site_detail_result);
							echo $site_detail_result->ship_name;*/
							/*echo $site_detail_result[0]->ship_starts_on;*/
							?>

							<button type="button" class="btn btn-primary btn-lg" id="manual_model_slide" data-toggle="modal" data-target="#slide_down_div"><i class="fa fa-envelope" aria-hidden="true"></i> Enquire</button>
				
						</div>

						<div class="modal fade" id="slide_down_div" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
							<div class="modal-dialog" role="document">
								<div class="modal-content enquiry-down
											    ">
									<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
											
											<h4 class="modal-title" id="myModalLabel" style="text-align:left;"><?php $arrival=$site_detail_result[0]->ship_starts_on; echo $site_detail_result[0]->cruise_title." | ".$site_detail_result[0]->ship_name." | ".date('d M Y',strtotime($arrival)); ?></h4>
									</div>
									<div class="modal-body ">
										<?php echo do_shortcode("[shipenquiryform ship_name='".$site_detail_result[0]->ship_name."' cruise_name='".$site_detail_result[0]->cruise_title."' date='".date('d M Y',strtotime($arrival))."']"); ?>
										
										<div style="clear:both;"></div>
						      		</div>
								</div>
						  	</div>
						</div>
					</div>

					<div class="demo-gallery left_slider">
						<!-- bxSlider Javascript file -->
					<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.bxslider.min.js"></script>
					<!-- bxSlider CSS file -->
					<link href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/jquery.bxslider.css" rel="stylesheet" />
					<script type="text/javascript">
						jQuery(document).ready(function(){
							jQuery('#lightgallery').bxSlider({
								auto: true,
								autoControls: true,
								infiniteLoop: true,
								pager: false,
								speed: 1000,
								pause: 7000,
							});
						});
					</script>
						<ul id="lightgallery" class="list-unstyled">
				          	<li>
				                <img class="img-responsive" src="http://ekups3e.cloudimg.io/s/crop/450x310/<?php echo str_replace("//www","www",$site_detail_result[0]->cruise_cover_image_href); ?>">
				            </li>
				            
				            <?php
								for($rc_all=0;$rc_all<count($room_accomodation_query_result_all);$rc_all++)
								{
							  		if($room_accomodation_query_result_all[$rc_all]->image_href!=null){
							  		?>
						            <li>
						                <img class="img-responsive" src="http://ekups3e.cloudimg.io/s/crop/450x310/<?php echo str_replace("//www","www",$room_accomodation_query_result_all[$rc_all]->image_href);?>">
						            </li>
							  		<?php
							  		}
							  	}

								for($rc_all_1=0;$rc_all_1<count($cruise_dining_options_query_result_all);$rc_all_1++)
								{
						  			if($cruise_dining_options_query_result_all[$rc_all_1]->image_href!=null)
						  			{
						  				$din_image=explode('.', $cruise_dining_options_query_result_all[$rc_all_1]->image_href);
						  				if(in_array('jpeg', $din_image) || in_array('jpg', $din_image) || in_array('JPEG', $din_image) || in_array('JPG', $din_image) || in_array('BMP', $din_image) || in_array('bmp', $din_image) || in_array('gif', $din_image) || in_array('GIF', $din_image) || in_array('png', $din_image) || in_array('PNG', $din_image))
						  				{
						  		?>
									            <li>
									                <img class="img-responsive" src="http://ekups3e.cloudimg.io/s/crop/450x310/<?php echo str_replace("//www","www",$cruise_dining_options_query_result_all[$rc_all_1]->image_href);?>">
									                
									                
									            </li>
						  		<?php
						  				}
						  				$din_image="";
						  			}
						  		}

								for($rc_all_1=0;$rc_all_1<count($cruise_entertainment_options_query_result_all);$rc_all_1++)
								{
						  			if($cruise_entertainment_options_query_result_all[$rc_all_1]->image_href!=null)
						  			{
						  		?>
						            <li>
						                <img class="img-responsive" src="http://ekups3e.cloudimg.io/s/crop/450x310/<?php echo str_replace("//www","www",$cruise_entertainment_options_query_result_all[$rc_all_1]->image_href);?>">
						                
						            </li>
						  		<?php
						  			}
						  		}

								for($rc_all_1=0;$rc_all_1<count($cruise_health_and_fitness_options_query_result_all);$rc_all_1++)
								{
							  		if($cruise_health_and_fitness_options_query_result_all[$rc_all_1]->image_href!=null)
							  		{
							  		?>
							            <li>
							                <img class="img-responsive" src="http://ekups3e.cloudimg.io/s/crop/450x310/<?php echo str_replace("//www","www",$cruise_health_and_fitness_options_query_result_all[$rc_all_1]->image_href);?>">
							                
							            </li>
							  		<?php
							  		}
							  	}

								for($rc_all_1=0;$rc_all_1<count($cruise_enrichment_options_query_result_all);$rc_all_1++)
								{
							  		if($cruise_enrichment_options_query_result_all[$rc_all_1]->image_href!=null)
							  		{
							  		?>
							            <li>
							                <img class="img-responsive" src="http://ekups3e.cloudimg.io/s/crop/450x310/<?php echo str_replace("//www","www",$cruise_enrichment_options_query_result_all[$rc_all_1]->image_href);?>">
							            </li>
							  		<?php
							  		}
							  	}

								for($rc_all_1=0;$rc_all_1<count($cruise_kids_and_teens_options_query_result_all);$rc_all_1++)
								{
							  		if($cruise_kids_and_teens_options_query_result_all[$rc_all_1]->image_href!=null)
							  		{
							  		?>
							            <li>
							                <img class="img-responsive" src="http://ekups3e.cloudimg.io/s/crop/450x310/<?php echo str_replace("//www","www",$cruise_kids_and_teens_options_query_result_all[$rc_all_1]->image_href);?>">
							            </li>
							  		<?php
							  		}
							  	}
				            ?>
				        </ul>
				        <!-- <div class="aroowdown">
				        	<a class="preclick"><i class="fa fa-chevron-left" aria-hidden="true"></i></a>
				        	<a class="nextclcik"><i class="fa fa-chevron-right" aria-hidden="true"></i></a>
				        </div> -->
				    </div>
			    </div>
			</div>

			<!-- Content and Image part Start -->
			<?php
				$basepoke_id_q = $wpdb->get_row("SELECT basepoke_id FROM ".BASEPOKE_CRUISES." WHERE cruise_id = '".$_GET['cruise_id']."' ");
				$basepoke_id = $basepoke_id_q->basepoke_id;
				$cruise_get_quote_extra_offer = "SELECT * FROM ".BASEPOKE_EXTRA_IMAGES." WHERE basepoke_id = '".$basepoke_id."'";
				$quote_result = $wpdb->get_results($cruise_get_quote_extra_offer);
				$quote_result_count = count($quote_result);
				if(!empty($offer_result->content_before_image) || !empty($offer_result->content_after_image) || $quote_result_count > 0 ){
			?>
					<div class="container quote_content">
						<?php if ($offer_result->content_before_image != "") { ?>
							<div class="quote_main_title">
								<?php echo $offer_result->offer_title; ?>
							</div>
						<?php } ?>
						<?php if ($offer_result->content_before_image != "") { ?>
							<div class="content_before_image_new">
								<?php echo $offer_result->content_before_image; ?>
							</div>
						<?php } 
						if ($quote_result_count != "0") 
						{
							?>
						
							<div class="cruise_detail_images_new <?php if(count($quote_result)<4){ echo "les_four_img"; } ?>">
								<div class="slider7">
	  							<?php 
									foreach ($quote_result as $images_val){ ?>
										<div class="slide">
											<img src="<?php echo $images_val->image_url; ?>">
											<!-- <div class="img_title">
												<?php echo $images_val->image_title; ?>
											</div> -->
											<!-- <div class="img_main_caption">
												<div class="img_caption">
													<?php 
														/*$cont = strip_tags($images_val->image_caption);
							                            $pieces = explode(" ", $cont);
							                            $second_part = implode(" ", array_splice($pieces, 0, 3));
							                            echo $second_part;*/
													?>
												</div>
											</div> -->
										</div>
								<?php } ?>
								</div>
							</div>
							<script type="text/javascript">
								jQuery(document).ready(function(){
								  jQuery('.slider7').bxSlider({
								    slideWidth: 250,
								    minSlides: 4,
								    maxSlides: 5,
								    slideMargin: 10
								  });
								});
							</script>
						<?php } ?>
						<?php if ($offer_result->content_after_image != "") { ?>
							<div class="content_after_image_new">
								<?php echo $offer_result->content_after_image; ?>
							</div>
						<?php } ?>
					</div>
				<?php } ?>
			<!-- Content and Image part End -->

			<!-- Tab part start -->

			<div class="container">
				<div class="border-div new_lay">
  				<ul class="nav nav-tabs">
					<li class="active"><a href="#ITINERARY">Itinerary</a></li>
					
					<?php if ($site_detail_result[0]->cruise_introduction != "") { ?>
					<li><a href="#overview">Ship Overview</a></li>
					<?php } if($site_detail_result[0]->cruise_unique_feature != ""){ ?>
					<li><a href="#features">Ship Features</a></li>
					<?php } if($site_detail_result[0]->cruise_video_url != ""){ ?>
					<li><a href="#videos">Ship Videos</a></li>
					<?php } if($site_detail_result[0]->ship_fly_cruise_price != "0" || $site_detail_result[0]->ship_cruise_only_price != "0" || $site_detail_result[0]->ship_inside_price != "0" || $site_detail_result[0]->ship_outside_price != "0" || $site_detail_result[0]->ship_balcony_price != "0" || $site_detail_result[0]->ship_suite_price != "0" ){ ?>
					<li><a href="#prices">Ship Prices</a></li>
					<?php } ?>
				</ul>

  				<div class="tab-content">

				  	<!-- Itinerary start -->
				    <div id="ITINERARY" class="tab-pane fade in active">
				      	<h3>Ship Itinerary</h3>
				      	      	
						<div class="destination clearfix">
							<div class="scroll">
								<div id="map" class="mapit"></div>
									<div class="destination-detail" >
										<div class="clearfix content mCustomScrollbar" style="height:300px;text-align: left;" id="content-1">
											<div class="c-row">
												<div class="c-1">Destination</div>
												<div class="c-2">Arrival</div>
												<div class="c-3">Location</div>
											</div>
											
											<?php
												for($p=0;$p<count($port_result);$p++){
													?>
													<div class="info-row">
														<div class="c-1 f-detail"><?php echo $port_result[$p]->port_name; ?>
															<?php
																$port_code = $port_result[$p]->port_code;
																$p = $p;
																$cruise_id = $_GET[cruise_id];
																
																$port_b_q = "SELECT port_description FROM port_extra_information WHERE port_code = '".$port_code."'";
																$port_b_r = $mydb->get_row($port_b_q);
																if(!empty($port_b_r)){
																?>
																 <i onclick="port_breif(this,'<?php echo $port_code; ?>','<?php echo $cruise_id."_".$p; ?>');" class="fa fa-info additional_info_c"></i>
															<?php } ?>
														</div>
														<div class="c-2 f-detail"><?php $port_arrival=$port_result[$p]->arrives_on; echo date('d M Y',strtotime($port_arrival)); ?></div>
														<div class="c-3 f-detail"><?php echo $port_result[$p]->location; ?></div>
													</div>
													<div class="info-row-details" id="<?php echo $cruise_id."_".$p; ?>"></div>
													<?php
													$loc = $port_result[$p]->port_name;
													$loc_ary = "'".$loc."',".$loc_ary;
												}
											?>
										</div>										
									</div>
							</div>	
							
							<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script> 
							<script type="text/javascript">
								var delay = 100;
								var infowindow = new google.maps.InfoWindow();
								var latlng = new google.maps.LatLng(21.0000, 78.0000);
								var mapOptions = {
									scrollwheel: false,
									navigationControl: true,
									mapTypeControl: true,
									scaleControl: false,
									draggable: false,
									    zoom: 20,
									    center: latlng,
									    mapTypeId: google.maps.MapTypeId.ROADMAP
							  	}
								var geocoder = new google.maps.Geocoder(); 
								var map = new google.maps.Map(document.getElementById("map"), mapOptions);
								var bounds = new google.maps.LatLngBounds();

								function geocodeAddress(address, next) {
									geocoder.geocode({address:address}, function (results,status)
									  { 
									     if (status == google.maps.GeocoderStatus.OK) {
									      var p = results[0].geometry.location;
									      var lat=p.lat();
									      var lng=p.lng();
									      createMarker(address,lat,lng);
									    }
									    else {
									       if (status == google.maps.GeocoderStatus.OVER_QUERY_LIMIT) {
									        nextAddress--;
									        delay++;
									      } else {
									                    }   
									    }
									    next();
									  }
									);
								}
								
								function createMarker(add,lat,lng) {
									var contentString = add;
									var marker = new google.maps.Marker({
									 position: new google.maps.LatLng(lat,lng),
									 map: map,
									       });

									google.maps.event.addListener(marker, 'click', function() {
									 infowindow.setContent(contentString); 
									 infowindow.open(map,marker);
									});

									bounds.extend(marker.position);
								}
								
								var locations = [<?php echo $loc_ary; ?>];
								var nextAddress = 0;
								
								function theNext(){
									if (nextAddress < locations.length)
									{
									  setTimeout('geocodeAddress("'+locations[nextAddress]+'",theNext)', delay);
									  nextAddress++;
									} else
									{
									  map.fitBounds(bounds);
									}
								}
								theNext();
								
								google.maps.event.addListener(map,'click',function() {
									this.setOptions({scrollwheel:false});
									this.setOptions({draggable:true});
									this.setOptions({scaleControl:true});
								});

							</script>

						</div>
						
					</div>
					<!-- Itinerary end -->

					<!-- Overview start -->
					<?php if ($site_detail_result[0]->cruise_introduction != "") { ?>
					    <div id="overview" class="tab-pane fade">
							<h3>Ship Overview</h3>
					      	<?php echo html_entity_decode($site_detail_result[0]->cruise_introduction); ?>
					    </div>
					<?php } ?>
					<!-- Overview end -->

					<!-- Features start -->
				    <div id="features" class="tab-pane fade">
				      	<h3>Ship Features</h3>
						<div class="container">
							<ul class="nav nav-pills nav-stacked col-md-2">
								<?php if($room_accomodation_query_result_all){ ?>
									<li><a href="#cabins" data-toggle="pill">Cabins</a></li>
								<?php } if($site_detail_result[0]->cruise_dining_intro){ ?>
									<li><a href="#dining" data-toggle="pill">Dining</a></li>
								<?php } if($site_detail_result[0]->cruise_entertainment_intro){ ?>
									<li><a href="#entertainment" data-toggle="pill">Entertainment</a></li>
								<?php } if($site_detail_result[0]->cruise_health_and_fitness_intro != ""){ ?>
									<li><a href="#healthfitness" data-toggle="pill">Health & Fitness</a></li>
								<?php } /*if($site_detail_result[0]->cruise_kids_and_teens_intro){ ?>
									<li><a href="#kidsteen" data-toggle="pill">Kids/Teen</a></li>
								<?php }*/ ?>

							</ul>
							<div class="tab-content inner-tab col-md-10">
									<?php if($room_accomodation_query_result_all){ ?>
								        <div class="tab-pane" id="cabins">
								            <h4>CABINS</h4>
								            
								                <?php $count_accomodation = 0;
													for($rc_all=0;$rc_all<count($room_accomodation_query_result_all);$rc_all++){
														if($room_accomodation_query_result_all[$rc_all]->image_href!=null){
															$count_accomodation = $count_accomodation+1;
														}
													}
												?>	

												<div class="dining-detail clearfix">
													<div class="find clearfix">
														<div class="find-nav">
															<?php for($rc=0;$rc<count($room_accomodation_query_result);$rc++){ ?>
																<?php 
																	$rp_name = preg_replace('/[^A-Za-z0-9\-]/', '', $room_accomodation_query_result[$rc]->name);
																?>
																<button type="button" class="btn btn-info" data-toggle="collapse" data-target="#<?php echo str_replace(" ","_",$rp_name); ?>">
																		<?php echo $room_accomodation_query_result[$rc]->name; ?>
																</button>

																<div class="grey-box-2 collapse" id="<?php echo str_replace(" ","_",$rp_name); ?>">
																	<div class="in_box">
																		<h2><?php echo $room_accomodation_query_result[$rc]->name; ?></h2>
																		<div class="clearfix">
																			<?php if($room_accomodation_query_result[$rc]->image_name!=""){ ?>
																				<div class="pen-img">
																					<img title="<?php echo $room_accomodation_query_result[$rc]->name; ?>" src="http://ekups3e.cloudimg.io/s/resize/750/<?php echo str_replace("//www","www",$room_accomodation_query_result[$rc]->image_href); ?>" alt="<?php echo $room_accomodation_query_result[$rc]->image_name; ?>" class="img-responsive">
																					
																					<div class="light_search_icon" data-toggle="modal" data-target=".bd-example-modal-lg1<?php echo $rc; ?>">
																							<i class="fa fa-search-plus" aria-hidden="true"></i>
																					</div>

																					<div class="modal fade bd-example-modal-lg1<?php echo $rc; ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
																						<div class="modal-dialog modal-lg tab_img_new_class">
																						    <div class="modal-content modelimgaselist">
																						    	<div class="modal-header">
																									<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
																									<h4 class="modal-title"><?php echo $room_accomodation_query_result[$rc]->name; ?></h4>
																								</div>
																								<div class="modal-body">
																									<p>
																										<img title="<?php echo $room_accomodation_query_result[$rc]->name; ?>" src="http://ekups3e.cloudimg.io/s/resize/1800/<?php echo str_replace("//www","www",$room_accomodation_query_result[$rc]->image_href); ?>" alt="<?php echo $room_accomodation_query_result[$rc]->image_name; ?>" class="img-responsive">
																									</p>
																								</div>
																						    </div>
																						  </div>
																					</div>
																				</div>
																				<div class="pen-right">
																				<?php } else{ ?>
																					<div class="pen">
																					<?php } ?>
																					<?php echo html_entity_decode($room_accomodation_query_result[$rc]->description); ?>
																					</div>
																				</div>	
																				
																				<div class="clearfix">
																					<div class="type">
																						<?php if($room_accomodation_query_result[$rc]->stats!=""){ echo "<b style='color:#00689B; font-weight: bold;'>STATS</b>"; } ?>
																						<?php echo html_entity_decode($room_accomodation_query_result[$rc]->stats); ?> 
																					</div>
																				</div>
																		</div>							
																	</div>
																	<?php } ?>
																</div>
														</div>
													</div>
								        </div>
								    <?php } if($site_detail_result[0]->cruise_dining_intro){ ?>
							        <div class="tab-pane" id="dining">
							            <h4>DINING</h4>
							            		<?php
													$count_dining = 0;
													for($rc_all=0;$rc_all<count($cruise_dining_options_query_result_all);$rc_all++){
														if($cruise_dining_options_query_result_all[$rc_all]->image_href!=null){
															$count_dining = $count_dining+1;
														}
													}
												?>
												<div class="ship-wrapper">
													<div class="dining-detail clearfix">
														<div class="clearfix">
															<div class="detail-part"></div>
																<?php 
																	$url = $site_detail_result[0]->cruise_dining_video;
																	$step1=explode('/', $url);
																	$vedio_id = $step1[3];
																	if($site_detail_result[0]->cruise_dining_video!="")
																	{ 
																		$headers = get_headers('http://www.youtube.com/oembed?url=http://www.youtube.com/watch?v='.$vedio_id);
																		if (strpos($headers[0], '200')) 
																		{
																		    //echo "The YouTube video you entered does not exist";	
																			?>
																			<div class="vedio-2">
																				<div>
																						<div class="js-lazyYT" data-width="350" data-height="250" data-youtube-id="<?php echo $vedio_id; ?>"></div>
																				</div>
																			</div>
																		<?php 
																		} 
																	}
																?>

														</div>
														<p><?php if($site_detail_result[0]->cruise_dining_intro==""){ echo "-"; } else{ echo html_entity_decode($site_detail_result[0]->cruise_dining_intro); }; ?></p>
													</div>
													<div class="find clearfix">
														<?php
															for($rc=0;$rc<count($cruise_dining_options_query_result);$rc++){
																$din_image=explode('.', $cruise_dining_options_query_result[$rc]->image_href);
																
																if(in_array('jpeg', $din_image) || in_array('jpg', $din_image) || in_array('JPEG', $din_image) || in_array('JPG', $din_image) || in_array('BMP', $din_image) || in_array('bmp', $din_image) || in_array('gif', $din_image) || in_array('GIF', $din_image) || in_array('png', $din_image) || in_array('PNG', $din_image)){
														?>
																	<?php $rp_name = preg_replace('/[^A-Za-z0-9\-]/', '', $cruise_dining_options_query_result[$rc]->name);
																	?>

																	<button type="button" class="btn btn-info" data-toggle="collapse" data-target="#<?php echo str_replace(" ","_",$rp_name); ?>">
																		<?php echo $cruise_dining_options_query_result[$rc]->name; ?>
																	</button>

																	<div class="grey-box-2 collapse" id="<?php echo str_replace(" ","_",$rp_name); ?>">
																		<div class="in_box">
																			<h2><?php echo $cruise_dining_options_query_result[$rc]->name; ?></h2>
																			<div class="clearfix">
																				<?php if($cruise_dining_options_query_result[$rc]->image_name!=""){ ?>
																					<div class="pen-img">
																						<img title="<?php echo $cruise_dining_options_query_result[$rc]->name; ?>" src="http://ekups3e.cloudimg.io/s/resize/750/<?php echo str_replace("//www","www",$cruise_dining_options_query_result[$rc]->image_href); ?>" alt="<?php echo $cruise_dining_options_query_result[$rc]->image_name; ?>" class="img-responsive">
																						
																						<div class="light_search_icon" data-toggle="modal" data-target=".bd-example-modal-lg2<?php echo $rc; ?>">
																							<i class="fa fa-search-plus" aria-hidden="true"></i>
																						</div>

																						<div class="modal fade bd-example-modal-lg2<?php echo $rc; ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
																						  	<div class="modal-dialog modal-lg tab_img_new_class">
																						    	<div class="modal-content modelimgaselist">
																						    		<div class="modal-header">
																										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
																										<h4 class="modal-title"><?php echo $cruise_dining_options_query_result[$rc]->name; ?></h4>
																									</div>
																									<div class="modal-body">
																										<p>
																						      				<img title="<?php echo $cruise_dining_options_query_result[$rc]->name; ?>" src="http://ekups3e.cloudimg.io/s/resize/1800/<?php echo str_replace("//www","www",$cruise_dining_options_query_result[$rc]->image_href); ?>" alt="<?php echo $cruise_dining_options_query_result[$rc]->image_name; ?>" class="img-responsive">
																										</p>
																									</div>
																						    	</div>
																						  	</div>
																						</div>
																					</div>
																					<div class="pen-right">
																						<?php } else{ ?>
																						<div class="pen">
																						<?php } ?>
																						
																						<?php echo html_entity_decode($cruise_dining_options_query_result[$rc]->description); ?>
																						</div>
																					</div>	
																					
																					<div class="clearfix">
																						<div class="type">
																							<?php if($cruise_dining_options_query_result[$rc]->stats!=""){ echo "<b style='color:#00689B; font-weight: bold;'>STATS</b>"; } ?>
																							<?php echo html_entity_decode($cruise_dining_options_query_result[$rc]->stats); ?> 
																						</div>										
																					</div>
																			</div>
																		</div>
																		<?php $din_image=""; } } ?>
																	</div>
													</div>
									</div>
							        <?php } if($site_detail_result[0]->cruise_entertainment_intro){ ?>
							        <div class="tab-pane" id="entertainment">
							            <h4>Entertainment</h4>

															<?php

															$count_entertainment = 0;
															for($rc_all=0;$rc_all<count($cruise_entertainment_options_query_result_all);$rc_all++){
																if($cruise_entertainment_options_query_result_all[$rc_all]->image_href!=null){
																	$count_entertainment = $count_entertainment+1;
																}
															}

															?>	
																										<div class="ship-wrapper">
																												
																												<div class="facility-detail clearfix">
																												
																													<div class="clearfix">

																<?php 
																$url = $site_detail_result[0]->cruise_entertainment_video;
																$step1=explode('/', $url);
																$vedio_id = $step1[3];
																if($site_detail_result[0]->cruise_entertainment_video!="")
																{ 
																	$headers = get_headers('http://www.youtube.com/oembed?url=http://www.youtube.com/watch?v='.$vedio_id);
																	if (strpos($headers[0], '200')) 
																	{
																	    //echo "The YouTube video you entered does not exist";	
																		?>
																		<div class="vedio-2">
																			<div>
																				<div class="js-lazyYT" data-width="350" data-height="250" data-youtube-id="<?php echo $vedio_id; ?>"></div>
																			</div>
																		</div>
																	<?php 
																	} 
																}
																?>

																													</div>
															<?php if($site_detail_result[0]->cruise_entertainment_intro==""){ } else{ echo html_entity_decode($site_detail_result[0]->cruise_entertainment_intro); }; ?>
																												</div>	
																											</div>									
																												<div class="find clearfix">
															<?php
															for($rc=0;$rc<count($cruise_entertainment_options_query_result);$rc++){
																?>
																	<?php $rp_name = preg_replace('/[^A-Za-z0-9\-]/', '', $cruise_entertainment_options_query_result[$rc]->name);
																	?>

																	<button type="button" class="btn btn-info" data-toggle="collapse" data-target="#<?php echo str_replace(" ","_",$rp_name); ?>">
																		<?php echo $cruise_entertainment_options_query_result[$rc]->name; ?>
																	</button>

																	<div class="grey-box-2 collapse" id="<?php echo str_replace(" ","_",$rp_name); ?>">
																		<div class="in_box">
																			<h2><?php echo $cruise_entertainment_options_query_result[$rc]->name; ?></h2>
																			<div class="clearfix">
																				<?php
																				if($cruise_entertainment_options_query_result[$rc]->image_name!=""){
																					?>
																					<div class="pen-img">
																						<img title="<?php echo $cruise_entertainment_options_query_result[$rc]->name; ?>" src="http://ekups3e.cloudimg.io/s/resize/750/<?php echo str_replace("//www","www",$cruise_entertainment_options_query_result[$rc]->image_href); ?>" alt="<?php echo $cruise_entertainment_options_query_result[$rc]->image_name; ?>" class="img-responsive">
																						<div class="light_search_icon" data-toggle="modal" data-target=".bd-example-modal-lg3<?php echo $rc; ?>">
																							<i class="fa fa-search-plus" aria-hidden="true"></i>
																						</div>

																						<div class="modal fade bd-example-modal-lg3<?php echo $rc; ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
																						  <div class="modal-dialog modal-lg tab_img_new_class">
																						    <div class="modal-content modelimgaselist">
																						    	<div class="modal-header">
																									<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
																									<h4 class="modal-title"><?php echo $cruise_entertainment_options_query_result[$rc]->name; ?></h4>
																								</div>
																								<div class="modal-body">
																									<p>
																						      		<img title="<?php echo $cruise_entertainment_options_query_result[$rc]->name; ?>" src="http://ekups3e.cloudimg.io/s/resize/1800/<?php echo str_replace("//www","www",$cruise_entertainment_options_query_result[$rc]->image_href); ?>" alt="<?php echo $cruise_entertainment_options_query_result[$rc]->image_name; ?>" class="img-responsive">
																									</p>
																								</div>
																						    </div>
																						  </div>
																						</div>

																					</div>
																					<div class="pen-right">
																					<?php
																				}
																				else{
																					?>
																					<div class="pen">
																					<?php
																				}
																				?>
																					<?php echo html_entity_decode($cruise_entertainment_options_query_result[$rc]->description); ?>
																				</div>
																			</div>	
																			<div class="clearfix">
																				<div class="type">
																					<?php if($cruise_entertainment_options_query_result[$rc]->stats!=""){ echo "<b style='color:#00689B; font-weight: bold;'>STATS</b>"; } ?>
																					<?php echo html_entity_decode($cruise_entertainment_options_query_result[$rc]->stats); ?> 
																				</div>												
																			</div>													
																		</div>								
																	</div>
																<?php
															}
															?>
																												</div>
							        </div>
							        <?php } if($site_detail_result[0]->cruise_health_and_fitness_intro != ""){ ?>
							        <div class="tab-pane" id="healthfitness">
							            <h4>Health & Fitness</h4>
							            
															<?php

															$count_health = 0;
															for($rc_all=0;$rc_all<count($cruise_health_and_fitness_options_query_result_all);$rc_all++){
																if($cruise_health_and_fitness_options_query_result_all[$rc_all]->image_href!=null){
																	$count_health = $count_health+1;
																}
															}

															if($count_health>1){
																/*
															?>										    	
															<div class="content-slider">
																<div id="slider-example-generic4" class="carousel slide" data-ride="carousel">
																  <!-- Indicators -->
																  <ol class="carousel-indicators">
																  	<?php
																  	$ih = 0;
																  	for($rc_all=0;$rc_all<count($cruise_health_and_fitness_options_query_result_all);$rc_all++){
																  		if($cruise_health_and_fitness_options_query_result_all[$rc_all]->image_href!=null){
																  		$ih++;
																  		?>
																  		<li title="<?php echo $cruise_health_and_fitness_options_query_result_all[$rc_all]->name; ?>" data-target="#slider-example-generic4" data-slide-to="<?php echo $rc_all; ?>" <?php if($ih=="1"){ echo 'class="active"'; } ?> ></li>
																  		<?php
																  		}
																  	}
																  	?>
																  </ol>

																  <!-- Wrapper for slides -->
																  <div class="carousel-inner" role="listbox">
																    <?php
																  	$ih = 0;
																    for($rc_all=0;$rc_all<count($cruise_health_and_fitness_options_query_result_all);$rc_all++){
																  		if($cruise_health_and_fitness_options_query_result_all[$rc_all]->image_href!=null){
																  		$ih++;
																    	?>
																    	    <div class="item <?php if($ih=="1"){ echo "active"; } ?>" >
																    	      <a href="#<?php echo str_replace(" ","_",$cruise_health_and_fitness_options_query_result_all[$rc_all]->name); ?>">
																		      <img title="<?php echo $cruise_health_and_fitness_options_query_result_all[$rc_all]->name; ?>" src="http://ekups3e.cloudimg.io/s/resize/750/<?php echo $cruise_health_and_fitness_options_query_result_all[$rc_all]->image_href; ?>" alt="<?php echo $cruise_health_and_fitness_options_query_result_all[$rc_all]->image_name; ?>" class="img-responsive">
																		      </a>
																		    </div>
																    	<?php
																   		}
																    }
																    ?>								    
																  </div>

																  <!-- Controls -->
																  <a class="left carousel-control" href="#slider-example-generic4" role="button" data-slide="prev">
																    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
																    <span class="sr-only">Previous</span>
																  </a>
																  <a class="right carousel-control" href="#slider-example-generic4" role="button" data-slide="next">
																    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
																    <span class="sr-only">Next</span>
																  </a>
																</div>													
															</div>	
															<?php
															*/
															}
															?>	
																										<div class="ship-wrapper">
																									    	<div class="facility-detail clearfix">
																												
																											<div class="clearfix">

																<?php 
																$url = $site_detail_result[0]->cruise_health_and_fitness_video;
																$step1=explode('/', $url);
																$vedio_id = $step1[3];
																if($site_detail_result[0]->cruise_health_and_fitness_video!="")
																{ 
																	$headers = get_headers('http://www.youtube.com/oembed?url=http://www.youtube.com/watch?v='.$vedio_id);
																	if (strpos($headers[0], '200')) 
																	{
																	    //echo "The YouTube video you entered does not exist";	
																		?>
																	<div class="vedio-2">
																		<div>
																			<div class="js-lazyYT" data-width="350" data-height="250" data-youtube-id="<?php echo $vedio_id; ?>"></div>
																		</div>
																	</div>
																<?php
																	}
																} 
																?>

																													</div>
															<?php if($site_detail_result[0]->cruise_health_and_fitness_intro==""){ } else{ echo html_entity_decode($site_detail_result[0]->cruise_health_and_fitness_intro); }; ?>
																												</div>	
																											</div>									
																												<div class="find clearfix">
															<?php
															for($rc=0;$rc<count($cruise_health_and_fitness_options_query_result);$rc++){
																?>
																	<?php 
																		$rp_name = preg_replace('/[^A-Za-z0-9\-]/', '', $cruise_health_and_fitness_options_query_result[$rc]->name);
																	?>
																	<button type="button" class="btn btn-info" data-toggle="collapse" data-target="#<?php echo str_replace(" ","_",$rp_name); ?>">
																		<?php echo $cruise_health_and_fitness_options_query_result[$rc]->name; ?>
																	</button>

																	<div class="grey-box-2 collapse" id="<?php echo str_replace(" ","_",$rp_name); ?>">
																		<div class="in_box">
																			<h2><?php echo $cruise_health_and_fitness_options_query_result[$rc]->name; ?></h2>
																			<div class="clearfix">
																				<?php
																				if($cruise_health_and_fitness_options_query_result[$rc]->image_name!=""){
																					?>
																					<div class="pen-img">
																						<img title="<?php echo $cruise_health_and_fitness_options_query_result[$rc]->name; ?>" src="http://ekups3e.cloudimg.io/s/resize/750/<?php echo str_replace("//www","www",$cruise_health_and_fitness_options_query_result[$rc]->image_href); ?>" alt="<?php echo $cruise_health_and_fitness_options_query_result[$rc]->image_name; ?>" class="img-responsive">
																						<div class="light_search_icon" data-toggle="modal" data-target=".bd-example-modal-lg4<?php echo $rc; ?>">
																							<i class="fa fa-search-plus" aria-hidden="true"></i>
																						</div>

																						<div class="modal fade bd-example-modal-lg4<?php echo $rc; ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
																						  <div class="modal-dialog modal-lg tab_img_new_class">
																						    <div class="modal-content modelimgaselist">
																						    	<div class="modal-header">
																									<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
																									<h4 class="modal-title"><?php echo $cruise_health_and_fitness_options_query_result[$rc]->name; ?></h4>
																								</div>
																								<div class="modal-body">
																									<p>
																						      <img title="<?php echo $cruise_health_and_fitness_options_query_result[$rc]->name; ?>" src="http://ekups3e.cloudimg.io/s/resize/1800/<?php echo str_replace("//www","www",$cruise_health_and_fitness_options_query_result[$rc]->image_href); ?>" alt="<?php echo $cruise_health_and_fitness_options_query_result[$rc]->image_name; ?>" class="img-responsive">
																									</p>
																								</div>
																						    </div>
																						  </div>
																						</div>

																					</div>
																					<div class="pen-right">
																					<?php
																				}
																				else{
																					?>
																					<div class="pen">
																					<?php
																				}
																				?>
																					<?php echo html_entity_decode($cruise_health_and_fitness_options_query_result[$rc]->description); ?>
																				</div>
																			</div>	
																			<div class="clearfix">
																				<div class="type">
																					<?php if($cruise_health_and_fitness_options_query_result[$rc]->stats!=""){ echo "<b style='color:#00689B; font-weight: bold;'>STATS</b>"; } ?>
																					<?php echo html_entity_decode($cruise_health_and_fitness_options_query_result[$rc]->stats); ?> 
																				</div>												
																			</div>													
																		</div>								
																	</div>
																<?php
															}
															?>
																												</div>
																									    
							        </div>
							        <?php } ?>
							</div><!-- tab content -->
						</div><!-- end of container -->
				    </div>
				    <!-- Features end -->
    
				    <!-- Prices start -->
					<div id="prices" class="tab-pane fade">
				    	<h3>Ship Prices</h3>
				    	<?php
				    		$up_dir = wp_upload_dir();
			    			$up_dir = $up_dir[baseurl];
				    	?>
				    	<div class="cr-prices">
				    		<?php if ($site_detail_result[0]->ship_fly_cruise_price != "0") { ?>
					    		<div class="cr-price-list">
					    			<div class="cr-price-image">
						    			<img src="<?php echo $up_dir; ?>/2016/03/back1-1.png">
						    		</div>
						    		<div class="cr-price-name">Fly Cruise Price</div>
						    		<div class="cr-price-amount"><?php echo "£".$site_detail_result[0]->ship_fly_cruise_price; ?></div>
						    		<div class="cr-price-button">
						    			<!-- <input type="submit"> -->
						    			<button type="button" class="btn btn-primary btn-lg manual_model_slide modal-test" id="manual_model_slide" data-toggle="modal" data-target="#slide_down_div" cuiseid="<?php echo $select_ship[$i]->a; ?>">ENQUIRY</button>
						    		</div>
						    	</div>
						   	<?php } ?>
						   	<?php if ($site_detail_result[0]->ship_cruise_only_price != "0") { ?>
						    	<div class="cr-price-list">
						    		<div class="cr-price-image">
						    			<img src="<?php echo $up_dir; ?>/2016/03/back1-1.png">
						    		</div>
						    		<div class="cr-price-name">Cruise Only Price</div>
						    		<div class="cr-price-amount"><?php echo "£".$site_detail_result[0]->ship_cruise_only_price; ?></div>
						    		<div class="cr-price-button">
						    			<!-- <input type="submit"> -->
						    			<button type="button" class="btn btn-primary btn-lg manual_model_slide modal-test" id="manual_model_slide" data-toggle="modal" data-target="#slide_down_div" cuiseid="<?php echo $select_ship[$i]->a; ?>">ENQUIRY</button>
						    		</div>
						    	</div>
					    	<?php } ?>
					    	<?php if ($site_detail_result[0]->ship_inside_price != "0") { ?>
						    	<div class="cr-price-list">
						    		<div class="cr-price-image">
						    			<img src="<?php echo $up_dir; ?>/2016/03/back1-1.png">
						    		</div>
						    		<div class="cr-price-name">Cruise Inside Price</div>
						    		<div class="cr-price-amount"><?php echo "£".$site_detail_result[0]->ship_inside_price; ?></div>
						    		<div class="cr-price-button">
						    			<!-- <input type="submit"> -->
						    			<button type="button" class="btn btn-primary btn-lg manual_model_slide modal-test" id="manual_model_slide" data-toggle="modal" data-target="#slide_down_div" cuiseid="<?php echo $select_ship[$i]->a; ?>">ENQUIRY</button>
						    		</div>
						    	</div>
					    	<?php } ?>
					    	<?php if ($site_detail_result[0]->ship_outside_price != "0") { ?>
						    	<div class="cr-price-list">
						    		<div class="cr-price-image">
						    			<img src="<?php echo $up_dir; ?>/2016/03/back1-1.png">
						    		</div>
						    		<div class="cr-price-name">Cruise Outside Price</div>
						    		<div class="cr-price-amount"><?php echo "£".$site_detail_result[0]->ship_outside_price; ?></div>
						    		<div class="cr-price-button">
						    			<!-- <input type="submit"> -->
						    			<button type="button" class="btn btn-primary btn-lg manual_model_slide modal-test" id="manual_model_slide" data-toggle="modal" data-target="#slide_down_div" cuiseid="<?php echo $select_ship[$i]->a; ?>">ENQUIRY</button>
						    		</div>
						    	</div>
					    	<?php } ?>
					    	<?php if ($site_detail_result[0]->ship_balcony_price != "0") { ?>
						    	<div class="cr-price-list">
						    		<div class="cr-price-image">
						    			<img src="<?php echo $up_dir; ?>/2016/03/back1-1.png">
						    		</div>
						    		<div class="cr-price-name">Cruise Balcony Price</div>
						    		<div class="cr-price-amount"><?php echo "£".$site_detail_result[0]->ship_balcony_price; ?></div>
						    		<div class="cr-price-button">
						    			<!-- <input type="submit"> -->
						    			<button type="button" class="btn btn-primary btn-lg manual_model_slide modal-test" id="manual_model_slide" data-toggle="modal" data-target="#slide_down_div" cuiseid="<?php echo $select_ship[$i]->a; ?>">ENQUIRY</button>
						    		</div>
						    	</div>
					    	<?php } ?>
					    	<?php if ($site_detail_result[0]->ship_suite_price != "0") { ?>
						    	<div class="cr-price-list">
						    		<div class="cr-price-image">
						    			<img src="<?php echo $up_dir; ?>/2016/03/back1-1.png">
						    		</div>
						    		<div class="cr-price-name">Cruise Suite Price</div>
						    		<div class="cr-price-amount"><?php echo "£".$site_detail_result[0]->ship_suite_price; ?></div>
						    		<div class="cr-price-button">
						    			<!-- <input type="submit"> -->
						    			<button type="button" class="btn btn-primary btn-lg manual_model_slide modal-test" id="manual_model_slide" data-toggle="modal" data-target="#slide_down_div" cuiseid="<?php echo $select_ship[$i]->a; ?>">ENQUIRY</button>
						    		</div>
						    	</div>
					    	<?php } ?>
				    	</div>
				   	</div>
				   	<!-- Prices end -->

				    <!-- Videos start -->
				    <div id="videos" class="tab-pane fade">
				      <h3>Ship Videos</h3>
				      <?php 
							$url = $site_detail_result[0]->cruise_video_url;
							$step1=explode('v=', $url);
							$step2 =explode('&',$step1[1]);
							//print_r($step2);
							if(empty($step2[0])){
								//echo "dfgjdkgj";
								$url = $site_detail_result[0]->cruise_video_url;
								$step1=explode('/', $url);
								//print_r($step1);
								$vedio_id = $step1[3];
							}
							else{
								$vedio_id = $step2[0];
							}
							if($site_detail_result[0]->cruise_video_url!="")
							{ 
								$headers = get_headers('http://www.youtube.com/oembed?url=http://www.youtube.com/watch?v='.$vedio_id);
								if (strpos($headers[0], '200')) 
								{
								    //echo "The YouTube video you entered does not exist";	
									?>
									<div class="vedio">
										<div class="js-lazyYT" data-width="350" data-height="250" data-youtube-id="<?php echo $vedio_id; ?>"></div>
									</div>
									<div class="setleftaligndata" >
									<?php 
								} 
								else
								{
								?>
									<div class="setleftaligndata" style="width:100%;padding-left:0;">
								<?php
								}
							}
							else
							{
							?>
								<div class="setleftaligndata" style="width:100%;padding-left:0;">
							<?php
							}
						?>
				    </div>
				    <!-- Videos end -->
				</div>
				</div>
				<div class="full_a">
				<a href="<?php echo esc_url(home_url('/')); ?>" class="cruise">BACK TO CRUISE LIST</a>
				</div>
			</div>

			<!-- Tab part end -->


		</div>
		</div>

		<script type="text/javascript">
			jQuery(document).ready(function(){
				
				jQuery(".find-nav button.btn-info").click(function(){
					jQuery(".find-nav button.btn-info").attr("aria-expanded", "false");
					jQuery('.grey-box-2').removeClass('in');
				});

				jQuery(".find button.btn-info").click(function(){
					jQuery(".find button.btn-info").attr("aria-expanded", "false");
					jQuery('.grey-box-2').removeClass('in');
				});

				jQuery('.find-nav .btn-info').click(function(){
    				
				});
				
				jQuery(".nav-pills li:first-child").addClass("active");
				jQuery(".tab-content .tab-pane:first-child").addClass("active");
				
				jQuery(".nav-tabs a").click(function(e){
					e.preventDefault();
					jQuery(this).tab('show');
			    });
			    jQuery(".nav-pills a").click(function(e){
			    	jQuery(".tab-content.col-md-10 div.tab-pane").css("display","none");
			    	var Tbhref = jQuery(this).attr("href");
			    	jQuery(".tab-content.col-md-10 div"+Tbhref).css("display","block");
				});
				jQuery(".nav-tabs li a").click(function(e){
					jQuery(".tab-content .tab-pane").css("display","none");
			    	var Tbhref = jQuery(this).attr("href");
			    	jQuery(".tab-content div"+Tbhref).css("display","block");

			    	var hrefval = jQuery(this).attr('href');
			    	if (hrefval == "#features") {
			    		jQuery("#features .container .inner-tab .tab-pane:first-child").css("display","block");
			    	}
				});
			});
		</script>
		
		<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/lazyYT.js"></script>
        
        <script type="text/javascript">
	        jQuery( document ).ready(function() {
	            jQuery('.js-lazyYT').lazyYT();
	            
	            // Pass some parameters
	            jQuery('.js-lazyYT').lazyYT({
	              loading_text: 'It is loading!...',
	              default_ratio: '16:9'
	            });

	            var ope_one_name = jQuery("#Cruiseline_Left ul.operator_name li:first-child").text();
	            jQuery('.loader').css('display','block');
				jQuery.ajax({
		            type: "POST",
		            url: ('<?php echo admin_url( 'admin-ajax.php' ); ?>'),
		            data: ({
		                action: 'iflair_get_operator',
		                opet_name: ope_one_name,
		            }),
		            success: function (response) {
		               jQuery('.container #Cruiseline_Right').html(response);
		               jQuery('.loader').css('display','none');
		            }
		        });
	        });

	        function iflair_operator(str){
	        	jQuery('.loader').css('display','block');
				jQuery.ajax({
		            type: "POST",
		            url: ('<?php echo admin_url( 'admin-ajax.php' ); ?>'),
		            data: ({
		                action: 'iflair_get_operator',
		                opet_name: str,
		            }),
		            success: function (response) {
		               jQuery('.container #Cruiseline_Right').html(response);
		               jQuery('.loader').css('display','none');
		            }
		        });
			}

		    jQuery('#deck_click').click(function() {
				setTimeout(
	            function() {
			        //var divid = image_deck_0;
			        //var dividsplit = divid.split("_")
			        var pic1 = jQuery('#image_deck_0 img');
					var w1 = pic1.width()+220;
					jQuery('#image_deck_0 img').css('bottom','-'+w1+'px');
					jQuery('#image_deck_0 img').addClass('bottomw');
					jQuery( "#deck_0" ).trigger( "click" );
					//alert(pic1);
					jQuery(".image_main_taber").show();
	            },
	            1000);
			});

			function iflair_detail_search_filter(str){
				var pagenumb='1';
				var check = str;
				var region = jQuery('#cruise_region').val();
				var operator = jQuery('#cruise_operator').val();
				var cruise_ship = jQuery('#cruise_ship').val();
				var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
				var leaving_from = jQuery('#cruise_leaving_from').val();
				var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
				var ship_vacation_days = jQuery('#cruise_ship_vacation_days').val();
				
				if(check=="reset"){
					jQuery('#cruise_region').prop('selectedIndex',0);
					jQuery('#cruise_operator').prop('selectedIndex',0);
					jQuery('#cruise_ship').prop('selectedIndex',0);
					jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
					jQuery('#cruise_leaving_from').prop('selectedIndex',0);
					jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
					jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);
			    	jQuery('.loader_filt').css('display','block');

					jQuery.cookie('str1', '', {expires: 1 });
					jQuery.cookie('str2', '', {expires: 1 });

					return false;
				}
				if(check=="region"){
					jQuery('#cruise_operator').prop('selectedIndex',0);
					jQuery('#cruise_ship').prop('selectedIndex',0);
					jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
					jQuery('#cruise_leaving_from').prop('selectedIndex',0);
					jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
					jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);
			    jQuery('.loader_filt').css('display','block');
						//iflair_detail_search_filter();
				}
				if(check=="operator"){
					jQuery('#cruise_ship').prop('selectedIndex',0);
					jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
					jQuery('#cruise_leaving_from').prop('selectedIndex',0);
					jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
					jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);
			    jQuery('.loader_filt').css('display','block');
						//iflair_detail_search_filter();
				}
				if(check=="cruise_ship"){
					jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
					jQuery('#cruise_leaving_from').prop('selectedIndex',0);
					jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
					jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);
			    jQuery('.loader_filt').css('display','block');
						//iflair_detail_search_filter();
				}
				if(check=="ship_fly_in"){
					jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
					jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);
			    jQuery('.loader_filt').css('display','block');
						//iflair_detail_search_filter();
				}
				if(check=="leaving_from"){
					jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
					jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);
			    jQuery('.loader_filt').css('display','block');
						//iflair_detail_search_filter();
				}
				if(check=="ship_starts_on"){
					jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);
			    jQuery('.loader_filt').css('display','block');
						//iflair_detail_search_filter();
				}
				if(check=="ship_vacation_days"){
						//iflair_detail_search_filter();
			    jQuery('.loader_filt').css('display','block');
				}
				if(check=="search"){

					jQuery.cookie('str1', '', {expires: 1 });
					jQuery.cookie('str2', '', {expires: 1 });

					var width_res = jQuery(".header").width();
					if(width_res<768){
						jQuery('.input-form.wrraper').slideToggle();
					}
					jQuery('.loader').css('display','block');
					jQuery('.search_header').addClass('searched');
					jQuery('.search_header').addClass('searched_image');
					jQuery('#replace_query_ajax').addClass('replace_query_class');
				}
				//alert(str);
				jQuery.ajax({
			        type: "POST",
			        url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
			        data: ({
			            action: 'iflair_detail_search_filter_response',
			            region: region,
			            operator: operator,
			            cruise_ship: cruise_ship,
			            ship_fly_in: ship_fly_in,
			            leaving_from: leaving_from,
			            ship_starts_on: ship_starts_on,
			            ship_vacation_days: ship_vacation_days
			        }),
			        success: function (response) {
			            jQuery('.form-field-cruise').html(response);
			        	jQuery('.loader_filt').css('display','none');
			        }
			    });
	    		//cruise_filter();
			}

			/* new tabing */
			jQuery(document).ready(function(){
				jQuery(".tab-pane").slideUp();
				jQuery(".tab-pane.active").slideDown();
				/*jQuery(".nav-tabs").click(function(){
					
					if(jQuery(this).next().hasClass("active")){
						jQuery(this).next().slideUp();
						jQuery(this).next().removeClass("active");
						jQuery(this).removeClass("active_detail");
					}
					else{
						jQuery(".nav-tabs").next().slideUp();
						jQuery(".nav-tabs").next().removeClass("active");
						jQuery(".nav-tabs li").removeClass("active");
						jQuery(".nav-tabs").removeClass("active_detail");
						jQuery(this).next().delay(500).slideDown();
						jQuery(this).next().addClass("active");	
						jQuery(this).addClass("active_detail");
					}
				});*/
				/*jQuery(".preclick").click(function(){
					jQuery( "#lightgallery img" ).trigger( "click" );
				});
				jQuery(".nextclcik").click(function(){
					jQuery( "#lightgallery img" ).trigger( "click" );
				});
				jQuery(".show_img_gallery").click(function(){
					jQuery( "#lightgallery img" ).trigger( "click" );
				});*/
					
					jQuery('.form-field').css('border','none');
					var pageNum = 1;
					<?php if(isset($_GET['cruise_region'])){ ?>;
					var region = "<?php echo $_GET['cruise_region']; ?>";
					<?php }else{ ?>
					var region = "";
					<?php } ?>
					<?php if(isset($my_selected_operator)){ ?>;
					var operator = "<?php echo $my_selected_operator; ?>";
					<?php }else{ ?>
					var operator = "";
					<?php } ?>
					<?php if(isset($_GET['cruise_ship'])){ ?>;
					var cruise_ship = "<?php echo $_GET['cruise_ship']; ?>";
					<?php }else{ ?>
					var cruise_ship = "";
					<?php } ?>
					<?php if(isset($_GET['cruise_ship_fly_in'])){ ?>;
					var ship_fly_in = "<?php echo $_GET['cruise_ship_fly_in']; ?>";
					<?php }else{ ?>
					var ship_fly_in = "";
					<?php } ?>
					<?php if(isset($_GET['cruise_ship_starts_on'])){ ?>;
					var ship_starts_on = "<?php echo $_GET['cruise_ship_starts_on']; ?>";
					<?php }else{ ?>
					var ship_starts_on = "";
					<?php } ?>
					<?php if(isset($_GET['cruise_ship_vacation_days'])){ ?>;
					var ship_vacation_days = "<?php echo $_GET['cruise_ship_vacation_days']; ?>";
					<?php }else{ ?>
					var ship_vacation_days = "";
					<?php } ?>
				    jQuery.ajax({
			            type: "POST",
			            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
			            data: ({
			                action: 'iflair_detail_search_filter_response',
				            region: region,
				            operator: operator,
				            cruise_ship: cruise_ship,
				            ship_fly_in: ship_fly_in,
				            ship_starts_on: ship_starts_on,
				            ship_vacation_days: ship_vacation_days,
			                pagenumb:pageNum
			            }),
			            success: function (response) {
			            	jQuery('.loader').css('display','none');
			                jQuery('.form-field').html(response);
							jQuery('.form-field').css('border','1px solid rgb(185, 181, 181)');
			            }
			        });
			});
		</script>
		
		<script type="text/javascript">
			jQuery(document).ready(function (){
				var cal_val = jQuery(".desktop_view .callhere ").html();
				//alert(cal_val);
				jQuery(".HeaderText .tel a").html(cal_val);
				jQuery(".callhere ").html(cal_val);
				jQuery(".callanswer .callme").attr("href","tel:"+cal_val);
				jQuery(".mobile_view .callhere").attr("href","tel:"+cal_val);
				jQuery(".calandmail a:first-child").attr("href","tel:"+cal_val);
				jQuery(".calandmail a:first-child ").html(cal_val);
			});
		</script>

<?php } get_footer(); ?>