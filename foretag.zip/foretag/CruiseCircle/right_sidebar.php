
    <?php $listing_page_id = get_site_option( 'iflair_cruise_theme_ship_listing_page' );?>
    <div class="sidebar_filter">
        <form action="<?php echo get_page_link($listing_page_id); ?>" name="detail_search" id="detail_search" method="get" class="form-field form-field-cruise" style="display: inline-table;" >           
        <img style="position: relative; width: auto; background: transparent none repeat scroll 0% 0%; margin: 10px auto; padding: 0px;" src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader_1.gif" class="loader">
            
        </form>
    </div>
    <div class="sidebar_filter_offer sidebar_filter"></div>
    <div role="complementary" class="sidebar-container" id="tertiary">
        <div class="sidebar-inner">
            <div class="box_image">
                <?php
                if ( is_active_sidebar( 'newsletter' ) ) : ?>
                    <?php dynamic_sidebar( 'newsletter' ); ?>
                <?php endif; ?>
            </div>
        </div><!-- .sidebar-inner -->
    </div><!-- #tertiary -->
<script>

jQuery( document ).ready(function() {


function iflair_detail_search_filter(str){
    var pagenumb='1';
    var check = str;
    var region = jQuery('#cruise_region').val();
    var operator = jQuery('#cruise_operator').val();
    var cruise_ship = jQuery('#cruise_ship').val();
    var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
    var leaving_from = jQuery('#cruise_leaving_from').val();
    var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
    var ship_cruise_nights = jQuery('#cruise_ship_cruise_nights').val();
    if(check=="reset"){
        jQuery('#cruise_region').prop('selectedIndex',0);
        jQuery('#cruise_operator').prop('selectedIndex',0);
        jQuery('#cruise_ship').prop('selectedIndex',0);
        jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
        jQuery('#cruise_leaving_from').prop('selectedIndex',0);
        jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
        jQuery('.loader_filt').css('display','block');

        jQuery.cookie('str1', '', {expires: 1 });
        jQuery.cookie('str2', '', {expires: 1 });

        return false;
    }
    if(check=="region"){
        jQuery('#cruise_operator').prop('selectedIndex',0);
        jQuery('#cruise_ship').prop('selectedIndex',0);
        jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
        jQuery('#cruise_leaving_from').prop('selectedIndex',0);
        jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
            //iflair_detail_search_filter();
    }
    if(check=="operator"){
        jQuery('#cruise_ship').prop('selectedIndex',0);
        jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
        jQuery('#cruise_leaving_from').prop('selectedIndex',0);
        jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
            //iflair_detail_search_filter();
    }
    if(check=="cruise_ship"){
        jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
        jQuery('#cruise_leaving_from').prop('selectedIndex',0);
        jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
            //iflair_detail_search_filter();
    }
    if(check=="ship_fly_in"){
        jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
            //iflair_detail_search_filter();
    }
    if(check=="leaving_from"){
        jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
            //iflair_detail_search_filter();
    }
    if(check=="ship_starts_on"){
        jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
            //iflair_detail_search_filter();
    }
    if(check=="ship_cruise_nights"){
            //iflair_detail_search_filter();
    jQuery('.loader_filt').css('display','block');
    }
    if(check=="search"){

        jQuery.cookie('str1', '', {expires: 1 });
        jQuery.cookie('str2', '', {expires: 1 });

        /*if(region==""){
            jQuery('#cruise_region').focus();
            alert("Where do you want to go?");
            return false;
        }
        if(operator==""){
            jQuery('#cruise_operator').focus();
            alert("Who would you like to Cruise with?");
            return false;
        }*/
        var width_res = jQuery(".header").width();
        if(width_res<768){
            jQuery('.input-form.wrraper').slideToggle();
        }
        jQuery('.loader').css('display','block');
        jQuery('.search_header').addClass('searched');
        jQuery('.search_header').addClass('searched_image');
        jQuery('#replace_query_ajax').addClass('replace_query_class');
        //cruise_filter();
    }
    //alert(str);
    jQuery.ajax({
        type: "POST",
        url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
        data: ({
            action: 'iflair_detail_search_filter_response',
            region: region,
            operator: operator,
            cruise_ship: cruise_ship,
            ship_fly_in: ship_fly_in,
            leaving_from: leaving_from,
            ship_starts_on: ship_starts_on,
            ship_cruise_nights: ship_cruise_nights
        }),
        success: function (response) {
            //jQuery('.loader').css('display','none');
            jQuery('.loader_filt').css('display','none');
            //alert(response);
            jQuery('.form-field-cruise').html(response);
        }
    });
    //cruise_filter();
}

/* new tabing */
jQuery(document).ready(function(){
    jQuery(".tab-pane").slideUp();
    jQuery(".tab-pane.active").slideDown();
    jQuery(".nav-tabs").click(function(){
        //alert("1");
        if(jQuery(this).next().hasClass("active")){
            //alert("2");
            jQuery(this).next().slideUp();
            jQuery(this).next().removeClass("active");
            jQuery(this).removeClass("active_detail");
/*
            var tab_height = jQuery(this).position().top;
            jQuery('html, body').animate({scrollTop:tab_height}, 'slow');*/
        }
        else{
            //alert("3");
            jQuery(".nav-tabs").next().slideUp();
            jQuery(".nav-tabs").next().removeClass("active");
            jQuery(".nav-tabs li").removeClass("active");
            jQuery(".nav-tabs").removeClass("active_detail");
            jQuery(this).next().delay(500).slideDown();
            jQuery(this).next().addClass("active"); 
            jQuery(this).addClass("active_detail");
/*
            var tab_height = jQuery(this).position().top;
            alert(tab_height);
            jQuery('html, body').animate({scrollTop:tab_height}, 'slow');*/
        }
    });
    jQuery(".preclick").click(function(){
        jQuery( "#lightgallery img" ).trigger( "click" );
    });
    jQuery(".nextclcik").click(function(){
        jQuery( "#lightgallery img" ).trigger( "click" );
    });
    jQuery(".show_img_gallery").click(function(){
        jQuery( "#lightgallery img" ).trigger( "click" );
    });
        
        //jQuery('.form-field').css('border','none');
        var pageNum = 1;
        <?php if(isset($_GET['cruise_region'])){ ?>;
        var region = "<?php echo $_GET['cruise_region']; ?>";
        <?php }else{ ?>
        var region = "";
        <?php } ?>
        <?php if(isset($my_selected_operator)){ ?>;
        var operator = "<?php echo $my_selected_operator; ?>";
        <?php }else{ ?>
        var operator = "";
        <?php } ?>
        <?php if(isset($_GET['cruise_ship'])){ ?>;
        var cruise_ship = "<?php echo $_GET['cruise_ship']; ?>";
        <?php }else{ ?>
        var cruise_ship = "";
        <?php } ?>
        <?php if(isset($_GET['cruise_ship_fly_in'])){ ?>;
        var ship_fly_in = "<?php echo $_GET['cruise_ship_fly_in']; ?>";
        <?php }else{ ?>
        var ship_fly_in = "";
        <?php } ?>
        <?php if(isset($_GET['cruise_ship_starts_on'])){ ?>;
        var ship_starts_on = "<?php echo $_GET['cruise_ship_starts_on']; ?>";
        <?php }else{ ?>
        var ship_starts_on = "";
        <?php } ?>
        <?php if(isset($_GET['cruise_ship_cruise_nights'])){ ?>;
        var ship_cruise_nights = "<?php echo $_GET['cruise_ship_cruise_nights']; ?>";
        <?php }else{ ?>
        var ship_cruise_nights = "";
        <?php } ?>
        jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'iflair_detail_search_filter_response',
                region: region,
                operator: operator,
                cruise_ship: cruise_ship,
                ship_fly_in: ship_fly_in,
                ship_starts_on: ship_starts_on,
                ship_cruise_nights: ship_cruise_nights,
                pagenumb:pageNum
            }),
            success: function (response) {
                jQuery('.loader').css('display','none');
                jQuery('.form-field').html(response);
                //jQuery('.form-field').css('border','1px solid rgb(185, 181, 181)');
            }
        });


});
});

</script>