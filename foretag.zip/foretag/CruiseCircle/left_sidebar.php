
    <div role="complementary" class="sidebar-container" id="tertiary">
        <div class="sidebar-inner">
            <div class="box_image">
                <?php
                if ( is_active_sidebar( 'newsletter' ) ) : ?>
                    <?php dynamic_sidebar( 'newsletter' ); ?>
                <?php endif; ?>
            </div>
        </div><!-- .sidebar-inner -->
    </div><!-- #tertiary -->
