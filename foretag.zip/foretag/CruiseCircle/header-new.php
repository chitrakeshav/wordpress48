<?php
/**
 * The Header for our theme
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */
?><!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, user-scalable=no" />
	<title><?php wp_title( '|', true, 'right' ); ?></title>
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<!--[if lt IE 9]>
	<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js"></script>
	<![endif]-->
	<?php wp_head(); ?>
	<!--<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,700,500,900&subset=latin,greek,greek-ext,vietnamese,cyrillic-ext,cyrillic' rel='stylesheet' type='text/css'>-->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800italic,800' rel='stylesheet' type='text/css'>
   	<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/imagenew/favicon.ico" type="image/x-icon">
   

    <link rel="stylesheet" type="text/css" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/slidebars.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/stylenew.css">
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/1140.css">
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/responsive.css">		
    
    <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/1.11.2jquery.min.js"></script>
    <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/LazyLoad.js"></script>        
    <script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/bootstrap.js"></script>	
    <script type="text/javascript">
	$(document).ready(function(){
		$( ".toggle-menu-header" ).click(function() {
				 
			  $( ".newheadermenu" ).slideToggle( "slow", function() {
			    
			  });
		});
		}); 
	</script>
</head>

<body <?php body_class(); ?>>
<?php 
	global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
	$mainsiteprefix='cm_';
	$agentsiteurl=get_option('siteurl');
	$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
	$agentsiteid=$agentsitedetail->id;
	$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
?>

<div id="page" class="hfeed site sitenew">
	<div class="main_header newheade" style="background:<?php echo get_site_option( 'header_bg_color' ); ?>;padding: 10px 0; text-align: center;">
	<a href="<?php //echo esc_url(home_url('/')); ?>"><img src="<?php //echo get_site_option( 'sitelogo' ); ?>" alt="<?php //echo get_site_option( 'blogname' ); ?>" /></a>
	<div class="">
		<div class="newfullheader">
			<div class="nheader fl">
				<a href="#"><img src="<?php bloginfo( 'template_url' ); ?>/imagenew/logo.png" alt=""></a>
			</div>
			<div class="nheaderright fr">
				<a href="#"><img src="<?php bloginfo( 'template_url' ); ?>/imagenew/find_nearest_cruise.png" alt="" ></a>
				<a href="#"><img src="<?php bloginfo( 'template_url' ); ?>/imagenew/Facebook-icon.png" alt="" class="socialimages"></a>
				<a href="#"><img src="<?php bloginfo( 'template_url' ); ?>/imagenew/twitter12.png" alt="" class="socialimages"></a>
				<a href="#"><img src="<?php bloginfo( 'template_url' ); ?>/imagenew/Google-plus-icon.png" alt="" class="socialimages"></a>
			</div>
			<div class="cl"></div>
		</div>
			<div class="toggle-menu-header"></div>
		<div class="newheadermenu">
						<?php

$defaults = array(
	'theme_location'  => '',
	'menu'            => 'header_menu',
	'container'       => 'div',
	'container_class' => '',
	'container_id'    => '',
	'menu_class'      => 'menu',
	'menu_id'         => '',
	'echo'            => true,
	'fallback_cb'     => 'wp_page_menu',
	'before'          => '',
	'after'           => '',
	'link_before'     => '',
	'link_after'      => '',
	'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
	'depth'           => 0,
	'walker'          => ''
);

wp_nav_menu( $defaults );
?>
		</div>
	</div>
</div>