<?php
/*
Template Name: Cruise Liner
*/
get_header(); 
//print_r($_GET);

get_header(); ?>
<div class="servicewrapper">
<div class="fullarea">
<div class="leftside">
	<div id="primary" class="content-area">
		<div id="content" class="site-content servicewrapper" role="main">
		<header class="entry-header">
			<h1 class="entry-title"><?php echo the_title(); ?></h1>
		</header>
			<?php /* The loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>
				<?php the_content(); ?>

			<?php endwhile; ?>
			<div class="row new_list_box">
			<br>
			<?php
			wp_reset_query();
			$pages = get_pages(array(
				'meta_key' => '_wp_page_template',
				'meta_value' => 'operator_details.php'
			));
			foreach($pages as $page){
				$src = wp_get_attachment_image_src( get_post_thumbnail_id($page->ID), 'medium' );
				//print_r($src);
				$url = $src[0];
				echo '<div class="col-sm-4 new_list">';
				echo '<div class="new_listone">';
				echo '<a href="'.get_permalink($page->ID).'">';
				if(!empty($url)){
				echo '<img src="'.$url.'" >';
				}
				else{
				echo $page->post_title.'';
				}
				echo '</a>';
				echo '</div>';
				echo '</div>';
			}
			?>
			</div>

		</div><!-- #content -->
	</div><!-- #primary -->
</div>
<div class="sidebararea">
	<?php get_sidebar(); ?>
</div>
<div class="clr"></div>
</div>
</div>
<?php get_footer(); ?>