<?php
/*
Template Name: Ship Listing Cruise Club
*/
get_header('new');
?>
<div class="header wrraper" style="b url(<?php $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo $feat_image; ?>) no-repeat scroll center top / cover ">
	<div class= "mobile-top wrapper clearfix">
			<a href="#" class="w-arrow"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/white-arrow.png"></a>
			<div id="sb-toggle-right " class="">
				<a href="#" class="menu-bt sb-toggle-right" ><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/menu-bt.png"></a>
			</div>
		</div>
	<div class="container ">		
		<div class="showheadnewbtn">
		<div class="grey-box-wrraper clearfix">
			<div class="grey-box">
				<h1>FIND YOUR CRUISE</h1>
				<p>Go anywhere, anyplace, anytime with 1000’s of cruises to choose from</p>				
				<h3>Search your cruise holiday here</h3>		
			</div>					
		</div>

		<input type="button" value="How it works" class="work-bt"> 
	</div>
	</div>
	<div class="loader" style="display:none;">
		<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader.gif">
	</div>
	<div class="input-form wrraper clearfix newforminput">
		<div class="container clearfix">
			<div class="form-field">
				
				<form action="#" method="post" class="iflair_template_form" id="iflair_template_form">
					<div class="category-form clearfix">
						<div class="btn-group i-1" role="group">
							<select name="iflair_template_cruise_operators" id="iflair_template_cruise_operators" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_ajax_second_filter();" >
								<option value="">Select Tour Operator</option>
								<?php
								$site_operator_list_query= "SELECT * FROM `cruise_operators` WHERE operator_id IN (".$agent_assign_operator.")";
								$select_cruise_operators = $mydb->get_results($site_operator_list_query);
								foreach ($select_cruise_operators as $cruise_operators_obj) :
								   echo "<option value='".$cruise_operators_obj->operator_id."'>".$cruise_operators_obj->operator_title."</option>";
								endforeach;
								?>
						    </select>
					  	</div>
					  <span id="second_filter">
						<div class="btn-group i-1" role="group">
							<select disabled="true" name="iflair_template_cruise_ship_size" id="iflair_template_cruise_ship_size" class="btn btn-default dropdown-toggle text p-2" required onchange="iflair_ajax_cruise_operators();" >
								<option value="">Select a ship size</option>
							    <?php
							    $select_cruise_ship_size = $mydb->get_results("SELECT * FROM `cruise_ship_size`");
								foreach ($select_cruise_ship_size as $cruise_ship_size_obj) :
								   echo "<option value='".$cruise_ship_size_obj->size_id."'>".$cruise_ship_size_obj->size_title."</option>";
								endforeach;
							    ?>
						    </select>
					  	</div>
						<div class="btn-group i-1" role="group">
							<select disabled="true"name="iflair_template_cruise_ship_style" id="iflair_template_cruise_ship_style" class="btn btn-default dropdown-toggle text p-2" required onchange="iflair_ajax_cruise_operators();">
								<option value="">Select a ship style</option>
							    <?php
							    $select_cruise_ship_style = $mydb->get_results("SELECT * FROM `cruise_ship_style`");
								foreach ($select_cruise_ship_style as $cruise_ship_style_obj) :
								   echo "<option value='".$cruise_ship_style_obj->style_id."'>".$cruise_ship_style_obj->style_title."</option>";
								endforeach;
							    ?>
						    </select>
					  	</div>
						<div class="btn-group i-1" role="group">
							<select disabled="true" name="iflair_template_cruise_language" id="iflair_template_cruise_language" class="btn btn-default dropdown-toggle text p-2" required onchange="iflair_ajax_cruise_operators();" >
								<option value="">Select a language</option>
							    <?php
							    $select_cruise_language = $mydb->get_results("SELECT language_code,language_title FROM `cruise_language`");
								foreach ($select_cruise_language as $cruise_language_obj) :
								   echo "<option value='".$cruise_language_obj->language_code."'>".$cruise_language_obj->language_title."</option>";
								endforeach;
							    ?>
						    </select>
					  	</div>	
					  </span>				
						
						<a class="iflair_template_value_reseter" id="iflair_template_value_reseter" onclick="iflair_ajax_cruise_operators();" >Reset</a>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<div class="d-content clearfix">
	<div class="container">
		<h2>Results for Mediterranean</h2>
		<div class="side-bar">											
			<div class="ship-features">
				<ul>
					<li><a class="iflair_template_value_cruiseship" >Cruise Ships</a></li>
					<li id="sub_list"><a>Ship Size<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
						<ul>
							<?php
						    $select_cruise_ship_size = $mydb->get_results("SELECT css.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_size AS css ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id IN ($agent_assign_operator) AND css.size_title = cc.cruise_ship_size GROUP BY cc.cruise_ship_size ORDER BY cc.cruise_operator_name");
							foreach ($select_cruise_ship_size as $cruise_ship_size_obj) :
							?>
							<li><a onclick="iflair_ajax_cruise_operators_left('cruise_ship_size','<?php echo $cruise_ship_size_obj->size_title; ?>');"><?php echo $cruise_ship_size_obj->size_title; ?></a></li>
							<?php
							endforeach;
						    ?>
						</ul>
					</li>
					<li id="sub_list">
						<a>Ship Style<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
						<ul>
							<?php
								$select_cruise_ship_style = $mydb->get_results("SELECT css.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_style AS css ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id IN ($agent_assign_operator) AND css.style_title = cc.crusie_ship_style GROUP BY cc.crusie_ship_style ORDER BY cc.cruise_operator_name");
								foreach ($select_cruise_ship_style as $cruise_ship_style_obj) :
								?>
								<li><a onclick="iflair_ajax_cruise_operators_left('crusie_ship_style','<?php echo $cruise_ship_style_obj->style_title; ?>');"><?php echo $cruise_ship_style_obj->style_title; ?></a></li>
								<?php
								endforeach;
						    ?>
						</ul>
					</li>
					<li id="sub_list">
						<a>Language<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
						<ul>
							<?php
								$select_cruise_language = $mydb->get_results("SELECT cl.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_language AS cl ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id IN ($agent_assign_operator) AND cl.language_code = cc.cruise_language GROUP BY cc.cruise_language ORDER BY cc.cruise_operator_name");
								foreach ($select_cruise_language as $cruise_language_obj) :
								?>
								<li><a onclick="iflair_ajax_cruise_operators_left('cruise_language','<?php echo $cruise_language_obj->language_code; ?>');"><?php echo $cruise_language_obj->language_title; ?></a></li>
								<?php
								endforeach;
						    ?>
						</ul>
					</li>
				</ul>
			</div>
		</div>
		<div class="result-part">
			<div id="replace_query_ajax">
				 <script type="text/javascript">	
					jQuery(document).ready(function(){
						/*jQuery("#pagination li").click(function(){*/
							var pageNum = 1;
							jQuery('#iflair_template_cruise_operators').prop('selectedIndex',0);
	    					jQuery('#iflair_template_cruise_ship_size').prop('selectedIndex',0);
	    					jQuery('#iflair_template_cruise_ship_style').prop('selectedIndex',0);
	    					jQuery('#iflair_template_cruise_language').prop('selectedIndex',0);
	    					var touroperator = jQuery('#iflair_template_cruise_operators').val();
							var shipsize = jQuery('#iflair_template_cruise_ship_size').val();
							var shipstyle = jQuery('#iflair_template_cruise_ship_style').val();
							var shiplanguage = jQuery('#iflair_template_cruise_language').val();

						        jQuery.ajax({
						            type: "POST",
						            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
						            data: ({
						                action: 'iflair_ajax_response_cruise_operators',
						                touroperator: touroperator,
						                shipsize:shipsize,
						                shipstyle:shipstyle,
						                shiplanguage:shiplanguage,
						                pagenumb:pageNum
						            }),
						            success: function (response) {
						            	jQuery('.loader').css('display','none');
						                //alert(response);
						                jQuery('#replace_query_ajax').html(response);
						            }
						        });
							
						//});
					});


				</script>
				<?php 
				/* pagination iflair code */
				/*$page_links = paginate_links( array(
    'base' => add_query_arg( 'pagenum', '%#%' ),
    'format' => '',
    'show_all'=> true,
    'prev_text' => __( '&laquo;', 'aag' ),
    'next_text' => __( '&raquo;', 'aag' ),
    'total' => $num_of_pages,
    'current' => $pagenum
) );*/
				
/*if ( $page_links ) {
    echo  '<div class="clear"></div><div class="tablenav"><div class="divnav-pages">' .$page_links . '</div><div class="clear"></div></div>';
}*/
/* pagination iflair code */
				?>

			</div>
		</div>
	</div>


<style type="text/css">
	#pagination-menu {
		width: 100%;
		float: left;	
	}
	ul#pagination {
		width: 100%;

	}
	ul#pagination li {
		display: inline-block;
		padding: 10px;
		border: 1px solid #ccc;
	}
	ul#pagination li.inactive {
		display: none;
	}
</style>

<script>
jQuery( document ).ready(function() {
	jQuery('.iflair_template_value_reseter').click(function(){
	    jQuery('#iflair_template_cruise_operators').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_ship_size').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_ship_style').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_language').prop('selectedIndex',0);
	    iflair_ajax_cruise_operators();
	});
	jQuery('#iflair_template_cruise_operators').click(function(){
	    jQuery('#iflair_template_cruise_ship_size').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_ship_style').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_language').prop('selectedIndex',0);
	});
	jQuery('.iflair_template_value_cruiseship').click(function(){
		jQuery('#iflair_template_cruise_operators').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_ship_size').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_ship_style').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_language').prop('selectedIndex',0);
	    iflair_ajax_cruise_operators();
	});

	jQuery('#sub_list a').on('click',function(){
		jQuery(this).next('ul').slideToggle();
	});

});
function iflair_ajax_cruise_operators(){  
		jQuery('.loader').css('display','block');	
		//var id = str;
		var pagenumb='1';
		var touroperator = jQuery('#iflair_template_cruise_operators').val();
		var shipsize = jQuery('#iflair_template_cruise_ship_size').val();
		var shipstyle = jQuery('#iflair_template_cruise_ship_style').val();
		var shiplanguage = jQuery('#iflair_template_cruise_language').val();
        jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'iflair_ajax_response_cruise_operators',
                touroperator: touroperator,
                shipsize:shipsize,
                shipstyle:shipstyle,
                shiplanguage:shiplanguage,
                pagenumb:pagenumb
            }),
            success: function (response) {
            	jQuery('.loader').css('display','none');
                //alert(response);
                jQuery('#replace_query_ajax').html(response);
            }
        });
}

function iflair_ajax_second_filter(){ 
	jQuery('.loader').css('display','block');	
	//var id = str;
	var pagenumb='1';
	var touroperator = jQuery('#iflair_template_cruise_operators').val();
	var shipsize = jQuery('#iflair_template_cruise_ship_size').val();
	var shipstyle = jQuery('#iflair_template_cruise_ship_style').val();
	var shiplanguage = jQuery('#iflair_template_cruise_language').val();
    jQuery.ajax({
        type: "POST",
        url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
        data: ({
            action: 'iflair_ajax_response_combo_cruise_operators',
            touroperator: touroperator,
            shipsize:shipsize,
            shipstyle:shipstyle,
            shiplanguage:shiplanguage,
            pagenumb:pagenumb
        }),
        success: function (response) {
        	jQuery('.loader').css('display','none');
            //alert(response);
            jQuery('#second_filter').html(response);
        }
    });
	iflair_ajax_cruise_operators();
}

function iflair_ajax_cruise_operators_left(str1,str2){  
		jQuery('.loader').css('display','block');	
		var str1 = str1;
		//alert(str1);	
		var str2 = str2;
		//alert(str2);
		var pagenumb=pagenumb;
		var touroperator = jQuery('#iflair_template_cruise_operators').val();
		//alert(jQuery("#iflair_template_cruise_operators option:selected").text());
		var shipsize = jQuery('#iflair_template_cruise_ship_size').val();
		var shipstyle = jQuery('#iflair_template_cruise_ship_style').val();
		var shiplanguage = jQuery('#iflair_template_cruise_language').val();
        jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'iflair_ajax_response_cruise_operators',
                str1: str1,
                str2: str2,
                pagenumb:pagenumb
            }),
            success: function (response) {
            	jQuery('.loader').css('display','none');
                //alert(response);
                jQuery('#replace_query_ajax').html(response);
            }
        });
}

</script>	

<?php
get_footer('new'); 
?>