<?php
/*
Template Name: Additional Page
*/
get_header();
?>

<?php
	$listing_page_id = get_site_option( 'iflair_cruise_theme_ship_listing_page' );
?>
<div class="servicewrapper">
<div class="fullarea">
	<div class="leftsidesmall">
		
		<?php get_sidebar(); ?>
		<?php //include("left_sidebar.php");?>
	</div>
<div class="rightbigger">
	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">
			<div class="servicewrapper">
			<?php /* The loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<header class="entry-header">
						<?php if ( has_post_thumbnail() && ! post_password_required() ) : ?>
						<div class="entry-thumbnail">
							<?php the_post_thumbnail(); ?>
						</div>
						<?php endif; ?>

						<h1 class="entry-title"><?php the_title(); ?></h1>
					</header><!-- .entry-header -->

					<div class="entry-content">
						<?php the_content(); ?>
						<?php wp_link_pages( array( 'before' => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentythirteen' ) . '</span>', 'after' => '</div>', 'link_before' => '<span>', 'link_after' => '</span>' ) ); ?>
					</div><!-- .entry-content -->

					<footer class="entry-meta">
						<?php edit_post_link( __( 'Edit', 'twentythirteen' ), '<span class="edit-link">', '</span>' ); ?>
					</footer><!-- .entry-meta -->
				</article><!-- #post -->

				<?php comments_template(); ?>
			<?php endwhile; ?>
			</div>
		</div><!-- #content -->
	</div><!-- #primary -->
</div>

</div>
</div>
<?php
get_footer(); 
?>