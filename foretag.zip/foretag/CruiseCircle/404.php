<?php
/**
 * The template for displaying 404 pages (Not Found)
 *
 * @package WordPress
 * @subpackage Twenty_Thirteen
 * @since Twenty Thirteen 1.0
 */

get_header(); ?>
<div class="servicewrapper">
<div class="fullarea">
<div class="leftside">
	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">
			<div class="servicewrapper">
			<?php /* The loop */ ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<header class="entry-header">
						<h1 class="entry-title">Not Found</h1>
					</header><!-- .entry-header -->

					<div class="entry-content">
						<p>It looks like nothing was found at this location.</p>
					</div><!-- .entry-content -->

				</article><!-- #post -->

			</div>
		</div><!-- #content -->
	</div><!-- #primary -->
</div>
<div class="sidebararea">
<?php get_sidebar(); ?>
</div>
</div>
</div>
<?php get_footer(); ?>