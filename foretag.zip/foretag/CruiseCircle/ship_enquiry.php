<?php
/*
Template Name: Ship Enquiry
*/
get_header(); 
global $wpdb,$mydb;

$site_detail_result = $mydb->get_results("SELECT * FROM cruise_cruise WHERE cruise_id = '$_GET[ship_id]' LIMIT 1");
if(!$site_detail_result[0]->cruise_cover_image_href){  } else { ?>
<div style="background: transparent url('<?php echo $site_detail_result[0]->cruise_cover_image_href;?>') no-repeat scroll left center / cover; height: 250px; " >
  <div class="container">
    <div class="detail">
    </div>
  </div>
</div>
<?php } ?>

<div class="content-d clearfix">
  <div class="container">
    <div class="detail">
      <div class="about-this clearfix">
        <h3>Make An Enquiry For <?php if($site_detail_result[0]->cruise_operator_name){ echo $site_detail_result[0]->cruise_operator_name; }else{} ?> - <?php if($site_detail_result[0]->cruise_title){ echo $site_detail_result[0]->cruise_title; }else{} ?></h3>
        <div class="cruse" id="responseshipenquiry">
			<?php
				echo do_shortcode("[shipenquiryform]");
			?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
get_footer(); 
?>

