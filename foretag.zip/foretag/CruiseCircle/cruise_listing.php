<?php
/*
Template Name: Cruise Listing
*/
get_header();
$river_page_id = get_site_option( 'iflair_cruise_theme_river_page' );
$ocean_page_id = get_site_option( 'iflair_cruise_theme_ocean_page' );
if(!empty($_GET)){
	?>
	<script type="text/javascript">
		jQuery(document).ready(function(){

			jQuery.cookie('str1', '', {expires: 1,path: "/" });
			jQuery.cookie('str2', '', {expires: 1,path: "/" });

			jQuery('.loader').css('display','block');
			var pageNum = 1;
			//var tab_id = "<?php echo $_GET['tab_id']; ?>";
					
			var region = "<?php if(isset($_GET['cruise_region'])){ echo $_GET['cruise_region']; } ?>";
			var operator = "<?php if(isset($_GET['cruise_operator'])){ echo $_GET['cruise_operator']; } ?>";
			var cruise_ship = "<?php if(isset($_GET['cruise_ship'])){ echo $_GET['cruise_ship']; } ?>";
			var ship_fly_in = "<?php if(isset($_GET['cruise_ship_fly_in'])){ echo $_GET['cruise_ship_fly_in']; } ?>";
			var ship_starts_on = "<?php if(isset($_GET['cruise_ship_starts_on'])){ echo $_GET['cruise_ship_starts_on']; } ?>";
			var from_cruise_date = "<?php if(isset($_GET['from_cruise_date'])){ echo $_GET['from_cruise_date']; } ?>";
			var to_cruise_date = "<?php if(isset($_GET['to_cruise_date'])){ echo $_GET['to_cruise_date']; } ?>";
			var ship_cruise_nights = "<?php if(isset($_GET['cruise_ship_cruise_nights'])){ echo $_GET['cruise_ship_cruise_nights']; } ?>";

				//if(<?php echo $_GET['tab_id']; ?>=="undefined"){
					var check = 0;
				//}

			<?php if(isset($_GET['start_price'])){ ?>;
				<?php if($_GET['start_price']=="undefined"){ ?>;
				var s = "0";
				<?php }else{ ?>
				var s = "<?php echo $_GET['start_price']; ?>";
				<?php } ?>
			<?php }else{ ?>
			var s = "0";
			<?php } ?>
			<?php if(isset($_GET['end_price'])){ ?>;
				<?php if($_GET['end_price']=="undefined"){ ?>;
				var e = "10000";
				<?php }else{ ?>
				var e = "<?php echo $_GET['end_price']; ?>";
				<?php } ?>
			<?php }else{ ?>
			var e = "10000";
			<?php } ?>

			if( region == "" && operator == "" && cruise_ship == "" && ship_fly_in == "" && ship_starts_on == "" && ship_cruise_nights == "" ){	
			    var s = "0";
			    var e = "1000";
			}

			var check = 0;
			//if( <?php echo $_GET['tab_id']; ?>=="1" || <?php echo $_GET['tab_id']; ?>=="2"){
			//	var tab_id = <?php echo $_GET['tab_id']; ?>
			//}
			//else if(check=="1" || check=="2" ){
				var tab_id = check;
			//}
			//else{
			//	var tab_id = "<?php echo $_GET['tab_id']; ?>";
			//}
			jQuery(".main_tab_loader").show();
		    jQuery.ajax({
	            type: "POST",
	            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
	            data: ({
	                action: 'iflair_search_filter_response',
		            region: region,
		            //tab_id: tab_id,
		            operator: operator,
		            cruise_ship: cruise_ship,
		            ship_fly_in: ship_fly_in,
		            ship_starts_on: ship_starts_on,
		            ship_cruise_nights: ship_cruise_nights,
		            from_cruise_date:from_cruise_date,
		            to_cruise_date:to_cruise_date,
		            s:s,
		            e:e,
	                pagenumb:pageNum
	            }),
	            success: function (response) {
	            	jQuery(".main_tab_loader").hide();
	            	cruise_filter();
	            	//jQuery('.loader').css('display','none');
	                //alert(response);
	                jQuery('.form-field').html(response);
            		jQuery(".content").mCustomScrollbar();
            		jQuery(".search_header").addClass("searched");
            		jQuery(".search_header").addClass("searched_image");
					jQuery('.input-form').slideDown();
							
			    if(s=="0" && e=="10000"){

			    }
			    else if(e=="1000"){
					jQuery('#1_radio').prop('checked',true);
			    }
			    else if(e=="1500"){
					jQuery('#2_radio').prop('checked',true);
			    }
			    else if(e=="2000"){
					jQuery('#3_radio').prop('checked',true);
			    }
			    else if(e=="3000"){
					jQuery('#4_radio').prop('checked',true);
			    }
			    else if(e=="4000"){
					jQuery('#5_radio').prop('checked',true);
			    }
			    else if(e=="5000"){
					jQuery('#6_radio').prop('checked',true);
			    }
			    else if(s!="0" && e=="10000"){
					jQuery('#7_radio').prop('checked',true);
			    }
					jQuery('.main_tab_loader img').css('display','block');
	            }
	        });
		});
	</script>
	<?php
}
?>
<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/jquery.mCustomScrollbar.css">
<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.mCustomScrollbar.concat.min.js"></script>

<link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script>
	/*jQuery(function() {
		jQuery( "#cruise_ship_starts_on" ).datepicker();
	});*/
	var dateToday = new Date();    
	/*jQuery(function () {
	    jQuery("#cruise_ship_starts_on").datepicker({ 
	      minDate: dateToday ,
	      dateFormat: 'yy-mm-dd'
	    });
	});*/
		jQuery(function () {
			jQuery("#cruise_ship_starts_on").datepicker({
				showButtonPanel: false,  
				minDate: dateToday ,
				dateFormat: 'yy-mm-dd'
			}); 
		});
</script>
<div class="header wrraper search_header" style="background:rgba(0, 0, 0, 0) url(<?php $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo $feat_image; ?>) no-repeat scroll center top / cover ">
	<div class= "mobile-top wrapper clearfix">
			<a href="#" class="w-arrow"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/white-arrow.png"></a>
		</div>
	<div class="loader" style="display:none;">
		<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader.gif">
	</div>
	<div class=" blackback col-sm-3">
	<!-- <div class="open_search servicewrapper">
		<a class="manage_search" >Back to search results</a>
	</div> -->
	<!-- 
	<div class="tabing fl">
		<a class="active_tab tsb-tab" id="1">River Cruises</a>
		<a id="2" class="tsb-tab">Cruise Liners</a>
		<a id="3" class="tsb-tab">Fly Cruises</a>
	</div> -->
	<div class="clr"></div>

	<div class="open_search clearfix" style="display: block;">
		<div class="container">
			<div class=" headertwobtn fl">
				<a class="tsb-tab" id="2">Ocean Cruises</a>
				<a class="tsb-tab" id="1">River Cruises</a>
			</div>
			<div class="main_tab_loader" style="display:none;"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/progress-bar.gif"></div>
			<!-- <p id="result_story"></p> -->
		</div>
	</div>

	<div class="input-form wrraper clearfix backmake">
		<div class="servicewrapper  clearfix">
		<?php
			$listing_page_id = get_site_option( 'iflair_cruise_theme_ship_listing_page' );
		?>
		<!-- <form action="<?php //echo get_page_link($listing_page_id); ?>" method="get" name="rearange_filter" id="rearange_filter"> -->
			<div class="form-field">

			</div>
		<!-- </form> -->
		</div>
	</div>
</div>
	</div>

<div id="replace_query_ajax">
</div>
<div class="new_design_homepage">
<div class="home_page_area">
	<div class="servicewrapper">
		<div class="homtwo">
			<div class="leftsidearea fl">
			</div>
			<div class="rightsider fl">
				<!-- Group offers by Cruiseline Start -->
				<?php
					$gt_ope_list = $wpdb->get_results("SELECT tour_operator_name FROM cc_tour_operator");
					$gt_ope_list_count = count($gt_ope_list);
					if ($gt_ope_list_count != "0") 
					{
				?>
						<div class="container">
							<div id="Cruiseline_Left">
								<?php
									echo "<ul class='operator_name'>";
									foreach ($gt_ope_list as $gt_ope_name) 
									{
								?>
										<li class="operator"><a onclick="iflair_operator(this.text);"><?php echo $gt_ope_name->tour_operator_name; ?></a></li>
								<?php }
									echo "</ul>";

								?>
							</div>
							<div class="loader" style="display:none;">
								<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader.gif">
							</div>
							<div id="Cruiseline_Right">
								
							</div>
						</div>
				<?php } ?>
				<!-- Group offers by Cruiseline End -->
			</div>
			<div class="clear"></div>
		</div>
	</div>
</div>
</div>
</div>

<script>

function iflair_operator(str){
	jQuery('.loader').css('display','block');
	jQuery.ajax({
        type: "POST",
        url: ('<?php echo admin_url( 'admin-ajax.php' ); ?>'),
        data: ({
            action: 'iflair_get_operator',
            opet_name: str,
        }),
        success: function (response) {
           jQuery('.container #Cruiseline_Right').html(response);
           jQuery('.loader').css('display','none');
        }
    });
}

jQuery( document ).ready(function() {

	var ope_one_name = jQuery("#Cruiseline_Left ul.operator_name li:first-child").text();

	<?php if(is_page('4683')){ ?>
    jQuery.ajax({
        type: "POST",
        url: ('<?php echo admin_url( 'admin-ajax.php' ); ?>'),
        data: ({
            action: 'iflair_get_operator',
            opet_name: ope_one_name,
        }),
        success: function (response) {
           jQuery('.container #Cruiseline_Right').html(response);
           jQuery('.loader').css('display','none');
        }
    });
    <?php } ?>

    jQuery("#Cruiseline_Left ul.operator_name li:first-child").addClass("ope-active");

    jQuery("#Cruiseline_Left ul.operator_name li a").click(function(){
    	jQuery("#Cruiseline_Left ul.operator_name li").removeClass("ope-active");
    	jQuery(this).parent().addClass("ope-active");
    });

	jQuery('.loader').css('display','block');
	jQuery('.form-field').css('border','none');
				jQuery('.input-form').slideUp();
		var pageNum = 1;
		<?php if(isset($_GET['cruise_region'])){ ?>;
		var region = "<?php echo $_GET['cruise_region']; ?>";
		<?php }else{ ?>
		var region = "";
		<?php } ?>
		<?php if(isset($my_selected_operator)){ ?>;
		var operator = "<?php echo $my_selected_operator; ?>";
		<?php }if(isset($_GET['cruise_operator'])){ ?> 
		var operator = "<?php echo $_GET['cruise_operator']; ?>";
		<?php }else{ ?>
		var operator = "";
		<?php } ?>
		<?php if(isset($_GET['cruise_ship'])){ ?>;
		var cruise_ship = "<?php echo $_GET['cruise_ship']; ?>";
		<?php }else{ ?>
		var cruise_ship = "";
		<?php } ?>
		<?php if(isset($_GET['cruise_ship_fly_in'])){ ?>;
		var ship_fly_in = "<?php echo $_GET['cruise_ship_fly_in']; ?>";
		<?php }else{ ?>
		var ship_fly_in = "";
		<?php } ?>
		<?php if(isset($_GET['cruise_ship_starts_on'])){ ?>;
		var ship_starts_on = "<?php echo $_GET['cruise_ship_starts_on']; ?>";
		<?php }else{ ?>
		var ship_starts_on = "";
		<?php } ?>
		<?php if(isset($_GET['from_cruise_date'])){ ?>;
		var from_cruise_date = "<?php echo $_GET['from_cruise_date']; ?>";
		<?php }else{ ?>
		var from_cruise_date = "";
		<?php } ?>
		<?php if(isset($_GET['to_cruise_date'])){ ?>;
		var to_cruise_date = "<?php echo $_GET['to_cruise_date']; ?>";
		<?php }else{ ?>
		var to_cruise_date = "";
		<?php } ?>
		<?php if(isset($_GET['cruise_ship_cruise_nights'])){ ?>;
		var ship_cruise_nights = "<?php echo $_GET['cruise_ship_cruise_nights']; ?>";
		<?php }else{ ?>
		var ship_cruise_nights = "";
		<?php } ?>
	
			<?php if(isset($_GET['start_price'])){ ?>;
				<?php if($_GET['start_price']=="undefined"){ ?>;
				var s = "0";
				<?php }else{ ?>
				var s = "<?php echo $_GET['start_price']; ?>";
				<?php } ?>
			<?php }else{ ?>
			var s = "0";
			<?php } ?>
			<?php if(isset($_GET['end_price'])){ ?>;
				<?php if($_GET['end_price']=="undefined"){ ?>;
				var e = "10000";
				<?php }else{ ?>
				var e = "<?php echo $_GET['end_price']; ?>";
				<?php } ?>
			<?php }else{ ?>
			var e = "10000";
			<?php } ?>

			if( region == "" && operator == "" && cruise_ship == "" && ship_fly_in == "" && ship_starts_on == "" && ship_cruise_nights == "" ){	
			    var s = "0";
			    var e = "1000";
			}

	    jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'iflair_search_filter_response',
	            region: region,
	            operator: operator,
	            cruise_ship: cruise_ship,
	            ship_fly_in: ship_fly_in,
	            ship_starts_on: ship_starts_on,
	            ship_cruise_nights: ship_cruise_nights,
	            from_cruise_date:from_cruise_date,
	            to_cruise_date:to_cruise_date,
	            s:s,
	            e:e,
                pagenumb:pageNum
            }),
            success: function (response) {
				jQuery('.input-form').slideDown();
				if(s=="0" && e=="10000"){

			    }
			    else if(e=="1000"){
					jQuery('#1_radio').prop('checked',true);
			    }
			    else if(e=="1500"){
					jQuery('#2_radio').prop('checked',true);
			    }
			    else if(e=="2000"){
					jQuery('#3_radio').prop('checked',true);
			    }
			    else if(e=="3000"){
					jQuery('#4_radio').prop('checked',true);
			    }
			    else if(e=="4000"){
					jQuery('#5_radio').prop('checked',true);
			    }
			    else if(e=="5000"){
					jQuery('#6_radio').prop('checked',true);
			    }
			    else if(s!="0" && e=="10000"){
					jQuery('#7_radio').prop('checked',true);
			    }

                jQuery('.form-field').html(response);
				//jQuery('.form-field').css('border','1px solid rgb(185, 181, 181)');
	            jQuery(".main_tab_loader").hide();
            	//jQuery('.loader').css('display','none');
            }
        });


	<?php if(is_page($river_page_id)){
		?>
		setTimeout(function() {
	        jQuery("#1").trigger('click');
	    },10);
		<?php
	}
	elseif(is_page($ocean_page_id)){
		?>
		setTimeout(function() {
	        jQuery("#2").trigger('click');
	    },10);
		<?php
	}?>

	jQuery(".tsb-tab").click(function(){
		//jQuery(".main_tab_loader").show();
		jQuery(".tsb-tab").removeClass("active_tab");
		jQuery(this).addClass("active_tab");
		var tab_id = jQuery(".active_tab").attr('id');
		jQuery("#tab_loader").show();
		/*jQuery('#cruise_region').prop('selectedIndex',0);
		jQuery('#cruise_operator').prop('selectedIndex',0);
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
		iflair_search_filter(tab_id);

		var min1 = 0;
		var max1 = 10000;
	    jQuery( "#slider-range" ).slider({
	      range: true,
	      min: 0,
	      max: 10000,
	      values: [ min1, max1 ],
	      slide: function( event, ui ) {
	        jQuery( "#amount" ).html( "<span class='start_a'>£" + ui.values[ 0 ] + "</span><span class='end_a'>£" + ui.values[ 1 ] +"</span>" );
			jQuery( "#amount1" ).val(ui.values[ 0 ]);
			jQuery( "#amount2" ).val(ui.values[ 1 ]);
	      }
	    });

/*
		var tab_id = jQuery(".active_tab").attr('id');
		if(jQuery(".active_tab").attr('id')=="1"){
			var path = "rivercruise/";
		}
		else if(jQuery(".active_tab").attr('id')=="2"){
			var path = "oceansearch/";
		}
		else{
			var path = "";
		}
		history.pushState({},"URL Rewrite Example",newURL+""+path);

*/
	});

	jQuery(this).next('ul').slideUp();
	jQuery('#sub_list a').on('click',function(){
		/*jQuery(this).next('ul').slideToggle();*/
	});


	var w = window.innerWidth;
	if(w<"768"){
		//alert("slide");
			jQuery('.search-bt-2').on('click',function(){
				jQuery('.side-bar').slideToggle();
			});
		jQuery('.open_search').on('click',function(){
			jQuery('.input-form.wrraper').slideToggle();
			jQuery('.side-bar').slideToggle();
		});
	}
	else{
		jQuery('.open_search').on('click',function(){
			jQuery('.searched .input-form.wrraper').slideToggle();
			//alert("change search now");
		});
	}

	jQuery('#cruise_region').prop('selectedIndex',0);
	jQuery('#cruise_operator').prop('selectedIndex',0);
	jQuery('#cruise_ship').prop('selectedIndex',0);
	jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
	jQuery('#cruise_leaving_from').prop('selectedIndex',0);
	jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
	jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);

});

function iflair_search_filter(str){
	var pagenumb='1';
	var check = str;
	var tab_id = jQuery(".active_tab").attr('id');
	if(check=="1" || check=="undefined" || check=="2"){
	//var tab_id = <?php if(isset($_GET['tab_id']) && $_GET['tab_id'] != "undefined"){ ?>"<?php echo $_GET['tab_id']; ?>"<?php }else{ ?>jQuery(".active_tab").attr('id')<?php } ?>;

	var region = <?php if(isset($_GET['cruise_region'])){ echo '"'.$_GET['cruise_region'].'"'; }else{?>jQuery('#cruise_region').val();<?php } ?>;
	var operator = <?php if(isset($_GET['cruise_operator'])){ echo '"'.$_GET['cruise_operator'].'"'; }else{?>jQuery('#cruise_operator').val();<?php } ?>;
	var cruise_ship = <?php if(isset($_GET['cruise_ship'])){ echo '"'.$_GET['cruise_ship'].'"'; }else{?>jQuery('#cruise_ship').val();<?php } ?>;
	var ship_fly_in = <?php if(isset($_GET['cruise_ship_fly_in'])){ echo '"'.$_GET['cruise_ship_fly_in'].'"'; }else{?>jQuery('#cruise_ship_fly_in').val();<?php } ?>;
	var ship_starts_on = <?php if(isset($_GET['cruise_ship_starts_on'])){ echo '"'.$_GET['cruise_ship_starts_on'].'"'; }else{?>jQuery('#cruise_ship_starts_on').val();<?php } ?>;
	var ship_cruise_nights = <?php if(isset($_GET['cruise_ship_cruise_nights'])){ echo '"'.$_GET['cruise_ship_cruise_nights'].'"'; }else{?>jQuery('#cruise_ship_cruise_nights').val();<?php } ?>;

	<?php if(isset($_GET['start_price'])){ ?>;
		<?php if($_GET['start_price']=="undefined"){ ?>;
		var s = "0";
		<?php }else{ ?>
		var s = "<?php echo $_GET['start_price']; ?>";
		<?php } ?>
	<?php }else{ ?>
	var s = "0";
	<?php } ?>
	<?php if(isset($_GET['end_price'])){ ?>;
		<?php if($_GET['end_price']=="undefined"){ ?>;
		var e = "10000";
		<?php }else{ ?>
		var e = "<?php echo $_GET['end_price']; ?>";
		<?php } ?>
	<?php }else{ ?>
	var e = "10000";
	<?php } ?>
	

	}
	else{
	var region = jQuery('#cruise_region').val();
	var operator = jQuery('#cruise_operator').val();
	var cruise_ship = jQuery('#cruise_ship').val();
	var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
	var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
	var from_cruise_date = jQuery('#from_cruise_date').val();
	var to_cruise_date = jQuery('#to_cruise_date').val();
	var ship_cruise_nights = jQuery('#cruise_ship_cruise_nights').val();
    var s = jQuery("#amount1").val();
    var e = jQuery("#amount2").val();
	
	}
	if(check=="reset"){
		jQuery('#cruise_region').prop('selectedIndex',0);
		jQuery('#cruise_operator').prop('selectedIndex',0);
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    	jQuery('.loader_filt').css('display','block');

		jQuery.cookie('str1', '',{expires: 1,path: "/" });
		jQuery.cookie('str2', '',{expires: 1,path: "/" });

		return false;
	}
	if(check=="region"){
		jQuery('#cruise_operator').prop('selectedIndex',0);
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="operator"){
		jQuery('#cruise_ship').prop('selectedIndex',0);
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="cruise_ship"){
		jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
		jQuery('#cruise_leaving_from').prop('selectedIndex',0);
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="ship_fly_in"){
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="leaving_from"){
		jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="ship_starts_on"){
		jQuery('#cruise_ship_cruise_nights').prop('selectedIndex',0);
    jQuery('.loader_filt').css('display','block');
			//iflair_search_filter();
	}
	if(check=="ship_cruise_nights"){
			//iflair_search_filter();
    jQuery('.loader_filt').css('display','block');
	}
	if(check=="search"){

		//var newURL = window.location.href;
<?php $listing_page_id = get_site_option( 'iflair_cruise_theme_ship_listing_page' );?>
var newURL = "<?php echo get_permalink($listing_page_id); ?>";
		//alert(newURL);
		/*var url_1 = window.location.pathname;
		alert(url_1);*/
		if(jQuery(".active_tab").attr('id')=="1"){
			var path = "";
		}
		else if(jQuery(".active_tab").attr('id')=="2"){
			var path = "";
		}
		else{
			var path = "";
		}

		if(jQuery('#amount1').val()=="undefined"){
			var s = "0";
		}
		else{
			var s =jQuery('#amount1').val();
		}
		if(jQuery('#amount2').val()=="undefined"){
			var e = "10000";
		}
		else{
			var e = jQuery('#amount2').val();
		}
		//alert(start_price);
		
		if( region == "" && operator == "" && cruise_ship == "" && ship_fly_in == "" && ship_starts_on == "" && ship_cruise_nights == "" ){	
		    var s = "0";
		    var e = "1000";
		}
        history.pushState({},"URL Rewrite Example",newURL+""+path+"?cruise_region="+region+"&from_cruise_date="+from_cruise_date+"&to_cruise_date="+to_cruise_date+"&cruise_operator="+operator+"&cruise_ship="+cruise_ship+"&cruise_ship_cruise_nights="+ship_cruise_nights+"&tab_id="+tab_id+"&start_price="+s+"&end_price="+e);

		jQuery.cookie('str1', '',{expires: 1,path: "/" });
		jQuery.cookie('str2', '',{expires: 1,path: "/" });

		/*if(region==""){
			jQuery('#cruise_region').focus();
			alert("Where do you want to go?");
			return false;
		}
		if(operator==""){
			jQuery('#cruise_operator').focus();
			alert("Who would you like to Cruise with?");
			return false;
		}*/
		var width_res = jQuery(".header").width();
		if(width_res<768){
			jQuery('.input-form.wrraper').slideToggle();
		}
		jQuery('.loader').css('display','block');
		jQuery('.search_header').addClass('searched');
		jQuery('.search_header').addClass('searched_image');
		jQuery('#replace_query_ajax').addClass('replace_query_class');
		jQuery(".blackback").addClass("home_searched");
		cruise_filter("ajaxer");
	}
	//alert(str);
	jQuery.ajax({
        type: "POST",
        url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
        data: ({
            action: 'iflair_search_filter_response',
            tab_id : tab_id,
            region: region,
            operator: operator,
            cruise_ship: cruise_ship,
            ship_fly_in: ship_fly_in,
            //leaving_from: leaving_from,
            ship_starts_on: ship_starts_on,
            ship_cruise_nights: ship_cruise_nights,
            from_cruise_date:from_cruise_date,
            to_cruise_date:to_cruise_date,
            s:s,
            e:e,
            pagenumb:pagenumb
        }),
        success: function (response) {
            //alert(response);
            jQuery('.form-field').html(response);
			jQuery("#tab_loader").hide();
			jQuery('.input-form').slideDown();
        	//jQuery('.loader').css('display','none');
        	if(s=="0" && e=="10000"){

		    }
		    else if(e=="1000"){
				jQuery('#1_radio').prop('checked',true);
		    }
		    else if(e=="1500"){
				jQuery('#2_radio').prop('checked',true);
		    }
		    else if(e=="2000"){
				jQuery('#3_radio').prop('checked',true);
		    }
		    else if(e=="3000"){
				jQuery('#4_radio').prop('checked',true);
		    }
		    else if(e=="4000"){
				jQuery('#5_radio').prop('checked',true);
		    }
		    else if(e=="5000"){
				jQuery('#6_radio').prop('checked',true);
		    }
		    else if(s!="0" && e=="10000"){
				jQuery('#7_radio').prop('checked',true);
		    }
		    
        	jQuery('.loader_filt').css('display','none');
			//jQuery(".main_tab_loader").hide();
	        jQuery(".main_tab_loader").hide();
        }
    });
}

function cruise_filter(str){
	var str = str;
	jQuery('.loader').css('display','block');
	var pagenumb='1';
		if(str == "ajaxer"){
			var region = jQuery('#cruise_region').val();
			var operator = jQuery('#cruise_operator').val();
			var cruise_ship = jQuery('#cruise_ship').val();
			var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
			var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
			var ship_cruise_nights = jQuery('#cruise_ship_cruise_nights').val();
			var tab_id = jQuery(".active_tab").attr('id');
			var from_cruise_date = jQuery('#from_cruise_date').val();
			var to_cruise_date = jQuery('#to_cruise_date').val();
			var s = jQuery('#amount1').val();
			var e = jQuery('#amount2').val();
		}else{
			var region = <?php if(isset($_GET['cruise_region'])){ echo '"'.$_GET['cruise_region'].'"'; }else{?>jQuery('#cruise_region').val();<?php } ?>;
			var region = <?php if(isset($_GET['cruise_region'])){ echo '"'.$_GET['cruise_region'].'"'; }else{?>jQuery('#cruise_region').val();<?php } ?>;
			var operator = <?php if(isset($_GET['cruise_operator'])){ echo '"'.$_GET['cruise_operator'].'"'; }else{?>jQuery('#cruise_operator').val();<?php } ?>;
			var cruise_ship = <?php if(isset($_GET['cruise_ship'])){ echo '"'.$_GET['cruise_ship'].'"'; }else{?>jQuery('#cruise_ship').val();<?php } ?>;
			var ship_fly_in = <?php if(isset($_GET['cruise_ship_fly_in'])){ echo '"'.$_GET['cruise_ship_fly_in'].'"'; }else{?>jQuery('#cruise_ship_fly_in').val();<?php } ?>;
			var ship_starts_on = <?php if(isset($_GET['cruise_ship_starts_on'])){ echo '"'.$_GET['cruise_ship_starts_on'].'"'; }else{?>jQuery('#cruise_ship_starts_on').val();<?php } ?>;
			var ship_cruise_nights = <?php if(isset($_GET['cruise_ship_cruise_nights'])){ echo '"'.$_GET['cruise_ship_cruise_nights'].'"'; }else{?>jQuery('#cruise_ship_cruise_nights').val();<?php } ?>;
			var from_cruise_date = <?php if(isset($_GET['from_cruise_date'])){ echo '"'.$_GET['from_cruise_date'].'"'; }else{?>jQuery('#from_cruise_date').val();<?php } ?>;
			var to_cruise_date = <?php if(isset($_GET['to_cruise_date'])){ echo '"'.$_GET['to_cruise_date'].'"'; }else{?>jQuery('#to_cruise_date').val();<?php } ?>;
			var tab_id = <?php if(isset($_GET['tab_id'])){ echo '"'.$_GET['tab_id'].'"'; }else{?>jQuery(".active_tab").attr('id');<?php } ?>;

	/*var region = jQuery('#cruise_region').val();
	var operator = jQuery('#cruise_operator').val();
	var cruise_ship = jQuery('#cruise_ship').val();
	var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
	//var leaving_from = jQuery('#cruise_leaving_from').val();
	var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
	var ship_cruise_nights = jQuery('#cruise_ship_cruise_nights').val();
	*/
			
			<?php if(isset($_GET['start_price'])){ ?>;
				<?php if($_GET['start_price']=="undefined"){ ?>;
				var s = "0";
				<?php }else{ ?>
				var s = "<?php echo $_GET['start_price']; ?>";
				<?php } ?>
			<?php }else{ ?>
			var s = "0";
			<?php } ?>
			<?php if(isset($_GET['end_price'])){ ?>;
				<?php if($_GET['end_price']=="undefined"){ ?>;
				var e = "10000";
				<?php }else{ ?>
				var e = "<?php echo $_GET['end_price']; ?>";
				<?php } ?>
			<?php }else{ ?>
			var e = "10000";
			<?php } ?>
		}
			//alert(region);
			

	if( region == "" && operator == "" && cruise_ship == "" && ship_fly_in == "" && ship_starts_on == "" && ship_cruise_nights == "" ){	
	    var s = "0";
	    var e = "1000";
	}


	jQuery('body').addClass('loader_body');
	jQuery('.main-footer').addClass('loader_footer');
	jQuery('#replace_query_ajax').addClass('loader_replace_query');
	jQuery('#replace_query_ajax').addClass('replace_query_class');
	jQuery('#replace_query_ajax').addClass('col-sm-9');
	
	var sort_val = jQuery("#sort").val();
	jQuery.ajax({
        type: "POST",
        url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
        data: ({
            action: 'cruise_filter_response',
            <?php if($_COOKIE['str1']!=""){ ?>str1: <?php echo "'".$_COOKIE['str1']."',"; } ?>
            <?php if($_COOKIE['str2']!=""){ ?>str2: <?php echo "'".$_COOKIE['str2']."',"; } ?>
            region: region,
            //tab_id : tab_id,
            operator: operator,
            cruise_ship: cruise_ship,
            ship_fly_in: ship_fly_in,
            //leaving_from: leaving_from,
            ship_starts_on: ship_starts_on,
            ship_cruise_nights: ship_cruise_nights,
            from_cruise_date:from_cruise_date,
            to_cruise_date:to_cruise_date,
			sort_val:sort_val,
            s:s,
            e:e,
            pagenumb:pagenumb
        }),
        success: function (response) {
        	jQuery(".new_design_homepage .home_page_area").remove();
			jQuery('body').removeClass('loader_body');
			jQuery('.main-footer').removeClass('loader_footer');
			jQuery('#replace_query_ajax').removeClass('loader_replace_query');
        	//jQuery('.loader').css('display','none');
            jQuery('#replace_query_ajax').html(response);
            jQuery(".content").mCustomScrollbar();
            jQuery("img.lazy").lazyload({skip_invisible : true});
            var history=jQuery('#history').html();
            //alert(history);	
			    if(s=="0" && e=="10000"){

			    }
			    else if(e=="1000"){
					jQuery('#1_radio').prop('checked',true);
			    }
			    else if(e=="1500"){
					jQuery('#2_radio').prop('checked',true);
			    }
			    else if(e=="2000"){
					jQuery('#3_radio').prop('checked',true);
			    }
			    else if(e=="3000"){
					jQuery('#4_radio').prop('checked',true);
			    }
			    else if(e=="4000"){
					jQuery('#5_radio').prop('checked',true);
			    }
			    else if(e=="5000"){
					jQuery('#6_radio').prop('checked',true);
			    }
			    else if(s!="0" && e=="10000"){
					jQuery('#7_radio').prop('checked',true);
			    }
            jQuery("#result_story").html(history);
        	jQuery('.loader').css('display','none');
	               
	var w = window.innerWidth;
	if(w<"1024"){
		var visible = jQuery('.searched .input-form.wrraper').is(":visible");
		//alert(visible);
		if(visible){
			//alert("11100");
			jQuery('.searched .input-form.wrraper').slideUp();
		}
		else{
			jQuery('.searched .input-form.wrraper').slideDown();
		}
		/*jQuery('.tsb-tab').on('click',function(){
			var visible = jQuery('.searched .input-form.wrraper').is(":visible");
			//alert(visible);
			if(visible=="true" ){
				//jQuery('.searched .input-form.wrraper').slideUp();
				if(jQuery(".tsb-tab").hasClass("active_tab")){
					//jQuery(".tsb-tab").removeClass("active_tab");
					jQuery('.searched .input-form.wrraper').slideUp();
					alert("1");
				}else{
					alert("2");
					//jQuery(".tsb-tab").addClass("active_tab");
					jQuery('.searched .input-form.wrraper').slideToggle();
				}
			}
			else{
				if(jQuery(".tsb-tab").hasClass("active_tab")){
					alert("3");
					//jQuery(".tsb-tab").removeClass("active_tab");
					jQuery('.searched .input-form.wrraper').slideDown();
				}
				else{
					alert("4");
				}
				//jQuery('.searched .input-form.wrraper').slideDown();
			}

		});*/
		jQuery('.search-bt-2').click(function(){
			jQuery('.searched .input-form.wrraper').slideUp();
			//alert("10");
		});
	}
		}
    });
}
</script>
<?php
get_footer(); 
?>