<?php
/*
Plugin Name: iFlair Operator Management
Plugin URI: http://www.iflair.com/
Description: its operator management ...
Version: 1.0
Author: iFlair
*/

ob_start();
global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;

define( 'TOUR_OPERATOR_TABLE_NAME', $wpdb->prefix . "tour_operator");
define( 'CRUISE_FINDER_TABLE_NAME', "cruise_operators");
define( 'OPERATOR_MANAGEMENT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

$table_query = "CREATE TABLE IF NOT EXISTS ".TOUR_OPERATOR_TABLE_NAME." (
  `id` int(255) NOT NULL,
  `tour_operator_name` varchar(255) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1";
$wpdb->query($table_query);

add_action( 'admin_menu', 'create_database_operator_management' );

wp_register_style( 'myPluginStylesheet', plugins_url('css/plugin_style.css', __FILE__) );
wp_enqueue_style( 'myPluginStylesheet' );

wp_enqueue_style('thickbox');
wp_enqueue_script('thickbox');
add_action('wp_ajax_shipenquirydetail', 'shipenquirydetail'); // Logged-in users
add_action('wp_ajax_nopriv_shipenquirydetail', 'shipenquirydetail'); // Guest users

function create_database_operator_management(){

global $wpdb;
add_menu_page('Tour Operators', 'Tour Operators', 'manage_options', 'tour-operators' , 'iflair_tourselecter', plugins_url( 'iflair-operator-management/images/icon.png'));
add_submenu_page( 'operator-listing', ' Tour Operators', 'Tour Operators', 'manage_options', 'iflair_tourselecter' , 'iflair_tourselecter');
}

function iflair_tourselecter(){
	global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
  	$mainsiteprefix='cm_';
	$agentsiteurl=get_option('siteurl');
	$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
	$agentsiteid=$agentsitedetail->id;
	$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
	
	if(isset($_POST['iflair_save_tour'])){
		$wpdb->query("TRUNCATE TABLE ".TOUR_OPERATOR_TABLE_NAME);
		for($to_id=0;$to_id<count($_POST["iflair_tour_operator_id"]);$to_id++){
			$iflair_tour_operator_id = $_POST['iflair_tour_operator_id'][$to_id];
			$wpdb->insert(
				TOUR_OPERATOR_TABLE_NAME, 
				array(
					'tour_operator_name' => $iflair_tour_operator_id
				)
			);
		}	
		echo "<div id='message' style='margin: 20px 0px 0px;' class='updated below-h2'><p>Tour Operator Update Successfully. </p></div>";	
	}
?>
	<div class="wrap">
		<h1>Select Tour Operator</h1>
		<br/>
		<form action="#" method="post" class="tour_selection" id="tour_selection" >
			<table class="wp-list-table widefat fixed striped pages">
				<tbody id="the-list">
					<tr>
						<td style="width: 15%;">
							<label for="iflair_tour_operator_id">Select Tour Operator</label>
						</td>
						<td id="iflair_tour_list" >
							<!-- <input type='checkbox' value="" checked> -->
							<input type='radio' id="select-all" value="Check all" name="selectall" /><label for="select-all"><b>Check all</b></label> &nbsp; &nbsp; &nbsp; &nbsp;
							<input type='radio' id="de-select-all" value="Check all" name="selectall" /><label for="de-select-all"><b>Uncheck all</b></label>
							<br><hr>
							<script type="text/javascript">
								jQuery('#select-all').click(function(event) { 
									//alert("Lets Check....");  
								    if(this.checked) {
								    	//alert("Lets Check....");  
								        // Iterate each checkbox
								        jQuery(':checkbox').each(function() {
								            this.checked = true;                        
								        });
								    }
								});
								jQuery('#de-select-all').click(function(event) { 
									//alert("Lets Check....");  
								    if(this.checked) {
								    	//alert("Lets Check....");  
								        // Iterate each checkbox
								        jQuery(':checkbox').each(function() {
								            this.checked = false;                        
								        });
								    }
								});
							</script>
								
								<?php
									
									$operator_name = $wpdb->get_results("SELECT tour_operator_name FROM ".TOUR_OPERATOR_TABLE_NAME."");
									$op_temp_nm = array();
									foreach ($operator_name as $operator) 
									{
										$op_temp_nm[] = $operator->tour_operator_name;
									}

									$static_tour = "SELECT operator_id,operator_title FROM ".CRUISE_FINDER_TABLE_NAME." WHERE FIND_IN_SET (operator_id, '".$agent_assign_operator."')";
									$static_tour = $mydb->get_results($static_tour);

									if(count($static_tour)>0)
									{
										for($i=0; $i<count($static_tour);$i++)
										{
											$opet_name = $static_tour[$i]->operator_title;
											if ($opet_name != "") 
											{
												/*$cruise_opt = "SELECT cruise_operator_name,cruise_response_id FROM cruise_cruise WHERE FIND_IN_SET (cruise_id, '".$agent_assign_operator."')"; die();
												$cruise_opt_res = $mydb->get_results($cruise_opt);
												$cruise_opt_res_count = count($cruise_opt_res);
												if ($cruise_opt_res_count != "0") 
												{
													foreach ($cruise_opt_res as $cruise_opt)
													{
														$rep_id = $cruise_opt->cruise_response_id;
														$opt_detail = "SELECT * FROM cruise_ship_cruise WHERE ship_id = '$rep_id'";
														$opt_detail_res = $mydb->get_results($opt_detail);
														$opt_detail_res_count = count($opt_detail_res);
														if ($opt_detail_res_count != "0") 
														{
															$style = "display: block";
														}
														else
														{
															$style = "display: none";
														}
													}
												}*/

												$cruise_opt = "SELECT cruise_response_id FROM cruise_cruise WHERE cruise_operator_name LIKE '$opet_name'";
												$cruise_opt_res = $mydb->get_results($cruise_opt);
												$cruise_opt_res_count = count($cruise_opt_res);
												if ($cruise_opt_res_count != "0") 
												{
													foreach ($cruise_opt_res as $cruise_opt)
													{
														$rep_id = $cruise_opt->cruise_response_id;
														$opt_detail = "SELECT * FROM cruise_ship_cruise WHERE ship_id = '$rep_id'";
														$opt_detail_res = $mydb->get_results($opt_detail);
														$opt_detail_res_count = count($opt_detail_res);
														if ($opt_detail_res_count != "0") 
														{
															$style = "display: block";
														}
														else
														{
															$style = "display: none";
														}
													}
												}
												if($style == "display: block"){
								?>

							        <p style="float: left;width: 24%; <?php echo $style; ?>">
								        <input type='checkbox' <?php if (in_array($static_tour[$i]->operator_title, $op_temp_nm)) { echo "checked"; } ?> value="<?php echo $static_tour[$i]->operator_title; ?>" id="iflair_tour_operator_id<?php echo $i; ?>" name="iflair_tour_operator_id[]">
								        <label for="iflair_tour_operator_id<?php echo $i; ?>"><?php echo $static_tour[$i]->operator_title; ?></label>
							    	</p>
							 <?php
							     } } } }
							?>
						</td>
					</tr>
					<tr>
						<td></td>
						<td>
							<input type="submit" name="iflair_save_tour" id="submit" class="button button-primary" value="Save Changes" />
						</td>
					</tr>
				</tbody>
			</table>
		</form>
	</div>
<?php
}