<link rel="stylesheet" type="text/css" href="<?php echo CRUISE_OFFER_PLUGIN_URL; ?>/css/bootstrap.min.css">
<div class="msg_back">
	<div id="msg_box"></div>
</div>
<div class="wrap">
	<input type="hidden" value="add" name="tag_attr" id="tag_attr" class="tag_attr col-sm-12" />
	<h1>Tag Management</h1>
	<div class="add_edit_tag"><br>
		<div class="row">
			<div class="col-sm-2">Tag Name :- </div>
			<div class="col-sm-6">
				<input type="text" value="" name="tag_name" id="tag_name" class="tag_name col-sm-12" />
			</div>
			<div class="col-sm-4"><!-- <a onclick="save_tag();" class="button button-primary button-large">Add / Edit</a> --><input class="button button-primary button-large" type="submit" onclick="save_tag();" value="Add / Edit" /></div>
		</div>
	</div>

	<hr>
	<br>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">
	<div class="tag_list_box">
		<table id="data_tag" class="display" cellspacing="0" width="100%">
	        <thead>
	            <tr>
	                <th>#</th>
	                <th>Tag Name</th>
	                <th>Shortcode</th>
	                <th>Assigned Cruises</th>
	                <th>Action</th>
	            </tr>
	        </thead>
	        <tbody>
        	<?php
            	$tag_r = $wpdb->get_results("SELECT * FROM ".$tag_tbl." WHERE tag_status = '1' ");
            	/*echo "<pre>";
            	print_r($tag_r);
            	echo "</pre>";*/
            	if(!empty($tag_r)){
            		for ($tag_i=0; $tag_i < count($tag_r) ; $tag_i++) { 
            			$tag_id = $tag_r[$tag_i]->tag_id;
            			$tag_name = $tag_r[$tag_i]->tag_name;
            			$tag_slug = $tag_r[$tag_i]->tag_slug;
			        	?>
				            <tr>
				                <td><?php echo $tag_i+1; ?></td>
				                <td><?php echo $tag_name; ?></td>
				                <td> [taged-cruise tagname='<?php echo $tag_name; ?>'] </td>
				                <td>Arrived in few time</td>
				                <td><a href="javascript:void(0);" onclick="edit_tag('<?php echo $tag_slug; ?>','<?php echo $tag_name; ?>')" >Edit</a> || <a href="javascript:void(0);" onclick="delete_tag('<?php echo $tag_name; ?>','<?php echo $tag_id; ?>')" >Delete</a></td>
				            </tr>
			            <?php
        			}
            	}
            ?>
	        </tbody>
		</table>
	</div>
</div>
<script type="text/javascript">
	jQuery(document).ready(function() {
	    jQuery('#data_tag').DataTable();
		jQuery("#tag_attr").val("add");
		jQuery("#tag_name").val("");
	} );
	function save_tag() {
		var tag_name = jQuery("#tag_name").val();
		var tag_attr = jQuery("#tag_attr").val();
		if(tag_name == ""){
			//alert("Tag name must be not empty!");
		  	jQuery(".msg_back").fadeIn();
		  	jQuery("#msg_box").slideDown();
			jQuery("#msg_box").html("Tag name must be not empty!");
			jQuery("#tag_name").focus();
			jQuery("#tag_name").css("box-shadow","1px 1px 1px #FF0909");
		}
		else{
			jQuery("#tag_name").css("box-shadow","1px 1px 1px #ffffff");
			jQuery.ajax({
			  type: "POST",
			  url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
			  data: ({
			      action: 'save_tag',
			      tag_attr:tag_attr,
			      tag_name:tag_name
			  }),
			  success: function (response) {
			  	//alert(response);
			  	jQuery(".msg_back").fadeIn();
			  	jQuery("#msg_box").slideDown();
			  	jQuery("#msg_box").html(response);
				window.location.reload();
			  }
			});
		}
	}

	function edit_tag(slug,name) {
		var tag_slug = slug;
		var tag_name = name;
		jQuery("#tag_attr").val(tag_slug);
		jQuery("#tag_name").val(tag_name);
		jQuery("#tag_name").focus();
	}

	function delete_tag(tag_name,tag_id) {
		var r = confirm("Are you sure want to delete '"+tag_name+"' tag!");
		if (r == true) {
			jQuery.ajax({
			  type: "POST",
			  url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
			  data: ({
			      action: 'delete_tag',
			      tag_id:tag_id,
			      tag_name:tag_name
			  }),
			  success: function (response) {
			  	jQuery(".msg_back").fadeIn();
			  	jQuery("#msg_box").slideDown();
				jQuery("#msg_box").html("Tag deleted Successfully.");
				window.location.reload();
			  }
			});
		} else {
		  	jQuery(".msg_back").fadeIn();
		  	jQuery("#msg_box").slideDown();
			jQuery("#msg_box").html("Tag not deleted!");
		}
	}

	jQuery(".msg_back").click(function(){
		//alert("Yes");
		jQuery(".msg_back").fadeOut();
		jQuery("#msg_box").slideUp();
	});
</script>
<Style>
.msg_back {
  height: 100%;
  left: 0;
  position: fixed;
  top: 0;
  width: 100%;
  z-index: 90000;
  display: none;
  background: rgba(0, 0, 0, 0.3) none repeat scroll 0 0;
}
#msg_box {
  border: 1px solid green;
  border-radius: 10px;
  box-shadow: 5px 5px 20px #ccc;
  font-size: 19px;
  left: 40%;
  padding: 30px 50px;
  position: absolute;
  top: 20px;
  background: #fff none repeat scroll 0 0;
}
</Style>