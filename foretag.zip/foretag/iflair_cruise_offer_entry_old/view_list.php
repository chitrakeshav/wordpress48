<?php
  global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
  $mainsiteprefix='cm_';
  $agentsiteurl=get_option('siteurl');
  $agentsitedetail=iflair_get_subsite_id($agentsiteurl);
  $agentsiteid=$agentsitedetail->id;
  $agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
  $agent_assign_operator;

/*$query = "SELECT * FROM ".$wpdb->prefix."quote_extra_offer"." ORDER BY id DESC";
$list_res = $wpdb->get_results($query);
$list_res_count = count($list_res);*/
?>
<div class="wrap">
  <h1>View Offers </h1>

<?php
$per_page_list = 10;
if(isset($_GET['paged'])){
	$crnt_page = $_GET['paged'];
}
else{
	$crnt_page = 1;
}
	$start_page = ($crnt_page-1)*$per_page_list;

$prop_list_q = "";
$prop_list_q .= "SELECT * FROM ".$wpdb->prefix."quote_extra_offer"."";
$prop_list_q .= " ORDER BY id DESC";
$list_res_all = $wpdb->get_results($prop_list_q);
$list_res_count_all = count($list_res_all);

$last_page = $list_res_count_all/$per_page_list;

$prop_list_q .= " LIMIT ".$start_page.",".$per_page_list."";
$list_res = $wpdb->get_results($prop_list_q);
$list_res_count = count($list_res);
?>
<form action="" name="frm_ag_property" id="frm_ag_property" class="frm_ag_property" method="get" enctype="multipart/form-data">
	<div class="tablenav top">
		<div class="tablenav-pages">
		<span class="displaying-num"><?php echo $list_res_count_all; ?> items</span>
			<?php 
			if($list_res_count>0 && ( $list_res_count_all != $list_res_count)){
			?>
				<span class="pagination-links">
					<a class="first-page <?php if($_GET['paged']<2){ echo "disabled"; } ?>" <?php if($_GET['paged']<2){}else{ echo 'href="admin.php?page=iflair_view_offers&paged=1"'; } ?> title="Go to the first page">«</a>
					
					<a class="prev-page <?php if($_GET['paged']<2){ echo "disabled"; } ?>" <?php if($_GET['paged']<2){}else{ echo 'href="admin.php?page=iflair_view_offers&paged='.($crnt_page-1).'"'; } ?> title="Go to the previous page">‹</a>
					
					<span class="paging-input">
						<label class="screen-reader-text" for="current-page-selector">Select Page</label>
							<!-- <input id="current-page-selector" class="current-page" type="text" size="1" value="<?php //echo $crnt_page; ?>" name="paged" title="Current page"> -->
							<?php echo $crnt_page; ?>
						of
						<span class="total-pages"><?php echo ceil($last_page); ?></span>
					</span>

					<a class="next-page <?php if($_GET['paged']>=ceil($last_page)){ echo "disabled"; } ?>" <?php if($_GET['paged']>=ceil($last_page)){}else{ echo 'href="admin.php?page=iflair_view_offers&paged='.($crnt_page+1).'"'; } ?> title="Go to the next page">›</a>
					
					<a class="last-page <?php if($_GET['paged']>=ceil($last_page)){ echo "disabled"; } ?>" <?php if($_GET['paged']>=ceil($last_page)){}else{ echo 'href="admin.php?page=iflair_view_offers&paged='.ceil($last_page).'"'; } ?> title="Go to the last page">»</a>
				</span>
			<?php
			}
			?>
		</div>
	</div>
</form>



  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

	<table class="wp-list-table widefat fixed striped pages">
	   <thead>
	      <tr>
	         <td width="60"></td>
	         <th width="400">Package Title</th>
	         <th>Amount Per Person</th>
	         <th>Dates</th>
	         <th>Package Summery</th>
	         <th width="150">Status</th>
	      </tr>
	   </thead>
	   <tbody id="the-list">
<?php
for ($ol=0; $ol < $list_res_count ; $ol++) { 
    //echo "SELECT csc.ship_id FROM cruise_ship_cruise as csc INNER JOIN cruise_cruise as cc ON csc.ship_id=cc.cruise_response_id WHERE csc.cruise_id = ".$list_res[$ol]->cruise_id."";
    $find_status = $mydb->get_row("SELECT csc.ship_id FROM cruise_ship_cruise as csc INNER JOIN cruise_cruise as cc ON csc.ship_id=cc.cruise_response_id WHERE csc.cruise_id = '".$list_res[$ol]->cruise_id."'");
    //print_r($find_status);
	?>
	      <tr id="del_<?php echo $list_res[$ol]->cruise_id; ?>">
	         <th>
	            <?php //echo $ol+1; ?>
	            <?php if($list_res_count_all != $list_res_count){ echo ($ol-9)+($per_page_list*$crnt_page); }else{ echo $ol+1; } ?>
	         </th>
	         <td>
	            <strong><?php echo $list_res[$ol]->extra_info; ?></strong>
				<div class="row-actions">
					<?php
					if(!empty($find_status)){
					?>
					<span class="view"><a title="Edit this item" type="button" data-toggle="modal" data-target="#myModal<?php echo $list_res[$ol]->cruise_id; ?>" onclick="cruise_offer_list('<?php echo $list_res[$ol]->cruise_id; ?>');" >Edit</a></span> | 
					  <!-- Modal -->
					  <div class="modal fade" id="myModal<?php echo $list_res[$ol]->cruise_id; ?>" role="dialog">
					    <div class="modal-dialog modal-lg">
					    
					      <!-- Modal content-->
					      <div class="modal-content">
					        <div class="modal-header">
					          <button type="button" class="close" data-dismiss="modal">&times;</button>
					          <h4 class="modal-title" style="color: black;"><?php echo $list_res[$ol]->extra_info; ?></h4>
					        </div>
					        <div class="modal-body">
					        <img style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 44%; " src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader.gif" class="loader">
					          <div id="<?php echo $list_res[$ol]->cruise_id; ?>">
					          </div>
					        </div><!-- 
					        <div class="modal-footer">
					          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					        </div> -->
					      </div>
					      
					    </div>
					  </div>
					<?php } ?>
						<span class="view"><a title="Delete this item" type="button" onclick="cruise_offer_delete('<?php echo $list_res[$ol]->cruise_id; ?>');" >Delete</a></span>
				</div>
	         </td>
	         <td>
	            <?php echo $list_res[$ol]->offer_price; ?>
	         </td>
	         <td>
	            <?php echo "Departure Date : ".$list_res[$ol]->departure_date."<br>"; ?>
	            <?php echo "Start Date : ".$list_res[$ol]->offer_start_date."<br>"; ?>
	            <?php echo "End Date : ".$list_res[$ol]->offer_end_date.""; ?>
	         </td>
	         <td>
	            <?php echo $list_res[$ol]->package_summary; ?>
	         </td>
	         <td>
	            <?php
 	            if(!empty($find_status)){
 	            	$curdate=strtotime(date("Y/m/d"));
					$startdate=strtotime($list_res[$ol]->offer_start_date);
					$enddate=strtotime($list_res[$ol]->offer_end_date);

					if($curdate <= $enddate && $curdate >= $startdate )
					{
	 	            	echo "<p style='color:green;'>Active</p>";
	 	            }
	 	            else{
	            		echo "Deactivated";
	 	            }
	            }
	            else{
	            	echo "Deactivated";
	            }
	            ?>
	         </td>
	      </tr>
<?php
}
?>
	   </tbody>
	</table>
  <script type="text/javascript">
    function cruise_offer_list(str){
      var id = str;
      //alert(id);
        jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'cruise_offer_entry_form_ajax_res',
                id : id
            }),
            success: function (response) {
                jQuery('.loader').css('display','none');
                jQuery('#'+id).html(response);
            }
        });
    }
    function cruise_offer_delete(str){
		var id = str;
		var txt;
		var r = confirm("Confirm To Delete!");
		if (r == true) {
      		//alert(id);
	        jQuery.ajax({
	            type: "POST",
	            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
	            data: ({
	                action: 'cruise_offer_delete_res',
	                id : id
	            }),
	            success: function (response) {
	            	jQuery('#del_'+id).addClass("del_class");
	            	jQuery('#del_'+id).html(response);
	                //jQuery('.loader').css('display','none');
	                //jQuery('#'+id).html(response);
	            }
	        });
		} else {
		    txt = "Offer Not Deleted.";
		    alert(txt);
		}
    }
    jQuery(document).ready(function (){
    	jQuery('.modal').on('hidden.bs.modal', function () {
		window.location.reload();
		})

		jQuery(document).on('click', '.addnew', function(){
      /*var  num = jQuery(this).parent().parent().parent().parent().find('.newadd').length;*/
      /*alert(num);*/
      var ParentId = jQuery(this).parents().find(".cruse-information").attr("id");
      var num     = jQuery('#'+ParentId+' .newadd').length;
      var newNum  = new Number(num + 1);
      var controldiv = jQuery('.controls'),
      currentEntry = jQuery(this).parents('.newadd:first'),
      newEntry = jQuery(currentEntry.clone()).appendTo(controldiv);
      var temp = jQuery('.hidden_date').val();
      var newNum  = parseInt(temp) + 1;
      jQuery('.hidden_date').val(newNum);

      newEntry.find('input[type=text]').val('');
      newEntry.find('.custom_date').removeClass('hasDatepicker');
      newEntry.find('.custom_date').attr('id', 'custom_date_' + newNum);

      
      newEntry.find('textarea').val('');
      newEntry.find('.hiddneid').val('');
      newEntry.find('.addnew').removeClass('con_delete');
      newEntry.find('.p_port_name').attr('id', 'p_port_name' + newNum);
      controldiv.find('.newadd:not(:first) .addnew')
          .removeClass('addnew').addClass('removenew')
          .val('remove');
      }).on('click', '.removenew', function(e)
      {
          if(jQuery(this).hasClass('con_delete')){
              var hidid = jQuery(this).parent().find('.hiddneid').val();
              
              if(confirm('Are you sure you want to remove?'))
              {
                  jQuery(this).parents('.newadd:first').remove();
                  var newNum = jQuery('.newadd').length;
                  e.preventDefault();
                  return false;
              }
          }
          else{
              jQuery(this).parents('.newadd:first').remove();
              var newNum = jQuery('.newadd').length;
              e.preventDefault();
              return false;
          }
      });
    })
  </script>
</div>
<style type="text/css">
.del_class{
	background: red;
  opacity: 0.8;
  -webkit-transition: all 1s ease-in-out;
  -moz-transition: all 1s ease-in-out;
  -o-transition: all 1s ease-in-out;
  transition: all 1s ease-in-out;
  /*transform: scale(0.0);
  -webkit-transform: scale(0.0);
  -moz-transform: scale(0.0);
  -o-transform: scale(0.0);*/
}
.offer_entry_table {
    width: 100% !important;
}
.main_info .leftsidetb {
    width: 100% !important;
}
.main_info {
    width: 100% !important;
}
.extra_info {
    display: none;
}
#resetform{
	display: none;
}
</style>