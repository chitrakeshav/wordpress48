<?php
global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
$mainsiteprefix='cm_';
$agentsiteurl=get_option('siteurl');
$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
$agentsiteid=$agentsitedetail->id;
$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
$agent_assign_operator;

$region = $_POST['region'];
$ship_id = $_POST['ship_id'];
$departure_date = $_POST['departure_date'];

$package_offer_query_unlimit = "";
$package_offer_query_unlimit .= "SELECT ship_id,cruise_id,extra_info,cruise_nights,offer_price,departure_date FROM ".$wpdb->prefix."quote_extra_offer WHERE offer_start_date < curdate() and offer_end_date > curdate() ";
if($region!="" ){
	$package_offer_query_unlimit .= " AND ship_region = '".$region."'";
}
if( $ship_id!="" ){
	$package_offer_query_unlimit .= " AND ship_id = '".$ship_id."'";
}
if( $departure_date!="" ){
	$package_offer_query_unlimit .= " AND departure_date LIKE '%".$departure_date."%'";
}
//echo $package_offer_query_unlimit;
$package_offer_query = $package_offer_query_unlimit." LIMIT $start,$per_page";
//echo $offer_query = "SELECT offer_price,package_summary,cabin_info FROM ".$wpdb->prefix."quote_extra_offer WHERE offer_start_date < curdate() and offer_end_date > curdate() ";
//echo $package_offer_query;
$package_offer = $wpdb->get_results($package_offer_query);

$detail_page_id = get_site_option( 'iflair_cruise_theme_ship_detail_page' );

?>

  <div class="loader" style="display:none;">
    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader.gif">
  </div>
<?php
	
	if(count($package_offer) == 0)
	{
		echo "<div class='no_offer_area'>No Offers Found ..<div>";
	}
	else
	{
		package_offer_pagging($page,$per_page,$package_offer_query_unlimit);
		echo "<div class='package_offer_box'>";
		for($i=0;$i<count($package_offer);$i++)
		{
			$cruise_query = $mydb->get_row("SELECT cruise_profile_image_href,cruise_cover_image_href FROM cruise_cruise WHERE cruise_response_id = '".$package_offer[$i]->ship_id."'");
			/*echo "<pre>";
			print_r($package_offer[$i]);
			print_r($cruise_query);
			echo "</pre>";*/
			?>
			<div class="offer_main_box">
				<div class="offer_main_box_area">
				<div class="offer_box_one">
					<a href="<?php echo get_page_link($detail_page_id);?>?cruise_id=<?php echo $package_offer[$i]->cruise_id; ?>">
					<img src="http://ekups3e.cloudimg.io/s/crop/300x200/<?php echo str_replace("//www","www",$cruise_query->cruise_cover_image_href); ?>">
					</a>
				</div>
				<div class="offer_box_two">
					<h2><?php echo $package_offer[$i]->extra_info; ?></h2>
					<!-- <h2><?php //echo $package_offer[$i]->departure_date; ?></h2> -->
					<div class="offer_box_two_image"><img src="http://ekups3e.cloudimg.io/s/resize/300/<?php echo str_replace("//www","www",$cruise_query->cruise_profile_image_href); ?>"></div>
				</div>
				<?php
				if( $package_offer[$i]->cruise_nights == "" || $package_offer[$i]->cruise_nights == "0" )
				{
					$cruise_nights_list = "";
					$cruise_nights_grid = "";
				}
				else{
					//$cruise_nights_list = '<span>'.$package_offer[$i]->cruise_nights.' nights</span> ';
					//$cruise_nights_grid = '<p>'.$package_offer[$i]->cruise_nights.' nights</p>';
					$cruise_nights_list = "";
					$cruise_nights_grid = "";
				}
				?>
				<div class="offer_box_three">
					<div class="grid_text">
						<?php echo $cruise_nights_list; ?><p>from</p> <span>£<?php echo number_format($package_offer[$i]->offer_price); ?></span> <p>PP</p>
					</div>
					<div class="list_text">
						<p>from</p>
						<?php echo $cruise_nights_grid; ?>
						<span>£<?php echo number_format($package_offer[$i]->offer_price); ?></span><p>Per Person</p><a href="<?php echo get_page_link($detail_page_id);?>?cruise_id=<?php echo $package_offer[$i]->cruise_id; ?>">Details</a>
					</div>
				</div>
				</div>
			</div>
			<?php
		}
		echo "</div>";
		package_offer_pagging($page,$per_page,$package_offer_query_unlimit);
	}
	?>

<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery("#pagination li").click(function(){
			jQuery('.loader').css('display','block');
			var pageNum = this.id;
			var perpage = <?php echo $per_page; ?>;
			var ship_id = jQuery('#offer_ship').val();
			var region = jQuery('#offer_region').val();

			    jQuery.ajax({
		            type: "POST",
		            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
		            data: ({
		                action: 'package_offer_response',
		                ship_id:ship_id,
		                region:region,
		                pagenumb:pageNum,
		                perpage:perpage
		            }),
		            success: function (response) {
		                //alert(response);
		                jQuery('.offer_result').html(response);
					    jQuery('.loader').css('display','none');
		            }
		        });
			
		});
	});
</script>
