<?php
/*
Plugin Name: iFlair Cruise Offer Entry
Plugin URI: http://www.iflair.com/
Description: This Plugin will show cruie property assigned to you.
Author: Maulik Panchal
Version: 1.0
Author URI: http://www.iflair.com/
*/
global $wpdb;
define( 'DETAIL_PAGE',esc_url(home_url('/'))."ship-detail");
define( 'CRUISE_OFFER_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CRUISE_OFFER_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define('QUOTE_EXTRA_OFFER',$wpdb->prefix."quote_extra_offer");
define('QUOTE_EXTRA_OFFER_IMAGES',$wpdb->prefix."quote_extra_offer_images");
$tag_tbl = $wpdb->prefix."tag_management";
add_action('wp_ajax_save_tag', 'save_tag'); // Logged-in users
add_action('wp_ajax_nopriv_save_tag', 'save_tag'); // Guest users
add_action('wp_ajax_delete_tag', 'delete_tag'); // Logged-in users
add_action('wp_ajax_nopriv_delete_tag', 'delete_tag'); // Guest users

/* MK Aded New cruise search */
add_action('wp_ajax_iflair_cruise_filter_response_offer', 'iflair_cruise_filter_response_offer'); // Logged-in users
add_action('wp_ajax_nopriv_iflair_cruise_filter_response_offer', 'iflair_cruise_filter_response_offer'); // Guest users
add_action('wp_ajax_iflair_search_filter_response_offer', 'iflair_search_filter_response_offer'); // Logged-in users
add_action('wp_ajax_nopriv_iflair_search_filter_response_offer', 'iflair_search_filter_response_offer'); // Guest users
add_action('wp_ajax_iflair_cruise_detail_offer', 'iflair_cruise_detail_offer'); // Logged-in users
add_action('wp_ajax_nopriv_iflair_cruise_detail_offer', 'iflair_cruise_detail_offer'); // Guest users

add_action('wp_ajax_cruise_offer_entry_form_ajax_res', 'cruise_offer_entry_form_ajax_res'); // Logged-in users
add_action('wp_ajax_nopriv_cruise_offer_entry_form_ajax_res', 'cruise_offer_entry_form_ajax_res'); // Guest users

add_action('wp_ajax_iflair_crusie_save_offer_ajax_res', 'iflair_crusie_save_offer_ajax_res');
//add_action('wp_ajax_nopriv_iflair_crusie_save_offer_ajax_res', 'iflair_crusie_save_offer_ajax_res'); // Guest users
add_action( 'admin_menu', 'iflair_cruise_offer_entry_listing' );
//wp_enqueue_script('jquery-ui-datepicker');

add_action('wp_ajax_package_offer_response', 'package_offer_response'); // Logged-in users
add_action('wp_ajax_nopriv_package_offer_response', 'package_offer_response'); // Guest users

add_action('wp_ajax_package_offer_filter', 'package_offer_filter'); // Logged-in users
add_action('wp_ajax_nopriv_package_offer_filter', 'package_offer_filter'); // Guest users

add_action('wp_ajax_cruise_offer_delete_res', 'cruise_offer_delete_res'); // Logged-in users
add_action('wp_ajax_nopriv_cruise_offer_delete_res', 'cruise_offer_delete_res'); // Guest users

add_action('wp_ajax_package_offer_right', 'package_offer_right'); // Logged-in users
add_action('wp_ajax_nopriv_package_offer_right', 'package_offer_right'); // Guest users


function iflair_cruise_offer_entry_listing(){
  global $wpdb,$tag_tbl;
  add_menu_page('iFlair Cruise Offer', 'iFlair Cruise Offer', 'manage_options', 'iflair-cruise-offer' , 'iflair_cruise_offer_entry');

  add_submenu_page( 'iflair-cruise-offer', 'View Offers', 'View Offers',
    'manage_options', 'iflair_view_offers', 'iflair_view_offers');

  add_submenu_page( 'iflair-cruise-offer', 'Tag Management', 'Tag Management',
    'manage_options', 'iflair_tag_management', 'iflair_tag_management');
  $tag_q_1 = "CREATE TABLE IF NOT EXISTS ".$tag_tbl." (
    `tag_id` int(11) NOT NULL,
    `tag_name` varchar(255) NOT NULL,
    `tag_slug` varchar(255) NOT NULL,
    `tag_status` int(11) NOT NULL,
    `tag_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;";
  $tag_q_2 = "ALTER TABLE ".$tag_tbl."
    ADD PRIMARY KEY (`tag_id`),
    ADD UNIQUE KEY `tag_name` (`tag_name`),
    ADD UNIQUE KEY `tag_slug` (`tag_slug`);";
  $tag_q_3 = "ALTER TABLE ".$tag_tbl."
    MODIFY `tag_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;";
  $tag_r_1 = $wpdb->get_results($tag_q_1);
  $tag_r_2 = $wpdb->get_results($tag_q_2);
  $tag_r_3 = $wpdb->get_results($tag_q_3);

  /*$query1 = "CREATE TABLE IF NOT EXISTS `cc_quote_extra_offer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ship_id` int(11) NOT NULL,
  `cruise_id` varchar(55) NOT NULL,
  `ship_region` varchar(255) DEFAULT NULL,
  `cruise_type` varchar(55) DEFAULT NULL,
  `departure_date` date DEFAULT NULL,
  `offer_start_date` date DEFAULT NULL,
  `offer_end_date` date DEFAULT NULL,
  `description` text,
  `cabin_info` varchar(255) DEFAULT NULL,
  `offer_price` int(11) DEFAULT NULL,
  `extra_info` varchar(55) DEFAULT NULL,
  `package_summary` varchar(55) DEFAULT NULL,
  `vacation_days` int(25) DEFAULT NULL,
  `cruise_nights` int(25) DEFAULT NULL,
  `post_cruise` varchar(255) DEFAULT NULL,
  `embark_at` varchar(255) DEFAULT NULL,
  `disembark_at` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `ports_visited` varchar(255) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `updated_date` date DEFAULT NULL,
  PRIMARY KEY (id)
  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;";
  $wpdb->query($query1);*/

  $query2 = "CREATE TABLE IF NOT EXISTS `cc_quote_extra_offer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ship_id` int(11) NOT NULL,
  `cruise_id` varchar(55) NOT NULL,
  `ship_region` varchar(255) NOT NULL,
  `cruise_type` varchar(55) DEFAULT NULL,
  `departure_date` date DEFAULT NULL,
  `offer_start_date` date DEFAULT NULL,
  `offer_end_date` date DEFAULT NULL,
  `description` text,
  `cabin_info` varchar(255) DEFAULT NULL,
  `offer_price` int(11) DEFAULT NULL,
  `extra_info` varchar(55) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `package_summary` varchar(255) DEFAULT NULL,
  `vacation_days` int(25) DEFAULT NULL,
  `cruise_nights` int(25) DEFAULT NULL,
  `post_cruise` varchar(255) DEFAULT NULL,
  `embark_at` varchar(255) DEFAULT NULL,
  `disembark_at` varchar(255) DEFAULT NULL,
  `ports_visited` varchar(255) DEFAULT NULL,
  `content_title` varchar(255) NOT NULL,
  `content_before_image` varchar(255) NOT NULL,
  `content_after_image` varchar(255) NOT NULL,
  `created_date` date DEFAULT NULL,
  `updated_date` date DEFAULT NULL,
  PRIMARY KEY (id)
  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1";
  $wpdb->query($query2);

  $query2 = "CREATE TABLE IF NOT EXISTS `cc_quote_extra_offer_images` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `cruise_id` varchar(255) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `image_title` varchar(255) NOT NULL,
  `image_caption` varchar(255) NOT NULL,
  PRIMARY KEY (image_id)
  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1";
  $wpdb->query($query2);
}

function iflair_cruise_offer_entry(){
wp_register_style( 'cruisePluginStylesheet', plugins_url('css/offer_entry_style.css', __FILE__) );
wp_enqueue_style( 'cruisePluginStylesheet' );
wp_enqueue_script( 'cruisePluginScript', CRUISE_OFFER_PLUGIN_URL . 'js/1.11.2jquery.min.js', array(), '1.0.0', true );
//wp_enqueue_script( 'cruisePluginScript1', CRUISE_OFFER_PLUGIN_URL . 'js/cookie.js', true );
wp_enqueue_script( 'cruisePluginScript2', CRUISE_OFFER_PLUGIN_URL . 'js/jquery.mCustomScrollbar.concat.min.js', array(), '1.0.0', true );
?>
    <?php
  global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
  $mainsiteprefix='cm_';
  $agentsiteurl=get_option('siteurl');
  $agentsitedetail=iflair_get_subsite_id($agentsiteurl);
  $agentsiteid=$agentsitedetail->id;
  $agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
  $agent_assign_operator;

  ?>
  
  <div class="loader" style="display:none;">
    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader.gif" style="position: absolute; left: 50%;">
  </div>
  <h2>Cruise Search Offer Entry</h2>
  <div class="input-form wrraper clearfix">
    <div class="container clearfix">
	    <div class="form-field">
	  	</div>
  <div id="replace_query_ajax">
  </div>

<script>

jQuery( document ).ready(function() {

	jQuery('.loader').css('display','block');
	var pagenumb = 1;
	    jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'iflair_search_filter_response_offer',
                pagenumb:pagenumb
            }),
            success: function (response) {
				jQuery('.input-form').slideDown();
            	jQuery('.loader').css('display','none');
                jQuery('.form-field').html(response);
				//jQuery('.form-field').css('border','1px solid rgb(185, 181, 181)');
            }
        });


        
      //jQuery.cookie('str1', '', {expires: 1 });
      //jQuery.cookie('str2', '', {expires: 1 });

      jQuery('#iflair_cruise_region').prop('selectedIndex',0);
      jQuery('#iflair_cruise_operator').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_fly_in').prop('selectedIndex',0);
      jQuery('#iflair_cruise_leaving_from').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);

      //jQuery('#extra_info').limit('50','#charsLeft');

      jQuery(document).on('click', '.addnew', function(){
      /*var  num = jQuery(this).parent().parent().parent().parent().find('.newadd').length;*/
      /*alert(num);*/
      var ParentId = jQuery(this).parents().find(".cruse-information").attr("id");
      var num     = jQuery('#'+ParentId+' .newadd').length;
      var newNum  = new Number(num + 1);
      var controldiv = jQuery('.controls'),
      currentEntry = jQuery(this).parents('.newadd:first'),
      newEntry = jQuery(currentEntry.clone()).appendTo(controldiv);
      var temp = jQuery('.hidden_date').val();
      var newNum  = parseInt(temp) + 1;
      jQuery('.hidden_date').val(newNum);

      newEntry.find('input[type=text]').val('');
      newEntry.find('.custom_date').removeClass('hasDatepicker');
      newEntry.find('.custom_date').attr('id', 'custom_date_' + newNum);

      
      newEntry.find('textarea').val('');
      newEntry.find('.hiddneid').val('');
      newEntry.find('.addnew').removeClass('con_delete');
      newEntry.find('.p_port_name').attr('id', 'p_port_name' + newNum);
      controldiv.find('.newadd:not(:first) .addnew')
          .removeClass('addnew').addClass('removenew')
          .val('remove');
      }).on('click', '.removenew', function(e)
      {
          if(jQuery(this).hasClass('con_delete')){
              var hidid = jQuery(this).parent().find('.hiddneid').val();
              
              if(confirm('Are you sure you want to remove?'))
              {
                  jQuery(this).parents('.newadd:first').remove();
                  var newNum = jQuery('.newadd').length;
                  e.preventDefault();
                  return false;
              }
          }
          else{
              jQuery(this).parents('.newadd:first').remove();
              var newNum = jQuery('.newadd').length;
              e.preventDefault();
              return false;
          }
      });

       
    });

    function resetForm()
    {
      
      //document.getElementById("offer_entry").reset();
      //jQuery("#departure_date_new").val('');
      jQuery("#start_date").val('');
      jQuery("#end_date").val('');
      jQuery("#vacation_days").val('');
      jQuery("#cruise_nights").val('');
      jQuery("#post_cruise").val('');
      jQuery("#embark_at").val('');
      jQuery("#disembark_at").val('');
      jQuery("#contact_number").val('');
      jQuery("#ports_visited").val('');
      jQuery(".package_summary").val('');
      jQuery("#quote_description").val('');
      jQuery("#extra_info").val('');
      jQuery("#cabin_info").val('');
      jQuery("#offer_price").val('');
      jQuery(".package_summary").val('');
    }  
    function iflair_search_filter_response_offer(str){
      var pagenumb='1';
      var check = str;
      var region = jQuery('#iflair_cruise_region').val();
      var operator = jQuery('#iflair_cruise_operator').val();
      var cruise_ship = jQuery('#iflair_cruise_ship').val();
      var ship_fly_in = jQuery('#iflair_cruise_ship_fly_in').val();
      var leaving_from = jQuery('#iflair_cruise_leaving_from').val();
      var ship_starts_on = jQuery('#iflair_cruise_ship_starts_on').val();
      var ship_vacation_days = jQuery('#iflair_cruise_ship_vacation_days').val();
      if(check=="reset"){
        jQuery('#iflair_cruise_region').prop('selectedIndex',0);
        jQuery('#iflair_cruise_operator').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_fly_in').prop('selectedIndex',0);
        jQuery('#iflair_cruise_leaving_from').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
          jQuery('.loader_filt').css('display','block');

        //jQuery.cookie('str1', '', {expires: 1 });
        //jQuery.cookie('str2', '', {expires: 1 });

        return false;
      }
      if(check=="region"){
        jQuery('#iflair_cruise_operator').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_fly_in').prop('selectedIndex',0);
        jQuery('#iflair_cruise_leaving_from').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
        jQuery('.loader_filt').css('display','block');
          //iflair_search_filter_response_offer();
      }
      if(check=="operator"){
        jQuery('#iflair_cruise_ship').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_fly_in').prop('selectedIndex',0);
        jQuery('#iflair_cruise_leaving_from').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
        jQuery('.loader_filt').css('display','block');
          //iflair_search_filter_response_offer();
      }
      if(check=="cruise_ship"){
        jQuery('#iflair_cruise_ship_fly_in').prop('selectedIndex',0);
        jQuery('#iflair_cruise_leaving_from').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
        jQuery('.loader_filt').css('display','block');
          //iflair_search_filter_response_offer();
      }
      if(check=="ship_fly_in"){
        jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
        jQuery('.loader_filt').css('display','block');
          //iflair_search_filter_response_offer();
      }
      if(check=="leaving_from"){
        jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
        jQuery('.loader_filt').css('display','block');
          //iflair_search_filter_response_offer();
      }
      if(check=="ship_starts_on"){
        jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
        jQuery('.loader_filt').css('display','block');
          //iflair_search_filter_response_offer();
      }
      if(check=="ship_vacation_days"){
          //iflair_search_filter_response_offer();
        jQuery('.loader_filt').css('display','block');
      }
      if(check=="search"){
        
         // jQuery.cookie('str1', '', {expires: 1 });
      	  //jQuery.cookie('str2', '', {expires: 1 });

        jQuery('.loader').css('display','block');
        jQuery('.search_header').addClass('searched');
        jQuery('.search_header').addClass('searched_image');
        jQuery('#replace_query_ajax').addClass('replace_query_class');
        iflair_cruise_filter_response_offer();

      }
      //alert(str);
      jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'iflair_search_filter_response_offer',
                region: region,
                operator: operator,
                cruise_ship: cruise_ship,
                ship_fly_in: ship_fly_in,
                leaving_from: leaving_from,
                ship_starts_on: ship_starts_on,
                ship_vacation_days: ship_vacation_days,
                pagenumb:pagenumb
            }),
            success: function (response) {
              //jQuery('.loader').css('display','none');
              jQuery('.loader_filt').css('display','none');
              //alert(response);
              jQuery('.form-field').html(response);
              //jQuery(".content").mCustomScrollbar();
            }
        });
        //iflair_cruise_filter_response_offer();
    }

    function iflair_cruise_filter_response_offer(){
      jQuery('.loader').css('display','block');
      var pagenumb='1';
      var region = jQuery('#iflair_cruise_region').val();
      var operator = jQuery('#iflair_cruise_operator').val();
      var cruise_ship = jQuery('#iflair_cruise_ship').val();
      var ship_fly_in = jQuery('#iflair_cruise_ship_fly_in').val();
      var leaving_from = jQuery('#iflair_cruise_leaving_from').val();
      var ship_starts_on = jQuery('#iflair_cruise_ship_starts_on').val();
      var ship_vacation_days = jQuery('#iflair_cruise_ship_vacation_days').val();
      //alert(region);
      jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'iflair_cruise_filter_response_offer',
                region: region,
                operator: operator,
                cruise_ship: cruise_ship,
                ship_fly_in: ship_fly_in,
                leaving_from: leaving_from,
                ship_starts_on: ship_starts_on,
                ship_vacation_days: ship_vacation_days,
                pagenumb:pagenumb
            }),
            success: function (response) {
              jQuery('.loader').css('display','none');
                jQuery('#replace_query_ajax').html(response);
                //jQuery(".content").mCustomScrollbar();
                      
        }
        });
    }

    
  </script>
  <?php
}


function iflair_search_filter_response_offer(){
  global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
  $mainsiteprefix='cm_';
  wp_enqueue_script('jquery-ui-datepicker');
  $agentsiteurl=get_option('siteurl');
  $agentsitedetail=iflair_get_subsite_id($agentsiteurl);
  $agentsiteid=$agentsitedetail->id;
  $agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
  $agent_assign_operator;

  /*echo "<pre>";
  print_r($_POST);
  echo "</pre>";*/
  if($_POST['region']=="all" ){ $region = ""; }else{ $region = $_POST['region']; }
  if($_POST['operator']=="all" ){ $operator = ""; }else{ $operator = $_POST['operator']; }
  if($_POST['cruise_ship']=="all" ){ $cruise_ship = ""; }else{ $cruise_ship = $_POST['cruise_ship']; }
  if($_POST['ship_fly_in']=="all" ){ $ship_fly_in = ""; }else{ $ship_fly_in = $_POST['ship_fly_in']; }  
  if($_POST['leaving_from']=="all" ){ $leaving_from = ""; }else{ $leaving_from = $_POST['leaving_from']; }
  if($_POST['ship_starts_on']=="all" ){ $ship_starts_on = ""; }else{ $ship_starts_on = $_POST['ship_starts_on']; }
  if($_POST['ship_vacation_days']=="all" ){ $ship_vacation_days = ""; }else{ $ship_vacation_days = $_POST['ship_vacation_days']; }  


  if($leaving_from!=""){
    $leaving_from_cruise_id= "SELECT cruise_id FROM cruise_port WHERE port_code='$leaving_from'";
    //echo $leaving_from_cruise_id."<---";
    $select_leaving_from_cruise_id = $mydb->get_results($leaving_from_cruise_id);
      $leaving_from_cruise_id_arr = array();
    foreach ($select_leaving_from_cruise_id as $leaving_from_cruise_id_obj) {
      $leaving_from_cruise_id_arr[] = $leaving_from_cruise_id_obj->cruise_id;
    }
    //print_r($leaving_from_cruise_id_arr);
    $leaving_from_cruise_id = $leaving_from_cruise_id_arr[0];
    //print_r($id_res);
    for($i=1;$i<count($leaving_from_cruise_id_arr);$i++){
      $leaving_from_cruise_id = $leaving_from_cruise_id.",".$leaving_from_cruise_id_arr[$i];
    }
    //echo $leaving_from_cruise_id;
  }


  ?>
  <div class="form-field">
    <div class="btn-group i-1 h-1" role="group">
        <select name="iflair_cruise_region" id="iflair_cruise_region" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('region');" >
        <option value="" >Where do you want to go?</option>
        <?php
        
          $tab_condition = $_POST['tab_id'];
          $cruise_region == "";
          $cruise_region .= "SELECT csc.ship_region , csc.ship_cruise_type , csc.cruise_id FROM `cruise_ship_cruise` as csc INNER JOIN `cruise_operators` as co ON csc.ship_operator = co.operator_app_id WHERE co.operator_id IN (".$agent_assign_operator.")";
          if($tab_condition == 1){
            $cruise_region .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
          }
          elseif($tab_condition == 2){
            $cruise_region .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
          }
          else{
            $cruise_region .= "";
          }
          $cruise_region .= " GROUP BY csc.ship_region ORDER BY FIND_IN_SET('River', csc.ship_cruise_type),csc.ship_region";
          echo $cruise_region;
          $select_cruise_region_res = $mydb->get_results($cruise_region);


        foreach ($select_cruise_region_res as $cruise_region_prepared_obj) :
          $HiddenRiver = explode(',',$cruise_region_prepared_obj->ship_cruise_type);
        ?>
          <option value="<?php echo $cruise_region_prepared_obj->ship_region; ?>" <?php if($region == $cruise_region_prepared_obj->ship_region ){ echo "selected"; } ?> ><?php echo $cruise_region_prepared_obj->ship_region; ?><?php if(in_array('River', $HiddenRiver)){ echo " ( River )"; } ?></option>
        <?php
        endforeach;
        ?>
    </select>
      </div>

    <div class="btn-group i-2 h-2" role="group">
      <?php
        $cruise_operator_title= "SELECT co.operator_id,co.operator_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
      
        if($region != ""){
          $cruise_operator_title .= " AND csc.ship_region = '$region'";
        }
        if($cruise_ship != ""){
          $cruise_operator_title .= " AND csc.ship_id = $cruise_ship";
        }
        if($ship_fly_in != ""){
          $cruise_operator_title .= " AND csc.ship_fly_in = '$ship_fly_in'";
        }
        if($leaving_from != ""){
          $cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
        }
        if($ship_starts_on != ""){
          $cruise_operator_title .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
        }
        if($ship_vacation_days != ""){
          $cruise_operator_title .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
        }
        if($tab_condition == 1){
          $cruise_operator_title .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
        }
        elseif($tab_condition == 2){
          $cruise_operator_title .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
        }
        else{
          $cruise_operator_title .= "";
        }
            $cruise_operator_title .= " GROUP BY co.operator_title ORDER BY co.operator_title";
          
          //echo $cruise_operator_title;
        $select_cruise_operator_title = $mydb->get_results($cruise_operator_title);
        $c2 = count($select_cruise_operator_title);
        $qq="0 value";
      ?>
        <img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
        <select <?php //if($c2==0){echo 'disabled="true" ';}?> name="iflair_cruise_operator" id="iflair_cruise_operator" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('operator');" >
        <option value="" >Which Cruise Line?</option>
        <option value="all" <?php if($_POST['operator']=="all"){ echo "selected"; } ?>>Any</option>
        <?php
        foreach ($select_cruise_operator_title as $cruise_operator_title_obj) :
          ?>
          <option value="<?php echo $cruise_operator_title_obj->operator_id; ?>" <?php if($operator == $cruise_operator_title_obj->operator_id ){ echo "selected"; } ?> ><?php echo $cruise_operator_title_obj->operator_title; ?></option>
          <?php
        endforeach;
        ?>
      </select>
      </div>

      <div class="btn-group i-3 h-3" role="group">
        <?php
          $cruise_cruise_ship="";
          $cruise_cruise_ship .= "SELECT csc.ship_id,cc.cruise_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
        if($region != ""){
          $cruise_cruise_ship .= " AND csc.ship_region = '$region'";
        }
        if($operator != ""){
          $cruise_cruise_ship .= " AND co.operator_id = $operator";
        }
        if($leaving_from != ""){
          $cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
        }
        if($ship_fly_in != ""){
          $cruise_cruise_ship .= " AND csc.ship_fly_in = '$ship_fly_in'";
        }
        if($ship_starts_on != ""){
          $cruise_cruise_ship .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
        }
        if($ship_vacation_days != ""){
          $cruise_cruise_ship .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
        }
        if($tab_condition == 1){
          $cruise_cruise_ship .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
        }
        elseif($tab_condition == 2){
          $cruise_cruise_ship .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
        }
        else{
          $cruise_cruise_ship .= "";
        }
            $cruise_cruise_ship .= " GROUP BY cc.cruise_title ORDER BY csc.ship_id";
          
        $select_cruise_ship = $mydb->get_results($cruise_cruise_ship);
        $c3 = count($select_cruise_ship);
        if($c3==0){$cruise_ship="";}
        ?>
        <img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
        <select <?php //if($c3==0){echo 'disabled="true" ';}?> name="iflair_cruise_ship" id="iflair_cruise_ship" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('cruise_ship');" >
        <option value="" >Which Ship?</option>
        <option value="all" <?php if($_POST['cruise_ship']=="all" ){ echo "selected"; } ?>>Any</option>
        <?php
        foreach ($select_cruise_ship as $cruise_ship_obj) :
          ?>
          <option value="<?php echo $cruise_ship_obj->ship_id; ?>" <?php if($cruise_ship == $cruise_ship_obj->ship_id ){ echo "selected"; } ?> ><?php echo $cruise_ship_obj->cruise_title; ?></option>
          <?php
        endforeach;
        ?>
      </select>
      </div>

      <div class="btn-group i-4 h-4" role="group">
        <?php
          $cruise_ship_fly_in= "SELECT csc.ship_fly_in FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
        if($region != ""){
          $cruise_ship_fly_in .= " AND csc.ship_region = '$region'";
        }
        if($operator != ""){
          $cruise_ship_fly_in .= " AND co.operator_id = $operator";
        }
        if($cruise_ship != ""){
          $cruise_ship_fly_in .= " AND csc.ship_id = $cruise_ship";
        }
        if($ship_starts_on != ""){
          $cruise_ship_fly_in .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
        }
        if($ship_vacation_days != ""){
          $cruise_ship_fly_in .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
        }
        if($tab_condition == 1){
          $cruise_ship_fly_in .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
        }
        elseif($tab_condition == 2){
          $cruise_ship_fly_in .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
        }
        else{
          $cruise_ship_fly_in .= "";
        }
            $cruise_ship_fly_in .= " GROUP BY csc.ship_fly_in ORDER BY csc.ship_fly_in";
          
        $select_cruise_ship_fly_in = $mydb->get_results($cruise_ship_fly_in);
        $c4 = count($select_cruise_ship_fly_in);
        ?>
        <img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
        <select <?php //if($c4==0){echo 'disabled="true" ';}?> name="iflair_cruise_ship_fly_in" id="iflair_cruise_ship_fly_in" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('ship_fly_in');" >
        <option value="" >Leaving from</option>
        <option value="all" <?php if($_POST['leaving_from'] == "all" ){ echo "selected"; } ?>>Any</option>
        <?php
        foreach ($select_cruise_ship_fly_in as $cruise_ship_fly_in_obj) :
          ?>
          <option value="<?php echo $cruise_ship_fly_in_obj->ship_fly_in; ?>" <?php if($ship_fly_in == $cruise_ship_fly_in_obj->ship_fly_in ){ echo "selected"; } ?> ><?php echo $cruise_ship_fly_in_obj->ship_fly_in; ?></option>
          <?php
        endforeach;
        ?>
      </select>
      </div>

      <?php /*
      <div class="btn-group i-4 h-4" role="group">
        <?php
          $cruise_leaving_from= "SELECT * FROM cruise_port";
        if($cruise_ship != ""){
          $cruise_leaving_from .= " WHERE ship_id = $cruise_ship";
        }
          $cruise_leaving_from .= " GROUP BY cruise_id ORDER BY port_id";
          //$cruise_leaving_from .= " GROUP BY port_code, cruise_id ORDER BY port_id";
          //echo $cruise_leaving_from;
        $select_cruise_leaving_from = $mydb->get_results($cruise_leaving_from);

        $c4 = count($select_cruise_leaving_from);
        ?>
        <img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
        <select <?php //if($c4==0){echo 'disabled="true" ';}?> name="cruise_leaving_from" id="cruise_leaving_from" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_search_filter_response_offer('leaving_from');" >
        <option value="">Leaving from</option>
        <?php
        $arr = array();
        foreach ($select_cruise_leaving_from as $cruise_leaving_from_obj) :
          if(!in_array($cruise_leaving_from_obj->port_code,$arr)){ 
              $arr[] = $cruise_leaving_from_obj->port_code; 
              ?>
              <option value="<?php echo $cruise_leaving_from_obj->port_code; ?>" <?php if($leaving_from == $cruise_leaving_from_obj->port_code ){ echo "selected"; } ?> ><?php echo $cruise_leaving_from_obj->port_name; ?></option>
          <?php 
          }
        endforeach;
        ?>
      </select>
      </div>
      */ ?>

      <div class="btn-group i-2 h-5" role="group">
        <?php
          $todays_date = date('Y-m-d H:i:s');
        $cruise_when= "SELECT csc.ship_starts_on FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
          $cruise_when .= " AND csc.ship_starts_on >= '$todays_date'";
        if($region != ""){
          $cruise_when .= " AND csc.ship_region = '$region'";
        }
        if($operator != ""){
          $cruise_when .= " AND co.operator_id = $operator";
        }
        if($cruise_ship != ""){
          $cruise_when .= " AND csc.ship_id = $cruise_ship";
        }
        if($leaving_from != ""){
          $cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
        }
        if($ship_fly_in != ""){
          $cruise_when .= " AND csc.ship_fly_in = '$ship_fly_in'";
        }
        if($ship_vacation_days != ""){
          $cruise_when .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
        }
        if($tab_condition == 1){
          $cruise_when .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
        }
        elseif($tab_condition == 2){
          $cruise_when .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
        }
        else{
          $cruise_when .= "";
        }
            $cruise_when .= " GROUP BY YEAR(csc.ship_starts_on),MONTH(csc.ship_starts_on) ORDER BY csc.ship_starts_on";
          
        $select_cruise_when = $mydb->get_results($cruise_when);
        //echo $cruise_when;
        $c5 = count($select_cruise_when);
        ?>
        <?php /*
        <input type="text" placeholder="When" value="<?php echo $ship_starts_on; ?>" name="cruise_ship_starts_on" id="cruise_ship_starts_on" >
      */ ?>
        <img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
        <select <?php //if($c5==0){echo 'disabled="true" ';}?> name="iflair_cruise_ship_starts_on" id="iflair_cruise_ship_starts_on" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('ship_starts_on');" >
        <option value="" >When</option>
        <option value="all" <?php if($_POST['ship_starts_on']=="all" ){ echo "selected"; } ?>>Any</option>
        <?php
        foreach ($select_cruise_when as $cruise_when_obj) :
          ?>
          <option value="<?php echo date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ; ?>" <?php if($ship_starts_on == date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ){ echo "selected"; } ?> ><?php $ship_date=$cruise_when_obj->ship_starts_on; echo date('F Y',strtotime($ship_date)); ?></option>
          <?php
        endforeach;
        ?>
      </select>
      </div>

      <div class="btn-group i-3 h-6" role="group">
        <?php
        $cruise_days= "SELECT csc.ship_vacation_days FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
        if($region != ""){
          $cruise_days .= " AND csc.ship_region = '$region'";
        }
        if($operator != ""){
          $cruise_days .= " AND co.operator_id = $operator";
        }
        if($cruise_ship != ""){
          $cruise_days .= " AND csc.ship_id = $cruise_ship";
        }
        if($leaving_from != ""){
          $cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
        }
        if($ship_fly_in != ""){
          $cruise_days .= " AND csc.ship_fly_in = '$ship_fly_in'";
        }
        if($ship_starts_on != ""){
          $cruise_days .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
        }
        /*if($ship_vacation_days != ""){
          $cruise_days .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
        }*/
        if($tab_condition == 1){
          $cruise_days .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
        }
        elseif($tab_condition == 2){
          $cruise_days .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
        }
        else{
          $cruise_days .= "";
        }
            $cruise_days .= " GROUP BY csc.ship_vacation_days ORDER BY csc.ship_vacation_days";
          
        $select_cruise_days = $mydb->get_results($cruise_days);
        $c6 = count($select_cruise_days);
        ?>
        <img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
        <select <?php //if($c6==0){echo 'disabled="true" ';}?> name="iflair_cruise_ship_vacation_days" id="iflair_cruise_ship_vacation_days" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('ship_vacation_days');" >
        <option value="" >Days</option>
        <option value="all" <?php if($_POST['ship_vacation_days']=="all" ){ echo "selected"; } ?>>Any</option>
        <?php
        foreach ($select_cruise_days as $cruise_days_obj) :
          ?>
          <option value="<?php echo $cruise_days_obj->ship_vacation_days ; ?>" <?php if($ship_vacation_days == $cruise_days_obj->ship_vacation_days ){ echo "selected"; } ?> ><?php echo $cruise_days_obj->ship_vacation_days ; ?></option>
          <?php
        endforeach;
        ?>
      </select>
      </div>
      <div colspan="6">
        <span onclick="iflair_search_filter_response_offer('search');" class="search-bt-2" style="text-align: center; line-height: 46px;cursor:pointer;">Search</span>
      </div>
  </div>

  <?php
  exit();
}
function iflair_cruise_filter_response_offer(){

global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
//wp_deregister_script('jquery-ui-core','jquery-ui-dialog');
//wp_register_script('jquery-ui','http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.5/jquery-ui.js',array('jquery'));
//wp_enqueue_script('jquery-ui');
//add_action( 'admin_enqueue_scripts', 'enqueue_date_picker' );
$mainsiteprefix='cm_';
$agentsiteurl=get_option('siteurl');
$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
$agentsiteid=$agentsitedetail->id;
$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
$agent_assign_operator;

  if($_POST['region']=="all" ){ $region = ""; }else{ $region = $_POST['region']; }
  if($_POST['operator']=="all" ){ $operator = ""; }else{ $operator = $_POST['operator']; }
  if($_POST['cruise_ship']=="all" ){ $cruise_ship = ""; }else{ $cruise_ship = $_POST['cruise_ship']; }
  if($_POST['ship_fly_in']=="all" ){ $ship_fly_in = ""; }else{ $ship_fly_in = $_POST['ship_fly_in']; }  
  if($_POST['leaving_from']=="all" ){ $leaving_from = ""; }else{ $leaving_from = $_POST['leaving_from']; }
  if($_POST['ship_starts_on']=="all" ){ $ship_starts_on = ""; }else{ $ship_starts_on = $_POST['ship_starts_on']; }
  if($_POST['ship_vacation_days']=="all" ){ $ship_vacation_days = ""; }else{ $ship_vacation_days = $_POST['ship_vacation_days']; }


?>

<div class="d-content clearfix setdataheight">
  <div class="container">
<h2 id="filter_title"><?php //echo "Results for ".$string; ?></h2>

<?php
  $select_ship_query_left ="";
  $select_ship_query_left .= "SELECT cc.cruise_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
  $conditional_query ="";
  $conditional_query .="cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";

  if($leaving_from!=""){
    $lq = "SELECT cruise_id FROM cruise_port WHERE port_code = '$leaving_from' GROUP BY cruise_id";
    $select_lq = $mydb->get_results($lq);
    //print_r($select_lq[0]['cruise_id']);
    $leaving_string = $select_lq[0]->cruise_id;
    for($i=1;$i<count($select_lq);$i++)
    {
      //echo $select_lq[$i]->cruise_id;
      $leaving_string = $leaving_string.",".$select_lq[$i]->cruise_id;
    }
    //echo $leaving_string;
    $select_ship_query_left .= " AND csc.cruise_id IN ($leaving_string)";
  }
  if($_POST['str1']!="date_departure" ){
    if($region != ""){
      $select_ship_query_left .= " AND csc.ship_region = '$region'";
      $conditional_query .= " AND csc.ship_region = '$region'";
    }
    if($operator != ""){
      $select_ship_query_left .= " AND co.operator_id = $operator";
      $conditional_query .= " AND co.operator_id = $operator";
    }
    if($cruise_ship != ""){
      $select_ship_query_left .= " AND csc.ship_id = $cruise_ship";
      $conditional_query .= " AND csc.ship_id = $cruise_ship";
    }
    if($ship_fly_in != ""){
      $select_ship_query_left .= " AND csc.ship_fly_in = '$ship_fly_in'";
      $conditional_query .= " AND csc.ship_fly_in = '$ship_fly_in'";
    }
    if($ship_starts_on != ""){
      $select_ship_query_left .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
      $conditional_query .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
    }
    if($ship_vacation_days != ""){
      $select_ship_query_left .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
      $conditional_query .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
    }
  }

  $select_ship_query_left .= " GROUP BY cc.cruise_title"; /* Comment */
  $select_ship_query_left .= " ORDER BY cc.cruise_title";

  //echo $select_ship_query_left;
  $select_ship_query_left_r = $mydb->get_results($select_ship_query_left);


/* Master Query Start------------------------------- */
  $pagenum=$_POST['pagenumb'];
  if($_POST['pagenumb']==""){
    $per_page = 10;
    $page='1';
    $start='0';
  }
  else {
    $per_page = 10;
    $page=$_POST['pagenumb']; 
    $start=($page-1)*$per_page;
  }

  //echo "Response Found -> ".$_POST['region']."<br>";

  if($_POST['str1'] !="" && $_POST['str2'] != "" ){
    if($_POST['str1']=="date_departure"){
      $date_departure = $_POST['str2'];
      $id_query = "SELECT * FROM cruise_ship_cruise WHERE $_POST[str1] LIKE '%$_POST[str2]%' GROUP BY ship_id";
      $id_res = $mydb->get_results($id_query);
        $ship_id = $id_res[0]->ship_id;
        //print_r($id_res);
        for($i=1;$i<count($id_res);$i++){
          $ship_id = $ship_id.",".$id_res[$i]->ship_id;
        }
        //echo $ship_id; ;
      
      $select_ship_query = "SELECT csc.cruise_id,csc.ship_id,csc.ship_name,csc.ship_starts_on,csc.ship_region,csc.ship_vacation_days,csc.ship_cruise_nights,csc.ship_fly_cruise_price,csc.ship_cruise_only_price,csc.ship_operator,cc.cruise_profile_image_href,cc.cruise_cover_image_href,cc.cruise_title,cc.cruise_operator_name FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator) AND csc.ship_starts_on LIKE '%$date_departure%'";
    }
    else{
      $id_query = "SELECT csc.cruise_id,csc.ship_id,csc.ship_name,csc.ship_starts_on,csc.ship_region,csc.ship_vacation_days,csc.ship_cruise_nights,csc.ship_fly_cruise_price,csc.ship_cruise_only_price,csc.ship_operator,cc.cruise_profile_image_href,cc.cruise_cover_image_href,cc.cruise_title,cc.cruise_operator_name FROM cruise_cruise WHERE $_POST[str1] = '$_POST[str2]'";
      $id_res = $mydb->get_results($id_query);
        $ship_id = $id_res[0]->cruise_response_id;
        for($i=1;$i<count($id_res);$i++){
          $ship_id = $ship_id.",".$id_res[$i]->cruise_response_id;
        }
      $select_ship_query = "SELECT csc.cruise_id,csc.ship_id,csc.ship_name,csc.ship_starts_on,csc.ship_region,csc.ship_vacation_days,csc.ship_cruise_nights,csc.ship_fly_cruise_price,csc.ship_cruise_only_price,csc.ship_operator,cc.cruise_profile_image_href,cc.cruise_cover_image_href,cc.cruise_title,cc.cruise_operator_name FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator) AND csc.ship_id IN ($ship_id)";
    }
      //echo $ship_id;
  }
  else{
    $select_ship_query ="";
    $select_ship_query .= "SELECT csc.cruise_id,csc.ship_id,csc.ship_name,csc.ship_starts_on,csc.ship_region,csc.ship_vacation_days,csc.ship_cruise_nights,csc.ship_fly_cruise_price,csc.ship_cruise_only_price,csc.ship_operator,cc.cruise_profile_image_href,cc.cruise_cover_image_href,cc.cruise_title,cc.cruise_operator_name FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
  }

  if($leaving_from!=""){
    $lq = "SELECT cruise_id FROM cruise_port WHERE port_code = '$leaving_from' GROUP BY cruise_id";
    $select_lq = $mydb->get_results($lq);
    //print_r($select_lq[0]['cruise_id']);
    $leaving_string = $select_lq[0]->cruise_id;
    for($i=1;$i<count($select_lq);$i++)
    {
      //echo $select_lq[$i]->cruise_id;
      $leaving_string = $leaving_string.",".$select_lq[$i]->cruise_id;
    }
    //echo $leaving_string;
    $select_ship_query .= " AND csc.cruise_id IN ($leaving_string)";
    $string .= $leaving_from ;
  }
  if($_POST['str1']!="date_departure" ){
    $string ="";
    if($region != ""){
      $select_ship_query .= " AND csc.ship_region = '$region'";
      $string .= $region ;
    }
    if($operator != ""){
      $select_ship_query .= " AND co.operator_id = $operator";
      $string .= $operator ;
    }
    if($cruise_ship != ""){
      $select_ship_query .= " AND csc.ship_id = $cruise_ship";
      $string .= $cruise_ship ;
    }
    if($ship_fly_in != ""){
      $select_ship_query .= " AND csc.ship_fly_in = '$ship_fly_in'";
      $string .= $ship_fly_in ;
    }
    if($ship_starts_on != ""){
      $select_ship_query .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
      $string .= $ship_starts_on ;
    }
    if($ship_vacation_days != ""){
      $select_ship_query .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
      $string .= $ship_vacation_days ;
    }
  }

  //$select_ship_query .= " GROUP BY csc.ship_name"; /* Comment */
  $select_ship_query .= " ORDER BY csc.ship_starts_on";
  $select_ship_query_unlimit = $select_ship_query;
  $select_ship_query .= " LIMIT $start,$per_page";
  //echo $string;
  //echo $select_ship_query;
  $select_ship = $mydb->get_results($select_ship_query);
  /*echo "<pre>";
  print_r($select_ship);
  echo "</pre>";*/
  //echo count($select_ship);
/* Master Query End--------------------------------------------------------- */

?>
<?php /*
<div class="side-bar">                  
  <div class="ship-features">
    <ul>
      <li><a class="pointer_class iflair_template_value_cruiseship" onclick="iflair_ajax_cruise_operators_left('reset');" >Cruise Lines</a></li>
      <li id="sub_list"><a>Cruise Ship<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
        <ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
          <?php
            if(count($select_ship_query_left_r)==0){
              
            $select_cruise_ship_size_all = $mydb->get_results("SELECT cruise_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_size AS css ON co.operator_title = cc.cruise_operator_name GROUP BY cc.cruise_title ORDER BY cruise_title");
            foreach ($select_cruise_ship_size_all as $cruise_ship_size_obj) :
            ?>
            <li><a onclick="iflair_ajax_cruise_operators_left('cruise_title','<?php echo $cruise_ship_size_obj->cruise_title; ?>');" class="<?php if($cruise_ship_size_obj->cruise_title==$_COOKIE['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_title; ?></a></li>
            <?php
            endforeach;
            }
            else{
            foreach ($select_ship_query_left_r as $cruise_ship_size_obj) :
            ?>
            <li><a onclick="iflair_ajax_cruise_operators_left('cruise_title','<?php echo $cruise_ship_size_obj->cruise_title; ?>');" class="<?php if($cruise_ship_size_obj->cruise_title==$_COOKIE['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_title; ?></a></li>
            <?php
            endforeach;
            }
            ?>
        </ul>
      </li>
      <li id="sub_list"><a>Ship Size<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
        <ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
          <?php
          $main_size = "";
          $main_size .= "SELECT cc.cruise_ship_size FROM ";
          $main_size .= $conditional_query;
          $main_size .= " GROUP BY cruise_ship_size";
            $select_cruise_ship_size = $mydb->get_results("$main_size");
            if(count($select_cruise_ship_size)==0){
              $select_cruise_ship_size_all = $mydb->get_results("$main_size");
            foreach ($select_cruise_ship_size_all as $cruise_ship_size_obj) :
            ?>
            <li><a onclick="iflair_ajax_cruise_operators_left('cruise_ship_size','<?php echo $cruise_ship_size_obj->cruise_ship_size; ?>');" class="<?php if($cruise_ship_size_obj->cruise_ship_size==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_ship_size; ?></a></li>
            <?php
            endforeach;
            }
            else{
            foreach ($select_cruise_ship_size as $cruise_ship_size_obj) :
            ?>
            <li><a onclick="iflair_ajax_cruise_operators_left('cruise_ship_size','<?php echo $cruise_ship_size_obj->cruise_ship_size; ?>');" class="<?php if($cruise_ship_size_obj->cruise_ship_size==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_ship_size; ?></a></li>
            <?php
            endforeach;
            }
            ?>
        </ul>
      </li>
      <li id="sub_list">
        <a>Ship Style<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
        <ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
          <?php
            $main_style = "";
            $main_style .= "SELECT cc.crusie_ship_style FROM ";
            $main_style .= $conditional_query;
            $main_style .= " GROUP BY crusie_ship_style";
              $select_cruise_ship_style = $mydb->get_results("$main_style");
            if(count($select_cruise_ship_style)==0){
              $select_cruise_ship_style_all = $mydb->get_results("$main_style");
              foreach ($select_cruise_ship_style_all as $cruise_ship_style_obj) :
              ?>
              <li><a onclick="iflair_ajax_cruise_operators_left('crusie_ship_style','<?php echo $cruise_ship_style_obj->crusie_ship_style; ?>');" class="<?php if($cruise_ship_style_obj->crusie_ship_style==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_style_obj->crusie_ship_style; ?></a></li>
              <?php
              endforeach;
            }
            else{
              foreach ($select_cruise_ship_style as $cruise_ship_style_obj) :
              ?>
              <li><a onclick="iflair_ajax_cruise_operators_left('crusie_ship_style','<?php echo $cruise_ship_style_obj->crusie_ship_style; ?>');" class="<?php if($cruise_ship_style_obj->crusie_ship_style==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_style_obj->crusie_ship_style; ?></a></li>
              <?php
              endforeach;
            }
            ?>
        </ul>
      </li>
      <li id="sub_list">
        <a>Language<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
        <ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
          <?php
            $select_cruise_language = $mydb->get_results("SELECT cl.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_language AS cl ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id =$operator AND cl.language_code = cc.cruise_language GROUP BY cc.cruise_language ORDER BY cc.cruise_operator_name");
            if(count($select_cruise_language)==0){
              $select_cruise_language_all = $mydb->get_results("SELECT cl.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_language AS cl ON co.operator_title = cc.cruise_operator_name GROUP BY cl.language_code ORDER BY cc.cruise_operator_name");
              foreach ($select_cruise_language_all as $cruise_language_obj) :
              ?>
              <li><a onclick="iflair_ajax_cruise_operators_left('cruise_language','<?php echo $cruise_language_obj->language_code; ?>');" class="<?php if($cruise_language_obj->language_code==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_language_obj->language_title; ?></a></li>
              <?php
              endforeach;
            }
            else{
              foreach ($select_cruise_language as $cruise_language_obj) :
              ?>
              <li><a onclick="iflair_ajax_cruise_operators_left('cruise_language','<?php echo $cruise_language_obj->language_code; ?>');" class="<?php if($cruise_language_obj->language_code==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_language_obj->language_title; ?></a></li>
              <?php
              endforeach;
            }
            ?>
        </ul>
      </li>
      <!-- <li id="sub_list">
        <input type="text" placeholder="Departure Date" value="<?php if($_POST['str1']=="date_departure"){ echo $_POST['str2']; } ?>" name="iflair_cruise_ship_departure_date" id="iflair_cruise_ship_departure_date" onchange="iflair_ajax_cruise_operators_left('date_departure','');" style="width: 100%;padding-left: 25px;">
      </li> -->
    </ul>
  </div>
</div>
*/ ?>
    <div class="result-part">
<?php
  
  if(count($select_ship) == 0)
  {
    echo "No Cruise Found ..";
  }
  else
  {
    //echo $page;
    //echo $per_page;
    //echo $select_ship_query;
    cruise_pagging_offer($page,$per_page,$select_ship_query_unlimit);

    for($i=0;$i<count($select_ship);$i++)
    {
    ?>

<div class="mediter-box clearfix">
  <div class="medi-left">
    <div class="newtableimg">
      <div class="netablecellimg">
		<img src="<?php if($select_ship[$i]->cruise_cover_image_href!=""){ echo "http://ekups3e.cloudimg.io/s/crop/300x200/".str_replace('//www','www',$select_ship[$i]->cruise_cover_image_href); }else{ echo esc_url( get_template_directory_uri() )."/images/noImageAvailable.png"; } ?>" class="img-responsive">
      </div>
    </div>
  </div>
  <div class="medi-mid">
	<?php
	$offer_query = "SELECT offer_price,package_summary,cabin_info FROM ".QUOTE_EXTRA_OFFER." WHERE offer_start_date < curdate() and offer_end_date > curdate() AND cruise_id = '".$select_ship[$i]->cruise_id."'";
	$found_offer = $wpdb->get_row($offer_query);
	?>
    <h3><?php echo $select_ship[$i]->ship_name; ?></h3>
    <p class="small_p">Region <span>- <?php echo $select_ship[$i]->ship_region; ?></span></p>
    <p>Departure Date <span>- <?php $ship_date=$select_ship[$i]->ship_starts_on; echo date('d/m/Y',strtotime($ship_date)); ?></span></p>
    <p class="small_p">No of Nights <span>- <?php echo $select_ship[$i]->ship_cruise_nights; ?></span></p>
    <p>Ship <span>- <?php echo $select_ship[$i]->cruise_title; ?></span></p>
  </div>
  <div class="medi-right">
    
    <div class="main_added_text" style="text-align: center;">
		<?php 
		$price1 = $select_ship[$i]->ship_cruise_only_price;
		$price2 = $select_ship[$i]->ship_fly_cruise_price;
		
		if(!empty($found_offer)){
			?>
			<h2>Package Price</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>From <span class="textbld">£<?php echo number_format($found_offer->offer_price); ?></span>  per person</p>
			<?php
		}
		elseif($price1=="0" && $price2=="0")
		{
			?>
			<h2>Cruise from price</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>Please enquire for today’s price</p>
			<?php
		}
		elseif( ( $price1!="0" && $price1 < $price2 ) || $price2== "0" )
		{
			?>
			<h2>Cruise from price</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>From <span class="textbld">£<?php echo number_format($price1); ?></span>  per person</p>
			<?php
		}
		elseif( ( $price2!="0" && $price1 > $price2 ) || $price1== "0" )
		{
			?>
			<h2>Cruise from price</h2>
			<?php echo $found_offer->package_summary; ?>
			<p>From <span class="textbld">£<?php echo number_format($price2); ?></span>  per person</p>
			<?php
		}
		elseif( ( $price1!="0" && $price2!="0" ) && $price1==$price2 )
		{
			?>
			<!-- <h2>Cruise from price</h2> -->
			<?php echo $found_offer->package_summary; ?>
			<p class="text1">From </p><p class="textbld">£<?php echo number_format($price1); ?><span class="text2">pp</span></p>
			<?php
		}
		else{
			?>
			<!-- <h2>Cruise from price</h2> -->
			<?php echo $found_offer->package_summary; ?>
			<p class="text1">Please enquire for today’s price</p>
			<?php
		}
		echo '<div class="'.$offer_class2.'"></div>';
		?>
		</div>

    <div class="added_img">
    </div>
  </div>
</div>

<div class="cruse-information cruise_offer_box clearfix" id="<?php echo $select_ship[$i]->cruise_id; ?>">
  <?php echo $select_ship[$i]->cruise_id; ?>

</div>

    <?php
    }
  }
  ?>
<script type="text/javascript">
    jQuery.noConflict();
    jQuery(document).ready(function(){
      jQuery(".mediter-box").click(function(){
        jQuery(".cruise_offer_box").slideUp();
        jQuery(".cruise_offer_box").empty();
        var id = jQuery(this).next(".cruise_offer_box").attr('id');
        jQuery("#"+id).slideToggle();
        jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'cruise_offer_entry_form_ajax_res',
                id : id
            }),
            success: function (response) {
                jQuery('.loader').css('display','none');
                jQuery('#'+id).html(response);
            }
        });
      });
      
      jQuery("#pagination li").click(function(){
        jQuery('.loader').css('display','block');
        var pageNum = this.id;
        var region = jQuery('#iflair_cruise_region').val();
        var operator = jQuery('#iflair_cruise_operator').val();
        var cruise_ship = jQuery('#iflair_cruise_ship').val();
        var ship_fly_in = jQuery('#iflair_cruise_ship_fly_in').val();
        var leaving_from = jQuery('#iflair_cruise_leaving_from').val();
        var ship_starts_on = jQuery('#iflair_cruise_ship_starts_on').val();
        var ship_vacation_days = jQuery('#iflair_cruise_ship_vacation_days').val();
        jQuery.ajax({
              type: "POST",
              url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
              data: ({
                  action: 'iflair_cruise_filter_response_offer',
                region: region,
                operator: operator,
                cruise_ship: cruise_ship,
                ship_fly_in: ship_fly_in,
                leaving_from: leaving_from,
                ship_starts_on: ship_starts_on,
                ship_vacation_days: ship_vacation_days,
                  pagenumb:pageNum
              }),
              success: function (response) {
                jQuery('.loader').css('display','none');
                  //alert(response);
                  jQuery('#replace_query_ajax').html(response);
                  //jQuery(".content").mCustomScrollbar();
              }
          });
      });
      jQuery('.itinerary_btn').click(function(){
        //jQuery(this).parent().parent().parent().next('.cruse-information').slideToggle();
        if(jQuery(this).parent().parent().parent().next('.cruse-information').hasClass("a1")){
          jQuery(this).parent().parent().parent().next('.cruse-information').removeClass("a1");
          jQuery(this).parent().parent().parent().next('.cruse-information').slideUp();
        }
        else{
          jQuery('.cruse-information').removeClass("a1");
          jQuery('.cruse-information').slideUp();
          jQuery(this).parent().parent().parent().next('.cruse-information').slideDown();
          jQuery(this).parent().parent().parent().next('.cruse-information').addClass("a1");
        }
      });
      jQuery(this).next('ul').slideUp();
      jQuery('#sub_list a').on('click',function(){
        jQuery(this).next('ul').slideToggle();
      });
      var item = jQuery(".active_left");
        item.parent().parent().css('display','block');
        item.parent().parent().parent().parent().css('display','block');
    });

function iflair_ajax_cruise_operators_left(str1,str2){  
    jQuery('.loader').css('display','block'); 
    var pagenumb='1';
    var str1 = str1;
    //alert(str1);  
    /*if(str1=='date_departure'){
      var str2 =jQuery('#iflair_cruise_ship_departure_date').val();
      jQuery('#iflair_cruise_region').prop('selectedIndex',0);
      jQuery('#iflair_cruise_operator').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_fly_in').prop('selectedIndex',0);
      jQuery('#iflair_cruise_leaving_from').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
    }*/
    if(str1=='reset'){
      jQuery('#iflair_cruise_region').prop('selectedIndex',0);
      jQuery('#iflair_cruise_operator').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_fly_in').prop('selectedIndex',0);
      jQuery('#iflair_cruise_leaving_from').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
    }
    else{
      var str2 = str2;
    }

    //jQuery.cookie('str1', str1, {expires: 1 });
    //jQuery.cookie('str2', str2, {expires: 1 });

    //alert(str2);
    var operator = jQuery('#iflair_cruise_operator').val();
    var region = jQuery('#iflair_cruise_region').val();
    var pagenumb=pagenumb;
    var touroperator = jQuery('#iflair_template_cruise_operators').val();
    //alert(jQuery("#iflair_template_cruise_operators option:selected").text());
    var shipsize = jQuery('#iflair_template_cruise_ship_size').val();
    var shipstyle = jQuery('#iflair_template_cruise_ship_style').val();
    var shiplanguage = jQuery('#iflair_template_cruise_language').val();
    var dateToday = new Date();
        jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'iflair_cruise_filter_response_offer',
                str1: str1,
                str2: str2,
              operator: operator,
        region: region,
                pagenumb:pagenumb
            }),
            success: function (response) {
              jQuery('.loader').css('display','none');
                //alert(response);
                jQuery('#replace_query_ajax').html(response);
                  //jQuery(".content").mCustomScrollbar();
          /*jQuery("#iflair_cruise_ship_departure_date").datepicker({ 
            minDate: dateToday ,
            dateFormat: 'yy-mm-dd'
          });*/
          
            }
        });
}

    function iflair_cruise_detail_offer_of(cruise_id){
          jQuery('.loader_1').css('display','block');
      var id = id;
      var ship_name = ship_name;
      var cruise_id = cruise_id;
      var region = jQuery('#iflair_cruise_region').val();
      var operator = jQuery('#iflair_cruise_operator').val();
      var cruise_ship = jQuery('#iflair_cruise_ship').val();
      var ship_fly_in = jQuery('#iflair_cruise_ship_fly_in').val();
      var leaving_from = jQuery('#iflair_cruise_leaving_from').val();
      var ship_starts_on = jQuery('#iflair_cruise_ship_starts_on').val();
      var ship_vacation_days = jQuery('#iflair_cruise_ship_vacation_days').val();
      jQuery.ajax({
              type: "POST",
              url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
              data: ({
                  action: 'iflair_cruise_detail_offer',
                region: region,
                operator: operator,
                cruise_ship: cruise_ship,
                ship_fly_in: ship_fly_in,
                leaving_from: leaving_from,
                ship_starts_on: ship_starts_on,
                ship_vacation_days: ship_vacation_days,
                id: id,
                ship_name: ship_name,
                cruise_id: cruise_id
              }),
              success: function (response) {
                jQuery('.loader_1').css('display','none');
                  //alert(response);
                //jQuery('.scroll_empty').empty();
                  jQuery('.scroll'+cruise_id).html(response);
                  //jQuery(".content").mCustomScrollbar();
              }
          });
    }


</script>
  </div>
</div>
  <?php
  exit();
}

/* Code started by Arvind */
function cruise_pagging_offer($page="",$numofrec,$select_ship_query){
  global $wpdb,$mydb,$mainsiteprefix;       
  //wp_enqueue_script('jquery-ui-datepicker');
$start = ($page-1)*$per_page;
$page = $page;
  $cur_page = $page;
  $page -= 1;
  $per_page = $numofrec;
  $previous_btn = true;
  $next_btn = true;
  $first_btn = true;
  $last_btn = true;
  $start = $page * $per_page;
  //$count = $pages;
  //$no_of_paginations = ceil($count / $per_page);

  $select_ship_pag = $mydb->get_results($select_ship_query);
$innercount = count($select_ship_pag);
$no_of_paginations = ceil($innercount/$per_page);

  /* ---------------Calculating the starting and endign values for the loop----------------------------------- */
  if ($cur_page >= 3) {
      $start_loop = $cur_page - 1;
      if ($no_of_paginations > $cur_page + 1)
          $end_loop = $cur_page + 1;
      else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 2) {
          $start_loop = $no_of_paginations - 2;
          $end_loop = $no_of_paginations;
      } else {
          $end_loop = $no_of_paginations;
      }
  } else {
      $start_loop = 1;
      if ($no_of_paginations > 3)
          $end_loop = 3;
      else
          $end_loop = $no_of_paginations;
  }
  /* ----------------------------------------------------------------------------------------------------------- */
  $msg .= "<div class='pagination-menu'><ul id='pagination'>";

  // FOR ENABLING THE FIRST BUTTON
  if ($first_btn && $cur_page > 1) {
      $msg .= "<li id='1' class='active'><<</li>";
  } else if ($first_btn) {
      $msg .= "<li id='1' class='inactive'><<</li>";
  }

  // FOR ENABLING THE PREVIOUS BUTTON
  if ($previous_btn && $cur_page > 1) {
      $pre = $cur_page - 1;
      $msg .= "<li id='$pre' class='active'><</li>";
  } else if ($previous_btn) {
      $msg .= "<li class='inactive'><</li>";
  }
  for ($i = $start_loop; $i <= $end_loop; $i++) {

      if ($cur_page == $i)
          $msg .= "<li id='$i' class='active currentdiv'>{$i}</li>";
      else
          $msg .= "<li id='$i' class='active'>{$i}</li>";
  }

  // TO ENABLE THE NEXT BUTTON
  if ($next_btn && $cur_page < $no_of_paginations) {
      $nex = $cur_page + 1;
      $msg .= "<li id='$nex' class='active'>></li>";
  } else if ($next_btn) {
      $msg .= "<li class='inactive'>></li>";
  }

  // TO ENABLE THE END BUTTON
  if ($last_btn && $cur_page < $no_of_paginations) {
      $msg .= "<li id='$no_of_paginations' class='active'>>></li>";
  } else if ($last_btn) {
      $msg .= "<li id='$no_of_paginations' class='inactive'>>></li>";
  }
  $msg = $msg . "</ul></div>";  // Content for pagination
  echo $msg;
}
function iflair_crusie_save_offer_ajax_res(){
  global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
  //wp_enqueue_script('jquery-ui-datepicker');
  /*echo "<pre>";
  print_r($_POST);
  echo "</pre>";
  die();*/
  $cruise_id = $_POST['cruise_id'];
  $ship_id = $_POST['ship_id'];
  $ship_region = $_POST['ship_region'];
  $cruise_type = $_POST['cruise_type'];
  $departure_date =  $_POST['departure_date'];
  $start_date = $_POST['start_date'];
  $end_date = $_POST['end_date'];
  $vacation_days = $_POST['vacation_days'];
  $cruise_nights = $_POST['cruise_nights'];
  $post_cruise = $_POST['post_cruise'];
  $embark_at = $_POST['embark_at'];
  $disembark_at = $_POST['disembark_at'];
  $contact_number = $_POST['contact_number'];
  $ports_visited = $_POST['ports_visited'];
  $quote_description = $_POST['quote_description'];
  $cabin_info = $_POST['cabin_info'];
  $offer_price = $_POST['offer_price'];
  $extra_info = $_POST['extra_info'];

  $content_title = $_POST['con_title'];
  $content_before_image = $_POST['content_before_image'];
  $content_after_image = $_POST['content_after_image'];


  $date = date('Y-m-d');
  if(!empty($_POST['package_summary'])){$package_summary = implode(",", $_POST['package_summary']);}else{$package_summary = "";}

  $que = "SELECT * FROM ".QUOTE_EXTRA_OFFER." where ship_id = '".$ship_id."' and cruise_id = '".$cruise_id."' ";
  $offer_select= $wpdb->get_row("SELECT * FROM ".QUOTE_EXTRA_OFFER." where ship_id = '".$ship_id."' and cruise_id = '".$cruise_id."' ");
    //print '<pre>';
    //print_r($offer_select);
    //print '</pre>';
  $offer_count = count($offer_select);

  //echo "<br/>QUERY".$que;
  //echo "<br/>COUNT".$offer_count;
  
  if(empty($offer_count))
  {
    $wpdb->insert(
          QUOTE_EXTRA_OFFER,
          array( 
              'ship_id' => $ship_id,
              'cruise_id' => $cruise_id,
              'ship_region' => $ship_region,
              'cruise_type' => $cruise_type,
              'departure_date' => $departure_date, 
              'offer_start_date' => $start_date, 
              'offer_end_date' => $end_date,
              'vacation_days' => $vacation_days,
              'cruise_nights' => $cruise_nights,
              'post_cruise' => $post_cruise,
              'embark_at' => $embark_at,
              'disembark_at' => $disembark_at,
              'contact_number' => $contact_number,
              'ports_visited' => $ports_visited,
              'description' => $quote_description,
              'package_summary' => $package_summary,
              'cabin_info' => $cabin_info,
              'offer_price' => $offer_price,
              'extra_info' => $extra_info,
              'created_date' => $date,
              'content_title' => $content_title,
              'content_before_image' => $content_before_image,
              'content_after_image' => $content_after_image
          ) 
          
        );
echo "<br>".$wpdb->last_query."<hr>";
        $lastid = $wpdb->insert_id;
        $gt_cr_id = $wpdb->get_row( 'SELECT cruise_id FROM '.QUOTE_EXTRA_OFFER.' WHERE id = "'.$lastid.'" ', OBJECT );
        $gt_cr_id->cruise_id;
        $count = count($_POST['con_img_url']);
        
        for ($i=0; $i <$count; $i++)
        {
          if($_POST['con_img_url'][$i] != ""){
            $wpdb->insert(QUOTE_EXTRA_OFFER_IMAGES, array( 
              'cruise_id' => $gt_cr_id->cruise_id,
              'image_url' => $_POST['con_img_url'][$i],
              'image_title' => $_POST['con_img_title'][$i],
              'image_caption' => $_POST['con_img_caption'][$i],
	          ));
echo "<br>".$wpdb->last_query."<hr>";
	        }
        }
            
        echo 'Value Insterted';
    
  }
  else
  {
      $wpdb->update(
            QUOTE_EXTRA_OFFER,
            array( 
              'ship_region' => $ship_region,
              'cruise_type' => $cruise_type,
              'departure_date' => $departure_date, 
              'offer_start_date' => $start_date, 
              'offer_end_date' => $end_date,
              'vacation_days' => $vacation_days,
              'cruise_nights' => $cruise_nights,
              'post_cruise' => $post_cruise,
              'embark_at' => $embark_at,
              'disembark_at' => $disembark_at,
              'contact_number' => $contact_number,
              'ports_visited' => $ports_visited,
              'description' => $quote_description,
              'package_summary' => $package_summary,
              'cabin_info' => $cabin_info,
              'offer_price' => $offer_price,
              'extra_info' => $extra_info,
              'updated_date' => $date,
              'content_title' => $content_title,
              'content_before_image' => $content_before_image,
              'content_after_image' => $content_after_image
            ),
            array('ship_id' => $ship_id, 'cruise_id' => $cruise_id)
          );
echo "<br>".$wpdb->last_query."<hr>";

        /*echo "<br>".$wpdb->last_query."<hr>";
        exit();*/

        $count = count($_POST['con_img_url']);
        $wpdb->delete( QUOTE_EXTRA_OFFER_IMAGES, array( 'cruise_id' => $cruise_id ) );
echo "<br>".$wpdb->last_query."<hr>";    

        for ($i=0; $i <$count; $i++)
        {
            if($_POST['con_img_url'][$i] != ""){
	            $wpdb->insert(QUOTE_EXTRA_OFFER_IMAGES, array( 
	            'cruise_id' => $cruise_id,
	            'image_url' => $_POST['con_img_url'][$i],
	            'image_title' => $_POST['con_img_title'][$i],
	            'image_caption' => $_POST['con_img_caption'][$i],
	            ));
echo "<br>".$wpdb->last_query."<hr>";
	        }
        }

      echo 'Value Updated';
  }
  die();
}
function cruise_offer_entry_form_ajax_res(){
  global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
  //wp_enqueue_script( 'jquery' );
  //wp_enqueue_script( 'jquery-ui-core' );
  //wp_enqueue_script( 'jquery-datepicker', 'http://jquery-ui.googlecode.com/svn/trunk/ui/jquery.ui.datepicker.js', array('jquery', 'jquery-ui-core' ) );
  $mainsiteprefix='cm_';
  $agentsiteurl=get_option('siteurl');
  $agentsitedetail=iflair_get_subsite_id($agentsiteurl);
  $agentsiteid=$agentsitedetail->id;
  $agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
  $agent_assign_operator;
  

  $cruise_id = $_POST['id'];
  $cruise_details_query = "SELECT csc.cruise_id,csc.ship_id,csc.ship_name,csc.ship_starts_on,csc.ship_region,csc.ship_vacation_days,csc.ship_cruise_nights,csc.ship_fly_cruise_price,csc.ship_cruise_only_price,csc.ship_operator,cc.cruise_profile_image_href,cc.cruise_cover_image_href,cc.cruise_title,cc.cruise_operator_name,cc.crusie_ship_type,csc.ship_fly_in,csc.ship_fly_out FROM cruise_ship_cruise as csc INNER JOIN cruise_cruise as cc ON csc.ship_id=cc.cruise_response_id WHERE csc.cruise_id = '".$cruise_id."'";
  $cruise_details = $mydb->get_row($cruise_details_query);

/*  echo $cruise_id;
  echo "<pre>";
  print_r($cruise_details);
  echo "</pre>";*/
  
  $cruise_type = "SELECT DISTINCT `crusie_ship_type` FROM cruise_cruise WHERE `crusie_ship_type` != ''";
  $type_details = $mydb->get_results($cruise_type);

  $cruise_type = $cruise_details->crusie_ship_type;

  //get extra offer value
  $offer_details_query = "SELECT * FROM ".QUOTE_EXTRA_OFFER."  where cruise_id = '".$cruise_id."'";
  $offer_details = $wpdb->get_row($offer_details_query);
  $cruise_type = $offer_details->cruise_type;
  $departure_date = $offer_details->departure_date;
  $offer_start_date = $offer_details->offer_start_date;
  $offer_end_date = $offer_details->offer_end_date;
  $vacation_days = $offer_details->vacation_days;
  $cruise_nights = $offer_details->cruise_nights;
  $post_cruise = $offer_details->post_cruise;
  $embark_at = $offer_details->embark_at;
  $disembark_at = $offer_details->disembark_at;
  $contact_number = $offer_details->contact_number;
  $ports_visited = $offer_details->ports_visited;
  $description = $offer_details->description;
  $package_summary = $offer_details->package_summary;
  $cabin_info = $offer_details->cabin_info;
  $offer_price = $offer_details->offer_price;
  $extra_info = $offer_details->extra_info;
  $content_title = $offer_details->content_title;
  $content_before_image = $offer_details->content_before_image;
  $content_after_image = $offer_details->content_after_image;

  /*echo 'SELECT * FROM '.QUOTE_EXTRA_OFFER_IMAGES.' WHERE cruise_id = "'.$cruise_id.'"';*/
  $img_lp_con = $wpdb->get_results( 'SELECT * FROM '.QUOTE_EXTRA_OFFER_IMAGES.' WHERE cruise_id = "'.$cruise_id.'"', OBJECT );
  $img_lp_count = count($img_lp_con);

  ?>

  <script type="text/javascript">
    function save_offer()
    {
      
      $('#offer_entry').validate({
              errorPlacement: function(error,element) {
              return true;
              }
      });
      tinyMCE.triggerSave();
      var cruiseformdata = jQuery("#offer_entry").serialize();
      //$.validator.messages.required = '';
      if ($("#offer_entry").valid()) {
            
      jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: 'data='+cruiseformdata+'&action=iflair_crusie_save_offer_ajax_res',
            success: function(response) {
              //alert(response);
              var newhtm = '<tr id="msg_div"><th><h3 style="color:#15B587">'+response+'</h3></th></tr>';
              jQuery("#msg_div").replaceWith(newhtm);
                      
          }
        });
      }
    }
  </script>
  <link href="<?php echo plugin_dir_url( __FILE__ ); ?>css/datepicker.css" rel="stylesheet" type="text/css"/>  
  <script type="text/javascript" src="<?php echo plugin_dir_url( __FILE__ ); ?>js/jquery-1.7.1.min.js"></script>
  <script type="text/javascript" src="<?php echo plugin_dir_url( __FILE__ ); ?>js/jquery-ui-1.8.18.custom.min.js"></script>
  <script type="text/javascript" src="<?php echo plugin_dir_url( __FILE__ ); ?>js/jquery.limit-1.2.source.js"></script>
  <script type="text/javascript" src="<?php echo plugin_dir_url( __FILE__ ); ?>js/jquery.validate.js"></script>
  <form action="" name="offer_entry" id="offer_entry" method="post">
    <input type="hidden" name="ship_id1" id="ship_id1" value="<?php echo $cruise_details->ship_id ; ?>">
    <input type="hidden" name="ship_id" id="ship_id" value="<?php echo $cruise_details->ship_id ; ?>">
    <input type="hidden" name="ship_region" id="ship_region" value="<?php echo $cruise_details->ship_region; ?>">
    <input type="hidden" name="cruise_id" id="cruise_id" value="<?php echo $_POST['id']; ?>">
    <input type="hidden" name="hidden_img" value="<?php echo $img_lp_count; ?>" class="hidden_img">
    <!-- <input type="hidden" name="departure_date" id="departure_date" value="<?php //echo date('Y-m-d',strtotime($cruise_details->ship_starts_on)); ?>"> -->
    <table class="offer_entry_table">
      <tr>
        <td colspan="2">
          <h2><?php echo ucfirst($cruise_details->crusie_ship_type); ?> Offer Entry Form</h2>
        </td>
      </tr>
      <tr>
        <td style="width: 65%" class="main_info">
          <table style="text-align: left;" class="leftsidetb" cellspacing="10">
            <tr><th colspan="2">Offer Information</th></tr>
            <tr>
              <td>Cruise Type</td>
              <td>
                <input type="text" name="cruise_type" id="cruise_type" value="<?php echo $cruise_details->crusie_ship_type; ?>" readonly="readonly">
                <!--select name="cruise_type" id="crusie_type">
                <?php foreach($type_details as $tData){?>
                  <option value="<?php echo $tData->crusie_ship_type?>" <?php echo ($cruise_type==$tData->crusie_ship_type ? 'selected="/selected/"' : '');?>><?php echo $tData->crusie_ship_type;?></option>
                <?php } ?>
                </select--> 
              </td>
            </tr>

            <tr>
              <td>Package Title (50 charecter)</td>
              <td>
              <textarea name="extra_info" class="required" id="extra_info"><?php echo $extra_info;?></textarea>
              </td>
            </tr>
            <tr>
              <td></td>
              <td>You have <span id="left1"></span> characters left</td>
            </tr>
            <tr>
              <td>Amount Per Person</td>
              <td><input type="text" class="required" name="offer_price" id="offer_price" value="<?php echo $offer_price;?>"></td>
            </tr>

            <tr>
              <td>Departure Date</td>
              <td><input type="text" name="departure_date" id="departure_date_new" readonly="readonly" class="departure_date" value="<?php if($departure_date==""){ echo date('Y-m-d',strtotime($cruise_details->ship_starts_on)); }else{ echo date('Y-m-d',strtotime($departure_date)); } ?>" /></td>
            </tr>
            <tr>
              <td>Start Offer</td>
              <td><input type="text" readonly="readonly" class="start_date" name="start_date" id="start_date" value="<?php echo $offer_start_date; ?>" /></td>
              </tr>
            <tr>
              <td>Valid Until</td>
              <td><input type="text" readonly="readonly" name="end_date" id="end_date" class="end_date" value="<?php echo $offer_end_date; ?>"></td>
            </tr>

            <!-- <tr>
              <td>Vacation Days</td>
              <td><input type="text" name="vacation_days" id="vacation_days" value="<?php echo $vacation_days;?>"></td>
            </tr>

            <tr>
              <td>Cruise Nights</td>
              <td><input type="text" name="cruise_nights" id="cruise_nights" value="<?php echo $cruise_nights;?>"></td>
            </tr>

            <tr>
              <td>Post Cruise</td>
              <td><input type="text" name="post_cruise" id="post_cruise" value="<?php echo $post_cruise;?>"></td>
            </tr>

            <tr>
              <td>Embark at</td>
              <td><input type="text" name="embark_at" id="embark_at" value="<?php echo $embark_at;?>"></td>
            </tr>

            <tr>
              <td>Disembark at</td>
              <td><input type="text" name="disembark_at" id="disembark_at" value="<?php echo $disembark_at;?>"></td>
            </tr>

            <tr>
              <td>Ports Visited</td>
              <td>
                <textarea name="ports_visited" id="ports_visited"><?php echo $ports_visited; ?></textarea>
              </td>
            </tr> -->

            <tr>
              <td>Contact Number</td>
              <td><input type="text" name="contact_number" id="contact_number" value="<?php echo $contact_number;?>"></td>
              <script type="text/javascript">
                jQuery("#contact_number").keypress(function (e) {
                  //alert(e.which);
                   //if the letter is not digit then display error and don't type anything
                   if (e.which != 8 && e.which != 43 && e.which != 0 && (e.which < 48 || e.which > 57 )) {
                      //display error message
                      //jQuery("#errmsg").html("Digits Only").show().fadeOut("slow");
                      jQuery("#contact_number").css("border","1px solid red");
                      //jQuery(".iphorm_1_5-input-wrap").next().delay(1000).css("border","0px solid red");
                             return false;
                  }
                  else{
                      jQuery("#contact_number").css("border","1px solid #5B9DD9");
                  }
                });
              </script>
            </tr>

            <tr>
              <td>Package</td>
              <td>
                <?php $package_summary_array = explode(",", $package_summary); ?>
                  <input type="checkbox" name="package_summary[]" class="package_summary" value="Flights" id="package_summary1" <?php if(in_array("Flights", $package_summary_array)){ echo "checked"; } ?> /><label for="package_summary1">Flights</label>
                  <br/>
                  <input type="checkbox" name="package_summary[]" class="package_summary" value="Hotels + Cruise" id="package_summary2" <?php if(in_array("Hotels + Cruise", $package_summary_array)){ echo "checked"; } ?> /><label for="package_summary2">Hotels + Cruise</label>
                  <br/>
                  <input type="checkbox" name="package_summary[]" class="package_summary" value="Flight + Cruise" id="package_summary3" <?php if(in_array("Flight + Cruise", $package_summary_array)){ echo "checked"; } ?> /><label for="package_summary3">Flight + Cruise</label>
                  <br/>
                  <input type="checkbox" name="package_summary[]" class="package_summary" value="Cruise + Hotel" id="package_summary4" <?php if(in_array("Cruise + Hotel", $package_summary_array)){ echo "checked"; } ?> /><label for="package_summary4">Cruise + Hotel</label>
                  <br/>
                  <input type="checkbox" name="package_summary[]" class="package_summary" value="Flight + Cruise + Hotel" id="package_summary5" <?php if(in_array("Flight + Cruise + Hotel", $package_summary_array)){ echo "checked"; } ?> /><label for="package_summary5">Flight + Cruise + Hotel</label>
                  <br/>
              </td>
            </tr>
            <tr>
              <td>Cruise-Holiday<!-- Further cruise,tour or hotel information --></td>
              <td>
              &nbsp;
              </td>
            </tr>
            <tr>
            <td colspan="2">
              <?php
                //$editor_id = 'quote_description_'.$_POST['id'];
                $editor_id = 'quote_description';
                $content = stripslashes($description);
                wp_editor( $content, $editor_id , $settings = array( 'media_buttons' => false , 'editor_height'=> '200px' ));
                
                ?>
                <!-- <textarea name="quote_description" class="required" id="quote_description"><?php echo $description;?></textarea> -->
            </td>
            </tr>
            <?php /*
            <tr>
              <td>Cabin (30 charecter)</td>
              <td><input type="text" name="cabin_info" class="required" id="cabin_info" value="<?php echo $cabin_info?>">
              </td>
            </tr>
            <tr>
              <td></td>
              <td>You have <span id="left"></span> charecter left</td>
            </tr>
            */ ?>
            <tr>
              <td>Short Summary</td>
              <td>
                <textarea name="cabin_info" class="required" id="cabin_info"><?php echo $cabin_info?></textarea>
              </td>
            </tr>
            <tr>
              <td>Title</td>
              <td>
                <input type="text" name="con_title" id="con_title" class="con_title" value="<?php echo $content_title?>">
              </td>
            </tr>
            <tr>
              <td>Content Before Image</td>
            </tr>
            <tr>
              <td colspan="2">
	              <?php
	                //$editor_id = 'quote_description_'.$_POST['id'];
	                $editor_id = 'content_before_image';
	                $content = stripslashes($content_before_image);
	                wp_editor( $content, $editor_id , $settings = array( 'media_buttons' => false , 'editor_height'=> '200px' ));
	                
	                ?>
            	</td>
            </tr>
            <tr>
            	<td class="controls" colspan="2">
          				<?php 
          					if($img_lp_count != "0"){
            					for ($i=0; $i < $img_lp_count ; $i++) { ?>
              						<table class="newadd">
                  						<tr>
                  							<td colspan="2">
                  								<?php if($i == 0 ){ ?>
					                              	<input type="button" name="addnew" class="addnew con_delete button button-primary button-large" value="Add New">
					                          	<?php } else{ ?>
					                              	<input type="button" name="addnew" class="removenew con_delete button button-primary button-large" value="Remove">
					                          	<?php } ?>
					                          		<input type="hidden" name="hiddneid[]" class="hiddneid" value="<?php echo $img_lp_con[$i]->image_id; ?>">
                      						</td>
                  						</tr>
                  						<tr>
					                  		<td>
					                  			<label for="name">Image URL</label>
					                  		</td>
					                  		<td>
					                      		<input type="text" name="con_img_url[]" id="con_img_url" class="con_img_url" value="<?php echo $img_lp_con[$i]->image_url; ?>">
					                      	</td>
					                      	<td>
					                      		<a class="button button-primary button-large" href="<?php echo admin_url(); ?>upload.php" target="_blank">Add Media</a>
					                      	</td>
					                  	</tr>
					                  	<tr class="adddata">
					                  		<td>
					                  			<label for="name">Image Title</label>		
					                  		</td>
					                  		<td>
					                  			<input type="text" name="con_img_title[]" id="con_img_title" class="con_img_title" value="<?php echo $img_lp_con[$i]->image_title; ?>">
					                  		</td>
					                  	</tr>
					                  	<tr>
					                  		<td>
					                  			<label for="name">Image Caption</label>		
					                  		</td>
					                  		<td>
					                  			<input type="text" name="con_img_caption[]" id="con_img_caption" class="con_img_caption" value="<?php echo $img_lp_con[$i]->image_caption; ?>">		
					                  		</td>
					                  	</tr>
              						</table>
            					<?php } } else{ ?>
						              <table class="newadd">
						              		<tr>
						              			<td colspan="2">
						              				<input type="button" name="addnew" class="addnew con_delete button button-primary button-large" value="Add New">
						              			</td>
						              		</tr>
						                  	<tr>
						                  		<td>
						                  			<label for="name">Image URL</label>
						                  		</td>
						                  		<td>
						                  			<input type="text" name="con_img_url[]" id="con_img_url" class="con_img_url" value="">		
						                  		</td>
						                  		<td>
					                      			<a class="button button-primary button-large" href="<?php echo admin_url(); ?>upload.php" target="_blank">Add Media</a>
					                      		</td>
						                  	</tr>
						                  	<tr>
						                  		<td>
						                  			<label for="name">Image Title</label>		
						                  		</td>
						                  		<td>
						                  			<input type="text" name="con_img_title[]" id="con_img_title" class="con_img_title" value="">
						                  		</td>
						                  	</tr>
						                  	<tr>
						                  		<td>
						                  			<label for="name">Image Caption</label>
						                  		</td>
						                  		<td>
						                  			<input type="text" name="con_img_caption[]" id="con_img_caption" class="con_img_caption" value="">		
						                  		</td>
						                  	</tr>
						              </table>
						        <?php } ?>
        		</td>
            </tr>
            <tr>
              <td>Content After Image</td>
            </tr>
            <tr>
              <td colspan="2">
              <?php
                //$editor_id = 'quote_description_'.$_POST['id'];
                $editor_id = 'content_after_image';
                $content = stripslashes($content_after_image);
                wp_editor( $content, $editor_id , $settings = array( 'media_buttons' => false , 'editor_height'=> '200px' ));
                
                ?>
            </tr>

            <tr>
              <?php 
              $detail_page_id = get_site_option( 'iflair_cruise_theme_ship_detail_page' );
              $view_url = get_permalink($detail_page_id).'?cruise_id='.$cruise_id;

              ?>
              <td><input class="button button-primary button-large" type="button" name="save" id="save" onclick="save_offer()" value="Save"></td>
              <td><input id="resetform" class="button button-primary button-large" type="button" name="Reset" value="Reset" onclick="return resetForm();"></td>
              <td><a href="<?php echo $view_url;?>" target="_blank" class="button button-primary button-large">View</a></td>
            <tr>
          </table>
        </td>
        <td style="width: 35%" class="extra_info">
          <table style="text-align: left;" class="rightsidetb">
            <tr><th colspan="2" class="cruisetitleadmin">Cruise Information</th></tr>
            <tr><td class="titlefield">Sail Date</td><td><?php echo date('d M Y',strtotime($cruise_details->ship_starts_on)); ?></td></tr>
            <tr><td class="titlefield">Cruise Line</td><td><?php echo $cruise_details->ship_operator; ?></td></tr>
            <tr><td class="titlefield">Ship</td><td><?php echo $cruise_details->ship_name; ?></td></tr>
            <tr><td class="titlefield">Region</td><td><?php echo $cruise_details->ship_region; ?></td></tr>
            <tr><td class="titlefield">Cruise</td><td><?php echo $cruise_details->cruise_title; ?></td></tr>
            <tr><td class="titlefield">Fly Out</td><td><?php echo $cruise_details->ship_fly_out; ?></td></tr>
            <tr><td class="titlefield">Fly in</td><td><?php echo $cruise_details->ship_fly_in; ?></td></tr>
            <tr><td class="titlefield">Cruise Night</td><td><?php echo $cruise_details->ship_cruise_nights; ?></td></tr>
            <tr><td class="titlefield">Vacation Days</td><td><?php echo $cruise_details->ship_vacation_days; ?></td></tr>
          </table>
        </td>
      </tr>

        <tr id="msg_div">
          <th></th>
        </tr>
    </table>
  </form>
  <script type="text/javascript">
    $(document).ready(function() {
      $('#start_date').datepicker({
        inline: true,
        nextText: '&rarr;',
        prevText: '&larr;',
        showOtherMonths: true,
        dateFormat: 'yy-mm-dd',
        dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        showOn: "button",
        buttonImage: "<?php echo plugin_dir_url( __FILE__ ); ?>/calendar-blue.png",        buttonImageOnly: true,
      });
      $('#end_date').datepicker({
        inline: true,
        nextText: '&rarr;',
        prevText: '&larr;',
        showOtherMonths: true,
        dateFormat: 'yy-mm-dd',
        dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        showOn: "button",
        buttonImage: "<?php echo plugin_dir_url( __FILE__ ); ?>/calendar-blue.png",        buttonImageOnly: true,
      });
      $('#departure_date_new').datepicker({
        inline: true,
        nextText: '&rarr;',
        prevText: '&larr;',
        showOtherMonths: true,
        dateFormat: 'yy-mm-dd',
        dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        showOn: "button",
        buttonImage: "<?php echo plugin_dir_url( __FILE__ ); ?>/calendar-blue.png",        buttonImageOnly: true,
      });

      $('#extra_info').limit('50','#left1');
      //$('#cabin_info').limit('30','#left');
      
    });
  </script>
   
  <?php
  \_WP_Editors::enqueue_scripts();
  print_footer_scripts();
  \_WP_Editors::editor_js();
  die();
}

function package_offer_pagging($page="",$numofrec,$select_ship_query){
  global $wpdb,$mydb,$mainsiteprefix;       
  
  $start = ($page-1)*$per_page;
  $page = $page;
  $cur_page = $page;
  $page -= 1;
  $per_page = $numofrec;
  $previous_btn = true;
  $next_btn = true;
  $first_btn = true;
  $last_btn = true;
  $start = $page * $per_page;
  //$count = $pages;
  //$no_of_paginations = ceil($count / $per_page);

  $select_ship_pag = $wpdb->get_results($select_ship_query);
$innercount = count($select_ship_pag);
$no_of_paginations = ceil($innercount/$per_page);

  /* ---------------Calculating the starting and endign values for the loop----------------------------------- */
  if ($cur_page >= 3) {
      $start_loop = $cur_page - 1;
      if ($no_of_paginations > $cur_page + 1)
          $end_loop = $cur_page + 1;
      else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 2) {
          $start_loop = $no_of_paginations - 2;
          $end_loop = $no_of_paginations;
      } else {
          $end_loop = $no_of_paginations;
      }
  } else {
      $start_loop = 1;
      if ($no_of_paginations > 3)
          $end_loop = 3;
      else
          $end_loop = $no_of_paginations;
  }
  /* ----------------------------------------------------------------------------------------------------------- */
  $msg .= "<div class='pagination-menu'><ul id='pagination'>";

  // FOR ENABLING THE FIRST BUTTON
  if ($first_btn && $cur_page > 1) {
      $msg .= "<li id='1' class='active'>First</li>";
  } else if ($first_btn) {
      $msg .= "<li id='1' class='inactive'>First</li>";
  }

  // FOR ENABLING THE PREVIOUS BUTTON
  if ($previous_btn && $cur_page > 1) {
      $pre = $cur_page - 1;
      $msg .= "<li id='$pre' class='active'>Previous</li>";
  } else if ($previous_btn) {
      $msg .= "<li class='inactive'>Previous</li>";
  }
  for ($i = $start_loop; $i <= $end_loop; $i++) {
      //echo $cur_page;
      if ($cur_page == $i)
          $msg .= "<li id='$i' class='active currentdiv'>{$i}</li>";
      else
          $msg .= "<li id='$i' class='active'>{$i}</li>";
  }

  // TO ENABLE THE NEXT BUTTON
  if ($next_btn && $cur_page < $no_of_paginations) {
      $nex = $cur_page + 1;
      $msg .= "<li id='$nex' class='active'>Next</li>";
  } else if ($next_btn) {
      $msg .= "<li class='inactive'>Next</li>";
  }

  // TO ENABLE THE END BUTTON
  if ($last_btn && $cur_page < $no_of_paginations) {
      $msg .= "<li id='$no_of_paginations' class='active'>Last</li>";
  } else if ($last_btn) {
      $msg .= "<li id='$no_of_paginations' class='inactive'>Last</li>";
  }
  $msg = $msg . "</ul></div>";  // Content for pagination
  echo $msg;
}

function package_offer_func($atts) {
  global $wpdb,$mydb;
  ?>
  <link href="<?php echo plugin_dir_url( __FILE__ ); ?>css/package_offer_style.css" rel="stylesheet" type="text/css"/>  
  <?php
  ob_start();

  if(!empty($atts) && isset($atts['per_page'])){
    $per_page=$atts['per_page'];
  }
  else{
    $per_page=2;
  }
  
  if(!empty($_POST)){
    //$start=$_POST['pagenumb'];
    $page=$_POST['pagenumb'];
  }
  else{
    $start=0;
    $page=1;
  }

  $start = ($page-1)*$per_page;

?>
<div class="filter_line">

<?php

  if(!empty($atts) && isset($atts['layout'])){
    if($atts['layout'] == "grid"){
    ?>
    <div id="layout_changer_box" class="grid_layout_box">
    <?php
    }
    else if($atts['layout'] == "list"){
    ?>
    <div id="layout_changer_box" class="list_layout_box">
    <?php
    }
    else{
    ?>
    <div class="layout_changer">
      <a class="grid_layout fa fa-th-large"></a>
      <a class="list_layout active_layout fa fa-list-ul"></a>
    </div>
    <div id="layout_changer_box" class="list_layout_box">
    <?php
    }
  }
  ?>
    <div class="offer_result">
    <?php include(CRUISE_OFFER_PLUGIN_PATH.'/package_offer.php'); ?>
    </div>
</div>
  </div>
  <script type="text/javascript">
    jQuery(document).ready(function(){
      jQuery(".grid_layout").click(function(){
        //alert("grid");
        jQuery(".list_layout").removeClass("active_layout");
        jQuery(".grid_layout").addClass("active_layout");
        //jQuery("#layout_changer_box").removeClass("list_layout_box");
        //jQuery("#layout_changer_box").addClass("grid_layout_box");

        jQuery("#layout_changer_box").removeClass("list_layout_box").delay(200).queue(function(next){
            jQuery("#layout_changer_box").addClass("grid_layout_box");
            next();
        });

      });
      jQuery(".list_layout").click(function(){
        //alert("list");
        jQuery(".grid_layout").removeClass("active_layout");
        jQuery(".list_layout").addClass("active_layout");
        //jQuery("#layout_changer_box").removeClass("grid_layout_box");
        //jQuery("#layout_changer_box").addClass("list_layout_box");

        jQuery("#layout_changer_box").removeClass("grid_layout_box").delay(200).queue(function(next){
            jQuery("#layout_changer_box").addClass("list_layout_box");
            next();
        });
      });
      package_offer_right();

    });

    function package_offer_filter(str){
      var offer_val = str;

      if(offer_val == "search"){

        jQuery(".display_offer").removeClass("active_toggle_offer");
        jQuery(".sidebar_filter_offer_detail").slideUp();

        jQuery('.loader').css('display','block');
        var pageNum = 1;
        var perpage = <?php echo $per_page; ?>;
        var region = jQuery('#offer_region').val();
        //alert(region);
        var ship_id = jQuery("#offer_ship").val();
        var departure_date = jQuery("#offer_departure_date").val();

        jQuery.ajax({
              type: "POST",
              url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
              data: ({
                  action: 'package_offer_response',
                  pagenumb:pageNum,
                  perpage:perpage,
                  ship_id:ship_id,
                  region:region,
                  departure_date:departure_date
              }),
              success: function (response) {
                  //alert(response);
                  jQuery('.offer_result').html(response);
                jQuery('.loader').css('display','none');
              }
          });
        }
      }

      function package_offer_right(str){
        jQuery('.loader_r').css('display','block');
        var pageNum = 1;
        var perpage = <?php echo $per_page; ?>;
        var region = jQuery('#offer_region').val();
        //alert(region);
        var ship_id = jQuery("#offer_ship").val();
        var departure_date = jQuery("#offer_departure_date").val();

        jQuery.ajax({
              type: "POST",
              url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
              data: ({
                  action: 'package_offer_right',
                  ship_id:ship_id,
                  region:region,
                  departure_date:departure_date
              }),
              success: function (response) {
                  //alert(response);
                  jQuery('.sidebar_filter_offer').html(response);

                  jQuery("#detail_search").hide();
                  //jQuery("#side_filter_con").empty();
                  jQuery(".sidebar_filter h3").html("Cruise Offer Search");
                jQuery('.loader').css('display','none');
              }
          });
      }
  </script>
  <?php
  $content = ob_get_clean();
  return $content;
}

add_shortcode( 'package_offer', 'package_offer_func' );

function package_offer_response(){

  $pagenum=$_POST['pagenumb'];
  $per_page=$_POST['perpage'];
  if($_POST['pagenumb']==""){
    //$per_page = 10;
    $page='1';
    $start='0';
  }
  else {
    //$per_page = 10;
    $page=$_POST['pagenumb']; 
    $start=($page-1)*$per_page;
  }
  
  include(CRUISE_OFFER_PLUGIN_PATH.'/package_offer.php');
  exit();
}

function iflair_view_offers(){
  include(CRUISE_OFFER_PLUGIN_PATH.'/view_list.php');
}

function cruise_offer_delete_res(){
  global $wpdb;
  //echo $_POST['id'];
  $query = "DELETE FROM ".QUOTE_EXTRA_OFFER." WHERE cruise_id = '".$_POST[id]."'";
  $wpdb->delete( QUOTE_EXTRA_OFFER_IMAGES, array( 'cruise_id' => $_POST[id] ) );    
  $list_res = $wpdb->get_results($query);
  echo "<td colspan='6' style='color: rgb(255, 255, 255); text-align: left;'>Offer Deleted Successfully.</td>";
  exit();
}

function package_offer_right(){
  global $wpdb, $mydb;
  /*echo "<pre>";
  //print_r($_POST);
  echo "</pre>";*/
  $region = $_POST['region'];
  $ship_id = $_POST['ship_id'];
  $departure_date = $_POST['departure_date'];
  ?>
<div id="side_filter_con">

<?php
$region_query = "";
$region_query .= "SELECT ship_id,cruise_id,ship_region FROM `".QUOTE_EXTRA_OFFER."` WHERE offer_start_date < curdate() and offer_end_date > curdate()";
if($ship_id!=""){
  $region_query .= " AND ship_id ='".$ship_id."'";
}
if($departure_date!=""){
  $region_query .= " AND departure_date LIKE '%$departure_date%'";
}
$region_query .= " GROUP BY ship_region";

$offer_region = $wpdb->get_results($region_query);
?>
<div class="loader_r" style="display:none;">
  <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader_1.gif" class="loader_r_img">
</div>
<select onchange="package_offer_right('region');" class="btn btn-default dropdown-toggle text p-2 second_filter_class" id="offer_region" name="offer_region">
<option value="">Select Region</option>
  <?php
  for ($os=0; $os < count($offer_region) ; $os++) {
    ?><option <?php if($offer_region[$os]->ship_region==$_POST['region']){ echo "selected"; } ?> value="<?php echo $offer_region[$os]->ship_region; ?>"><?php echo $offer_region[$os]->ship_region; ?></option>
    <?php
  }
  ?>
</select>


<?php
$ship_id_query = "";
$ship_id_query .= "SELECT ship_id,cruise_id,ship_region FROM `".QUOTE_EXTRA_OFFER."` WHERE offer_start_date < curdate() and offer_end_date > curdate()";
if($region!=""){
  $ship_id_query .= " AND ship_region ='".$region."'";
}
if($departure_date!=""){
  $ship_id_query .= " AND departure_date LIKE '%$departure_date%'";
}
$ship_id_query .= " GROUP BY ship_id";
$cruise_arry1 = $wpdb->get_results($ship_id_query);

$ship_arry = $cruise_arry1[0]->ship_id;
for ($sop=1; $sop < count($cruise_arry1) ; $sop++) { 
  $ship_arry = $ship_arry."','".$cruise_arry1[$sop]->ship_id;
}

$offer_ship = $mydb->get_results("SELECT cruise_title,cruise_response_id FROM cruise_cruise WHERE cruise_response_id IN ('".$ship_arry."') ");
?>

<div class="loader_r" style="display:none;">
  <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader_1.gif" class="loader_r_img">
</div>
<select onchange="package_offer_right('ship');" class="btn btn-default dropdown-toggle text p-2 second_filter_class" id="offer_ship" name="offer_ship">
<option value="">Select Ship</option>
    <?php
    for ($os=0; $os < count($offer_ship) ; $os++) {
    ?><option <?php if($offer_ship[$os]->cruise_response_id==$_POST['ship_id']){ echo "selected"; } ?> value="<?php echo $offer_ship[$os]->cruise_response_id; ?>"><?php echo $offer_ship[$os]->cruise_title; ?></option>
    <?php
    }
    ?>
</select>

<?php
$departure_date_query = "";
$departure_date_query .= "SELECT ship_id,cruise_id,ship_region,departure_date FROM `".QUOTE_EXTRA_OFFER."` WHERE offer_start_date < curdate() and offer_end_date > curdate()";
if($region!=""){
  $departure_date_query .= " AND ship_region ='".$region."'";
}
if($ship_id!=""){
  $departure_date_query .= " AND ship_id ='".$ship_id."'";
}
$departure_date_query .= " GROUP BY YEAR(departure_date),MONTH(departure_date) ORDER BY departure_date";

$offer_departure_date = $wpdb->get_results($departure_date_query);
?>
<div class="loader_r" style="display:none;">
  <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader_1.gif" class="loader_r_img">
</div>
<select onchange="package_offer_right('departure_date');" class="btn btn-default dropdown-toggle text p-2 second_filter_class" id="offer_departure_date" name="offer_departure_date">
<option value="">Select Departure Date</option>
  <?php
  for ($os=0; $os < count($offer_departure_date) ; $os++) {
    ?><option <?php if(date('Y-m',strtotime($offer_departure_date[$os]->departure_date))==$_POST['departure_date']){ echo "selected"; } ?> value="<?php echo date('Y-m',strtotime($offer_departure_date[$os]->departure_date)); ?>"><?php echo date('F Y',strtotime($offer_departure_date[$os]->departure_date)); ?></option>
    <?php
  }
  ?>
</select>

<span style="text-align: center; line-height: 46px;cursor:pointer;" class="search-bt-2" onclick="package_offer_filter('search');">Search</span>

</div>
  <?php
  exit();
}

function iflair_tag_management(){
  global $wpdb,$mydb,$tag_tbl;
  include(CRUISE_OFFER_PLUGIN_PATH.'/tag_management.php');
}
function save_tag(){
  global $wpdb,$mydb,$tag_tbl;
  $tag_attr = $_POST['tag_attr'];
  $tag_name = $_POST['tag_name'];
  $tag_slug = strtolower(str_replace(' ', '-', $_POST['tag_name']));
  $tag_status = "1";
  /*echo "<pre>";
  print_r($_POST);
  echo "</pre>";*/
  if($tag_attr == "add"){
    $tag_id_q = $wpdb->get_row("SELECT tag_id FROM ".$tag_tbl." WHERE tag_name = '".$tag_name."' ");
    if(empty($tag_id_q->tag_id)){
      //echo "Add tag name :- ".$tag_name;
      $tag_i_q = $wpdb->insert(
          $tag_tbl,
          array(
              'tag_name' => $tag_name,
              'tag_slug' => $tag_slug,
              'tag_status' => $tag_status,
            )
        );
      echo "Your New Tag Added Successfully.";
    }
    else{
      echo "This Tag is Already Exist :- .".$tag_name;
    }
  }
  else{
    $tag_id_q = $wpdb->get_row("SELECT tag_id FROM ".$tag_tbl." WHERE tag_slug = '".$tag_attr."' ");
    //print_r($tag_id_q);
    $tag_id = $tag_id_q->tag_id;
    //echo "Edit tag name :- ".$tag_name;
    $tag_i_q = $wpdb->update(
        $tag_tbl,
        array(
            'tag_name' => $tag_name,
            'tag_slug' => $tag_slug,
            'tag_status' => $tag_status,
          ),
        array(
            'tag_id' => $tag_id
          )
      );
    echo "Your Tag Edited Successfully.";
  }
  exit();
}

function delete_tag(){
  global $wpdb,$mydb,$tag_tbl;
  $tag_id = $_POST['tag_id'];
  $tag_name = $_POST['tag_name'];
  $tag_status = "0";
    $tag_i_q = $wpdb->update(
        $tag_tbl,
        array(
            'tag_status' => $tag_status,
          ),
        array(
            'tag_id' => $tag_id
          )
      );
    echo "Tag '".$tag_name."' Deleted Successfully.";
}
?>