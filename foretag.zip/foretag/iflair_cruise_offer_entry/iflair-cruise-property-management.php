<?php
/*
Plugin Name: iFlair Cruise Offer Entry
Plugin URI: http://www.iflair.com/
Description: This Plugin will show cruie property assigned to you.
Author: Maulik Panchal
Version: 1.0
Author URI: http://www.iflair.com/
*/
global $wpdb;
define( 'DETAIL_PAGE',esc_url(home_url('/'))."ship-detail");
define( 'CRUISE_OFFER_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define('ca_quote_extra_offer',"ca_quote_extra_offer");


/* MK Aded New cruise search */
add_action('wp_ajax_iflair_cruise_filter_response_offer', 'iflair_cruise_filter_response_offer'); // Logged-in users
add_action('wp_ajax_nopriv_iflair_cruise_filter_response_offer', 'iflair_cruise_filter_response_offer'); // Guest users
add_action('wp_ajax_iflair_search_filter_response_offer', 'iflair_search_filter_response_offer'); // Logged-in users
add_action('wp_ajax_nopriv_iflair_search_filter_response_offer', 'iflair_search_filter_response_offer'); // Guest users
add_action('wp_ajax_iflair_cruise_detail_offer', 'iflair_cruise_detail_offer'); // Logged-in users
add_action('wp_ajax_nopriv_iflair_cruise_detail_offer', 'iflair_cruise_detail_offer'); // Guest users

add_action('wp_ajax_cruise_offer_entry_form_ajax_res', 'cruise_offer_entry_form_ajax_res'); // Logged-in users
add_action('wp_ajax_nopriv_cruise_offer_entry_form_ajax_res', 'cruise_offer_entry_form_ajax_res'); // Guest users

add_action('wp_ajax_iflair_crusie_save_offer_ajax_res', 'iflair_crusie_save_offer_ajax_res');
//add_action('wp_ajax_nopriv_iflair_crusie_save_offer_ajax_res', 'iflair_crusie_save_offer_ajax_res'); // Guest users
add_action( 'admin_menu', 'iflair_cruise_offer_entry_listing' );
//wp_enqueue_script('jquery-ui-datepicker');

function iflair_cruise_offer_entry_listing(){
  global $wpdb;
  add_menu_page('iFlair Cruise Offer', 'iFlair Cruise Offer', 'manage_options', 'iflair-cruise-offer' , 'iflair_cruise_offer_entry');


}

function iflair_cruise_offer_entry(){
wp_register_style( 'cruisePluginStylesheet', plugins_url('css/offer_entry_style.css', __FILE__) );
wp_enqueue_style( 'cruisePluginStylesheet' );
wp_enqueue_script( 'cruisePluginScript', CRUISE_OFFER_PLUGIN_URL . 'js/1.11.2jquery.min.js', array(), '1.0.0', true );
wp_enqueue_script( 'cruisePluginScript1', CRUISE_OFFER_PLUGIN_URL . 'js/cookie.js', array(), '1.0.0', true );
wp_enqueue_script( 'cruisePluginScript2', CRUISE_OFFER_PLUGIN_URL . 'js/jquery.mCustomScrollbar.concat.min.js', array(), '1.0.0', true );
?>
<script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/cookie.js"></script>
<?php
  global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
  $mainsiteprefix='cm_';
  $agentsiteurl=get_option('siteurl');
  $agentsitedetail=iflair_get_subsite_id($agentsiteurl);
  $agentsiteid=$agentsitedetail->id;
  $agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
  $agent_assign_operator;

  ?>
  
  <div class="loader" style="display:none;">
    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader.gif" style="position: absolute; left: 50%;">
  </div>
  <h2>Cruise Search Offer Entry</h2>
  <div class="input-form wrraper clearfix">
    <div class="container clearfix">
      <div class="form-field">
        
        <div class="btn-group i-1 h-1" role="group">
        <select name="iflair_cruise_region" id="iflair_cruise_region" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('region');" >
        <option value="" disabled>Where do you want to go?</option>
        <?php
        $cruise_types= "SELECT cruise_id FROM `cruise_ship_cruise_type` WHERE ship_cruise_type = 'River'";
        $cruise_types_array_r = $mydb->get_results($cruise_types);
        

        $types_array = array();
        foreach ($cruise_types_array_r as $cruise_types_array) :
          if(!in_array($cruise_types_array->cruise_id,$types_array)){ 
            $types_array[] = $cruise_types_array->cruise_id;
          }
        endforeach;
        //print_r($types_array);

        $cruise_region= "SELECT csc.ship_region , csc.cruise_id FROM `cruise_ship_cruise` as csc INNER JOIN `cruise_operators` as co ON csc.ship_operator = co.operator_app_id WHERE co.operator_id IN (".$agent_assign_operator.") GROUP BY csc.ship_region";
        $select_cruise_region = $mydb->get_results($cruise_region);
        $types_ocean = array();
        $types_river = array();
        foreach ($select_cruise_region as $cruise_region_obj) :

            if(in_array($cruise_region_obj->cruise_id , $types_array)){
              //$types_river[] = $cruise_region_obj->cruise_id;
              $types_river[] = '<option value="'.$cruise_region_obj->ship_region.'">'.$cruise_region_obj->ship_region.' ( River )</option>';
            }
            else{
              //$types_ocean[] = $cruise_region_obj->cruise_id;
              $types_ocean[] = '<option value="'.$cruise_region_obj->ship_region.'">'.$cruise_region_obj->ship_region.'</option>';
            }

        endforeach;
        echo "<pre>";
        print_r($types_ocean);
        echo "<br>";
        print_r($types_river);
        echo "</pre>";
        ?>
    </select>
      </div>

    <div class="btn-group i-2 h-2" role="group">
      <?php
        $cruise_operator_title= "SELECT * FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
      
        if($region != ""){
          $cruise_operator_title .= " AND csc.ship_region = '$region'";
        }
        if($operator != ""){
          $cruise_operator_title .= " AND co.operator_id = $operator";
        }
        if($cruise_ship != ""){
          $cruise_operator_title .= " AND csc.ship_id = $cruise_ship";
        }
        if($ship_fly_in != ""){
          $cruise_operator_title .= " AND csc.ship_fly_in = '$ship_fly_in'";
        }
        if($ship_starts_on != ""){
          $cruise_operator_title .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
        }
        if($ship_vacation_days != ""){
          $cruise_operator_title .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
        }
          else{
            $cruise_operator_title .= " GROUP BY co.operator_title ORDER BY co.operator_title";
          }
        $select_cruise_operator_title = $mydb->get_results($cruise_operator_title);
        $c2 = count($select_cruise_operator_title);
        $qq="0 value";
      ?>
        <img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
        <select <?php //if($c2==0){echo 'disabled="true" ';}?> name="iflair_cruise_operator" id="iflair_cruise_operator" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('operator');" >
        <option value="" disabled>Which Cruise Line?</option>
        <option value="all" <?php if($_POST['operator']=="all"){ echo "selected"; } ?>>Any</option>
        <?php
        foreach ($select_cruise_operator_title as $cruise_operator_title_obj) :
          ?>
          <option value="<?php echo $cruise_operator_title_obj->operator_id; ?>" <?php if($operator == $cruise_operator_title_obj->operator_id ){ echo "selected"; } ?> ><?php echo $cruise_operator_title_obj->operator_title; ?></option>
          <?php
        endforeach;
        ?>
      </select>
      </div>

      <div class="btn-group i-3 h-3" role="group">
        <?php
          $cruise_cruise_ship="";
          $cruise_cruise_ship .= "SELECT * FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
        if($region != ""){
          $cruise_cruise_ship .= " AND csc.ship_region = '$region'";
        }
        if($operator != ""){
          $cruise_cruise_ship .= " AND co.operator_id = $operator";
        }
        if($cruise_ship != ""){
          $cruise_cruise_ship .= " AND csc.ship_id = $cruise_ship";
        }
        if($ship_fly_in != ""){
          $cruise_cruise_ship .= " AND csc.ship_fly_in = '$ship_fly_in'";
        }
        if($ship_starts_on != ""){
          $cruise_cruise_ship .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
        }
        if($ship_vacation_days != ""){
          $cruise_cruise_ship .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
        }
          else{
            $cruise_cruise_ship .= " GROUP BY cc.cruise_title ORDER BY csc.ship_id";
          }
        $select_cruise_ship = $mydb->get_results($cruise_cruise_ship);
        $c3 = count($select_cruise_ship);
        if($c3==0){$cruise_ship="";}
        ?>
        <img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
        <select <?php //if($c3==0){echo 'disabled="true" ';}?> name="iflair_cruise_ship" id="iflair_cruise_ship" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('cruise_ship');" >
        <option value="" disabled>Which Ship?</option>
        <option value="all" <?php if($_POST['cruise_ship']=="all" ){ echo "selected"; } ?>>Any</option>
        <?php
        foreach ($select_cruise_ship as $cruise_ship_obj) :
          ?>
          <option value="<?php echo $cruise_ship_obj->ship_id; ?>" <?php if($cruise_ship == $cruise_ship_obj->ship_id ){ echo "selected"; } ?> ><?php echo $cruise_ship_obj->cruise_title; ?></option>
          <?php
        endforeach;
        ?>
      </select>
      </div>

      <div class="btn-group i-4 h-4" role="group">
        <?php
          $cruise_ship_fly_in= "SELECT csc.ship_fly_in FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
        if($region != ""){
          $cruise_ship_fly_in .= " AND csc.ship_region = '$region'";
        }
        if($operator != ""){
          $cruise_ship_fly_in .= " AND co.operator_id = $operator";
        }
        if($cruise_ship != ""){
          $cruise_ship_fly_in .= " AND csc.ship_id = $cruise_ship";
        }
        if($ship_fly_in != ""){
          $cruise_ship_fly_in .= " AND csc.ship_fly_in = '$ship_fly_in'";
        }
        if($ship_starts_on != ""){
          $cruise_ship_fly_in .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
        }
        if($ship_vacation_days != ""){
          $cruise_ship_fly_in .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
        }
          else{
            $cruise_ship_fly_in .= " GROUP BY csc.ship_fly_in ORDER BY csc.ship_fly_in";
          }
        $select_cruise_ship_fly_in = $mydb->get_results($cruise_ship_fly_in);
        $c4 = count($select_cruise_ship_fly_in);
        ?>
        <img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
        <select <?php //if($c4==0){echo 'disabled="true" ';}?> name="iflair_cruise_ship_fly_in" id="iflair_cruise_ship_fly_in" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('ship_fly_in');" >
        <option value="">Leaving from</option>
        <?php
        foreach ($select_cruise_ship_fly_in as $cruise_ship_fly_in_obj) :
          ?>
          <option value="<?php echo $cruise_ship_fly_in_obj->ship_fly_in; ?>" <?php if($ship_fly_in == $cruise_ship_fly_in_obj->ship_fly_in ){ echo "selected"; } ?> ><?php echo $cruise_ship_fly_in_obj->ship_fly_in; ?></option>
          <?php
        endforeach;
        ?>
      </select>
      </div>


      <div class="btn-group i-2 h-5" role="group">
        <?php
        $cruise_when= "SELECT csc.ship_starts_on FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
        if($region != ""){
          $cruise_when .= " AND csc.ship_region = '$region'";
        }
        if($operator != ""){
          $cruise_when .= " AND co.operator_id = $operator";
        }
        if($cruise_ship != ""){
          $cruise_when .= " AND csc.ship_id = $cruise_ship";
        }
        if($leaving_from != ""){
          $cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
        }
        if($ship_fly_in != ""){
          $cruise_when .= " AND csc.ship_fly_in = '$ship_fly_in'";
        }
        if($ship_vacation_days != ""){
          $cruise_when .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
        }
            $cruise_when .= " GROUP BY YEAR(csc.ship_starts_on),MONTH(csc.ship_starts_on) ORDER BY csc.ship_starts_on";
          
        $select_cruise_when = $mydb->get_results($cruise_when);
        $c5 = count($select_cruise_when);
        ?>
        <?php /*
        <input type="text" placeholder="When" value="<?php echo $ship_starts_on; ?>" name="iflair_cruise_ship_starts_on" id="iflair_cruise_ship_starts_on" >
      */ ?>
        <img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
        <select <?php //if($c5==0){echo 'disabled="true" ';}?> name="iflair_cruise_ship_starts_on" id="iflair_cruise_ship_starts_on" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('ship_starts_on');" >
        <option value="" >When</option>
        <option value="all" <?php if($_POST['ship_starts_on']=="all" ){ echo "selected"; } ?>>Any</option>
        <?php
        foreach ($select_cruise_when as $cruise_when_obj) :
          ?>
          <option value="<?php echo date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ; ?>" <?php if($ship_starts_on == date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ){ echo "selected"; } ?> ><?php $ship_date=$cruise_when_obj->ship_starts_on; echo date('F Y',strtotime($ship_date)); ?></option>
          <?php
        endforeach;
        ?>
      </select>
      </div>

      <div class="btn-group i-3 h-6" role="group">
        <?php
        $cruise_days= "SELECT csc.ship_vacation_days FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
        if($region != ""){
          $cruise_days .= " AND csc.ship_region = '$region'";
        }
        if($operator != ""){
          $cruise_days .= " AND co.operator_id = $operator";
        }
        if($cruise_ship != ""){
          $cruise_days .= " AND csc.ship_id = $cruise_ship";
        }
        if($ship_fly_in != ""){
          $cruise_days .= " AND csc.ship_fly_in = '$ship_fly_in'";
        }
        if($ship_starts_on != ""){
          $cruise_days .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
        }
        if($ship_vacation_days != ""){
          $cruise_days .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
        }
          else{
            $cruise_days .= " GROUP BY csc.ship_vacation_days ORDER BY csc.ship_vacation_days";
          }
        $select_cruise_days = $mydb->get_results($cruise_days);
        $c6 = count($select_cruise_days);
        ?>
        <img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
        <select <?php //if($c6==0){echo 'disabled="true" ';}?> name="iflair_cruise_ship_vacation_days" id="iflair_cruise_ship_vacation_days" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('ship_vacation_days');" >
        <option value="" disabled>Days</option>
        <option value="all" <?php if($_POST['ship_vacation_days']=="all"){ echo "selected"; } ?>>Any</option>
        <?php
        foreach ($select_cruise_days as $cruise_days_obj) :
          ?>
          <option value="<?php echo $cruise_days_obj->ship_vacation_days ; ?>" <?php if($ship_vacation_days == $cruise_days_obj->ship_vacation_days ){ echo "selected"; } ?> ><?php echo $cruise_days_obj->ship_vacation_days ; ?></option>
          <?php
        endforeach;
        ?>
      </select>
      </div>
      <div>
          <span onclick="iflair_search_filter_response_offer('search');" class="search-bt-2" style="text-align: center; line-height: 46px;cursor:pointer;">Search</span>
      <div>
      </div>
    </div>
  </div>
  
  <div id="replace_query_ajax">
  </div>

  <script type="text/javascript">
    

    jQuery( document ).ready(function() {
        
      jQuery.cookie('str1', '', {expires: 1 });
      jQuery.cookie('str2', '', {expires: 1 });

      jQuery('#iflair_cruise_region').prop('selectedIndex',0);
      jQuery('#iflair_cruise_operator').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_fly_in').prop('selectedIndex',0);
      jQuery('#iflair_cruise_leaving_from').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);

      //jQuery('#extra_info').limit('50','#charsLeft');

       
    });

    function resetForm()
    {
      
      //document.getElementById("offer_entry").reset();
      jQuery("#start_date").val('');
      jQuery("#end_date").val('');
      jQuery("#quote_description").val('');
      jQuery("#extra_info").val('');
      jQuery("#cabin_info").val('');
      jQuery("#offer_price").val('');
    }  
    function iflair_search_filter_response_offer(str){
      var pagenumb='1';
      var check = str;
      var region = jQuery('#iflair_cruise_region').val();
      var operator = jQuery('#iflair_cruise_operator').val();
      var cruise_ship = jQuery('#iflair_cruise_ship').val();
      var ship_fly_in = jQuery('#iflair_cruise_ship_fly_in').val();
      var leaving_from = jQuery('#iflair_cruise_leaving_from').val();
      var ship_starts_on = jQuery('#iflair_cruise_ship_starts_on').val();
      var ship_vacation_days = jQuery('#iflair_cruise_ship_vacation_days').val();
      if(check=="reset"){
        jQuery('#iflair_cruise_region').prop('selectedIndex',0);
        jQuery('#iflair_cruise_operator').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_fly_in').prop('selectedIndex',0);
        jQuery('#iflair_cruise_leaving_from').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
          jQuery('.loader_filt').css('display','block');

        jQuery.cookie('str1', '', {expires: 1 });
        jQuery.cookie('str2', '', {expires: 1 });

        return false;
      }
      if(check=="region"){
        jQuery('#iflair_cruise_operator').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_fly_in').prop('selectedIndex',0);
        jQuery('#iflair_cruise_leaving_from').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
        jQuery('.loader_filt').css('display','block');
          iflair_search_filter_response_offer();
      }
      if(check=="operator"){
        jQuery('#iflair_cruise_ship').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_fly_in').prop('selectedIndex',0);
        jQuery('#iflair_cruise_leaving_from').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
        jQuery('.loader_filt').css('display','block');
          iflair_search_filter_response_offer();
      }
      if(check=="cruise_ship"){
        jQuery('#iflair_cruise_ship_fly_in').prop('selectedIndex',0);
        jQuery('#iflair_cruise_leaving_from').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
        jQuery('.loader_filt').css('display','block');
          iflair_search_filter_response_offer();
      }
      if(check=="ship_fly_in"){
        jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
        jQuery('.loader_filt').css('display','block');
          iflair_search_filter_response_offer();
      }
      if(check=="leaving_from"){
        jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
        jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
        jQuery('.loader_filt').css('display','block');
          iflair_search_filter_response_offer();
      }
      if(check=="ship_starts_on"){
        jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
        jQuery('.loader_filt').css('display','block');
          iflair_search_filter_response_offer();
      }
      if(check=="ship_vacation_days"){
          iflair_search_filter_response_offer();
        jQuery('.loader_filt').css('display','block');
      }
      if(check=="search"){
        
        jQuery.cookie('str1', '', {expires: 1 });
        jQuery.cookie('str2', '', {expires: 1 });

        jQuery('.loader').css('display','block');
        jQuery('.search_header').addClass('searched');
        jQuery('.search_header').addClass('searched_image');
        jQuery('#replace_query_ajax').addClass('replace_query_class');
        iflair_cruise_filter_response_offer();

      }
      //alert(str);
      jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'iflair_search_filter_response_offer',
                region: region,
                operator: operator,
                cruise_ship: cruise_ship,
                ship_fly_in: ship_fly_in,
                leaving_from: leaving_from,
                ship_starts_on: ship_starts_on,
                ship_vacation_days: ship_vacation_days,
                pagenumb:pagenumb
            }),
            success: function (response) {
              //jQuery('.loader').css('display','none');
              jQuery('.loader_filt').css('display','none');
              //alert(response);
              jQuery('.form-field').html(response);
              //jQuery(".content").mCustomScrollbar();
            }
        });
        //iflair_cruise_filter_response_offer();
    }

    function iflair_cruise_filter_response_offer(){
      jQuery('.loader').css('display','block');
      var pagenumb='1';
      var region = jQuery('#iflair_cruise_region').val();
      var operator = jQuery('#iflair_cruise_operator').val();
      var cruise_ship = jQuery('#iflair_cruise_ship').val();
      var ship_fly_in = jQuery('#iflair_cruise_ship_fly_in').val();
      var leaving_from = jQuery('#iflair_cruise_leaving_from').val();
      var ship_starts_on = jQuery('#iflair_cruise_ship_starts_on').val();
      var ship_vacation_days = jQuery('#iflair_cruise_ship_vacation_days').val();
      jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'iflair_cruise_filter_response_offer',
                <?php if($_COOKIE['str1']!=""){ ?>str1: <?php echo "'".$_COOKIE['str1']."',"; } ?>
                <?php if($_COOKIE['str2']!=""){ ?>str2: <?php echo "'".$_COOKIE['str2']."',"; } ?>
                region: region,
                operator: operator,
                cruise_ship: cruise_ship,
                ship_fly_in: ship_fly_in,
                leaving_from: leaving_from,
                ship_starts_on: ship_starts_on,
                ship_vacation_days: ship_vacation_days,
                pagenumb:pagenumb
            }),
            success: function (response) {
              jQuery('.loader').css('display','none');
                jQuery('#replace_query_ajax').html(response);
                //jQuery(".content").mCustomScrollbar();
                      
        }
        });
    }

    
  </script>
  <?php
}


function iflair_search_filter_response_offer(){
  global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
  $mainsiteprefix='cm_';
  wp_enqueue_script('jquery-ui-datepicker');
  $agentsiteurl=get_option('siteurl');
  $agentsitedetail=iflair_get_subsite_id($agentsiteurl);
  $agentsiteid=$agentsitedetail->id;
  $agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
  $agent_assign_operator;

  /*echo "<pre>";
  print_r($_POST);
  echo "</pre>";*/
  if($_POST['region']=="all" ){ $region = ""; }else{ $region = $_POST['region']; }
  if($_POST['operator']=="all" ){ $operator = ""; }else{ $operator = $_POST['operator']; }
  if($_POST['cruise_ship']=="all" ){ $cruise_ship = ""; }else{ $cruise_ship = $_POST['cruise_ship']; }
  if($_POST['ship_fly_in']=="all" ){ $ship_fly_in = ""; }else{ $ship_fly_in = $_POST['ship_fly_in']; }  
  if($_POST['leaving_from']=="all" ){ $leaving_from = ""; }else{ $leaving_from = $_POST['leaving_from']; }
  if($_POST['ship_starts_on']=="all" ){ $ship_starts_on = ""; }else{ $ship_starts_on = $_POST['ship_starts_on']; }
  if($_POST['ship_vacation_days']=="all" ){ $ship_vacation_days = ""; }else{ $ship_vacation_days = $_POST['ship_vacation_days']; }  


  if($leaving_from!=""){
    $leaving_from_cruise_id= "SELECT cruise_id FROM cruise_port WHERE port_code='$leaving_from'";
    //echo $leaving_from_cruise_id."<---";
    $select_leaving_from_cruise_id = $mydb->get_results($leaving_from_cruise_id);
      $leaving_from_cruise_id_arr = array();
    foreach ($select_leaving_from_cruise_id as $leaving_from_cruise_id_obj) {
      $leaving_from_cruise_id_arr[] = $leaving_from_cruise_id_obj->cruise_id;
    }
    //print_r($leaving_from_cruise_id_arr);
    $leaving_from_cruise_id = $leaving_from_cruise_id_arr[0];
    //print_r($id_res);
    for($i=1;$i<count($leaving_from_cruise_id_arr);$i++){
      $leaving_from_cruise_id = $leaving_from_cruise_id.",".$leaving_from_cruise_id_arr[$i];
    }
    //echo $leaving_from_cruise_id;
  }


  ?>
  <div class="form-field">
    <div class="btn-group i-1 h-1" role="group">
        <select name="iflair_cruise_region" id="iflair_cruise_region" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('region');" >
        <option value="" >Where do you want to go?</option>
        <?php
        $cruise_types= "SELECT cruise_id FROM `cruise_ship_cruise_type` WHERE ship_cruise_type = 'River'";
        $cruise_types_array_r = $mydb->get_results($cruise_types);
        

        $types_array = array();
        foreach ($cruise_types_array_r as $cruise_types_array) :
          if(!in_array($cruise_types_array->cruise_id,$types_array)){ 
            $types_array[] = $cruise_types_array->cruise_id;
          }
        endforeach;
        //print_r($types_array);

        $cruise_region= "SELECT csc.ship_region , csc.cruise_id FROM `cruise_ship_cruise` as csc INNER JOIN `cruise_operators` as co ON csc.ship_operator = co.operator_app_id WHERE co.operator_id IN (".$agent_assign_operator.") GROUP BY csc.ship_region";
        $select_cruise_region = $mydb->get_results($cruise_region);
        $types_ocean = array();
        $types_river = array();
        foreach ($select_cruise_region as $cruise_region_obj) :

            if(in_array($cruise_region_obj->cruise_id , $types_array)){
              //$types_river[] = $cruise_region_obj->cruise_id;
              if($region == $cruise_region_obj->ship_region ){ $sel = "selected"; }else{ $sel = ""; }
              $types_river[] = '<option value="'.$cruise_region_obj->ship_region.'" '.$sel.'>'.$cruise_region_obj->ship_region.' ( River )</option>';
            }
            else{
              //$types_ocean[] = $cruise_region_obj->cruise_id;
              if($region == $cruise_region_obj->ship_region ){ $sel = "selected"; }else{ $sel = ""; }
              $types_ocean[] = '<option value="'.$cruise_region_obj->ship_region.'" '.$sel.'>'.$cruise_region_obj->ship_region.'</option>';
            }

        endforeach;
        echo "<pre>";
        print_r($types_ocean);
        echo "<br>";
        print_r($types_river);
        echo "</pre>";
        ?>
    </select>
      </div>

    <div class="btn-group i-2 h-2" role="group">
      <?php
        $cruise_operator_title= "SELECT * FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
      
        if($region != ""){
          $cruise_operator_title .= " AND csc.ship_region = '$region'";
        }
        if($cruise_ship != ""){
          $cruise_operator_title .= " AND csc.ship_id = $cruise_ship";
        }
        if($ship_fly_in != ""){
          $cruise_operator_title .= " AND csc.ship_fly_in = '$ship_fly_in'";
        }
        if($leaving_from != ""){
          $cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
        }
        if($ship_starts_on != ""){
          $cruise_operator_title .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
        }
        if($ship_vacation_days != ""){
          $cruise_operator_title .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
        }
            $cruise_operator_title .= " GROUP BY co.operator_title ORDER BY co.operator_title";
          
        $select_cruise_operator_title = $mydb->get_results($cruise_operator_title);
        $c2 = count($select_cruise_operator_title);
        $qq="0 value";
      ?>
        <img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
        <select <?php //if($c2==0){echo 'disabled="true" ';}?> name="iflair_cruise_operator" id="iflair_cruise_operator" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('operator');" >
        <option value="" >Which Cruise Line?</option>
        <option value="all" <?php if($_POST['operator']=="all"){ echo "selected"; } ?>>Any</option>
        <?php
        foreach ($select_cruise_operator_title as $cruise_operator_title_obj) :
          ?>
          <option value="<?php echo $cruise_operator_title_obj->operator_id; ?>" <?php if($operator == $cruise_operator_title_obj->operator_id ){ echo "selected"; } ?> ><?php echo $cruise_operator_title_obj->operator_title; ?></option>
          <?php
        endforeach;
        ?>
      </select>
      </div>

      <div class="btn-group i-3 h-3" role="group">
        <?php
          $cruise_cruise_ship="";
          $cruise_cruise_ship .= "SELECT * FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
        if($region != ""){
          $cruise_cruise_ship .= " AND csc.ship_region = '$region'";
        }
        if($operator != ""){
          $cruise_cruise_ship .= " AND co.operator_id = $operator";
        }
        if($leaving_from != ""){
          $cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
        }
        if($ship_fly_in != ""){
          $cruise_cruise_ship .= " AND csc.ship_fly_in = '$ship_fly_in'";
        }
        if($ship_starts_on != ""){
          $cruise_cruise_ship .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
        }
        if($ship_vacation_days != ""){
          $cruise_cruise_ship .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
        }
            $cruise_cruise_ship .= " GROUP BY cc.cruise_title ORDER BY csc.ship_id";
          
        $select_cruise_ship = $mydb->get_results($cruise_cruise_ship);
        $c3 = count($select_cruise_ship);
        if($c3==0){$cruise_ship="";}
        ?>
        <img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
        <select <?php //if($c3==0){echo 'disabled="true" ';}?> name="iflair_cruise_ship" id="iflair_cruise_ship" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('cruise_ship');" >
        <option value="" >Which Ship?</option>
        <option value="all" <?php if($_POST['cruise_ship']=="all" ){ echo "selected"; } ?>>Any</option>
        <?php
        foreach ($select_cruise_ship as $cruise_ship_obj) :
          ?>
          <option value="<?php echo $cruise_ship_obj->ship_id; ?>" <?php if($cruise_ship == $cruise_ship_obj->ship_id ){ echo "selected"; } ?> ><?php echo $cruise_ship_obj->cruise_title; ?></option>
          <?php
        endforeach;
        ?>
      </select>
      </div>

      <div class="btn-group i-4 h-4" role="group">
        <?php
          $cruise_ship_fly_in= "SELECT csc.ship_fly_in FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
        if($region != ""){
          $cruise_ship_fly_in .= " AND csc.ship_region = '$region'";
        }
        if($operator != ""){
          $cruise_ship_fly_in .= " AND co.operator_id = $operator";
        }
        if($cruise_ship != ""){
          $cruise_ship_fly_in .= " AND csc.ship_id = $cruise_ship";
        }
        if($ship_starts_on != ""){
          $cruise_ship_fly_in .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
        }
        if($ship_vacation_days != ""){
          $cruise_ship_fly_in .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
        }
            $cruise_ship_fly_in .= " GROUP BY csc.ship_fly_in ORDER BY csc.ship_fly_in";
          
        $select_cruise_ship_fly_in = $mydb->get_results($cruise_ship_fly_in);
        $c4 = count($select_cruise_ship_fly_in);
        ?>
        <img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
        <select <?php //if($c4==0){echo 'disabled="true" ';}?> name="iflair_cruise_ship_fly_in" id="iflair_cruise_ship_fly_in" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('ship_fly_in');" >
        <option value="" >Leaving from</option>
        <option value="all" <?php if($_POST['leaving_from'] == "all" ){ echo "selected"; } ?>>Any</option>
        <?php
        foreach ($select_cruise_ship_fly_in as $cruise_ship_fly_in_obj) :
          ?>
          <option value="<?php echo $cruise_ship_fly_in_obj->ship_fly_in; ?>" <?php if($ship_fly_in == $cruise_ship_fly_in_obj->ship_fly_in ){ echo "selected"; } ?> ><?php echo $cruise_ship_fly_in_obj->ship_fly_in; ?></option>
          <?php
        endforeach;
        ?>
      </select>
      </div>

      <div class="btn-group i-2 h-5" role="group">
        <?php
        $cruise_when= "SELECT csc.ship_starts_on FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
        if($region != ""){
          $cruise_when .= " AND csc.ship_region = '$region'";
        }
        if($operator != ""){
          $cruise_when .= " AND co.operator_id = $operator";
        }
        if($cruise_ship != ""){
          $cruise_when .= " AND csc.ship_id = $cruise_ship";
        }
        if($leaving_from != ""){
          $cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
        }
        if($ship_fly_in != ""){
          $cruise_when .= " AND csc.ship_fly_in = '$ship_fly_in'";
        }
        if($ship_vacation_days != ""){
          $cruise_when .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
        }
            $cruise_when .= " GROUP BY YEAR(csc.ship_starts_on),MONTH(csc.ship_starts_on) ORDER BY csc.ship_starts_on";
          
        $select_cruise_when = $mydb->get_results($cruise_when);
        $c5 = count($select_cruise_when);
        ?>
        <img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
        <select <?php //if($c5==0){echo 'disabled="true" ';}?> name="iflair_cruise_ship_starts_on" id="iflair_cruise_ship_starts_on" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('ship_starts_on');" >
        <option value="" >When</option>
        <option value="all" <?php if($_POST['ship_starts_on']=="all" ){ echo "selected"; } ?>>Any</option>
        <?php
        foreach ($select_cruise_when as $cruise_when_obj) :
          ?>
          <option value="<?php echo date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ; ?>" <?php if($ship_starts_on == date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ){ echo "selected"; } ?> ><?php $ship_date=$cruise_when_obj->ship_starts_on; echo date('F Y',strtotime($ship_date)); ?></option>
          <?php
        endforeach;
        ?>
      </select>
      </div>

      <div class="btn-group i-3 h-6" role="group">
        <?php
        $cruise_days= "SELECT csc.ship_vacation_days FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
        if($region != ""){
          $cruise_days .= " AND csc.ship_region = '$region'";
        }
        if($operator != ""){
          $cruise_days .= " AND co.operator_id = $operator";
        }
        if($cruise_ship != ""){
          $cruise_days .= " AND csc.ship_id = $cruise_ship";
        }
        if($leaving_from != ""){
          $cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
        }
        if($ship_fly_in != ""){
          $cruise_days .= " AND csc.ship_fly_in = '$ship_fly_in'";
        }
        if($ship_starts_on != ""){
          $cruise_days .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
        }
        if($ship_vacation_days != ""){
          $cruise_days .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
        }
            $cruise_days .= " GROUP BY csc.ship_vacation_days ORDER BY csc.ship_vacation_days";
          
        $select_cruise_days = $mydb->get_results($cruise_days);
        $c6 = count($select_cruise_days);
        ?>
        <img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
        <select <?php //if($c6==0){echo 'disabled="true" ';}?> name="iflair_cruise_ship_vacation_days" id="iflair_cruise_ship_vacation_days" class="btn btn-default dropdown-toggle text p-2 second_filter_class" required onchange="iflair_search_filter_response_offer('ship_vacation_days');" >
        <option value="" >Days</option>
        <option value="all" <?php if($_POST['ship_vacation_days']=="all" ){ echo "selected"; } ?>>Any</option>
        <?php
        foreach ($select_cruise_days as $cruise_days_obj) :
          ?>
          <option value="<?php echo $cruise_days_obj->ship_vacation_days ; ?>" <?php if($ship_vacation_days == $cruise_days_obj->ship_vacation_days ){ echo "selected"; } ?> ><?php echo $cruise_days_obj->ship_vacation_days ; ?></option>
          <?php
        endforeach;
        ?>
      </select>
      </div>
      <div colspan="6">
        <span onclick="iflair_search_filter_response_offer('search');" class="search-bt-2" style="text-align: center; line-height: 46px;cursor:pointer;">Search</span>
      </div>
  </div>

  <?php
  exit();
}
function iflair_cruise_filter_response_offer(){

global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
//wp_deregister_script('jquery-ui-core','jquery-ui-dialog');
//wp_register_script('jquery-ui','http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.5/jquery-ui.js',array('jquery'));
//wp_enqueue_script('jquery-ui');
//add_action( 'admin_enqueue_scripts', 'enqueue_date_picker' );
$mainsiteprefix='cm_';
$agentsiteurl=get_option('siteurl');
$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
$agentsiteid=$agentsitedetail->id;
$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
$agent_assign_operator;

  if($_POST['region']=="all" ){ $region = ""; }else{ $region = $_POST['region']; }
  if($_POST['operator']=="all" ){ $operator = ""; }else{ $operator = $_POST['operator']; }
  if($_POST['cruise_ship']=="all" ){ $cruise_ship = ""; }else{ $cruise_ship = $_POST['cruise_ship']; }
  if($_POST['ship_fly_in']=="all" ){ $ship_fly_in = ""; }else{ $ship_fly_in = $_POST['ship_fly_in']; }  
  if($_POST['leaving_from']=="all" ){ $leaving_from = ""; }else{ $leaving_from = $_POST['leaving_from']; }
  if($_POST['ship_starts_on']=="all" ){ $ship_starts_on = ""; }else{ $ship_starts_on = $_POST['ship_starts_on']; }
  if($_POST['ship_vacation_days']=="all" ){ $ship_vacation_days = ""; }else{ $ship_vacation_days = $_POST['ship_vacation_days']; }


?>

<div class="d-content clearfix setdataheight">
  <div class="container">
<h2 id="filter_title"><?php //echo "Results for ".$string; ?></h2>
<div class="side-bar">                  
  <div class="ship-features">
<?php
  $select_ship_query_left ="";
  $select_ship_query_left .= "SELECT cc.cruise_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
  $conditional_query ="";
  $conditional_query .="cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";

  if($leaving_from!=""){
    $lq = "SELECT cruise_id FROM cruise_port WHERE port_code = '$leaving_from' GROUP BY cruise_id";
    $select_lq = $mydb->get_results($lq);
    //print_r($select_lq[0]['cruise_id']);
    $leaving_string = $select_lq[0]->cruise_id;
    for($i=1;$i<count($select_lq);$i++)
    {
      //echo $select_lq[$i]->cruise_id;
      $leaving_string = $leaving_string.",".$select_lq[$i]->cruise_id;
    }
    //echo $leaving_string;
    $select_ship_query_left .= " AND csc.cruise_id IN ($leaving_string)";
  }
  if($_POST['str1']!="date_departure" ){
    if($region != ""){
      $select_ship_query_left .= " AND csc.ship_region = '$region'";
      $conditional_query .= " AND csc.ship_region = '$region'";
    }
    if($operator != ""){
      $select_ship_query_left .= " AND co.operator_id = $operator";
      $conditional_query .= " AND co.operator_id = $operator";
    }
    if($cruise_ship != ""){
      $select_ship_query_left .= " AND csc.ship_id = $cruise_ship";
      $conditional_query .= " AND csc.ship_id = $cruise_ship";
    }
    if($ship_fly_in != ""){
      $select_ship_query_left .= " AND csc.ship_fly_in = '$ship_fly_in'";
      $conditional_query .= " AND csc.ship_fly_in = '$ship_fly_in'";
    }
    if($ship_starts_on != ""){
      $select_ship_query_left .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
      $conditional_query .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
    }
    if($ship_vacation_days != ""){
      $select_ship_query_left .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
      $conditional_query .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
    }
  }

  $select_ship_query_left .= " GROUP BY cc.cruise_title"; /* Comment */
  $select_ship_query_left .= " ORDER BY cc.cruise_title";

  //echo $select_ship_query_left;
  $select_ship_query_left_r = $mydb->get_results($select_ship_query_left);


/* Master Query Start------------------------------- */
  $pagenum=$_POST['pagenumb'];
  if($_POST['pagenumb']==""){
    $per_page = 10;
    $page='1';
    $start='0';
  }
  else {
    $per_page = 10;
    $page=$_POST['pagenumb']; 
    $start=($page-1)*$per_page;
  }

  //echo "Response Found -> ".$_POST['region']."<br>";

  if($_POST['str1'] !="" && $_POST['str2'] != "" ){
    if($_POST['str1']=="date_departure"){
      $date_departure = $_POST['str2'];
      $id_query = "SELECT * FROM cruise_ship_cruise WHERE $_POST[str1] LIKE '%$_POST[str2]%' GROUP BY ship_id";
      $id_res = $mydb->get_results($id_query);
        $ship_id = $id_res[0]->ship_id;
        //print_r($id_res);
        for($i=1;$i<count($id_res);$i++){
          $ship_id = $ship_id.",".$id_res[$i]->ship_id;
        }
        //echo $ship_id; ;
      
      $select_ship_query = "SELECT *, csc.cruise_id AS a, cc.cruise_id AS b , cc.cruise_profile_image_href , cc.cruise_cover_image_href , cc.cruise_response_id , cc.cruise_title , cc.cruise_operator_name FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator) AND csc.ship_starts_on LIKE '%$date_departure%'";
    }
    else{
      $id_query = "SELECT * FROM cruise_cruise WHERE $_POST[str1] = '$_POST[str2]'";
      $id_res = $mydb->get_results($id_query);
        $ship_id = $id_res[0]->cruise_response_id;
        for($i=1;$i<count($id_res);$i++){
          $ship_id = $ship_id.",".$id_res[$i]->cruise_response_id;
        }
      $select_ship_query = "SELECT *, csc.cruise_id AS a, cc.cruise_id AS b , cc.cruise_profile_image_href , cc.cruise_cover_image_href , cc.cruise_response_id , cc.cruise_title , cc.cruise_operator_name FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator) AND csc.ship_id IN ($ship_id)";
    }
      //echo $ship_id;
  }
  else{
    $select_ship_query ="";
    $select_ship_query .= "SELECT csc.*, csc.cruise_id AS a, cc.cruise_id AS b , cc.cruise_profile_image_href , cc.cruise_cover_image_href , cc.cruise_response_id , cc.cruise_title , cc.cruise_operator_name FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE co.operator_id IN ($agent_assign_operator)";
  }

  if($leaving_from!=""){
    $lq = "SELECT cruise_id FROM cruise_port WHERE port_code = '$leaving_from' GROUP BY cruise_id";
    $select_lq = $mydb->get_results($lq);
    //print_r($select_lq[0]['cruise_id']);
    $leaving_string = $select_lq[0]->cruise_id;
    for($i=1;$i<count($select_lq);$i++)
    {
      //echo $select_lq[$i]->cruise_id;
      $leaving_string = $leaving_string.",".$select_lq[$i]->cruise_id;
    }
    //echo $leaving_string;
    $select_ship_query .= " AND csc.cruise_id IN ($leaving_string)";
    $string .= $leaving_from ;
  }
  if($_POST['str1']!="date_departure" ){
    $string ="";
    if($region != ""){
      $select_ship_query .= " AND csc.ship_region = '$region'";
      $string .= $region ;
    }
    if($operator != ""){
      $select_ship_query .= " AND co.operator_id = $operator";
      $string .= $operator ;
    }
    if($cruise_ship != ""){
      $select_ship_query .= " AND csc.ship_id = $cruise_ship";
      $string .= $cruise_ship ;
    }
    if($ship_fly_in != ""){
      $select_ship_query .= " AND csc.ship_fly_in = '$ship_fly_in'";
      $string .= $ship_fly_in ;
    }
    if($ship_starts_on != ""){
      $select_ship_query .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
      $string .= $ship_starts_on ;
    }
    if($ship_vacation_days != ""){
      $select_ship_query .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
      $string .= $ship_vacation_days ;
    }
  }

  //$select_ship_query .= " GROUP BY csc.ship_name"; /* Comment */
  $select_ship_query .= " ORDER BY csc.ship_starts_on";
  $select_ship_query_unlimit = $select_ship_query;
  $select_ship_query .= " LIMIT $start,$per_page";
  //echo $string;
  //echo $select_ship_query;
  $select_ship = $mydb->get_results($select_ship_query);
  //echo count($select_ship);
/* Master Query End--------------------------------------------------------- */

?>
    <ul>
      <li><a class="pointer_class iflair_template_value_cruiseship" onclick="iflair_ajax_cruise_operators_left('reset');" >Cruise Lines</a></li>
      <li id="sub_list"><a>Cruise Ship<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
        <ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
          <?php
            if(count($select_ship_query_left_r)==0){
              
            $select_cruise_ship_size_all = $mydb->get_results("SELECT cruise_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_size AS css ON co.operator_title = cc.cruise_operator_name GROUP BY cc.cruise_title ORDER BY cruise_title");
            foreach ($select_cruise_ship_size_all as $cruise_ship_size_obj) :
            ?>
            <li><a onclick="iflair_ajax_cruise_operators_left('cruise_title','<?php echo $cruise_ship_size_obj->cruise_title; ?>');" class="<?php if($cruise_ship_size_obj->cruise_title==$_COOKIE['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_title; ?></a></li>
            <?php
            endforeach;
            }
            else{
            foreach ($select_ship_query_left_r as $cruise_ship_size_obj) :
            ?>
            <li><a onclick="iflair_ajax_cruise_operators_left('cruise_title','<?php echo $cruise_ship_size_obj->cruise_title; ?>');" class="<?php if($cruise_ship_size_obj->cruise_title==$_COOKIE['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_title; ?></a></li>
            <?php
            endforeach;
            }
            ?>
        </ul>
      </li>
      <li id="sub_list"><a>Ship Size<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
        <ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
          <?php
          $main_size = "";
          $main_size .= "SELECT cc.cruise_ship_size FROM ";
          $main_size .= $conditional_query;
          $main_size .= " GROUP BY cruise_ship_size";
            $select_cruise_ship_size = $mydb->get_results("$main_size");
            if(count($select_cruise_ship_size)==0){
              $select_cruise_ship_size_all = $mydb->get_results("$main_size");
            foreach ($select_cruise_ship_size_all as $cruise_ship_size_obj) :
            ?>
            <li><a onclick="iflair_ajax_cruise_operators_left('cruise_ship_size','<?php echo $cruise_ship_size_obj->cruise_ship_size; ?>');" class="<?php if($cruise_ship_size_obj->cruise_ship_size==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_ship_size; ?></a></li>
            <?php
            endforeach;
            }
            else{
            foreach ($select_cruise_ship_size as $cruise_ship_size_obj) :
            ?>
            <li><a onclick="iflair_ajax_cruise_operators_left('cruise_ship_size','<?php echo $cruise_ship_size_obj->cruise_ship_size; ?>');" class="<?php if($cruise_ship_size_obj->cruise_ship_size==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_ship_size; ?></a></li>
            <?php
            endforeach;
            }
            ?>
        </ul>
      </li>
      <li id="sub_list">
        <a>Ship Style<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
        <ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
          <?php
            $main_style = "";
            $main_style .= "SELECT cc.crusie_ship_style FROM ";
            $main_style .= $conditional_query;
            $main_style .= " GROUP BY crusie_ship_style";
              $select_cruise_ship_style = $mydb->get_results("$main_style");
            if(count($select_cruise_ship_style)==0){
              $select_cruise_ship_style_all = $mydb->get_results("$main_style");
              foreach ($select_cruise_ship_style_all as $cruise_ship_style_obj) :
              ?>
              <li><a onclick="iflair_ajax_cruise_operators_left('crusie_ship_style','<?php echo $cruise_ship_style_obj->crusie_ship_style; ?>');" class="<?php if($cruise_ship_style_obj->crusie_ship_style==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_style_obj->crusie_ship_style; ?></a></li>
              <?php
              endforeach;
            }
            else{
              foreach ($select_cruise_ship_style as $cruise_ship_style_obj) :
              ?>
              <li><a onclick="iflair_ajax_cruise_operators_left('crusie_ship_style','<?php echo $cruise_ship_style_obj->crusie_ship_style; ?>');" class="<?php if($cruise_ship_style_obj->crusie_ship_style==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_style_obj->crusie_ship_style; ?></a></li>
              <?php
              endforeach;
            }
            ?>
        </ul>
      </li>
      <li id="sub_list">
        <a>Language<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
        <ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
          <?php
            $select_cruise_language = $mydb->get_results("SELECT cl.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_language AS cl ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id =$operator AND cl.language_code = cc.cruise_language GROUP BY cc.cruise_language ORDER BY cc.cruise_operator_name");
            if(count($select_cruise_language)==0){
              $select_cruise_language_all = $mydb->get_results("SELECT cl.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_language AS cl ON co.operator_title = cc.cruise_operator_name GROUP BY cl.language_code ORDER BY cc.cruise_operator_name");
              foreach ($select_cruise_language_all as $cruise_language_obj) :
              ?>
              <li><a onclick="iflair_ajax_cruise_operators_left('cruise_language','<?php echo $cruise_language_obj->language_code; ?>');" class="<?php if($cruise_language_obj->language_code==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_language_obj->language_title; ?></a></li>
              <?php
              endforeach;
            }
            else{
              foreach ($select_cruise_language as $cruise_language_obj) :
              ?>
              <li><a onclick="iflair_ajax_cruise_operators_left('cruise_language','<?php echo $cruise_language_obj->language_code; ?>');" class="<?php if($cruise_language_obj->language_code==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_language_obj->language_title; ?></a></li>
              <?php
              endforeach;
            }
            ?>
        </ul>
      </li>
      <!-- <li id="sub_list">
        <input type="text" placeholder="Departure Date" value="<?php if($_POST['str1']=="date_departure"){ echo $_POST['str2']; } ?>" name="iflair_cruise_ship_departure_date" id="iflair_cruise_ship_departure_date" onchange="iflair_ajax_cruise_operators_left('date_departure','');" style="width: 100%;padding-left: 25px;">
      </li> -->
    </ul>
  </div>
</div>

    <div class="result-part">
<?php
  
  if(count($select_ship) == 0)
  {
    echo "No Cruise Found ..";
  }
  else
  {
    //echo $page;
    //echo $per_page;
    //echo $select_ship_query;
    cruise_pagging_offer($page,$per_page,$select_ship_query_unlimit);

    for($i=0;$i<count($select_ship);$i++)
    {
    ?>

<div class="mediter-box clearfix">
  <div class="medi-left">
    <div class="newtableimg">
      <div class="netablecellimg">
        <img src="http://ej8pnde.cloudimg.io/s/resize/200/<?php if($select_ship[$i]->cruise_profile_image_href!=""){ echo $select_ship[$i]->cruise_profile_image_href; }else{ } ?>" class="img-responsive">
      </div>
    </div>
  </div>
  <div class="medi-mid">
    <h3><?php echo $select_ship[$i]->ship_name; ?></h3>
    <p class="small_p">Region <span>- <?php echo $select_ship[$i]->ship_region; ?></span></p>
    <p>Departure Date <span>- <?php $ship_date=$select_ship[$i]->ship_starts_on; echo date('d/m/Y',strtotime($ship_date)); ?></span></p>
    <p class="small_p">No of Nights <span>- <?php echo $select_ship[$i]->ship_cruise_nights; ?></span></p>
    <p>Ship <span>- <?php echo $select_ship[$i]->cruise_title; ?></span></p>
  </div>
  <div class="medi-right">
    
    <div class="main_added_text">
    <?php 
    $price1 = $select_ship[$i]->ship_cruise_only_price;
    $price2 = $select_ship[$i]->ship_fly_cruise_price;
    if($price1=="0" && $price2=="0")
    {
      ?>
      <h2>Guide Price Range</h2>
      <p>Please enquire for today’s price</p>
      <?php
    }
    elseif( ( $price1!="0" && $price1 < $price2 ) || $price2== "0" )
    {
      ?>
      <h2>Guide Price Range</h2>
      <p>From <span class="textbld">£<?php echo number_format($price1); ?></span> cruise only per person</p>
      <?php
    }
    elseif( ( $price2!="0" && $price1 > $price2 ) || $price1== "0" )
    {
      ?>
      <h2>Guide Price Range</h2>
      <p>From <span class="textbld">£<?php echo number_format($price2); ?></span> cruise only per person</p>
      <?php
    }
    ?>
    </div>
    <div class="added_img">
    </div>
  </div>
</div>
<div class="cruse-information cruise_offer_box clearfix" id="<?php echo $select_ship[$i]->cruise_id; ?>">
  <?php echo $select_ship[$i]->cruise_id; ?>
</div>

    <?php
    }
  }
  ?>
<script type="text/javascript">
    jQuery.noConflict();
    jQuery(document).ready(function(){
      jQuery(".mediter-box").click(function(){
        jQuery(".cruise_offer_box").slideUp();
        jQuery(".cruise_offer_box").empty();
        var id = jQuery(this).next(".cruise_offer_box").attr('id');
        jQuery("#"+id).slideToggle();
        jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'cruise_offer_entry_form_ajax_res',
                id : id
            }),
            success: function (response) {
                jQuery('.loader').css('display','none');
                jQuery('#'+id).html(response);
            }
        });
      });
      
      jQuery("#pagination li").click(function(){
        jQuery('.loader').css('display','block');
        var pageNum = this.id;
        var region = jQuery('#iflair_cruise_region').val();
        var operator = jQuery('#iflair_cruise_operator').val();
        var cruise_ship = jQuery('#iflair_cruise_ship').val();
        var ship_fly_in = jQuery('#iflair_cruise_ship_fly_in').val();
        var leaving_from = jQuery('#iflair_cruise_leaving_from').val();
        var ship_starts_on = jQuery('#iflair_cruise_ship_starts_on').val();
        var ship_vacation_days = jQuery('#iflair_cruise_ship_vacation_days').val();
        jQuery.ajax({
              type: "POST",
              url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
              data: ({
                  action: 'iflair_cruise_filter_response_offer',
                <?php if($_COOKIE['str1']!=""){ ?>str1: <?php echo "'".$_COOKIE['str1']."',"; } ?>
                <?php if($_COOKIE['str2']!=""){ ?>str2: <?php echo "'".$_COOKIE['str2']."',"; } ?>
                region: region,
                operator: operator,
                cruise_ship: cruise_ship,
                ship_fly_in: ship_fly_in,
                leaving_from: leaving_from,
                ship_starts_on: ship_starts_on,
                ship_vacation_days: ship_vacation_days,
                  pagenumb:pageNum
              }),
              success: function (response) {
                jQuery('.loader').css('display','none');
                  //alert(response);
                  jQuery('#replace_query_ajax').html(response);
                  //jQuery(".content").mCustomScrollbar();
              }
          });
      });
      jQuery('.itinerary_btn').click(function(){
        //jQuery(this).parent().parent().parent().next('.cruse-information').slideToggle();
        if(jQuery(this).parent().parent().parent().next('.cruse-information').hasClass("a1")){
          jQuery(this).parent().parent().parent().next('.cruse-information').removeClass("a1");
          jQuery(this).parent().parent().parent().next('.cruse-information').slideUp();
        }
        else{
          jQuery('.cruse-information').removeClass("a1");
          jQuery('.cruse-information').slideUp();
          jQuery(this).parent().parent().parent().next('.cruse-information').slideDown();
          jQuery(this).parent().parent().parent().next('.cruse-information').addClass("a1");
        }
      });
      jQuery(this).next('ul').slideUp();
      jQuery('#sub_list a').on('click',function(){
        jQuery(this).next('ul').slideToggle();
      });
      var item = jQuery(".active_left");
        item.parent().parent().css('display','block');
        item.parent().parent().parent().parent().css('display','block');
    });

function iflair_ajax_cruise_operators_left(str1,str2){  
    jQuery('.loader').css('display','block'); 
    var pagenumb='1';
    var str1 = str1;
    //alert(str1);  
    /*if(str1=='date_departure'){
      var str2 =jQuery('#iflair_cruise_ship_departure_date').val();
      jQuery('#iflair_cruise_region').prop('selectedIndex',0);
      jQuery('#iflair_cruise_operator').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_fly_in').prop('selectedIndex',0);
      jQuery('#iflair_cruise_leaving_from').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
    }*/
    if(str1=='reset'){
      jQuery('#iflair_cruise_region').prop('selectedIndex',0);
      jQuery('#iflair_cruise_operator').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_fly_in').prop('selectedIndex',0);
      jQuery('#iflair_cruise_leaving_from').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_starts_on').prop('selectedIndex',0);
      jQuery('#iflair_cruise_ship_vacation_days').prop('selectedIndex',0);
    }
    else{
      var str2 = str2;
    }

    jQuery.cookie('str1', str1, {expires: 1 });
    jQuery.cookie('str2', str2, {expires: 1 });

    //alert(str2);
    var operator = jQuery('#iflair_cruise_operator').val();
    var region = jQuery('#iflair_cruise_region').val();
    var pagenumb=pagenumb;
    var touroperator = jQuery('#iflair_template_cruise_operators').val();
    //alert(jQuery("#iflair_template_cruise_operators option:selected").text());
    var shipsize = jQuery('#iflair_template_cruise_ship_size').val();
    var shipstyle = jQuery('#iflair_template_cruise_ship_style').val();
    var shiplanguage = jQuery('#iflair_template_cruise_language').val();
    var dateToday = new Date();
        jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'iflair_cruise_filter_response_offer',
                str1: str1,
                str2: str2,
              operator: operator,
        region: region,
                pagenumb:pagenumb
            }),
            success: function (response) {
              jQuery('.loader').css('display','none');
                //alert(response);
                jQuery('#replace_query_ajax').html(response);
                  //jQuery(".content").mCustomScrollbar();
          /*jQuery("#iflair_cruise_ship_departure_date").datepicker({ 
            minDate: dateToday ,
            dateFormat: 'yy-mm-dd'
          });*/
          
            }
        });
}

    function iflair_cruise_detail_offer_of(cruise_id){
          jQuery('.loader_1').css('display','block');
      var id = id;
      var ship_name = ship_name;
      var cruise_id = cruise_id;
      var region = jQuery('#iflair_cruise_region').val();
      var operator = jQuery('#iflair_cruise_operator').val();
      var cruise_ship = jQuery('#iflair_cruise_ship').val();
      var ship_fly_in = jQuery('#iflair_cruise_ship_fly_in').val();
      var leaving_from = jQuery('#iflair_cruise_leaving_from').val();
      var ship_starts_on = jQuery('#iflair_cruise_ship_starts_on').val();
      var ship_vacation_days = jQuery('#iflair_cruise_ship_vacation_days').val();
      jQuery.ajax({
              type: "POST",
              url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
              data: ({
                  action: 'iflair_cruise_detail_offer',
                region: region,
                operator: operator,
                cruise_ship: cruise_ship,
                ship_fly_in: ship_fly_in,
                leaving_from: leaving_from,
                ship_starts_on: ship_starts_on,
                ship_vacation_days: ship_vacation_days,
                id: id,
                ship_name: ship_name,
                cruise_id: cruise_id
              }),
              success: function (response) {
                jQuery('.loader_1').css('display','none');
                  //alert(response);
                //jQuery('.scroll_empty').empty();
                  jQuery('.scroll'+cruise_id).html(response);
                  //jQuery(".content").mCustomScrollbar();
              }
          });
    }


</script>
  </div>
</div>
  <?php
  exit();
}

/* Code started by Arvind */
function cruise_pagging_offer($page="",$numofrec,$select_ship_query){
  global $wpdb,$mydb,$mainsiteprefix;       
  //wp_enqueue_script('jquery-ui-datepicker');
$start = ($page-1)*$per_page;
$page = $page;
  $cur_page = $page;
  $page -= 1;
  $per_page = $numofrec;
  $previous_btn = true;
  $next_btn = true;
  $first_btn = true;
  $last_btn = true;
  $start = $page * $per_page;
  //$count = $pages;
  //$no_of_paginations = ceil($count / $per_page);

  $select_ship_pag = $mydb->get_results($select_ship_query);
$innercount = count($select_ship_pag);
$no_of_paginations = ceil($innercount/$per_page);

  /* ---------------Calculating the starting and endign values for the loop----------------------------------- */
  if ($cur_page >= 3) {
      $start_loop = $cur_page - 1;
      if ($no_of_paginations > $cur_page + 1)
          $end_loop = $cur_page + 1;
      else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 2) {
          $start_loop = $no_of_paginations - 2;
          $end_loop = $no_of_paginations;
      } else {
          $end_loop = $no_of_paginations;
      }
  } else {
      $start_loop = 1;
      if ($no_of_paginations > 3)
          $end_loop = 3;
      else
          $end_loop = $no_of_paginations;
  }
  /* ----------------------------------------------------------------------------------------------------------- */
  $msg .= "<div class='pagination-menu'><ul id='pagination'>";

  // FOR ENABLING THE FIRST BUTTON
  if ($first_btn && $cur_page > 1) {
      $msg .= "<li id='1' class='active'><<</li>";
  } else if ($first_btn) {
      $msg .= "<li id='1' class='inactive'><<</li>";
  }

  // FOR ENABLING THE PREVIOUS BUTTON
  if ($previous_btn && $cur_page > 1) {
      $pre = $cur_page - 1;
      $msg .= "<li id='$pre' class='active'><</li>";
  } else if ($previous_btn) {
      $msg .= "<li class='inactive'><</li>";
  }
  for ($i = $start_loop; $i <= $end_loop; $i++) {

      if ($cur_page == $i)
          $msg .= "<li id='$i' class='active currentdiv'>{$i}</li>";
      else
          $msg .= "<li id='$i' class='active'>{$i}</li>";
  }

  // TO ENABLE THE NEXT BUTTON
  if ($next_btn && $cur_page < $no_of_paginations) {
      $nex = $cur_page + 1;
      $msg .= "<li id='$nex' class='active'>></li>";
  } else if ($next_btn) {
      $msg .= "<li class='inactive'>></li>";
  }

  // TO ENABLE THE END BUTTON
  if ($last_btn && $cur_page < $no_of_paginations) {
      $msg .= "<li id='$no_of_paginations' class='active'>>></li>";
  } else if ($last_btn) {
      $msg .= "<li id='$no_of_paginations' class='inactive'>>></li>";
  }
  $msg = $msg . "</ul></div>";  // Content for pagination
  echo $msg;
}
function iflair_crusie_save_offer_ajax_res(){
  global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
  //wp_enqueue_script('jquery-ui-datepicker');
  $cruise_id = $_POST['cruise_id'];
  $ship_id = $_POST['ship_id'];
  $cruise_type = $_POST['cruise_type'];
  $departure_date =  $_POST['departure_date'];
  $start_date = $_POST['start_date'];
  $end_date = $_POST['end_date'];
  $quote_description = $_POST['quote_description'];
  $cabin_info = $_POST['cabin_info'];
  $offer_price = $_POST['offer_price'];
  $extra_info = $_POST['extra_info'];
  $date = date('Y-m-d');

  $que = "SELECT * FROM ".ca_quote_extra_offer." where ship_id = '".$ship_id."' and cruise_id = '".$cruise_id."' ";
  $offer_select= $wpdb->get_row("SELECT * FROM ".ca_quote_extra_offer." where ship_id = '".$ship_id."' and cruise_id = '".$cruise_id."' ");
    //print '<pre>';
    //print_r($offer_select);
    //print '</pre>';
  $offer_count = count($offer_select);

  //echo "<br/>QUERY".$que;
  //echo "<br/>COUNT".$offer_count;
  
  if(empty($offer_count))
  {

    $wpdb->insert(
          ca_quote_extra_offer,
          array( 
              'ship_id' => $ship_id,
              'cruise_id' => $cruise_id,
              'cruise_type' => $cruise_type,
              'departure_date' => $departure_date, 
              'offer_start_date' => $start_date, 
              'offer_end_date' => $end_date,
              'description' => $quote_description,
              'cabin_info' => $cabin_info,
              'offer_price' => $offer_price,
              'extra_info' => $extra_info,
              'created_date' => $date
          ) 
          
        );
        echo 'Value Insterted'; 
    
  }
  else
  {
      $wpdb->update(
            ca_quote_extra_offer,
            array( 
              'cruise_type' => $cruise_type,
              'departure_date' => $departure_date, 
              'offer_start_date' => $start_date, 
              'offer_end_date' => $end_date,
              'description' => $quote_description,
              'cabin_info' => $cabin_info,
              'offer_price' => $offer_price,
              'extra_info' => $extra_info,
              'updated_date' => $date
            ),
            array('ship_id' => $ship_id, 'cruise_id' => $cruise_id)
            
          );
      echo 'Value Updated';
  }
  die();
}
function cruise_offer_entry_form_ajax_res(){
  global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
  //wp_enqueue_script( 'jquery' );
  //wp_enqueue_script( 'jquery-ui-core' );
  //wp_enqueue_script( 'jquery-datepicker', 'http://jquery-ui.googlecode.com/svn/trunk/ui/jquery.ui.datepicker.js', array('jquery', 'jquery-ui-core' ) );
  $mainsiteprefix='cm_';
  $agentsiteurl=get_option('siteurl');
  $agentsitedetail=iflair_get_subsite_id($agentsiteurl);
  $agentsiteid=$agentsitedetail->id;
  $agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
  $agent_assign_operator;
  

  $cruise_id = $_POST['id'];
  $cruise_details_query = "SELECT * FROM cruise_ship_cruise as csc INNER JOIN cruise_cruise as cc ON csc.ship_id=cc.cruise_response_id WHERE csc.cruise_id = '".$cruise_id."'";
  $cruise_details = $mydb->get_row($cruise_details_query);

  //echo $cruise_id;
  //echo "<pre>";
  //print_r($cruise_details);
  //echo "</pre>";
  
  $cruise_type = "SELECT DISTINCT `crusie_ship_type` FROM cruise_cruise WHERE `crusie_ship_type` != ''";
  $type_details = $mydb->get_results($cruise_type);

  $cruise_type = $cruise_details->crusie_ship_type;

  //get extra offer value
  $offer_details_query = "SELECT * FROM ca_quote_extra_offer  where cruise_id = '".$cruise_id."'";
  $offer_details = $wpdb->get_row($offer_details_query);
  $cruise_type = $offer_details->cruise_type;
  $offer_start_date = $offer_details->offer_start_date;
  $offer_end_date = $offer_details->offer_end_date;
  $description = $offer_details->description;
  $cabin_info = $offer_details->cabin_info;
  $offer_price = $offer_details->offer_price;
  $extra_info = $offer_details->extra_info;

  ?>
  <script type="text/javascript">
    function save_offer()
    {
      
      $('#offer_entry').validate({
              errorPlacement: function(error,element) {
              return true;
              }
      });
      tinyMCE.triggerSave();
      var cruiseformdata = jQuery("#offer_entry").serialize();
      //$.validator.messages.required = '';
      if ($("#offer_entry").valid()) {
            
      jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: 'data='+cruiseformdata+'&action=iflair_crusie_save_offer_ajax_res',
            success: function(response) {
              //alert(response);
              var newhtm = '<tr id="msg_div"><th><h3 style="color:#15B587">'+response+'</h3></th></tr>';
              jQuery("#msg_div").replaceWith(newhtm);
                      
          }
        });
      }
    }
  </script>
  <link href="<?php echo plugin_dir_url( __FILE__ ); ?>css/datepicker.css" rel="stylesheet" type="text/css"/>  
  <script type="text/javascript" src="<?php echo plugin_dir_url( __FILE__ ); ?>/js/jquery-1.7.1.min.js"></script>
  <script type="text/javascript" src="<?php echo plugin_dir_url( __FILE__ ); ?>/js/jquery-ui-1.8.18.custom.min.js"></script>
  <script type="text/javascript" src="<?php echo plugin_dir_url( __FILE__ ); ?>/js/jquery.limit-1.2.source.js"></script>
  <script type="text/javascript" src="<?php echo plugin_dir_url( __FILE__ ); ?>/js/jquery.validate.js"></script>
  
  <form action="" name="offer_entry" id="offer_entry" method="post">
    <input type="hidden" name="ship_id1" id="ship_id1" value="<?php echo $cruise_details->ship_id ; ?>">
    <input type="hidden" name="ship_id" id="ship_id" value="<?php echo $cruise_details->ship_id ; ?>">
    <input type="hidden" name="cruise_id" id="cruise_id" value="<?php echo $_POST['id']; ?>">
    <input type="hidden" name="departure_date" id="departure_date" value="<?php echo date('Y-m-d',strtotime($cruise_details->ship_starts_on)); ?>">
    <table class="offer_entry_table">
      <tr>
        <td colspan="2">
          <h2><?php echo ucfirst($cruise_details->crusie_ship_type); ?> Offer Entry Form</h2>
        </td>
      </tr>
      <tr>
        <td>
          <table style="text-align: left;" class="leftsidetb">
            <tr id="msg_div">
              <th></th>
            </tr>
            <tr><th colspan="2">Offer Information</th></tr>
            <tr>
              <td>Cruise Type</td>
              <td>
                <input type="text" name="cruise_type" id="cruise_type" value="<?php echo $cruise_details->crusie_ship_type; ?>" readonly="readonly">
                <!--select name="cruise_type" id="crusie_type">
                <?php foreach($type_details as $tData){?>
                  <option value="<?php echo $tData->crusie_ship_type?>" <?php echo ($cruise_type==$tData->crusie_ship_type ? 'selected="/selected/"' : '');?>><?php echo $tData->crusie_ship_type;?></option>
                <?php } ?>
                </select--> 
              </td>
            </tr>
            <tr>
              <td>Departure Date</td>
              <td><?php echo date('d M Y',strtotime($cruise_details->ship_starts_on)); ?></td>
            </tr>
            <tr>
              <td>Start Offer</td>
              <td><input type="text" readonly="readonly" class="start_date" name="start_date" id="start_date" value="<?php echo $offer_start_date; ?>" /></td>
              </tr>
            <tr>
              <td>Valid Until</td>
              <td><input type="text" readonly="readonly" name="end_date" id="end_date" class="end_date" value="<?php echo $offer_end_date; ?>"></td>
            </tr>
            <tr>
              <td>Further cruise,tour or hotel information</td>
              <td>
              &nbsp;
              </td>
            </tr>
            <tr>
            <td colspan="2">
              <?php
                $editor_id = 'quote_description';
                $content = stripslashes($description);
                wp_editor( $content, $editor_id , $settings = array( 'media_buttons' => false , 'editor_height'=> '200px' ));
                \_WP_Editors::enqueue_scripts();
                print_footer_scripts();
              \_WP_Editors::editor_js();
                ?>
                <!-- <textarea name="quote_description" class="required" id="quote_description"><?php echo $description;?></textarea> -->
            </td>
            </tr>
            <tr>
              <td>Cabin (30 charecter)</td>
              <td><input type="text" name="cabin_info" class="required" id="cabin_info" value="<?php echo $cabin_info?>">
              </td>
            </tr>
            <tr>
              <td></td>
              <td>You have <span id="left"></span> charecter left</td>
            </tr>
            <tr>
              <td>Offer Price</td>
              <td><input type="text" class="required" name="offer_price" id="offer_price" value="<?php echo $offer_price;?>"></td>
            </tr>
            <tr>
              <td>Title (50 charecter)</td>
              <td>
              <textarea name="extra_info" class="required" id="extra_info"><?php echo $extra_info;?></textarea>
              </td>
            </tr>
            <tr>
              <td></td>
              <td>You have <span id="left1"></span> charecter left</td>
            </tr>
            <tr>
              <?php 
              $detail_page_id = get_site_option( 'iflair_cruise_theme_ship_detail_page' );
              $view_url = get_permalink($detail_page_id).'?cruise_id='.$cruise_id;

              ?>
              <td><input class="button button-primary button-large" type="button" name="save" id="save" onclick="save_offer()" value="Save"></td>
              <td><input class="button button-primary button-large" type="button" name="Reset" value="Reset" onclick="return resetForm();"></td>
              <td><a href="<?php echo $view_url;?>" target="_blank" class="button button-primary button-large">View</a></td>
            <tr>
          </table>
        </td>
        <td>
          <table style="text-align: left;" class="rightsidetb">
            <tr><th colspan="2" class="cruisetitleadmin">Cruise Information</th></tr>
            <tr><td class="titlefield">Sail Date</td><td><?php echo date('d M Y',strtotime($cruise_details->ship_starts_on)); ?></td></tr>
            <tr><td class="titlefield">Cruise Line</td><td><?php echo $cruise_details->ship_operator; ?></td></tr>
            <tr><td class="titlefield">Ship</td><td><?php echo $cruise_details->ship_name; ?></td></tr>
            <tr><td class="titlefield">Region</td><td><?php echo $cruise_details->ship_region; ?></td></tr>
            <tr><td class="titlefield">Cruise</td><td><?php echo $cruise_details->cruise_title; ?></td></tr>
            <tr><td class="titlefield">Fly Out</td><td><?php echo $cruise_details->ship_fly_out; ?></td></tr>
            <tr><td class="titlefield">Fly in</td><td><?php echo $cruise_details->ship_fly_in; ?></td></tr>
            <tr><td class="titlefield">Cruise Night</td><td><?php echo $cruise_details->ship_cruise_nights; ?></td></tr>
            <tr><td class="titlefield">Vacation Days</td><td><?php echo $cruise_details->ship_vacation_days; ?></td></tr>
          </table>
        </td>
      </tr>
    </table>
  </form>
  <script type="text/javascript">
    $(document).ready(function() {
      $('#start_date').datepicker({
        inline: true,
        nextText: '&rarr;',
        prevText: '&larr;',
        showOtherMonths: true,
        dateFormat: 'yy-mm-dd',
        dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        showOn: "button",
        buttonImage: "<?php echo plugin_dir_url( __FILE__ ); ?>/calendar-blue.png",        buttonImageOnly: true,
      });
      $('#end_date').datepicker({
        inline: true,
        nextText: '&rarr;',
        prevText: '&larr;',
        showOtherMonths: true,
        dateFormat: 'yy-mm-dd',
        dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        showOn: "button",
        buttonImage: "<?php echo plugin_dir_url( __FILE__ ); ?>/calendar-blue.png",        buttonImageOnly: true,
      });

      $('#extra_info').limit('50','#left1');
      $('#cabin_info').limit('30','#left');
      
    });
  </script>
   
  <?php

  die();
}
?>