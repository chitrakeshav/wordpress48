<?php
/**
 * Plugin Name: Cruise Search Affiliate
 * Plugin URI: 
 * Description: This plugin allow to set a cruise search filter using simple shortcode & widget.
 * Version: 1.0.0
 * Author: Net Effect
 * Author URI: 
 */
?>
<?php 
define( 'CRUISE_SEARCH_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CRUISE_SEARCH_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

add_action('admin_menu','cruise_search_action');
function cruise_search_action(){

	global $wpdb;
	$query1 = "CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."cruise_select_data` (
	  `cj_id` int(11) NOT NULL,
	  `cruise_id` varchar(255) NOT NULL,
	  `ship_region` varchar(255) NOT NULL,
	  `ship_starts_on` varchar(255) NOT NULL,
	  PRIMARY KEY (`cj_id`)
	) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;";
	$wpdb->get_results($query1);

	$query2 = "ALTER TABLE `".$wpdb->prefix."cruise_select_data` CHANGE `cj_id` `cj_id` INT(11) NOT NULL AUTO_INCREMENT";
	$wpdb->get_results($query2);

	$query3 = "CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."cruise_affiliate` (
	  `affiliate_id` int(11) NOT NULL,
	  `affiliate_key` varchar(255) NOT NULL,
	  `affiliate_name` varchar(255) NOT NULL,
	  `affiliate_email` varchar(255) NOT NULL,
	  `affiliate_phone` varchar(255) NOT NULL,
	  `affiliate_site_title` varchar(255) NOT NULL,
	  `affiliate_site_url` varchar(255) DEFAULT NULL,
	  `affiliate_created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
	) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;";
	$wpdb->get_results($query3);

	$query4 = "ALTER TABLE `".$wpdb->prefix."cruise_affiliate` CHANGE `affiliate_id` `affiliate_id` INT(11) NOT NULL AUTO_INCREMENT";
	$wpdb->get_results($query4);

	//add_menu_page('Cruise Search', 'Cruise Search', 'manage_options', 'cruise-search', 'cruise-search', plugins_url( 'iflair_cruise_search/icon.png' ), 78);
    //add_submenu_page('options-general.php','Cruise Search Affiliation', 'Cruise Search Affiliation', 'manage_options', 'cruise-search-affiliation', 'cruise_search_affiliation' );
}

function cruise_search_filter_func(){
	global $wpdb;
	?>
<?php
ob_start();
//wp_enqueue_script('jquery-ui-datepicker');
//wp_enqueue_style('jquery-style', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.2/themes/smoothness/jquery-ui.css');
?>
<div class="cruise_search">
	<h2>Find your Ideal Cruise</h2>
	<form name="cruise_search" action="<?php echo esc_url(home_url('/')); ?>cruise-search/" method="get" target="_blank">
		<div class="formdetail">
		<input type="hidden" id="afffiliate_key" value="<?php $f_key = get_site_option( 'affiliate_key' ); if( $f_key!="" ){ echo $f_key; }else{ echo "00000000000"; } ?>" name="f_key" />
		<input type="hidden" name="tab_id" value="undefined" >
		<input type="hidden" name="start_price" value="undefined" >
		<input type="hidden" name="end_price" value="undefined" >

		<div class="inputfirst">
			<label>Cruise Region </label>
			<select required class="start_date region_select" name="cruise_region" onchange="get_region_month(this.value);" id="region_select" >
				<option value="">-- Select Region --</option>
				<?php
				$region_ar = $wpdb->get_results("SELECT ship_region FROM ".$wpdb->prefix."cruise_select_data GROUP BY ship_region ");
				//print_r($region_ar);
				foreach ($region_ar as $value) {
					echo '<option value="'.$value->ship_region.'">'.$value->ship_region.'</option>';
				}
				?>
			</select>
		</div>
		<div class="selectlist">
			<label>Cruise Departure Date</label>
			<?php 
			/*$date = date("Y-m-d");
			if(date("n", strtotime($date)) >= date("n")) {
				echo '2016';
				echo $date;
			}
			elseif(date("n", strtotime($date)) <= date("n")) {
				echo '2017';
				echo $date;
			}*/
			//$homepage = file_get_contents('http://192.168.1.74/Cruiseselect/wp-content/themes/Cruiseselect/iflair_destination_get_date_for_affiliate_code_in.txt');
			//echo $homepage;
			?>
			<div class="loader_month" style="display: none;position: absolute;">
				<img src="<?php echo CRUISE_SEARCH_PLUGIN_URL; ?>loader_new.gif" style="height: 36px;">
			</div>
			<select required class="start_date start_date_month" id="month_select" name="cruise_ship_starts_on" >
				<option value="">-- Select Month --</option>
				<option value="<?php echo date("Y"); ?>-01" >January</option>
				<option value="<?php echo date("Y"); ?>-02" >February</option>
				<option value="<?php echo date("Y"); ?>-03" >March</option>
				<option value="<?php echo date("Y"); ?>-04" >April</option>
				<option value="<?php echo date("Y"); ?>-05" >May</option>
				<option value="<?php echo date("Y"); ?>-06" >June</option>
				<option value="<?php echo date("Y"); ?>-07" >July</option>
				<option value="<?php echo date("Y"); ?>-08" >August</option>
				<option value="<?php echo date("Y"); ?>-09" >September</option>
				<option value="<?php echo date("Y"); ?>-10" >October</option>
				<option value="<?php echo date("Y"); ?>-11" >November</option>
				<option value="<?php echo date("Y"); ?>-12" >December</option>
			</select>
		</div>
		<script type="text/javascript">
			function get_region_month(region_val){
				var region_val = region_val;
		        jQuery('.loader_month').css('display','block');
				jQuery.ajax({
		            type: "POST",
		            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
		            data: ({
		                action: 'cruise_month',
		                region_val : region_val
		            }),
		            success: function (response) {
		                jQuery('.start_date_month').empty();
		            	jQuery('.loader_month').css('display','none');
		                //alert(response);
		                jQuery('.start_date_month').html(response);
		            }
		        });
			}
		</script>
		<div class="submitbtn fr"><label></label><input type="submit" value="FIND YOUR PERFECT CRUISE" name="submit" /></div>
		<div class="clr"></div>
		</div>
	</form>
	<!-- <img src="<?php //echo CRUISE_SEARCH_PLUGIN_URL; ?>logo.png" alt=""> -->
	<!-- <div class="assdetail">in association with <span class="asstitle">Cruise select</span></div> -->
	</div>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function() {
		    /*jQuery('.start_date').datepicker({
		    	minDate: new Date(),
		        dateFormat : 'yy-mm',
		        onSelect: function(dateText, inst) {
				    var toDate = new Date(inst.selectedYear, inst.selectedMonth, inst.selectedDay);//Date one month after selected date
				    var oneDay = new Date(toDate.getTime()+86400000);
				    jQuery('.end_date').datepicker('option','minDate', new Date(inst.selectedYear, inst.selectedMonth, inst.selectedDay));
				}
		    });
		    jQuery('.end_date').datepicker({dateFormat : 'dd-mm-yy'});*/

			jQuery(function() {
				jQuery( '.start_date' ).datepicker({
					minDate: new Date(),
					dateFormat : 'yy-mm'
				});
			});
		});
	</script>
	<style type="text/css">
	.cruise_search h2 {
	  background: #eeeeee none repeat scroll 0 0;
	  font-size: 17px;
	  padding: 7px 7px 7px 10px;
	  margin: 0;
	  line-height: 25px;
	}
	.formdetail{
		border: 1px solid #efefef;
		padding: 10px;
	}
	.submitbtn{
		margin-top: 10px;
	}
	.fr{
		float: right;
	}
	.clr{
		clear: both;
	}
	.formdetail input[type="text"]{
		background: #fff;
		height: 35px;

	}
	.formdetail label{
		font-size: 14px;
	}
	.cruise_search input {
	  border: 1px solid rgb(204, 204, 204);
	  margin-bottom: 10px;
	  width: 100%;
	}
	.cruise_search .submitbtn.fr > input {
	  background: rgb(0, 158, 227) none repeat scroll 0 0;
	  border: medium none;
	  font-family: "proxima_nova_rgregular";
	  font-size: 17px;
	}
	.cruise_search .submitbtn.fr > input:active, .cruise_search .submitbtn.fr > input:hover {
	  background: rgb(0, 0, 0) none repeat scroll 0 0;
	padding: 11px 24px 10px;
	}
	.formdetail select{
		width: 100%;
		height: 35px;
		border: 1px solid #cccccc;
		border-radius: 2px;
		-webkit-border-radius: 2px;
		-moz-border-radius: 2px;
		o-border-radius: 2px;;
	}
	.formdetail select option{
		font-size: 14px;
	}
	.inputfirst {
	  margin-bottom: 10px;
	}
	.assdetail {
	  color: #000000;
	  font-style: italic;
	  margin-bottom: 10px;
	  margin-top: 10px;
	  text-align: right;
	}
	.assdetail span.asstitle {
	  font-family: arial;
	  font-size: 17px;
	  font-style: normal;
	  text-transform: uppercase;
	}
	
		@media (max-width: 479px){
			.assdetail{
				text-align: center;
			}
			.assdetail span.asstitle{
				font-size: 14px;
			}
		}
	</style>
	<?php
	$output = ob_get_clean();
    return $output;
}
add_shortcode('Cruise-Filter','cruise_search_filter_func');

function cruise_search_affiliation(){
	global $wpdb;
?>

<?php
}


// Creating the widget 
class scf_widget extends WP_Widget {

	function __construct() {
		parent::__construct(
		// Base ID of your widget
		'scf_widget', 

		// Widget name will appear in UI
		__('Cruise Search', 'cruise_search'), 

		// Widget description
		array( 'description' => __( 'Cruise Search : Cruise select', 'cruise_search' ), ) 
		);
	}

	// Creating widget front-end
	// This is where the action happens
	public function widget( $args, $instance ) {
		$title = apply_filters( 'widget_title', $instance['title'] );
		// before and after widget arguments are defined by themes
		echo $args['before_widget'];
		if ( ! empty( $title ) )
		echo $args['before_title'] . $title . $args['after_title'];

		// This is where you run the code and display the output
		echo __( cruise_search_filter_func(), 'cruise_search' );
		echo $args['after_widget'];
	}			

	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		return $instance;
	}

	// Widget Backend 
	/*
	public function form( $instance ) {
		// Widget admin form
		?>
		<p>
		<!-- <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" /> -->
		<label for="<?php echo $this->get_field_id( 'affiliate' ); ?>"><?php _e( 'Affiliate Key :' ); ?></label> 
		</p>
		<?php 
		?>
		<br>
		<label for="<?php echo $this->get_field_id( 'affiliate' ); ?>"><?php _e( 'Affiliate Key :' ); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'affiliate' ); ?>" name="<?php echo $this->get_field_name( 'affiliate' ); ?>" type="text" value="<?php echo esc_attr( $affiliate ); ?>" />
		<br>
		<?php
		?>
		<?php
		//cruise_search_affiliation();
		//echo "<br>";
	}
		*/

} // Class scf_widget ends here

// Register and load the widget
function cruise_search_widget() {
	register_widget( 'scf_widget' );
}
add_action( 'widgets_init', 'cruise_search_widget' );


add_action('wp_ajax_cruise_month', 'cruise_month'); // Logged-in users
add_action('wp_ajax_nopriv_cruise_month', 'cruise_month'); // Guest users
function cruise_month(){
	global $wpdb;
	echo $m_q = "SELECT ship_starts_on FROM ".$wpdb->prefix."cruise_select_data WHERE ship_region = '".$_POST['region_val']."' GROUP BY YEAR(ship_starts_on),MONTH(ship_starts_on) ORDER BY ship_starts_on";
	$get_moth = $wpdb->get_results($m_q);

	echo '<option value="">-- Select Month --</option>';
	foreach ($get_moth as $cruise_when_obj) :
		?>
		<option value="<?php echo date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ; ?>" <?php if($ship_starts_on == date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ){ echo "selected"; } ?> ><?php $ship_date=$cruise_when_obj->ship_starts_on; echo date('F Y',strtotime($ship_date)); ?></option>
		<?php
	endforeach;
exit();
}

/* Admin manage area */

add_action('admin_menu', 'cruise_search_affiliate_page');
function cruise_search_affiliate_page() {
    add_submenu_page('options-general.php','Cruise Search Affiliate', 'Cruise Search Affiliate', 'manage_options', 'cruise-search-affiliate', 'cruise_search_affiliate', plugins_url( 'iflair_cruise_search/icon.png' ));
}
function cruise_search_affiliate() {
	global $wpdb;

	$affiliate_table =  $wpdb->prefix."cruise_affiliate";
	if($_POST['submit'] == "Add Affiliation"){
		$affiliate_key = $_POST['csf_affiliate_key'];
		$affiliate_name = $_POST['csf_affiliate_name'];
		$affiliate_email = $_POST['csf_affiliate_email'];
		$affiliate_phone = $_POST['csf_affiliate_phone'];
		$affiliate_site_title = $_POST['csf_affiliate_site_title'];
		$affiliate_site_url = $_POST['csf_affiliate_site_url'];
		
		$wpdb->insert($affiliate_table, array('affiliate_key' => $affiliate_key, 'affiliate_name' => $affiliate_name , 'affiliate_email' => $affiliate_email , 'affiliate_phone' => $affiliate_phone, 'affiliate_site_title' => $affiliate_site_title , 'affiliate_site_url' => $affiliate_site_url ) );
        echo "<div class='updated below-h2' style='margin: 20px 2px 10px;' id='message'><p>Cruise Filter Affiliation Added Successfuly.</p></div>";
	}
	elseif( $_POST['submit'] == "Edit Affiliation" && isset($_GET['edit_affiliate']) ){
		$affiliate_key = $_POST['csf_affiliate_key'];
		$affiliate_name = $_POST['csf_affiliate_name'];
		$affiliate_email = $_POST['csf_affiliate_email'];
		$affiliate_phone = $_POST['csf_affiliate_phone'];
		$affiliate_site_title = $_POST['csf_affiliate_site_title'];
		$affiliate_site_url = $_POST['csf_affiliate_site_url'];
		
		$wpdb->update($affiliate_table, array('affiliate_name' => $affiliate_name , 'affiliate_email' => $affiliate_email , 'affiliate_phone' => $affiliate_phone, 'affiliate_site_title' => $affiliate_site_title , 'affiliate_site_url' => $affiliate_site_url ), array('affiliate_key' => $affiliate_key,'affiliate_id' => $_GET["edit_affiliate"]) );
        echo "<div class='updated below-h2' style='margin: 20px 2px 10px;' id='message'><p>Cruise Filter Affiliation Updated Successfuly.</p></div>";
	}
	if(isset($_GET['delete']) && isset($_GET['key'])){
		//echo "mmm";
		$wpdb->delete($affiliate_table, array( 'affiliate_id' => $_GET['delete'] ,'affiliate_key' => $_GET['key'] ) );
        echo "<div class='error below-h2' style='margin: 20px 2px 10px;' id='message'><p>Cruise Filter Affiliation Deleted Successfuly.</p></div>";
		/* ?>
		<script type="text/javascript">
			var url = "options-general.php?page=cruise-search-affiliate";
			window.history.pushState("", "", url);
		</script>
		<?php */
	}
?>
<div style="display: none;left: -180px; width: 112.8%; height: 100%; background: rgba(0, 0, 0, 0.5) none repeat scroll 0px 0px; z-index: 10000 ! important; text-align: center; position: fixed;top: 0;" class="loader_sync"><img style="padding-top: 20%; padding-left: 15%; width: 60px;" src="<?php echo CRUISE_SEARCH_PLUGIN_URL; ?>loader_sync.gif" ></div>
<div class="wrap">
	<h2 style="float: left; margin-bottom: 15px;">Cruise Filter Affiliation</h2>
	<div style="float: right; margin-top: 20px;"><a style="border-radius: 3px; color: rgb(255, 255, 255); background: rgb(0, 133, 186) none repeat scroll 0% 0%; padding: 7px 20px; cursor: pointer;" onclick="sync_affiliate();">Synchronize Now</a></div>
	<?php 
	if(isset($_GET['edit_affiliate'])){
		$get_affil = $wpdb->get_row("SELECT * FROM ".$affiliate_table." WHERE affiliate_id = ".$_GET['edit_affiliate']." AND affiliate_key = ".$_GET['key']." ");
		?>
		<a class="page-title-action" href="options-general.php?page=cruise-search-affiliate" style="float: left; margin-top: 12px;">Add New Affiliation</a>
		<?php
	}
	?>
	<table class="form-table">
		<tbody>
			<tr>	
				<td style="padding: 0;">
	<form enctype="multipart/form-data" method="post" name="activity_table" action="">
		<table width="100%" border="0" class="widefat">
			<tbody>
				<tr>
					<td width="100%" class="table_td" colspan="4" style="margin: 0px; background: rgba(0, 0, 0, 0.2) none repeat scroll 0% 0%;">
						<h2 style="margin: 0"><?php if(isset($_GET['edit_affiliate'])){ echo "Edit"; }else{ echo "Add"; } ?> New Affiliate</h2>
						<input style="width:80%;" type="hidden" name="csf_affiliate_key" id="csf_affiliate_key" value="<?php if(isset($_GET['edit_affiliate'])){ echo $get_affil->affiliate_key; }else{ echo rand(00000000000,99999999999); } ?>">
					</td>
				</tr>

				<tr>
					<td width="15%" class="tooltip">
						Affiliate Name
					</td>
					<td width="35%" class="tooltip">
						<input style="width:80%;" type="text" required="" name="csf_affiliate_name" id="csf_affiliate_name" value="<?php echo $get_affil->affiliate_name; ?>">
					</td>

					<td width="15%" class="tooltip">
						Email
					</td>
					<td width="35%" class="tooltip">
						<input style="width:80%;" type="text" required="" name="csf_affiliate_email" id="csf_affiliate_email" value="<?php echo $get_affil->affiliate_email; ?>">
					</td>
				</tr>

				<tr>
					<td width="15%" class="tooltip">
						Phone Number
					</td>
					<td width="35%" class="tooltip">
						<input style="width:80%;" type="text" required="" name="csf_affiliate_phone" id="csf_affiliate_phone" value="<?php echo $get_affil->affiliate_phone; ?>">
					</td>

					<td width="15%" class="tooltip">
						Site Title
					</td>
					<td width="35%" class="tooltip">
						<input style="width:80%;" type="text" required="" name="csf_affiliate_site_title" id="csf_affiliate_site_title" value="<?php echo $get_affil->affiliate_site_title; ?>">
					</td>
				</tr>

				<tr>
					<td width="15%" class="tooltip">
						Site URL
					</td>
					<td width="35%" class="tooltip">
						<input style="width:80%;" type="text" name="csf_affiliate_site_url" id="csf_affiliate_site_url" value="<?php echo $get_affil->affiliate_site_url; ?>">
					</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td colspan="4" align="center" class="tooltip">
						<input type="submit" value="<?php if(isset($_GET['edit_affiliate'])){ echo "Edit"; }else{ echo "Add"; } ?> Affiliation" class="button-primary save alignleft" name="submit">
					</td>
				</tr>
			</tbody>
		</table>
	</form>
				</td>
			</tr>    	
		</tbody>
	</table>


<h2 style="float: left; margin-top: 50px;">Cruise Filter Affiliation List</h2>
<?php
$per_page = 10;
if(isset($_GET['paged'])){
	$crnt_page = $_GET['paged'];
}
else{
	$crnt_page = 1;
}
	$start_page = ($crnt_page-1)*$per_page;
$prop_list_q = "";
$prop_list_q .= "SELECT * FROM ".$affiliate_table."";
$prop_list_q .= " ORDER BY affiliate_id DESC";
$property_result_all = $wpdb->get_results($prop_list_q);
$property_result_count_all = count($property_result_all);

$last_page = $property_result_count_all/$per_page;

$prop_list_q .= " LIMIT ".$start_page.",".$per_page."";
$property_result = $wpdb->get_results($prop_list_q);
$property_result_count = count($property_result);
?>
	<form action="" name="frm_ag_property" id="frm_ag_property" class="frm_ag_property" method="get" enctype="multipart/form-data" style="float: right; margin-top: 50px;">
		<div class="tablenav top">
			<div class="tablenav-pages">
			<span class="displaying-num"><?php echo $property_result_count_all; ?> items</span>
				<?php 
				if($property_result_count>0 && ( $property_result_count_all != $property_result_count)){
				?>
					<span class="pagination-links">
						<a class="first-page <?php if($_GET['paged']<2){ echo "disabled"; } ?>" <?php if($_GET['paged']<2){}else{ echo 'href="options-general.php?page=cruise-search-affiliate&paged=1"'; } ?> title="Go to the first page">«</a>
						
						<a class="prev-page <?php if($_GET['paged']<2){ echo "disabled"; } ?>" <?php if($_GET['paged']<2){}else{ echo 'href="options-general.php?page=cruise-search-affiliate&paged='.($crnt_page-1).'"'; } ?> title="Go to the previous page">‹</a>
						
						<span class="paging-input">
							<label class="screen-reader-text" for="current-page-selector">Select Page</label>
								<!-- <input id="current-page-selector" class="current-page" type="text" size="1" value="<?php //echo $crnt_page; ?>" name="paged" title="Current page"> -->
								<?php echo $crnt_page; ?>
							of
							<span class="total-pages"><?php echo ceil($last_page); ?></span>
						</span>

						<a class="next-page <?php if($_GET['paged']>=ceil($last_page)){ echo "disabled"; } ?>" <?php if($_GET['paged']>=ceil($last_page)){}else{ echo 'href="options-general.php?page=cruise-search-affiliate&paged='.($crnt_page+1).'"'; } ?> title="Go to the next page">›</a>
						
						<a class="last-page <?php if($_GET['paged']>=ceil($last_page)){ echo "disabled"; } ?>" <?php if($_GET['paged']>=ceil($last_page)){}else{ echo 'href="options-general.php?page=cruise-search-affiliate&paged='.ceil($last_page).'"'; } ?> title="Go to the last page">»</a>
					</span>
				<?php
				}
				?>
			</div>
		</div>
	</form>

	<table class="wp-list-table widefat">
		<thead>
			<tr>
				<th style="margin: 0px; background: rgba(0, 0, 0, 0.2) none repeat scroll 0% 0%;" scope="col" class="manage-column"></th>
				<th style="margin: 0px; background: rgba(0, 0, 0, 0.2) none repeat scroll 0% 0%;" scope="col" class="manage-column">Affiliate Name</th>
				<th style="margin: 0px; background: rgba(0, 0, 0, 0.2) none repeat scroll 0% 0%;" scope="col" class="manage-column">Affiliation Key</th>
				<th style="margin: 0px; background: rgba(0, 0, 0, 0.2) none repeat scroll 0% 0%;" scope="col" class="manage-column">Email</th>
				<th style="margin: 0px; background: rgba(0, 0, 0, 0.2) none repeat scroll 0% 0%;" scope="col" class="manage-column">Phone</th>
				<th style="margin: 0px; background: rgba(0, 0, 0, 0.2) none repeat scroll 0% 0%;" scope="col" class="manage-column">Site</th>
				<th style="margin: 0px; background: rgba(0, 0, 0, 0.2) none repeat scroll 0% 0%;" scope="col" class="manage-column">Created Date</th>
			</tr>
		</thead>
		<tbody>
			<?php
			for ($prop_list=0; $prop_list <  $property_result_count ; $prop_list++) { 
			?>
			<tr>
				<td>
					<strong><?php if($property_result_count_all != $property_result_count){ echo ($prop_list-1)+($per_page*$crnt_page)-($per_page-2); }else{ echo $prop_list+1; } ?></strong>
				</td>
				<td>
					<strong><a href="options-general.php?page=cruise-search-affiliate&edit_affiliate=<?php echo $property_result[$prop_list]->affiliate_id; ?>&key=<?php echo $property_result[$prop_list]->affiliate_key; ?>"><?php echo $property_result[$prop_list]->affiliate_name; ?></a></strong>
					<div class="row-actions">
						<span class="view"><a title="Edit this item" href="options-general.php?page=cruise-search-affiliate&edit_affiliate=<?php echo $property_result[$prop_list]->affiliate_id; ?>&key=<?php echo $property_result[$prop_list]->affiliate_key; ?>">Edit</a></span> | 
						<span class="trash"><a title="Delete this item" href="options-general.php?page=cruise-search-affiliate&delete=<?php echo $property_result[$prop_list]->affiliate_id; ?>&key=<?php echo $property_result[$prop_list]->affiliate_key; ?>">Delete</a></span>
					</div>
				</td>
				<td>
					<?php echo $property_result[$prop_list]->affiliate_key; ?>
				</td>
				<td>
					<?php echo $property_result[$prop_list]->affiliate_email; ?>
				</td>
				<td>
					<?php echo $property_result[$prop_list]->affiliate_phone; ?>
				</td>
				<td>
					<?php 
					echo $property_result[$prop_list]->affiliate_site_title;
					if ($property_result[$prop_list]->affiliate_site_url!="") {
						echo " ( ".$property_result[$prop_list]->affiliate_site_url." ) ";
					}
					?>
				</td>
				<td>
					<?php echo $property_result[$prop_list]->affiliate_created_date; ?>
				</td>
			</tr>
			<?php 
			}
			?>
		</tbody>
	</table>
</div>
<script type="text/javascript">
	function sync_affiliate(){
        jQuery('.loader_sync').css('display','block');
		jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'iflair_ajax_afi'
            }),
            success: function (response) {
            	jQuery('.loader_sync').css('display','none');
            	//alert(response);	
            	alert("Data Synchronized. ");		    
            }
        });	
	}
</script>
<br><br><br>
<?php
	if(isset($_POST['affiliate_key_submit'])){
		$option_name = 'affiliate_key';
		$new_value = $_POST['affiliate_key'] ;
		update_option( $option_name, $new_value );
	}
?>
<form action="" id="update_options" name="update_options" class="update_options" method="post">
	<h1>Add Affiliation Key</h1>
	<input class="regular-text" value="<?php echo get_site_option( 'affiliate_key' ); ?>" id="affiliate_key" type="text" name="affiliate_key" size="36" />
	<br/>
	<br/>
	<input type="submit" value="Save Affiliate Key" class="button button-primary" id="submit" name="affiliate_key_submit">
</form>


<hr>
<?php
	if(isset($_POST['synchronize_submit'])){
		echo "<pre>";
		$myfile = fopen( "".CRUISE_SEARCH_PLUGIN_URL."Iflair_destination_Get_date_For_affiliate_Code_in_159753456852.txt", "r") or die("Unable to open file!");
		// Output one line until end-of-file
		while(!feof($myfile)) {
		  $a[] = fgets($myfile);
		  //print_r($a);
		  //echo count($a);
		}
		fclose($myfile);

		  //print_r($a[0]);
		$wpdb->get_results("TRUNCATE TABLE `".$wpdb->prefix."cruise_select_data`");
		  $xpl = explode(',', $a[0]);
		  for($i=0; $i < count($xpl) ; $i=$i+3) {
		  	//echo $xpl[$i+1].",".$xpl[$i+2].",".$xpl[$i+3]."<br>";
		  	if($xpl[$i+2]!=""){
				$insert_q = "INSERT INTO `".$wpdb->prefix."cruise_select_data` (cruise_id,ship_region,ship_starts_on) VALUES ('".$xpl[$i+2]."','".$xpl[$i+1]."','".$xpl[$i+3]."')";
				$wpdb->get_results($insert_q);
			}
		  }
		 echo '<div class="updated notice notice-success is-dismissible" id="message"><p>Synchronize Process Completed .</p></div>';
		/*echo "<pre>";
		print_r($cruise_data);
		echo "</pre>";*/
		echo "</pre>";
	}
?>
<form action="" id="update_options1" name="update_options1" class="update_options1" method="post">
	<h1>Synchronize With Cruise International</h1>
	<input type="submit" value="Synchronize Now" class="button button-primary" id="submit" name="synchronize_submit">
</form>
<br>
<br>
Shortcode for Add Search box :- <input type="text" readonly="" value="[Cruise-Filter]" /><br>
Also widget available in widget area .

<br>
<hr>
<?php
}

/* Affiliate function area start */
add_action('wp_ajax_iflair_ajax_afi', 'iflair_ajax_afi'); // Logged-in users
add_action('wp_ajax_nopriv_iflair_ajax_afi', 'iflair_ajax_afi'); // Guest users

function iflair_ajax_afi(){
global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
$mainsiteprefix='cm_';
$agentsiteurl=get_option('siteurl');
$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
$agentsiteid=$agentsitedetail->id;
$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
$agent_assign_operator;
echo "<pre>";
ini_set('memory_limit','1400M');

$cruise_region= "SELECT csc.ship_region , csc.cruise_id , csc.ship_starts_on FROM `cruise_ship_cruise` as csc INNER JOIN `cruise_operators` as co ON csc.ship_operator = co.operator_app_id WHERE co.operator_id IN (".$agent_assign_operator.")";
				$select_cruise_region_raw = $mydb->get_results($cruise_region, ARRAY_A);
//print_r($select_cruise_region_raw);
				$types_array = array();
				$types_array1 = "";
				foreach ($select_cruise_region_raw as $cruise_types_array) :
					$types_array[] = $cruise_types_array;
					//for ($i=0; $i < count($cruise_types_array) ; $i++) {
					foreach ($cruise_types_array as $cruise_types_array1) :
							//$types_array1 = $types_array1.",".$cruise_types_array[$i];
							$types_array1 = $types_array1.",".$cruise_types_array1;
					endforeach;
					//}
				endforeach;

/*
$select_cruise_region = array(array());
//foreach ($select_cruise_region_raw as $res){
	for ($i=0; $i < count($select_cruise_region_raw) ; $i++) { 
	    $select_cruise_region[$i]['ship_region'] = $select_cruise_region_raw[$i]->ship_region;
	    $select_cruise_region[$i]['cruise_id'] = $select_cruise_region_raw[$i]->cruise_id;
	    $select_cruise_region[$i]['ship_starts_on'] = $select_cruise_region_raw[$i]->ship_starts_on;
	}
*/

//print_r($select_cruise_region);
$select_cruise_region_1 = print_r($types_array1, true);

/*$myfile = fopen(get_template_directory_uri ()."/iflair_destination_get_date_for_affiliate_code_in.txt", "r") or die("Unable to open file!");
// Output one line until end-of-file
while(!feof($myfile)) {
  fwrite($myfile, $select_cruise_region_1);
  echo fgets($myfile) . "<br>";
}
fclose($myfile);*/



$filename = CRUISE_SEARCH_PLUGIN_PATH."Iflair_destination_Get_date_For_affiliate_Code_in_159753456852.txt";
if (!chmod($filename, 0666)) {
	echo "Cannot change the mode of file ($filename)";
};
$somecontent = $select_cruise_region_1;
// Let's make sure the file exists and is writable first.
if (is_writable($filename)) {
	file_put_contents($filename, "");
    // In our example we're opening $filename in append mode.
    // The file pointer is at the bottom of the file hence
    // that's where $somecontent will go when we fwrite() it.
    if (!$handle = fopen($filename, 'a')) {
         echo "Cannot open file ($filename)";
         exit;
    }

    // Write $somecontent to our opened file.
    if (fwrite($handle, $somecontent) === FALSE) {
        echo "Cannot write to file ($filename)";
        exit;
    }

    echo "Success, wrote ($somecontent) to file ($filename)";

    fclose($handle);

} else {
    echo "The file $filename is not writable";
}

echo "</pre>";
exit();
}
?>