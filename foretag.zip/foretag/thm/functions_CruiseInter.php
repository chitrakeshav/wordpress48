<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_parent_css' ) ):
    function chld_thm_cfg_parent_css() {
        wp_enqueue_style( 'chld_thm_cfg_parent', trailingslashit( get_template_directory_uri() ) . 'style.css', array(  ) );
    }
endif;
add_action( 'wp_enqueue_scripts', 'chld_thm_cfg_parent_css', 1001 );

// END ENQUEUE PARENT ACTION




add_action('wp_ajax_iflair_ajax_response_cruise_operators', 'iflair_ajax_response_cruise_operators'); // Logged-in users
add_action('wp_ajax_nopriv_iflair_ajax_response_cruise_operators', 'iflair_ajax_response_cruise_operators'); // Guest users
add_action('wp_ajax_iflair_ajax_response_combo_cruise_operators', 'iflair_ajax_response_combo_cruise_operators'); // Logged-in users
add_action('wp_ajax_nopriv_iflair_ajax_response_combo_cruise_operators', 'iflair_ajax_response_combo_cruise_operators'); // Guest users


function iflair_ajax_response_cruise_operators(){
global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;

	$mainsiteprefix='cm_';
	$agentsiteurl=get_option('siteurl');
	$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
	$agentsiteid=$agentsitedetail->id;
	$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
	$agent_assign_operator;

	$pagenum=$_POST['pagenumb'];
	if($_POST['pagenumb']==""){
		$per_page = 10;
		$page='1';
		$start='0';
	}
	else {
		$per_page = 10;
		$page=$_POST['pagenumb'];	
		$start=($page-1)*$per_page;
	}
					
					
	//echo $start = $page * $per_page;
					/* latecard pagination*/	
						
?>
<div id="replace_query_ajax">
	<?php
	if($_POST['str1'] !="" && $_POST['str2'] != "" ){
		$select_ship_query = "SELECT cc.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name WHERE 1=1  AND $_POST[str1] = '$_POST[str2]' GROUP BY cc.cruise_id ORDER BY cc.cruise_operator_name";		
	}
	else{
		//print_r($_POST);
		$select_ship_query = "";
		$select_ship_query .= "SELECT * FROM cruise_cruise ";
		$whereClauses = array();
		if (! empty($_POST['touroperator'])){ 
			$q0 = $mydb->get_var("SELECT operator_title FROM cruise_operators WHERE operator_id='$_POST[touroperator]'"); 
			$whereClauses[] ="cruise_operator_name='".$q0."'";
		}
		if (! empty($_POST['shipsize'])){ 
			$q1 = $mydb->get_var("SELECT size_title FROM cruise_ship_size WHERE size_id='$_POST[shipsize]'"); 
			$whereClauses[] ="cruise_ship_size='".$q1."'";
		}
		if (! empty($_POST['shipstyle'])){ 
			$q2 = $mydb->get_var("SELECT style_title FROM cruise_ship_style WHERE style_id='$_POST[shipstyle]'"); 
			$whereClauses[] ="crusie_ship_style='".$q2."'";
		}
		if (! empty($_POST['shiplanguage'])){ 

			$whereClauses[] ="cruise_language='".$_POST[shiplanguage]."'";
		}
		$where = '';
		if (count($whereClauses) > 0) { $where = ' WHERE '.implode(' AND ',$whereClauses); }
			$select_ship_query = "SELECT * FROM cruise_cruise".$where; 
			/*echo "<pre>";
			print_r($select_ship);
			echo "</pre>";*/
	}
	cruise_pagging($page,$per_page,$select_ship_query);
	$select_ship_query .= " LIMIT $start,$per_page";
	
	//exit();
	
	//echo $select_ship_query;
	$select_ship = $mydb->get_results($select_ship_query);
	//echo count($select_ship);
	if(count($select_ship) == 0)
	{
		echo "No Search result Found for :- ".$q0." , ".$q1." , ".$q2." , ".$q3." ";
	}
	else
	{
		for($i=0;$i<count($select_ship);$i++)
		{
		?>
		<div class="mediter-box m-24 clearfix">
			<div class="medi-left">
				<img src="<?php echo esc_url( get_template_directory_uri() )."/images/loader.gif"; ?>" data-original="<?php if($select_ship[$i]->cruise_cover_image_href!=""){ echo $select_ship[$i]->cruise_cover_image_href; }else{ echo esc_url( get_template_directory_uri() )."/images/no-property-image.jpg"; } ?>" class="img-responsive lazy">
  				<script>jQuery("img.lazy").lazyload();</script>

			</div>
			<div class="medi-mid">
				<h3><?php echo $select_ship[$i]->cruise_operator_name; ?></h3>
				<!-- 
				<p>Date <span>-  - <?php /*$time = strtotime($select_ship[$i]->ship_created_date); $newformat = date('j M Y',$time); echo $newformat; */?></span></p>
				<p>No of NIghts <span>- - </span></p> -->

				<p>Ship <span>- <?php echo $select_ship[$i]->cruise_title; ?></span></p>
			</div>
			<div class="medi-right">
				<h2>Guide Price Range</h2>
				<p><?php echo html_entity_decode(substr($select_ship[$i]->cruise_introduction,0,100)); if(strlen($select_ship[$i]->cruise_introduction)>100){ ?><span>...</span><?php } ?></p>
				<div class="clearfix right">
					<a href="<?php echo esc_url(home_url('/'));?>ship-details/?ship_id=<?php echo $select_ship[$i]->cruise_id; ?>" class="info-bt-a">VIEW MORE INFORMATION</a>
				</div>
			</div>
		</div>
		<?php
		}
	}
	?>
	<script type="text/javascript">	
					jQuery(document).ready(function(){
						jQuery("#pagination li").click(function(){
							jQuery('.loader').css('display','block');
							var pageNum = this.id;
							
	    					var touroperator = '<?php echo $_POST["touroperator"]; ?>';
							var shipsize = '<?php echo $_POST["shipsize"]; ?>';
							var shipstyle = '<?php echo $_POST["shipstyle"]; ?>';
							var shiplanguage = '<?php echo $_POST["shiplanguage"]; ?>';
							var str1='<?php echo $_POST["str1"]; ?>';
                			var str2='<?php echo $_POST["str2"]; ?>';
							
						        jQuery.ajax({
						            type: "POST",
						            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
						            data: ({
						                action: 'iflair_ajax_response_cruise_operators',
						                touroperator: touroperator,
						                shipsize:shipsize,
						                shipstyle:shipstyle,
						                shiplanguage:shiplanguage,
						                str1: str1,
                						str2: str2,
						                pagenumb:pageNum
						            }),
						            success: function (response) {
						                //alert(response);
						                jQuery('#replace_query_ajax').html(response);
						            	jQuery('.loader').css('display','none');
						            }
						        });
							
						});
					});


				</script>
<script>
jQuery( document ).ready(function() {
//alert("1358");
	jQuery('.iflair_template_value_reseter').click(function(){
	    jQuery('#iflair_template_cruise_operators').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_ship_size').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_ship_style').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_language').prop('selectedIndex',0);
	    iflair_ajax_cruise_operators();
	});
	jQuery('#iflair_template_cruise_operators').click(function(){
	    jQuery('#iflair_template_cruise_ship_size').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_ship_style').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_language').prop('selectedIndex',0);
	});
	jQuery('.iflair_template_value_cruiseship').click(function(){
		jQuery('#iflair_template_cruise_operators').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_ship_size').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_ship_style').prop('selectedIndex',0);
	    jQuery('#iflair_template_cruise_language').prop('selectedIndex',0);
	    iflair_ajax_cruise_operators();

	});

});


</script>
	<?php
	die();
?>
</div>
<?php
}

function iflair_ajax_response_combo_cruise_operators(){
global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;

	$mainsiteprefix='cm_';
	$agentsiteurl=get_option('siteurl');
	$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
	$agentsiteid=$agentsitedetail->id;
	$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
	$agent_assign_operator;


	?>
	<span id="second_filter">
		<?php
	    $cruise_ship_size_q = $mydb->get_row("SELECT size_title FROM cruise_ship_size WHERE size_id=$_POST[shipsize]");
	    $cruise_ship_size_v = $cruise_ship_size_q->size_title;
	    $cruise_ship_style_q = $mydb->get_row("SELECT style_title FROM cruise_ship_style WHERE style_id=$_POST[shipstyle]");
	    $cruise_ship_style_v = $cruise_ship_style_q->style_title;
	    $cruise_ship_lang_q = $mydb->get_row("SELECT language_title FROM cruise_language WHERE language_code='$_POST[shiplanguage]'");
	    $cruise_ship_lang_v = $cruise_ship_lang_q->language_title;

		if( $cruise_ship_size_v != "" && $cruise_ship_style_v != "" && $cruise_ship_lang_v != "" ){
    	?>
			<script type="text/javascript">	
				jQuery('#iflair_template_cruise_ship_size,#iflair_template_cruise_ship_style,#iflair_template_cruise_language').click(function() {
					jQuery('#iflair_template_cruise_ship_size').prop('selectedIndex',0);
					jQuery('#iflair_template_cruise_ship_style').prop('selectedIndex',0);
					jQuery('#iflair_template_cruise_language').prop('selectedIndex',0);
			});
			</script>
    	<?php
    	}

		?>
		<div class="btn-group i-1" role="group">
			<select name="iflair_template_cruise_ship_size" id="iflair_template_cruise_ship_size" class="btn btn-default dropdown-toggle text p-2" required onchange="iflair_ajax_second_filter();" >
				<option value="">Select a ship size</option>
			    <?php

			    $cruise_ship_size = "SELECT css.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_size AS css ON co.operator_title = cc.cruise_operator_name WHERE 1=1  AND css.size_title = cc.cruise_ship_size AND co.operator_id = $_POST[touroperator] GROUP BY cc.cruise_ship_size ORDER BY cc.cruise_operator_name";
			    echo $cruise_ship_size;
			    $select_cruise_ship_size = $mydb->get_results($cruise_ship_size);
			    //echo count($select_cruise_ship_size);
			    for($ss=0;$ss<count($select_cruise_ship_size);$ss++){
			    	?>
				   	<option <?php if( $cruise_ship_size_v == $select_cruise_ship_size[$ss]->size_title ){ echo "selected"; } ?> value="<?php echo $select_cruise_ship_size[$ss]->size_id; ?>"><?php echo $select_cruise_ship_size[$ss]->size_title; ?></option>
				   	<?php
			    }
			    ?>
		    </select>
	  	</div>
		<div class="btn-group i-1" role="group">
			<select <?php if(!$_POST['touroperator'] || !$_POST['shipsize'] ){ echo "disabled='true'";} ?> name="iflair_template_cruise_ship_style" id="iflair_template_cruise_ship_style" class="btn btn-default dropdown-toggle text p-2" required onchange="iflair_ajax_second_filter();">
				<option value="">Select a ship style</option>
			    <?php
			    	 //echo "SELECT css.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_style AS css ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id IN (1,2,3,7,9,10,11,12,14,15,16,20,24,28,29,32,112,116) AND css.style_title = cc.crusie_ship_style AND co.operator_id = 7 GROUP BY cc.crusie_ship_style ORDER BY cc.cruise_operator_name";
			    $cruise_ship_style ="";
			    $cruise_ship_style .="SELECT css.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_style AS css ON co.operator_title = cc.cruise_operator_name WHERE 1=1  AND css.style_title = cc.crusie_ship_style AND co.operator_id = $_POST[touroperator]"; 
			    if( $cruise_ship_size_v != "" ){
			    	 $cruise_ship_style .=" AND cruise_ship_size = '$cruise_ship_size_v'";
			    }
			    $cruise_ship_style .=" GROUP BY cc.crusie_ship_style ORDER BY cc.cruise_operator_name"; 
			    echo $cruise_ship_style;
			    $select_cruise_ship_style = $mydb->get_results($cruise_ship_style);
			    foreach ($select_cruise_ship_style as $cruise_ship_style_obj) :
					?>
				   	<option <?php if( $cruise_ship_style_v == $cruise_ship_style_obj->style_title ){ echo "selected"; } ?> value="<?php echo $cruise_ship_style_obj->style_id; ?>"><?php echo $cruise_ship_style_obj->style_title; ?></option>
				   	<?php
				endforeach;
			    ?>
		    </select>
	  	</div>
		<div class="btn-group i-1" role="group">
			<select <?php if(!$_POST['touroperator'] || !$_POST['shipsize']  || !$_POST['shipstyle'] ){ echo "disabled='true'";} ?> name="iflair_template_cruise_language" id="iflair_template_cruise_language" class="btn btn-default dropdown-toggle text p-2" required onchange="iflair_ajax_second_filter();" >
				<option value="">Select a language</option>
			    <?php
			    $cruise_ship_language ="";
			    $cruise_ship_language .="SELECT cl.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_language AS cl ON co.operator_title = cc.cruise_operator_name WHERE 1=1  AND cl.language_code = cc.cruise_language AND co.operator_id = $_POST[touroperator]"; 
			    if( $cruise_ship_size_v != "" ){
			    	 $cruise_ship_language .=" AND cruise_ship_size = '$cruise_ship_size_v'";
			    }
			    if( $cruise_ship_lang_v != "" ){
			    	 $cruise_ship_language .=" AND language_title = '$cruise_ship_lang_v'";
			    }
			    $cruise_ship_language .=" GROUP BY cc.cruise_language ORDER BY cc.cruise_operator_name"; 
			    echo $cruise_ship_language;
			    $select_cruise_language = $mydb->get_results($cruise_ship_language);

				foreach ($select_cruise_language as $cruise_language_obj) :
				   ?>
				   	<option <?php if( $cruise_ship_lang_v == $cruise_language_obj->language_title ){ echo "selected"; } ?> value="<?php echo $cruise_language_obj->language_code; ?>"><?php echo $cruise_language_obj->language_title; ?></option>
				   	<?php
				endforeach;
			    ?>
		    </select>
	  	</div>					
	</span>
	<?php
	die();
}
/* Code started by Arvind */
function iflair_get_subsite_id($agentsiteurl){
	global $wpdb,$mydb,$mainsiteprefix;

	$select_subsite_detail = "SELECT * FROM ".$mainsiteprefix."site_management WHERE site_url='".$agentsiteurl."'";
	$select_subsite = $mydb->get_row($select_subsite_detail);
	
	return $select_subsite;
} 
function iflair_get_tour_operator_assign($agentsiteid){
	global $wpdb,$mydb,$mainsiteprefix,$agentsiteid;
	$select_tour_opertor_detail = "SELECT tour_operator_id FROM ".$mainsiteprefix."tour_operator WHERE site_id='".$agentsiteid."'";
	$select_tour_opertor_assign = $mydb->get_col($select_tour_opertor_detail);
	if(is_array($select_tour_opertor_assign)){
		$get_assign_operator=implode(',', $select_tour_opertor_assign);
	}
	else {
		$get_assign_operator=array();	
	}
	return $get_assign_operator;

}
/* Code started by Arvind */
function cruise_pagging($page="",$numofrec,$select_ship_query){
	global $wpdb,$mydb,$mainsiteprefix;				
	
	$start = ($page-1)*$per_page;
	$page = $page;
	$cur_page = $page;
	$page -= 1;
	$per_page = $numofrec;
	$previous_btn = true;
	$next_btn = true;
	$first_btn = true;
	$last_btn = true;
	$start = $page * $per_page;
	//$count = $pages;
	//$no_of_paginations = ceil($count / $per_page);

	$select_ship_pag = $mydb->get_results($select_ship_query);
	$innercount = count($select_ship_pag);
	$no_of_paginations = ceil($innercount/$per_page);

	/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
	if ($cur_page >= 3) {
	    $start_loop = $cur_page - 1;
	    if ($no_of_paginations > $cur_page + 1)
	        $end_loop = $cur_page + 1;
	    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 2) {
	        $start_loop = $no_of_paginations - 2;
	        $end_loop = $no_of_paginations;
	    } else {
	        $end_loop = $no_of_paginations;
	    }
	} else {
	    $start_loop = 1;
	    if ($no_of_paginations > 3)
	        $end_loop = 3;
	    else
	        $end_loop = $no_of_paginations;
	}
	/* ----------------------------------------------------------------------------------------------------------- */
	$msg .= "<div class='pagination-menu'><ul id='pagination'>";

	// FOR ENABLING THE FIRST BUTTON
	if ($first_btn && $cur_page > 1) {
	    $msg .= "<li id='1' class='active'><<</li>";
	} else if ($first_btn) {
	    $msg .= "<li id='1' class='inactive'><<</li>";
	}

	// FOR ENABLING THE PREVIOUS BUTTON
	if ($previous_btn && $cur_page > 1) {
	    $pre = $cur_page - 1;
	    $msg .= "<li id='$pre' class='active'><</li>";
	} else if ($previous_btn) {
	    $msg .= "<li class='inactive'><</li>";
	}
	for ($i = $start_loop; $i <= $end_loop; $i++) {

	    if ($cur_page == $i)
	        $msg .= "<li id='$i' class='active currentdiv'>{$i}</li>";
	    else
	        $msg .= "<li id='$i' class='active'>{$i}</li>";
	}

	// TO ENABLE THE NEXT BUTTON
	if ($next_btn && $cur_page < $no_of_paginations) {
	    $nex = $cur_page + 1;
	    $msg .= "<li id='$nex' class='active'>></li>";
	} else if ($next_btn) {
	    $msg .= "<li class='inactive'>></li>";
	}

	// TO ENABLE THE END BUTTON
	if ($last_btn && $cur_page < $no_of_paginations) {
	    $msg .= "<li id='$no_of_paginations' class='active'>>></li>";
	} else if ($last_btn) {
	    $msg .= "<li id='$no_of_paginations' class='inactive'>>></li>";
	}
	$msg = $msg . "</ul></div>";  // Content for pagination
	echo $msg;
}

/* MK Aded New cruise search */
add_action('wp_ajax_cruise_filter_response', 'cruise_filter_response'); // Logged-in users
add_action('wp_ajax_nopriv_cruise_filter_response', 'cruise_filter_response'); // Guest users
add_action('wp_ajax_iflair_search_filter_response', 'iflair_search_filter_response'); // Logged-in users
add_action('wp_ajax_nopriv_iflair_search_filter_response', 'iflair_search_filter_response'); // Guest users
add_action('wp_ajax_cruise_detail', 'cruise_detail'); // Logged-in users
add_action('wp_ajax_nopriv_cruise_detail', 'cruise_detail'); // Guest users

add_action('wp_ajax_iflair_detail_search_filter_response', 'iflair_detail_search_filter_response'); // Logged-in users
add_action('wp_ajax_nopriv_iflair_detail_search_filter_response', 'iflair_detail_search_filter_response'); // Guest users

add_action('wp_ajax_price_filter_result', 'price_filter_result'); // Logged-in users
add_action('wp_ajax_nopriv_price_filter_result', 'price_filter_result'); // Guest users

function iflair_search_filter_response(){
	global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
	$mainsiteprefix='cm_';
	$agentsiteurl=get_option('siteurl');
	$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
	$agentsiteid=$agentsitedetail->id;
	$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
	$agent_assign_operator;

	/*echo "<pre>";
	print_r($_POST);
	echo "</pre>";*/
	if($_POST['region']=="all" ){ $region = ""; }else{ $region = $_POST['region']; }
	if($_POST['operator']=="all" ){ $operator = ""; }else{ $operator = $_POST['operator']; }
	if($_POST['cruise_ship']=="all" ){ $cruise_ship = ""; }else{ $cruise_ship = $_POST['cruise_ship']; }
	if($_POST['ship_fly_in']=="all" ){ $ship_fly_in = ""; }else{ $ship_fly_in = $_POST['ship_fly_in']; }	
	if($_POST['leaving_from']=="all" ){ $leaving_from = ""; }else{ $leaving_from = $_POST['leaving_from']; }
	if($_POST['ship_starts_on']=="all" ){ $ship_starts_on = ""; }else{ $ship_starts_on = $_POST['ship_starts_on']; }
	if($_POST['ship_vacation_days']=="all" ){ $ship_vacation_days = ""; }else{ $ship_vacation_days = $_POST['ship_vacation_days']; }	


	if($leaving_from!=""){
		$leaving_from_cruise_id= "SELECT cruise_id FROM cruise_port WHERE port_code='$leaving_from'";
		//echo $leaving_from_cruise_id."<---";
		$select_leaving_from_cruise_id = $mydb->get_results($leaving_from_cruise_id);
			$leaving_from_cruise_id_arr = array();
		foreach ($select_leaving_from_cruise_id as $leaving_from_cruise_id_obj) {
			$leaving_from_cruise_id_arr[] = $leaving_from_cruise_id_obj->cruise_id;
		}
		//print_r($leaving_from_cruise_id_arr);
		$leaving_from_cruise_id = $leaving_from_cruise_id_arr[0];
		//print_r($id_res);
		for($i=1;$i<count($leaving_from_cruise_id_arr);$i++){
			$leaving_from_cruise_id = $leaving_from_cruise_id.",".$leaving_from_cruise_id_arr[$i];
		}
		//echo $leaving_from_cruise_id;
	}


	?>
	<script type="text/javascript">jQuery("img.lazy").lazyload({skip_invisible : true});</script>
	<div class="form-field">
		
		<div class="btn-group i-1 h-1" role="group">
		    <select name="cruise_region" id="cruise_region" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_search_filter('region');" >
				<option value="" >Where do you want to go?</option>
				<?php
				
					$tab_condition = $_POST['tab_id'];
					$cruise_region == "";
					$cruise_region .= "SELECT csc.ship_region , csc.ship_cruise_type , csc.cruise_id FROM `cruise_ship_cruise` as csc WHERE 1=1";
					if($tab_condition == 1){
						$cruise_region .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
					}
					elseif($tab_condition == 2){
						$cruise_region .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
					}
					else{
						$cruise_region .= "";
					}
					$cruise_region .= " GROUP BY csc.ship_region ORDER BY FIND_IN_SET('River', csc.ship_cruise_type),csc.ship_region";
					echo $cruise_region;
					$select_cruise_region_res = $mydb->get_results($cruise_region);


				foreach ($select_cruise_region_res as $cruise_region_prepared_obj) :
					$HiddenRiver = explode(',',$cruise_region_prepared_obj->ship_cruise_type);
				?>
					<option value="<?php echo $cruise_region_prepared_obj->ship_region; ?>" <?php if($region == $cruise_region_prepared_obj->ship_region ){ echo "selected"; } ?> ><?php echo $cruise_region_prepared_obj->ship_region; ?><?php if(in_array('River', $HiddenRiver)){ echo " ( River )"; } ?></option>
				<?php
				endforeach;
				?>
		</select>
	  	</div>

		<div class="btn-group i-2 h-2" role="group">
			<?php
				$cruise_operator_title= "SELECT csc.ship_operator_id,csc.ship_operator_app_id FROM cruise_ship_cruise AS csc WHERE 1=1";
			
				if($region != ""){
					$cruise_operator_title .= " AND csc.ship_region = '$region'";
				}
				if($cruise_ship != ""){
					$cruise_operator_title .= " AND csc.ship_id = $cruise_ship";
				}
				if($ship_fly_in != ""){
					$cruise_operator_title .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_starts_on != ""){
					$cruise_operator_title .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
				}
				if($ship_vacation_days != ""){
					$cruise_operator_title .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
				}
				if($tab_condition == 1){
					$cruise_operator_title .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_operator_title .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_operator_title .= "";
				}
	  				$cruise_operator_title .= " GROUP BY csc.ship_operator_app_id ORDER BY csc.ship_operator_app_id";
	  			
	  			//echo $cruise_operator_title;
				$select_cruise_operator_title = $mydb->get_results($cruise_operator_title);
				$c2 = count($select_cruise_operator_title);
				$qq="0 value";
			?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c2==0){echo 'disabled="true" ';}?> name="cruise_operator" id="cruise_operator" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_search_filter('operator');" >
				<option value="" >Which Cruise Line?</option>
				<option value="all" <?php if($_POST['operator']=="all"){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_operator_title as $cruise_operator_title_obj) :
					?>
					<option value="<?php echo $cruise_operator_title_obj->ship_operator_id; ?>" <?php if($operator == $cruise_operator_title_obj->ship_operator_id ){ echo "selected"; } ?> ><?php echo ucfirst(str_replace("-"," ",$cruise_operator_title_obj->ship_operator_app_id)); ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>

	  	<div class="btn-group i-3 h-3" role="group">
	  		<?php
	  			$cruise_cruise_ship="";
	  			$cruise_cruise_ship .= "SELECT csc.ship_id,cc.cruise_title FROM cruise_cruise AS cc INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1";
				if($region != ""){
					$cruise_cruise_ship .= " AND csc.ship_region = '$region'";
				}
				if($operator != ""){
					$cruise_cruise_ship .= " AND csc.ship_operator_id = $operator";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_fly_in != ""){
					$cruise_cruise_ship .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($ship_starts_on != ""){
					$cruise_cruise_ship .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
				}
				if($ship_vacation_days != ""){
					$cruise_cruise_ship .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
				}
				if($tab_condition == 1){
					$cruise_cruise_ship .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_cruise_ship .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_cruise_ship .= "";
				}
	  				$cruise_cruise_ship .= " GROUP BY cc.cruise_title ORDER BY csc.ship_id";
	  			
				$select_cruise_ship = $mydb->get_results($cruise_cruise_ship);
				$c3 = count($select_cruise_ship);
				if($c3==0){$cruise_ship="";}
	  		?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c3==0){echo 'disabled="true" ';}?> name="cruise_ship" id="cruise_ship" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_search_filter('cruise_ship');" >
				<option value="" >Which Ship?</option>
				<option value="all" <?php if($_POST['cruise_ship']=="all" ){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_ship as $cruise_ship_obj) :
					?>
					<option value="<?php echo $cruise_ship_obj->ship_id; ?>" <?php if($cruise_ship == $cruise_ship_obj->ship_id ){ echo "selected"; } ?> ><?php echo $cruise_ship_obj->cruise_title; ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>

	  	<div class="btn-group i-4 h-4" role="group">
	  		<?php
	  			$cruise_ship_fly_in= "SELECT csc.ship_fly_in FROM cruise_cruise AS cc INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1";
				if($region != ""){
					$cruise_ship_fly_in .= " AND csc.ship_region = '$region'";
				}
				if($operator != ""){
					$cruise_ship_fly_in .= " AND csc.ship_operator_id = $operator";
				}
				if($cruise_ship != ""){
					$cruise_ship_fly_in .= " AND csc.ship_id = $cruise_ship";
				}
				if($ship_starts_on != ""){
					$cruise_ship_fly_in .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
				}
				if($ship_vacation_days != ""){
					$cruise_ship_fly_in .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
				}
				if($tab_condition == 1){
					$cruise_ship_fly_in .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_ship_fly_in .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_ship_fly_in .= "";
				}
	  				$cruise_ship_fly_in .= " GROUP BY csc.ship_fly_in ORDER BY csc.ship_fly_in";
	  			
				$select_cruise_ship_fly_in = $mydb->get_results($cruise_ship_fly_in);
				$c4 = count($select_cruise_ship_fly_in);
	  		?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c4==0){echo 'disabled="true" ';}?> name="cruise_ship_fly_in" id="cruise_ship_fly_in" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_search_filter('ship_fly_in');" >
				<option value="" >Leaving from</option>
				<option value="all" <?php if($_POST['leaving_from'] == "all" ){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_ship_fly_in as $cruise_ship_fly_in_obj) :
					?>
					<option value="<?php echo $cruise_ship_fly_in_obj->ship_fly_in; ?>" <?php if($ship_fly_in == $cruise_ship_fly_in_obj->ship_fly_in ){ echo "selected"; } ?> ><?php echo $cruise_ship_fly_in_obj->ship_fly_in; ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>

	  	<?php /*
	  	<div class="btn-group i-4 h-4" role="group">
	  		<?php
	  			$cruise_leaving_from= "SELECT * FROM cruise_port";
				if($cruise_ship != ""){
					$cruise_leaving_from .= " WHERE ship_id = $cruise_ship";
				}
	  			$cruise_leaving_from .= " GROUP BY cruise_id ORDER BY port_id";
	  			//$cruise_leaving_from .= " GROUP BY port_code, cruise_id ORDER BY port_id";
	  			//echo $cruise_leaving_from;
				$select_cruise_leaving_from = $mydb->get_results($cruise_leaving_from);

				$c4 = count($select_cruise_leaving_from);
	  		?>
				<img class="loader_filt" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="position: absolute; z-index: 4; background: rgb(255, 255, 255) none repeat scroll 0% 0%; left: 0px; padding: 18px 41%; display: none;">
		    <select <?php //if($c4==0){echo 'disabled="true" ';}?> name="cruise_leaving_from" id="cruise_leaving_from" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_search_filter('leaving_from');" >
				<option value="">Leaving from</option>
				<?php
				$arr = array();
				foreach ($select_cruise_leaving_from as $cruise_leaving_from_obj) :
					if(!in_array($cruise_leaving_from_obj->port_code,$arr)){ 
							$arr[] = $cruise_leaving_from_obj->port_code;	
							?>
							<option value="<?php echo $cruise_leaving_from_obj->port_code; ?>" <?php if($leaving_from == $cruise_leaving_from_obj->port_code ){ echo "selected"; } ?> ><?php echo $cruise_leaving_from_obj->port_name; ?></option>
					<?php 
					}
				endforeach;
				?>
			</select>
	  	</div>
	  	*/ ?>

	  	<div class="btn-group i-2 h-5" role="group">
	  		<?php
	  			$todays_date = date('Y-m-d H:i:s');
				$cruise_when= "SELECT csc.ship_starts_on FROM cruise_cruise AS cc INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1";
					$cruise_when .= " AND csc.ship_starts_on >= '$todays_date'";
				if($region != ""){
					$cruise_when .= " AND csc.ship_region = '$region'";
				}
				if($operator != ""){
					$cruise_when .= " AND csc.ship_operator_id = $operator";
				}
				if($cruise_ship != ""){
					$cruise_when .= " AND csc.ship_id = $cruise_ship";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_fly_in != ""){
					$cruise_when .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($ship_vacation_days != ""){
					$cruise_when .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
				}
				if($tab_condition == 1){
					$cruise_when .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_when .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_when .= "";
				}
	  				$cruise_when .= " GROUP BY YEAR(csc.ship_starts_on),MONTH(csc.ship_starts_on) ORDER BY csc.ship_starts_on";
	  			
				$select_cruise_when = $mydb->get_results($cruise_when);
				//echo $cruise_when;
				$c5 = count($select_cruise_when);
	  		?>
		    <?php /*
	  		<input type="text" placeholder="When" value="<?php echo $ship_starts_on; ?>" name="cruise_ship_starts_on" id="cruise_ship_starts_on" >
			*/ ?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c5==0){echo 'disabled="true" ';}?> name="cruise_ship_starts_on" id="cruise_ship_starts_on" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_search_filter('ship_starts_on');" >
				<option value="" >When</option>
				<option value="all" <?php if($_POST['ship_starts_on']=="all" ){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_when as $cruise_when_obj) :
					?>
					<option value="<?php echo date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ; ?>" <?php if($ship_starts_on == date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ){ echo "selected"; } ?> ><?php $ship_date=$cruise_when_obj->ship_starts_on; echo date('F Y',strtotime($ship_date)); ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>

	  	<div class="btn-group i-3 h-6" role="group">
	  		<?php
				$cruise_days= "SELECT csc.ship_vacation_days FROM cruise_cruise AS cc INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1";
				if($region != ""){
					$cruise_days .= " AND csc.ship_region = '$region'";
				}
				if($operator != ""){
					$cruise_days .= " AND csc.ship_operator_id = $operator";
				}
				if($cruise_ship != ""){
					$cruise_days .= " AND csc.ship_id = $cruise_ship";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_fly_in != ""){
					$cruise_days .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($ship_starts_on != ""){
					$cruise_days .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
				}
				/*if($ship_vacation_days != ""){
					$cruise_days .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
				}*/
				if($tab_condition == 1){
					$cruise_days .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_days .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_days .= "";
				}
	  				$cruise_days .= " GROUP BY csc.ship_vacation_days ORDER BY csc.ship_vacation_days";
	  			
				$select_cruise_days = $mydb->get_results($cruise_days);
				$c6 = count($select_cruise_days);
	  		?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c6==0){echo 'disabled="true" ';}?> name="cruise_ship_vacation_days" id="cruise_ship_vacation_days" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_search_filter('ship_vacation_days');" >
				<option value="" >Days</option>
				<option value="all" <?php if($_POST['ship_vacation_days']=="all" ){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_days as $cruise_days_obj) :
					?>
					<option value="<?php echo $cruise_days_obj->ship_vacation_days ; ?>" <?php if($ship_vacation_days == $cruise_days_obj->ship_vacation_days ){ echo "selected"; } ?> ><?php echo $cruise_days_obj->ship_vacation_days ; ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>
	  	<input type="hidden" value="<?php echo $tab_condition; ?>" name="tab_id">
		
		<span onclick="iflair_search_filter('search');" class="search-bt-2" style="text-align: center; line-height: 46px;cursor:pointer;">Search</span>

		<!-- <button type="submit" name="submit" class="search-bt-2" style="text-align: center; line-height: 46px;cursor:pointer;">Search</button> -->

	</div>

	<?php
	exit();
}
function cruise_filter_response(){

global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator,$Ope_ID;

//echo "New Operator id is ".$Ope_ID;
//print '<pre>';
//print_r($_POST);
//print '</pre>';
$mainsiteprefix='cm_';
$agentsiteurl=get_option('siteurl');
$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
$agentsiteid=$agentsitedetail->id;
$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
$agent_assign_operator;
$Ope_ID=$_POST['operator'];

/*
	$region = $_POST['region'];
	$operator = $_POST['operator'];
	$cruise_ship = $_POST['cruise_ship'];
	$ship_fly_in = $_POST['ship_fly_in'];
	$leaving_from = $_POST['leaving_from'];
	$ship_starts_on = $_POST['ship_starts_on'];
	$ship_vacation_days = $_POST['ship_vacation_days'];*/
	if($_POST['region']=="all" ){ $region = ""; }else{ $region = $_POST['region']; }
	if($_POST['operator']=="all" ){ $operator = ""; }else{ $operator = $_POST['operator']; }
	if($_POST['cruise_ship']=="all" ){ $cruise_ship = ""; }else{ $cruise_ship = $_POST['cruise_ship']; }
	if($_POST['ship_fly_in']=="all" ){ $ship_fly_in = ""; }else{ $ship_fly_in = $_POST['ship_fly_in']; }	
	if($_POST['leaving_from']=="all" ){ $leaving_from = ""; }else{ $leaving_from = $_POST['leaving_from']; }
	if($_POST['ship_starts_on']=="all" ){ $ship_starts_on = ""; }else{ $ship_starts_on = $_POST['ship_starts_on']; }
	if($_POST['ship_vacation_days']=="all" ){ $ship_vacation_days = ""; }else{ $ship_vacation_days = $_POST['ship_vacation_days']; }
	$tab_condition = $_POST['tab_id'];


?>

<div class="d-content clearfix setdataheight">
	<div class="container">
<h2 id="filter_title"><?php //echo "Results for ".$string; ?></h2>
<div class="side-bar">									
	<div class="ship-features">
<?php
	$select_ship_query_left ="";
	$select_ship_query_left .= "SELECT cc.cruise_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1 ";
	$conditional_query ="";
	$conditional_query .="cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1 ";

	if($tab_condition == 1){
		$conditional_query .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
	}
	elseif($tab_condition == 2){
		$conditional_query .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
	}
	else{
		$conditional_query .= "";
	}


	if($leaving_from!=""){
		$lq = "SELECT cruise_id FROM cruise_port WHERE port_code = '$leaving_from' GROUP BY cruise_id";
		$select_lq = $mydb->get_results($lq);
		//print_r($select_lq[0]['cruise_id']);
		$leaving_string = $select_lq[0]->cruise_id;
		for($i=1;$i<count($select_lq);$i++)
		{
			//echo $select_lq[$i]->cruise_id;
			$leaving_string = $leaving_string.",".$select_lq[$i]->cruise_id;
		}
		//echo $leaving_string;
		$select_ship_query_left .= " AND csc.cruise_id IN ($leaving_string)";
	}
	/*if($_POST['str1']!="date_departure" ){*/
		if($region != ""){
			$select_ship_query_left .= " AND csc.ship_region = '$region'";
			$conditional_query .= " AND csc.ship_region = '$region'";
		}
		if($operator != ""){
			$select_ship_query_left .= " AND co.operator_id = $operator";
			$conditional_query .= " AND co.operator_id = $operator";
		}
		if($cruise_ship != ""){
			$select_ship_query_left .= " AND csc.ship_id = $cruise_ship";
			$conditional_query .= " AND csc.ship_id = $cruise_ship";
		}
		if($ship_fly_in != ""){
			$select_ship_query_left .= " AND csc.ship_fly_in = '$ship_fly_in'";
			$conditional_query .= " AND csc.ship_fly_in = '$ship_fly_in'";
		}
		if($ship_starts_on != ""){
			$select_ship_query_left .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
			$conditional_query .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
		}
		if($ship_vacation_days != ""){
			$select_ship_query_left .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
			$conditional_query .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
		}
	/*}*/

	$select_ship_query_left .= " GROUP BY cc.cruise_title"; /* Comment */
	$select_ship_query_left .= " ORDER BY cc.cruise_title";

	//echo $select_ship_query_left;
	$select_ship_query_left_r = $mydb->get_results($select_ship_query_left);


/* Master Query Start------------------------------- */
	$pagenum=$_POST['pagenumb'];
	if($_POST['pagenumb']==""){
		$per_page = 10;
		$page='1';
		$start='0';
	}
	else {
		$per_page = 10;
		$page=$_POST['pagenumb'];	
		$start=($page-1)*$per_page;
	}

	//echo "Response Found -> ".$_POST['region']."<br>";

	if($_POST['str1'] !="" && $_POST['str2'] != "" ){
		if($_POST['str1']=="date_departure"){
			$date_departure = $_POST['str2'];
			$id_query = "SELECT ship_id FROM cruise_ship_cruise WHERE $_POST[str1] LIKE '%$_POST[str2]%' GROUP BY ship_id";
			$id_res = $mydb->get_results($id_query);
				$ship_id = $id_res[0]->ship_id;
				//print_r($id_res);
				for($i=1;$i<count($id_res);$i++){
					$ship_id = $ship_id.",".$id_res[$i]->ship_id;
				}
				//echo $ship_id; ;
			
			$select_ship_query = "SELECT cc.cruise_cover_image_href,csc.ship_name,csc.ship_starts_on,csc.ship_cruise_nights,cc.cruise_title,csc.ship_cruise_only_price,csc.ship_fly_cruise_price, csc.cruise_id AS a, cc.cruise_id AS b FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1  AND csc.ship_starts_on LIKE '%$date_departure%'";
		}
		else{
			$id_query = "SELECT cruise_response_id FROM cruise_cruise WHERE $_POST[str1] = '$_POST[str2]'";
			$id_res = $mydb->get_results($id_query);
				$ship_id = $id_res[0]->cruise_response_id;
				for($i=1;$i<count($id_res);$i++){
					$ship_id = $ship_id.",".$id_res[$i]->cruise_response_id;
				}
			$select_ship_query = "SELECT cc.cruise_cover_image_href,csc.ship_name,csc.ship_starts_on,csc.ship_cruise_nights,cc.cruise_title,csc.ship_cruise_only_price,csc.ship_fly_cruise_price, csc.cruise_id AS a, cc.cruise_id AS b FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1  AND csc.ship_id IN ($ship_id)";
		}
			//echo $ship_id;
	}
	else{
		$select_ship_query ="";
		$select_ship_query .= "SELECT cc.cruise_cover_image_href,csc.ship_name,csc.ship_starts_on,csc.ship_cruise_nights,cc.cruise_title,csc.ship_cruise_only_price,csc.ship_fly_cruise_price, csc.cruise_id AS a, cc.cruise_id AS b FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1 ";
	}

	if($leaving_from!=""){
		$lq = "SELECT cruise_id FROM cruise_port WHERE port_code = '$leaving_from' GROUP BY cruise_id";
		$select_lq = $mydb->get_results($lq);
		//print_r($select_lq[0]['cruise_id']);
		$leaving_string = $select_lq[0]->cruise_id;
		for($i=1;$i<count($select_lq);$i++)
		{
			//echo $select_lq[$i]->cruise_id;
			$leaving_string = $leaving_string.",".$select_lq[$i]->cruise_id;
		}
		//echo $leaving_string;
		$select_ship_query .= " AND csc.cruise_id IN ($leaving_string)";
		$string .= $leaving_from ;
	}
	/*if($_POST['str1']!="date_departure" ){*/
		$string ="";
		if($region != ""){
			$select_ship_query .= " AND csc.ship_region = '$region'";
			$string .= $region ;
		}
		if($operator != ""){
			$select_ship_query .= " AND co.operator_id = $operator";
			$string .= $operator ;
		}
		if($cruise_ship != ""){
			$select_ship_query .= " AND csc.ship_id = $cruise_ship";
			$string .= $cruise_ship ;
		}
		if($ship_fly_in != ""){
			$select_ship_query .= " AND csc.ship_fly_in = '$ship_fly_in'";
			$string .= $ship_fly_in ;
		}
		if($ship_starts_on != ""){
			$select_ship_query .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
			$string .= $ship_starts_on ;
		}
		if($ship_vacation_days != ""){
			$select_ship_query .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
			$string .= $ship_vacation_days ;
		}
	/*}*/

		if($tab_condition == 1){
			$select_ship_query .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
		}
		elseif($tab_condition == 2){
			$select_ship_query .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
		}
		else{
			$select_ship_query .= "";
		}

	//$select_ship_query .= " GROUP BY csc.ship_name"; /* Comment */
	//$select_ship_query .= " ORDER BY csc.ship_starts_on";
	if(!isset($_GET['start_price']) && !isset($_GET['start_price'])){
		$start_price = $_POST['s'];	
		$end_price = $_POST['e'];
	}
	else{
		$start_price = $_GET['start_price'];	
		$end_price = $_GET['start_price'];	
	}

/* price change start */

//if($start_price != "" && $end_price != "")
if($start_price == 0 && $end_price != ""){
	if($start_price == 0 && $end_price == 10000){
		$select_ship_query .= " AND csc.ship_cruise_only_price  >= 0";
		$price_history = "";
	}
	elseif($start_price == 0 && $end_price == 1000){
		//$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price < ".$end_price."";
		$select_ship_query = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price  > 0 AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price < ".$end_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price < ".$end_price.") )";
		$price_history = "in price Below £".number_format($end_price)."";
	}
	else{
		//$select_ship_query = ." AND csc.ship_cruise_only_price < ".$end_price."";
		$select_ship_query .= " AND csc.ship_cruise_only_price  >= 0 AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price < ".$end_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price < ".$end_price.") )";
		$price_history = "in price Below £".number_format($end_price)."";
	}
}
else if($start_price != "" && $end_price == 10000){
	if($start_price == 5000 && $end_price == 10000){
		//$select_ship_query = ." AND csc.ship_cruise_only_price >= ".$start_price."";
		$select_ship_query .= " AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price > ".$start_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price  > ".$start_price.") OR ( csc.ship_cruise_only_price = 0 AND csc.ship_fly_cruise_price = 0 ) ) ";
		$price_history = "in price Bigger than £".number_format($start_price)."";
	}
	else{
		//$select_ship_query = ." AND csc.ship_cruise_only_price >= ".$start_price."";
		$select_ship_query .= " AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price > ".$start_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price  > ".$start_price.") )";
		$price_history = "in price Bigger than £".number_format($start_price)."";
	}
}
elseif($start_price == "" && $end_price == ""){
	$select_ship_query .= " AND csc.ship_cruise_only_price  >= 0";
	$price_history = "";
}
else{
	//$select_ship_query = ." AND csc.ship_cruise_only_price BETWEEN ".$start_price." AND ".$end_price."";
	$select_ship_query .= " AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price BETWEEN ".$start_price." AND ".$end_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price BETWEEN ".$start_price." AND ".$end_price.") )";
	$price_history = "in price range of £".number_format($start_price)." to £".number_format($end_price)."";
}

/* price change end */

	$todays_date = date('Y-m-d H:i:s');
	$select_ship_query .= " AND csc.ship_starts_on >= '$todays_date'";
	$select_ship_query_unlimit = $select_ship_query;
	
	if( ($start_price != "" && $start_price != "0") && ( $end_price != "" &&  $end_price != "10000") ){
		//$select_ship_query.= " ORDER BY csc.ship_cruise_only_price, csc.ship_fly_cruise_price ASC LIMIT $start,$per_page";
		$select_ship_query.= " ORDER BY IF( csc.ship_cruise_only_price = 0, 1, 0), csc.ship_cruise_only_price LIMIT $start,$per_page";
		//$price_q = $mydb->get_results($select_ship_query." ORDER BY csc.ship_cruise_only_price, csc.ship_fly_cruise_price ASC LIMIT $start,$per_page");
		$price_q = $mydb->get_results($select_ship_query." ORDER BY IF( csc.ship_cruise_only_price = 0, 1, 0), csc.ship_cruise_only_price LIMIT $start,$per_page");
	}
	else{
		$select_ship_query.= " ORDER BY csc.ship_starts_on LIMIT $start,$per_page";
		$price_q = $mydb->get_results($select_ship_query." ORDER BY csc.ship_starts_on LIMIT $start,$per_page");
	}
	//echo $string;
	/*echo "<pre>";
	echo $select_ship_query;
	echo "</pre>";*/
	$select_ship = $mydb->get_results($select_ship_query);
	//echo count($select_ship);
/* Master Query End--------------------------------------------------------- */
$select_ship_query_unlimit_c = count($mydb->get_results($select_ship_query_unlimit));
echo "<pre id='history' style='display:none;'>";
//print_r($_POST);
$history_str = "";
	//if($_POST['operator']!="" || $_POST['region']!="" || $_POST['cruise_ship']!="" || $_POST['ship_fly_in']!="" || $_POST['ship_starts_on']!="" || $_POST['ship_vacation_days']!="" ){
		//$history_str .= "Search ";
		$history_str .= "Results Showing ".$select_ship_query_unlimit_c." ";
	//}

	if($_POST['region']=="all" || $_POST['region']==""){ 
		$history_str .= "cruises to Anywhere "; 
	}elseif($_POST['region']!=""){ 
		$history_str .= "cruises to ".$_POST['region']." "; 
	}

	if($_POST['operator']=="all" || $_POST['operator']==""){ 
		$history_str .= "with All Cruiselines "; 
	}elseif($_POST['operator']!=""){
		$val_op = $mydb->get_row("SELECT operator_title FROM cruise_operators WHERE operator_id = ".$_POST['operator']."");
		$history_str .= "with ".$val_op->operator_title." "; 
	}

	if($_POST['cruise_ship']=="all" || $_POST['cruise_ship']==""){ 
		$history_str .= "on Any Ship "; 
	}elseif($_POST['cruise_ship']!=""){
		$val_ship = $mydb->get_row("SELECT cruise_title FROM cruise_cruise WHERE cruise_response_id = ".$_POST['cruise_ship']."");
		$history_str .= "on ".$val_ship->cruise_title." "; 
	}

	if($_POST['ship_fly_in']=="all" || $_POST['ship_fly_in']==""){ 
		$history_str .= "leaving from Any Port "; 
	}elseif($_POST['ship_fly_in']!=""){ 
		$history_str .= "leaving from ".$_POST['ship_fly_in']." "; 
	}

	if($_POST['ship_starts_on']=="all" || $_POST['ship_starts_on']==""){ 
		$history_str .= "in All Months "; 
	}elseif($_POST['ship_starts_on']!=""){ 
		$history_str .= "in ".date('F Y',strtotime($_POST['ship_starts_on']))." "; 
	}

	if($_POST['ship_vacation_days']=="all" || $_POST['ship_vacation_days']==""){ 
		$history_str .= "for all Days "; 
	}elseif($_POST['ship_vacation_days']!=""){ 
		$history_str .= "for ".$_POST['ship_vacation_days']." Days "; 
	}
	$history_str .= $price_history.".";


$start_price = $_GET['start_price'];	
$end_price = $_GET['end_price'];	
//if($start_price != "" && $end_price != "")
if($start_price == 0 && $end_price != ""){
	if($start_price == 0 && $end_price == 10000){
		$price_history = "";
	}
	else{
		$price_history = "in price Below £".number_format($end_price)."";
	}
}
else if($start_price != "" && $end_price == 10000){
	$price_history = "in price Bigger than £".number_format($start_price)."";
}
elseif($start_price == "" && $end_price == ""){
	$price_history = "";
}
else{
	$price_history = "in price range of £".number_format($start_price)." to £".number_format($end_price)."";
}

echo $history_str."".$price_history;
echo "</pre>";

?>
		<ul>
			<!-- <li><a class="pointer_class iflair_template_value_cruiseship" onclick="iflair_ajax_cruise_operators_left('reset');" >Cruise Lines</a></li> -->
			<li id="sub_list"><a>Cruise Ship<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
				<ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
					<?php
						//echo "SELECT cruise_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_size AS css ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id =$operator GROUP BY cc.cruise_title ORDER BY cruise_title";
				    //$select_cruise_ship_size = $mydb->get_results("SELECT cruise_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_size AS css ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id =$operator GROUP BY cc.cruise_title ORDER BY cruise_title");
				   	if(count($select_ship_query_left_r)==0){
				   		
						$select_cruise_ship_size_all = $mydb->get_results("SELECT cruise_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_size AS css ON co.operator_title = cc.cruise_operator_name GROUP BY cc.cruise_title ORDER BY cruise_title");
						foreach ($select_cruise_ship_size_all as $cruise_ship_size_obj) :
						?>
						<li><a onclick="iflair_ajax_cruise_operators_left('cruise_title','<?php echo $cruise_ship_size_obj->cruise_title; ?>');" class="<?php if($cruise_ship_size_obj->cruise_title==$_COOKIE['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_title; ?></a></li>
						<?php
						endforeach;
				   	}
				   	else{
						foreach ($select_ship_query_left_r as $cruise_ship_size_obj) :
						?>
						<li><a onclick="iflair_ajax_cruise_operators_left('cruise_title','<?php echo $cruise_ship_size_obj->cruise_title; ?>');" class="<?php if($cruise_ship_size_obj->cruise_title==$_COOKIE['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_title; ?></a></li>
						<?php
						endforeach;
				   	}
				    ?>
				</ul>
			</li>
			<li id="sub_list"><a>Ship Size<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
				<ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
					<?php
					$main_size = "";
					$main_size .= "SELECT cc.cruise_ship_size FROM ";
					//$main_size .= "cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1 ";
					$main_size .= $conditional_query;
					$main_size .= " GROUP BY cruise_ship_size";
				    $select_cruise_ship_size = $mydb->get_results("$main_size");
				    if(count($select_cruise_ship_size)==0){
				    	$select_cruise_ship_size_all = $mydb->get_results("$main_size");
						foreach ($select_cruise_ship_size_all as $cruise_ship_size_obj) :
						?>
						<li><a onclick="iflair_ajax_cruise_operators_left('cruise_ship_size','<?php echo $cruise_ship_size_obj->cruise_ship_size; ?>');" class="<?php if($cruise_ship_size_obj->cruise_ship_size==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_ship_size; ?></a></li>
						<?php
						endforeach;
				    }
				    else{
						foreach ($select_cruise_ship_size as $cruise_ship_size_obj) :
						?>
						<li><a onclick="iflair_ajax_cruise_operators_left('cruise_ship_size','<?php echo $cruise_ship_size_obj->cruise_ship_size; ?>');" class="<?php if($cruise_ship_size_obj->cruise_ship_size==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_ship_size; ?></a></li>
						<?php
						endforeach;
				    }
				    ?>
				</ul>
			</li>

			<?php /*
			<li id="sub_list">
				<a>Ship Style<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
				<ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
					<?php
						$main_style = "";
						$main_style .= "SELECT cc.crusie_ship_style FROM ";
						//$main_style .= "cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1 ";
						$main_style .= $conditional_query;
						$main_style .= " GROUP BY crusie_ship_style";
				   		$select_cruise_ship_style = $mydb->get_results("$main_style");
						if(count($select_cruise_ship_style)==0){
							$select_cruise_ship_style_all = $mydb->get_results("$main_style");
							foreach ($select_cruise_ship_style_all as $cruise_ship_style_obj) :
							?>
							<li><a onclick="iflair_ajax_cruise_operators_left('crusie_ship_style','<?php echo $cruise_ship_style_obj->crusie_ship_style; ?>');" class="<?php if($cruise_ship_style_obj->crusie_ship_style==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_style_obj->crusie_ship_style; ?></a></li>
							<?php
							endforeach;
						}
						else{
							foreach ($select_cruise_ship_style as $cruise_ship_style_obj) :
							?>
							<li><a onclick="iflair_ajax_cruise_operators_left('crusie_ship_style','<?php echo $cruise_ship_style_obj->crusie_ship_style; ?>');" class="<?php if($cruise_ship_style_obj->crusie_ship_style==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_style_obj->crusie_ship_style; ?></a></li>
							<?php
							endforeach;
						}
				    ?>
				</ul>
			</li>
			
					<?php
						$select_cruise_language = $mydb->get_results("SELECT cl.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_language AS cl ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id =$operator AND cl.language_code = cc.cruise_language GROUP BY cc.cruise_language ORDER BY cc.cruise_operator_name");
						if(count($select_cruise_language)==0 && $operator==""){
						?>
						<li id="sub_list">
							<a>Language<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
							<ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
						<?php
							$select_cruise_language_all = $mydb->get_results("SELECT cl.* FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_language AS cl ON co.operator_title = cc.cruise_operator_name GROUP BY cl.language_code ORDER BY cc.cruise_operator_name");
							foreach ($select_cruise_language_all as $cruise_language_obj) :
							?>
							<li><a onclick="iflair_ajax_cruise_operators_left('cruise_language','<?php echo $cruise_language_obj->language_code; ?>');" class="<?php if($cruise_language_obj->language_code==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_language_obj->language_title; ?></a></li>
							<?php
							endforeach;
							?>
								</ul>
							</li>
							<?php
						}
						elseif(count($select_cruise_language)==0 && $operator!=""){
						}
						else{
						?>
						<li id="sub_list">
							<a>Language<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
							<ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
						<?php
							foreach ($select_cruise_language as $cruise_language_obj) :
							?>
							<li><a onclick="iflair_ajax_cruise_operators_left('cruise_language','<?php echo $cruise_language_obj->language_code; ?>');" class="<?php if($cruise_language_obj->language_code==$_POST['str2']){ echo "active_left";} ?>" ><?php echo $cruise_language_obj->language_title; ?></a></li>
							<?php
							endforeach;
							?>
								</ul>
							</li>
							<?php
						}
				    ?>
			<!-- <li id="sub_list">
				<input type="text" placeholder="Departure Date" value="<?php //if($_POST['str1']=="date_departure"){ echo $_POST['str2']; } ?>" name="cruise_ship_departure_date" id="cruise_ship_departure_date" onchange="iflair_ajax_cruise_operators_left('date_departure','');" style="width: 100%;padding-left: 25px;">
			</li> -->
			<li id="sub_list"><a>Departure Date<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/down-arrow.png" style="float: right; padding: 15px;"></a>
				<ul style="width: 100%; float: left;max-height: 150px;" class="clearfix content mCustomScrollbar">
					<?php
						//echo "SELECT cruise_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_size AS css ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id =$operator GROUP BY cc.cruise_title ORDER BY cruise_title";
				    //$select_cruise_ship_size = $mydb->get_results("SELECT cruise_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_size AS css ON co.operator_title = cc.cruise_operator_name WHERE co.operator_id =$operator GROUP BY cc.cruise_title ORDER BY cruise_title");
				   	if(count($select_ship_query_left_r)==0){
				   		
						$select_cruise_ship_size_all = $mydb->get_results("SELECT cruise_title FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc INNER JOIN cruise_ship_size AS css ON co.operator_title = cc.cruise_operator_name GROUP BY cc.cruise_title ORDER BY cruise_title");
						foreach ($select_cruise_ship_size_all as $cruise_ship_size_obj) :
						?>
						<li><a onclick="iflair_ajax_cruise_operators_left('cruise_title','<?php echo $cruise_ship_size_obj->cruise_title; ?>');" class="<?php if($cruise_ship_size_obj->cruise_title==$_COOKIE['str2']){ echo "active_left";} ?>" ><?php echo $cruise_ship_size_obj->cruise_title; ?></a></li>
						<?php
						endforeach;
				   	}
				   	else{
				   		$cruise_when= "SELECT csc.ship_starts_on FROM cruise_operators AS co INNER JOIN cruise_cruise AS cc ON co.operator_title = cc.cruise_operator_name INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1 ";
				if($region != ""){
					$cruise_when .= " AND csc.ship_region = '$region'";
				}
				if($operator != ""){
					$cruise_when .= " AND co.operator_id = $operator";
				}
				if($cruise_ship != ""){
					$cruise_when .= " AND csc.ship_id = $cruise_ship";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_fly_in != ""){
					$cruise_when .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($ship_vacation_days != ""){
					$cruise_when .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
				}
	  				$cruise_when .= " GROUP BY YEAR(csc.ship_starts_on),MONTH(csc.ship_starts_on) ORDER BY csc.ship_starts_on";
	  			
				$select_cruise_when = $mydb->get_results($cruise_when);
						foreach ($select_cruise_when as $cruise_when_obj) :
							?>
							<li><a onclick="iflair_ajax_cruise_operators_left('date_departure','<?php echo date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ; ?>');" class="<?php if($_POST['str2'] == date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ){ echo "active_left"; } ?>" ><?php $ship_date=$cruise_when_obj->ship_starts_on; echo date('F Y',strtotime($ship_date)); ?></a></li>
							<?php
						endforeach;
				   	}
				    ?>
				</ul>
			</li>
			*/?>
			<script type="text/javascript">
				jQuery(function() {
				    <?php if(isset($_POST['s'])){ ?>
						var min1 = "<?php echo $_POST['s']; ?>";
						<?php }else{ ?>
						var min1 = 0;
					<?php } ?>
				    <?php if(isset($_POST['e'])){ ?>
						var max1 = "<?php echo $_POST['e']; ?>";
						<?php }else{ ?>
						var max1 = 10000;
					<?php } ?>
				    jQuery( "#slider-range" ).slider({
				      range: true,
				      min: 0,
				      max: 10000,
				      values: [ min1, max1 ],
				      slide: function( event, ui ) {
				        jQuery( "#amount" ).html( "<span class='start_a'>£" + ui.values[ 0 ] + "</span><span class='end_a'>£" + ui.values[ 1 ] +"</span>" );
						jQuery( "#amount1" ).val(ui.values[ 0 ]);
						jQuery( "#amount2" ).val(ui.values[ 1 ]);
				      }
				    });

				    jQuery( "#amount" ).html( "<span class='start_a'>£" + jQuery( "#slider-range" ).slider( "values", 0 ) +
				     "</span><span class='end_a'>£" + jQuery( "#slider-range" ).slider( "values", 1 ) + "</span>" );
				});
				/*function price_filter(){
					alert("price");
				}*/
				jQuery(document).ready(function(){
			        jQuery( ".ui-slider-handle" ).mouseup(function() {
				    //jQuery('input[name="radio_price"]').attr('checked', false);
				    //jQuery('.radio_price').removeAttr('checked');
				    /*jQuery('input[name="radio_price"]').each(function(i) {
					    this.checked = false;
					});*/
					//jQuery('input[name="radio_price"]').prop('checked', false);
					//jQuery('.radio_price').attr('checked', false);
					//alert("12121");
					//jQuery("input[name='radio_price']").prop("checked",false);

			        jQuery('.loader').css('display','block');
			        var s = jQuery("#amount1").val();
			        var e = jQuery("#amount2").val();
			        var pagenumb = jQuery(".currentdiv").attr("id");
				var region = jQuery('#cruise_region').val();
				var operator = jQuery('#cruise_operator').val();
				var cruise_ship = jQuery('#cruise_ship').val();
				var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
				var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
				var ship_vacation_days = jQuery('#cruise_ship_vacation_days').val();

var tab_id = jQuery(".active_tab").attr('id');
var newURL = "<?php echo get_site_url(); ?>";
if(jQuery(".active_tab").attr('id')=="1"){
	var path = "rivercruise/";
}
else if(jQuery(".active_tab").attr('id')=="2"){
	var path = "oceansearch/";
}
else{
	var path = "";
}

if (window.history.pushState) {
	history.pushState({},"URL Rewrite Example",newURL+"/"+path+"?cruise_region="+region+"&cruise_operator="+operator+"&cruise_ship="+cruise_ship+"&cruise_ship_fly_in="+ship_fly_in+"&cruise_ship_starts_on="+ship_starts_on+"&cruise_ship_vacation_days="+ship_vacation_days+"&tab_id="+tab_id+"&start_price="+s+"&end_price="+e);
}

			        jQuery.ajax({
			            type: "POST",
			            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
			            data: ({
			                action: 'price_filter_result',
			                s: s,
			                e: e,
			                pagenumb:'1',
				            region: region,
				            operator: operator,
				            cruise_ship: cruise_ship,
				            ship_fly_in: ship_fly_in,
				            ship_starts_on: ship_starts_on,
				            ship_vacation_days: ship_vacation_days,
			                query:"<?php echo $select_ship_query_unlimit; ?>"
			            }),
			            success: function (response) {
			            	
			                //alert(response);
                			jQuery('.result-part').html(response);
				            var history=jQuery('#history1').html();
				            //alert(history);
				            jQuery("#result_story").html(history);
	                		//alert(s);
	                		//jQuery.cookie('start_price',s, {expires: 1, path:'/' });
							//jQuery.cookie('end_price',e, {expires: 1, path:'/' });
                			jQuery('.loader').css('display','none');
			        		//alert( s+" --- "+e );
							/*
							jQuery(".mCustomScrollbar").slideUp();
							jQuery(".mCustomScrollbar li a").removeClass("active_left");*/

							
			            }
			        });

			        });


			      })
			</script>
			<?php /*echo '<pre>';
			print_r($_GET);
			print_r($_REQUEST);
			echo '</pre>';*/
			 ?>

			<li id="sub_list" class="ui-slider_li"><a>Price Range (per person)</a>
				<div id="slider-range"></div>
				<p id="amount"></p>
				<input type="hidden" name="start_price" value="<?php if(isset($_POST['s'])){ echo $_POST['s'];}else{ echo "0"; }; ?>" id="amount1">
				<input type="hidden" name="end_price" value="<?php if(isset($_POST['e'])){ echo $_POST['e'];}else{ echo "10000"; }; ?>" id="amount2">
				<!-- <span onclick="price_filter();">find</span> -->
			<hr style="margin: 10px 0 0 0;">
				<div class="pricearea">
					<div class="pricerow">
						<div class="priceradio"><input id="1_radio" type="radio" class="radio_price" name="radio_price" value="1" onclick="radio_range(1);"></div>
						<label class="pricerange" for="1_radio">upto £1000</label>  
					</div>
					<div class="pricerow">
						<div class="priceradio"><input id="2_radio" type="radio" class="radio_price" name="radio_price" value="2" onclick="radio_range(2);"></div>
						<label class="pricerange" for="2_radio"> £1000 - £1500</label>  
					</div>
					<div class="pricerow">
						<div class="priceradio"><input id="3_radio" type="radio" class="radio_price" name="radio_price" value="3" onclick="radio_range(3);"></div>
						<label class="pricerange" for="3_radio"> £1500 - £2000</label>  
					</div>
					<div class="pricerow">
						<div class="priceradio"><input id="4_radio" type="radio" class="radio_price" name="radio_price" value="4" onclick="radio_range(4);"></div>
						<label class="pricerange" for="4_radio"> £2000- £3000</label>  
					</div>
					<div class="pricerow">
						<div class="priceradio"><input id="5_radio" type="radio" class="radio_price" name="radio_price" value="5" onclick="radio_range(5);"></div>
						<label class="pricerange" for="5_radio"> £3000 - £4000</label>  
					</div>
					<div class="pricerow">
						<div class="priceradio"><input id="6_radio" type="radio" class="radio_price" name="radio_price" value="6" onclick="radio_range(6);"></div>
						<label class="pricerange" for="6_radio"> £4000 - £5000</label>  
					</div>
					<div class="pricerow">
						<div class="priceradio"><input id="7_radio" type="radio" class="radio_price" name="radio_price" value="7" onclick="radio_range(7);"></div>
						<label class="pricerange" for="7_radio"> over £5000</label>  
					</div>
					<div class="pricerow">
						<div class=""><a id="8_radio" class="reset_price_btn" onclick="radio_range(8);"> Reset Price</a>  
					</div>
				</div>
				<script type="text/javascript">
					function radio_range(str){
						if(str==1){
							jQuery("#amount1").val(0);
							jQuery("#amount2").val(1000);
							var min1 = 0;
							var max1 = 1000;	
						}
						else if(str==2){
							jQuery("#amount1").val(1000);
							jQuery("#amount2").val(1500);
							var min1 = 1000;
							var max1 = 1500;	
						}
						else if(str==3){
							jQuery("#amount1").val(1500);
							jQuery("#amount2").val(2000);	
							var min1 = 1500;
							var max1 = 2000;
						}
						else if(str==4){
							jQuery("#amount1").val(2000);
							jQuery("#amount2").val(3000);	
							var min1 = 2000;
							var max1 = 3000;
						}
						else if(str==5){
							jQuery("#amount1").val(3000);
							jQuery("#amount2").val(4000);	
							var min1 = 3000;
							var max1 = 4000;
						}
						else if(str==6){
							jQuery("#amount1").val(4000);
							jQuery("#amount2").val(5000);	
							var min1 = 4000;
							var max1 = 5000;
						}
						else if(str==7){
							jQuery("#amount1").val(5000);
							jQuery("#amount2").val(10000);	
							var min1 = 5000;
							var max1 = 10000;
						}
						else if(str==8){
							//alert("tfopydfiop");
							jQuery("#amount1").val(0);
							jQuery("#amount2").val(10000);	
							var min1 = "0";
							var max1 = "10000";
								jQuery('#1_radio').prop('checked',false);
								jQuery('#2_radio').prop('checked',false);
								jQuery('#3_radio').prop('checked',false);
								jQuery('#4_radio').prop('checked',false);
								jQuery('#5_radio').prop('checked',false);
								jQuery('#6_radio').prop('checked',false);
								jQuery('#7_radio').prop('checked',false);
						}

				    
					    jQuery( "#slider-range" ).slider({
					      range: true,
					      min: 0,
					      max: 10000,
					      values: [ min1, max1 ],
					      slide: function( event, ui ) {
					        jQuery( "#amount" ).html( "<span class='start_a'>£" + ui.values[ 0 ] + "</span><span class='end_a'>£" + ui.values[ 1 ] +"</span>" );
							jQuery( "#amount1" ).val(ui.values[ 0 ]);
							jQuery( "#amount2" ).val(ui.values[ 1 ]);
					      }
					    });
					    jQuery( "#amount" ).html( "<span class='start_a'>£" + jQuery( "#slider-range" ).slider( "values", 0 ) +
					     "</span><span class='end_a'>£" + jQuery( "#slider-range" ).slider( "values", 1 ) + "</span>" );
						jQuery(".ui-slider-handle").trigger("mouseup");
						//var checked_val = jQuery(this).value;
						//jQuery("input[name='radio_price']").filter("[value=checked_val]").prop("checked",true);
					}
				</script>
			</li>

		</ul>
	</div>
</div>

		<div class="result-part">
<?php
	
		/*echo "<pre>";
		echo $select_ship_query;
		echo "</pre>";*/
	if(count($select_ship) == 0)
	{
		echo "<div class='no_result_area'>No Cruise Found ..<div>";
	}
	else
	{
		cruise_pagging($page,$per_page,$select_ship_query_unlimit);

		for($i=0;$i<count($select_ship);$i++)
		{
		?>

<div class="mediter-box clearfix">
	<div class="medi-left">
		<div class="newtableimg">
			<div class="netablecellimg">
				<img src="<?php if($select_ship[$i]->cruise_cover_image_href!=""){ echo "http://ekups3e.cloudimg.io/s/crop/300x200/".str_replace("//www","http://www",$select_ship[$i]->cruise_cover_image_href); }else{ echo esc_url( get_template_directory_uri() )."/images/noImageAvailable.png"; } ?>" class="img-responsive">
			</div>
		</div>
		<?php /*<img src="<?php if($select_ship[$i]->cruise_cover_image_href!=""){ echo "http://ekups3e.cloudimg.io/s/resize/200/".$select_ship[$i]->cruise_cover_image_href; }else{ echo esc_url( get_template_directory_uri() )."/images/no-property-image.jpg"; } ?>" class="img-responsive"> */?>
		<?php
		/*
		<img src="<?php echo esc_url( get_template_directory_uri() )."/images/loader.gif"; ?>" data-original="http://ekups3e.cloudimg.io/s/resize/200/<?php if($select_ship[$i]->cruise_cover_image_href!=""){ echo $select_ship[$i]->cruise_cover_image_href; }else{ echo esc_url( get_template_directory_uri() )."/images/no-property-image.jpg"; } ?>" class="img-responsive lazy<?php echo $i; ?>">
					<script>
						jQuery( document ).ready(function() {
							jQuery("img.lazy<?php echo $i; ?>").lazyload({skip_invisible : true});
						});
					</script>
		*/
		?>
	</div>
	<div class="medi-mid mid-mid-two">
		<h3><?php echo $select_ship[$i]->ship_name; ?></h3>
		<p class="date_new_site"><?php $ship_date=$select_ship[$i]->ship_starts_on; echo date('d M Y',strtotime($ship_date)); ?></p>
		<p class="day_new_site daytotal"><?php echo $select_ship[$i]->ship_vacation_days; ?> vacation nights</p>
		<p class="ship_new_site"><div class="tool"></div> <div class="shiptitle">Ship</div><span class="toolname">: <?php echo $select_ship[$i]->cruise_title; ?></span></p>
		<p class="itinerary_new_site">
		<span class="itecolor">itinerary : </span>

		<?php
		$select_itinerary_query ="";
		$select_itinerary_query .= "SELECT port_name FROM cruise_port WHERE cruise_id = '";
		$select_itinerary_query .= $select_ship[$i]->a;
		$select_itinerary_query .= "' GROUP BY port_name ORDER BY id";
		//echo $select_itinerary_query;
		$select_itinerary = $mydb->get_results($select_itinerary_query);
		$itinerary_count = count($select_itinerary);
		if($itinerary_count!="0"){
			echo $select_itinerary[0]->port_name;
			for($i1=1;$i1<count($select_itinerary);$i1++)
			{
				//echo "<pre>";
				//print_r($select_port);
				//echo "</pre>";
				?> <i class="fa fa-caret-right"></i>
				<?php echo $select_itinerary[$i1]->port_name;
				?>
			<?php
			}
		}
		?>
		</p>
	</div>
		<?php
			$offer_query = "SELECT offer_price FROM ".$wpdb->prefix."quote_extra_offer WHERE offer_start_date < curdate() and offer_end_date > curdate() AND cruise_id = '".$select_ship[$i]->cruise_id."'";
			$found_offer = $wpdb->get_row($offer_query);
			/*echo "<pre>";
			print_r($found_offer);
			echo "</pre>";*/
			if(!empty($found_offer)){
				$offer_class = '<div class="offer_class"></div>';
				$offer_class2 = " offer_class2";
				//echo '<div class="'.$offer_class.'"><img src="'.esc_url( get_template_directory_uri() ).'/images/superdeal.png" ></div>';
			}
			else{
				$offer_class = "";
				$offer_class2 = "";
			}
		?>
	<div class="medi-right">
		<?php echo $offer_class; ?>
		<div class="main_added_text">
		<?php 
		$price1 = $select_ship[$i]->ship_cruise_only_price;
		$price2 = $select_ship[$i]->ship_fly_cruise_price;
		
		if(!empty($found_offer)){
			?>
			<!-- <h2>Guide Price Range</h2> -->
			<p class="text1">From </p><p class="textbld">£<?php echo number_format($found_offer->offer_price); ?><span class="text2">pp</span></p>
			<?php
		}
		elseif($price1=="0" && $price2=="0")
		{
			?>
			<!-- <h2>Guide Price Range</h2> -->
			<p class="text1">Please enquire for today’s price</p>
			<?php
		}
		elseif( ( $price1!="0" && $price1 < $price2 ) || $price2== "0" )
		{
			?>
			<!-- <h2>Guide Price Range</h2> -->
			<p class="text1">From </p><p class="textbld">£<?php echo number_format($price1); ?><span class="text2">pp</span></p>
			<?php
		}
		elseif( ( $price2!="0" && $price1 > $price2 ) || $price1== "0" )
		{
			?>
			<!-- <h2>Guide Price Range</h2> -->
			<p class="text1">From <p class="textbld">£<?php echo number_format($price2); ?><span class="text2">pp</span></p>
			<?php
		}
		elseif( ( $price1!="0" && $price2!="0" ) && $price1==$price2 )
		{
			?>
			<!-- <h2>Guide Price Range</h2> -->
			<p class="text1">From </p><p class="textbld">£<?php echo number_format($price1); ?><span class="text2">pp</span></p>
			<?php
		}
		else{
			?>
			<!-- <h2>Guide Price Range</h2> -->
			<p class="text1">Please enquire for today’s price</p>
			<?php
		}
		echo '<div class="'.$offer_class2.'"></div>';
		?>
		</div>
		<?php $detail_page_id = get_site_option( 'iflair_cruise_theme_ship_detail_page' );?>
		<div class="added_img">
			<a target="_blank" href="<?php echo get_page_link($detail_page_id);?>?cruise_id=<?php echo $select_ship[$i]->a; ?>" class="info-bt new_btn_blue new_detail_btn">DETAILS <i class="fa fa-angle-right"></i></a>
					<!-- <script>jQuery("img.lazy").lazyload();</script> -->
			<a onclick="cruise_detail_of('<?php echo $select_ship[$i]->a; ?>');" class="new_btn_blue  itinerary_btn">Itinerary <i class="fa fa-caret-down"></i></a>
		</div>
	</div>
</div>
<div class="cruse-information clearfix">
	<div class="above_map_area"><h2 class="above_map_title">Cruise Itinerary</h2>
	<a target="_blank" href="<?php echo get_page_link($detail_page_id);?>?cruise_id=<?php echo $select_ship[$i]->a; ?>" class="info-bt new_btn_blue above_map">MORE DETAILS / ENQUIRE <i class="fa fa-caret-down"></i></a></div>
	<div class="scroll<?php echo $select_ship[$i]->a; ?> scroll_empty">
		<div class="loader_1" style="display:none;text-align: center; padding: 0px 0px 30px;">
			<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader_1.gif">
		</div>
	</div>

	<?php
	/*echo "<pre>";
	print_r($select_ship[$i]);
	echo "</pre>";*/
	?>
	<div class="clearfix right">
		<?php /*<a href="<?php echo get_page_link($detail_page_id);?>?ship_id=<?php echo $select_ship[$i]->b; ?>" class="info-bt new_btn_blue">VIEW MORE INFORMATION</a> */?>
	</div>
</div>

		<?php
		}
	}
	?>
<script type="text/javascript">
	
	jQuery(".content").mCustomScrollbar();
	var item = jQuery(".active_left");
	//var item = jQuery('ul li.sub_list').find('li').children('ul.sub_list');
	//alert(item);
    item.parent().parent().css('display','block');
    item.parent().parent().parent().parent().css('display','block');

	var dateToday = new Date();
    jQuery("#cruise_ship_departure_date").datepicker({ 
      minDate: dateToday ,
      dateFormat: 'yy-mm-dd'
    });

	jQuery(this).next('ul').slideUp();
	jQuery('#sub_list a').on('click',function(){
		jQuery(this).next('ul').slideToggle();
	});

function iflair_ajax_cruise_operators_left(str1,str2){
		jQuery('.loader').css('display','block');	
		var pagenumb='1';
		var str1 = str1;

		//alert(str1);	
		/*if(str1=='date_departure'){
			var str2 =jQuery('#cruise_ship_departure_date').val();
			jQuery('#cruise_region').prop('selectedIndex',0);
			jQuery('#cruise_operator').prop('selectedIndex',0);
			jQuery('#cruise_ship').prop('selectedIndex',0);
			jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
			jQuery('#cruise_leaving_from').prop('selectedIndex',0);
			jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
			jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);
		}*/
		if(str1=='reset'){
			jQuery('#cruise_region').prop('selectedIndex',0);
			jQuery('#cruise_operator').prop('selectedIndex',0);
			jQuery('#cruise_ship').prop('selectedIndex',0);
			jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
			jQuery('#cruise_leaving_from').prop('selectedIndex',0);
			jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
			jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);
		}
		else{
			var str2 = str2;
			/*jQuery('#cruise_region').prop('selectedIndex',0);
			jQuery('#cruise_operator').prop('selectedIndex',0);
			jQuery('#cruise_ship').prop('selectedIndex',0);
			jQuery('#cruise_ship_fly_in').prop('selectedIndex',0);
			jQuery('#cruise_leaving_from').prop('selectedIndex',0);
			jQuery('#cruise_ship_starts_on').prop('selectedIndex',0);
			jQuery('#cruise_ship_vacation_days').prop('selectedIndex',0);*/
		}

		jQuery.cookie('str1', str1,{expires: 1,path: "/" });
		jQuery.cookie('str2', str2,{expires: 1,path: "/" });

		//alert(str2);
		var operator = jQuery('#cruise_operator').val();
		var region = jQuery('#cruise_region').val();
		var pagenumb=pagenumb;
		var touroperator = jQuery('#iflair_template_cruise_operators').val();
		//alert(jQuery("#iflair_template_cruise_operators option:selected").text());
		var shipsize = jQuery('#iflair_template_cruise_ship_size').val();
		var shipstyle = jQuery('#iflair_template_cruise_ship_style').val();
		var shiplanguage = jQuery('#iflair_template_cruise_language').val();
		var s = jQuery('#amount1').val();
		var e = jQuery('#amount2').val();
        jQuery.ajax({
            type: "POST",
            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
            data: ({
                action: 'cruise_filter_response',
                str1: str1,
                str2: str2,
            	operator: operator,
				region: region,
                pagenumb:pagenumb,
                s: s,
                e: e
            }),
            success: function (response) {
                //alert(response);
                jQuery('#replace_query_ajax').html(response);
	                jQuery(".content").mCustomScrollbar();
			    /*jQuery("#cruise_ship_departure_date").datepicker({ 
			      minDate: dateToday ,
			      dateFormat: 'yy-mm-dd'
			    });*/
			    if(s=="0" && e=="10000"){
			    }
			    else if(e=="1000"){
					jQuery('#1_radio').prop('checked',true);
			    }
			    else if(e=="1500"){
					jQuery('#2_radio').prop('checked',true);
			    }
			    else if(e=="2000"){
					jQuery('#3_radio').prop('checked',true);
			    }
			    else if(e=="3000"){
					jQuery('#4_radio').prop('checked',true);
			    }
			    else if(e=="4000"){
					jQuery('#5_radio').prop('checked',true);
			    }
			    else if(e=="5000"){
					jQuery('#6_radio').prop('checked',true);
			    }
			    else if(s!="0" && e=="10000"){
					jQuery('#7_radio').prop('checked',true);
			    }
            	jQuery('.loader').css('display','none');
			    
            }
        });
}

		jQuery(document).ready(function(){

			var check = jQuery(".active_tab").attr('id');		
				if(check=="1" || check=="2" || check=="3" ){
					var tab_id = check;
				}
				else{
					var tab_id = jQuery(".active_tab").attr('id');
				}

			jQuery("#pagination li").click(function(){
				jQuery('.loader').css('display','block');
				var pageNum = this.id;
				var region = jQuery('#cruise_region').val();
				var operator = jQuery('#cruise_operator').val();
				var newoperator = "<?php echo $Ope_ID; ?>";
				if (operator == null && newoperator != "" ) 
				{
					operator = newoperator;
				}
				
				var cruise_ship = jQuery('#cruise_ship').val();
				var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
				var leaving_from = jQuery('#cruise_leaving_from').val();
				var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
				var ship_vacation_days = jQuery('#cruise_ship_vacation_days').val();
				var s = jQuery('#amount1').val();
				var e = jQuery('#amount2').val();


				    jQuery.ajax({
			            type: "POST",
			            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
			            data: ({
			                action: 'cruise_filter_response',
				            <?php if($_COOKIE['str1']!=""){ ?>str1: <?php echo "'".$_COOKIE['str1']."',"; } ?>
				            <?php if($_COOKIE['str2']!=""){ ?>str2: <?php echo "'".$_COOKIE['str2']."',"; } ?>
				            region: region,
				            tab_id : tab_id,
				            operator: operator,
				            cruise_ship: cruise_ship,
				            ship_fly_in: ship_fly_in,
				            leaving_from: leaving_from,
				            ship_starts_on: ship_starts_on,
				            ship_vacation_days: ship_vacation_days,
				            s:s,
				            e:e,
			                pagenumb:pageNum
			            }),
			            success: function (response) {
			                //alert(response);
			                jQuery('#replace_query_ajax').html(response);
			                //jQuery('#filter_title').empty();
				            //var filter_title=jQuery('#filter_title_tmp').html();
				            //alert(filter_title);
				            //jQuery('#filter_title-new').html(filter_title);
	                		jQuery(".content").mCustomScrollbar();

			    if(s=="0" && e=="10000"){
			    }
			    else if(e=="1000"){
					jQuery('#1_radio').prop('checked',true);
			    }
			    else if(e=="1500"){
					jQuery('#2_radio').prop('checked',true);
			    }
			    else if(e=="2000"){
					jQuery('#3_radio').prop('checked',true);
			    }
			    else if(e=="3000"){
					jQuery('#4_radio').prop('checked',true);
			    }
			    else if(e=="4000"){
					jQuery('#5_radio').prop('checked',true);
			    }
			    else if(e=="5000"){
					jQuery('#6_radio').prop('checked',true);
			    }
			    else if(s!="0" && e=="10000"){
					jQuery('#7_radio').prop('checked',true);
			    }
			            	jQuery('.loader').css('display','none');
			            }
			        });
				
			});
		});

		jQuery(document).ready(function(){
			jQuery('.itinerary_btn').click(function(){
				//jQuery(this).parent().parent().parent().next('.cruse-information').slideToggle();
				if(jQuery(this).parent().parent().parent().next('.cruse-information').hasClass("a1")){
					jQuery(this).parent().parent().parent().next('.cruse-information').removeClass("a1");
					jQuery(this).parent().parent().parent().next('.cruse-information').slideUp();
				}
				else{
					jQuery('.cruse-information').removeClass("a1");
					jQuery('.cruse-information').slideUp();
					jQuery(this).parent().parent().parent().next('.cruse-information').slideDown();
					jQuery(this).parent().parent().parent().next('.cruse-information').addClass("a1");
				}
			});
			/*jQuery('.itinerary_btn').click(function(){
				if(jQuery(this).parent().parent().parent().hasClass("active_information")){
					jQuery(this).parent().parent().parent().slideUp();
					jQuery(this).parent().parent().parent().removeClass("active_information");
					jQuery('.active_information').slideUp();
				}
				else{
					jQuery(this).parent().addClass('active_itinerary');
					jQuery(this).parent().parent().parent().removeClass("active_information");
					jQuery(this).parent().parent().parent().next('.cruse-information').slideDown();
					jQuery(this).parent().parent().parent().slideDown();
					jQuery(this).parent().parent().parent().addClass("active_information");
					jQuery('.active_information').slideDown();
				}
			});*/
		});

		function cruise_detail_of(cruise_id){
			var check = jQuery(".active_tab").attr('id');
			if(check=="1" || check=="2" || check=="3" ){
				var tab_id = check;
			}
	        jQuery('.loader_1').css('display','block');
			var id = id;
			var ship_name = ship_name;
			var cruise_id = cruise_id;
			var region = jQuery('#cruise_region').val();
			var operator = jQuery('#cruise_operator').val();
			var cruise_ship = jQuery('#cruise_ship').val();
			var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
			var leaving_from = jQuery('#cruise_leaving_from').val();
			var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
			var ship_vacation_days = jQuery('#cruise_ship_vacation_days').val();
			jQuery.ajax({
	            type: "POST",
	            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
	            data: ({
	                action: 'cruise_detail',
		            region: region,
		            tab_id : tab_id,
		            operator: operator,
		            cruise_ship: cruise_ship,
		            ship_fly_in: ship_fly_in,
		            leaving_from: leaving_from,
		            ship_starts_on: ship_starts_on,
		            ship_vacation_days: ship_vacation_days,
		            id: id,
		            ship_name: ship_name,
		            cruise_id: cruise_id
	            }),
	            success: function (response) {
	                //alert(response);
	            	jQuery('.scroll_empty').empty();
	                jQuery('.scroll'+cruise_id).html(response);
	                jQuery(".content").mCustomScrollbar();
	            	jQuery('.loader_1').css('display','none');
	            }
	        });
		}


</script>
	</div>
</div>
	<?php
	exit();
}
function cruise_detail(){
global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
$mainsiteprefix='cm_';
$agentsiteurl=get_option('siteurl');
$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
$agentsiteid=$agentsitedetail->id;
$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
$agent_assign_operator;

$cruise_id = $_POST['cruise_id'];

$select_port_query ="";
$select_port_query .= "SELECT port_code,port_name,arrives_on,location FROM cruise_port WHERE cruise_id = '";
$select_port_query .= $cruise_id;
$select_port_query .= "' ORDER BY id";
//echo $select_cruise_query;
$select_port = $mydb->get_results($select_port_query);
//echo count($select_ship);

if(count($select_port) == 0)
{
	echo "<span>No Port Details Found</span><br><br>";
}
else
{
	?>
	<div class="scroll">
		 <!-- mCustomScrollbar  style="max-height:200px;text-align: left;" - add this for slider -->
		<div class="clearfix content" id="content-<?php echo $cruise_id; ?>">
			<div class="c-row">
				<div class="c-1">Destination</div>
				<div class="c-2">Arrival</div>
				<div class="c-3">Location</div>
			</div>
			<?php
			for($i1=0;$i1<count($select_port);$i1++)
			{
				//echo "<pre>";
				//print_r($select_port);
				//echo "</pre>";
			?>
			<div class="info-row">
				<div class=" c-1 f-detail"><?php echo $select_port[$i1]->port_name; ?>
				<?php
				$port_code = $select_port[$i1]->port_code;
				$i1 = $i1;
				$cruise_id = $cruise_id;
				
				$port_b_q = "SELECT port_description FROM port_extra_information WHERE port_code = '".$port_code."'";
				$port_b_r = $mydb->get_row($port_b_q);
				if(!empty($port_b_r)){
				?>
				 <i onclick="port_breif(this,'<?php echo $port_code; ?>','<?php echo $cruise_id."_".$i1; ?>');" class="fa fa-info additional_info_c"></i>
				<?php } ?>
				 </div>
				<div class=" c-2 f-detail"><?php $port_arrival=$select_port[$i1]->arrives_on; echo date('d M Y',strtotime($port_arrival)); ?></div>
				<div class=" c-3 f-detail"><?php echo $select_port[$i1]->location; ?></div>
			</div>
			<div class="info-row-details" id="<?php echo $cruise_id."_".$i1; ?>"></div>
			<?php
				$loc = $select_port[$i1]->port_name;
				$loc_ary = "'".$loc."',".$loc_ary;
			}
			?>
		</div>
			<div id="map" class="map_list"></div>
	</div>
 
	<script type="text/javascript">
	var marker;
	var delay = 100;
	var infowindow = new google.maps.InfoWindow();
	var latlng = new google.maps.LatLng(21.0000, 78.0000);
	var mapOptions = {
scrollwheel: false,
navigationControl: true,
mapTypeControl: true,
scaleControl: false,
draggable: false,
	zoom: 20,
	center: latlng,
	mapTypeId: google.maps.MapTypeId.ROADMAP
	}
	var geocoder = new google.maps.Geocoder(); 
	var map = new google.maps.Map(document.getElementById("map"), mapOptions);
	var bounds = new google.maps.LatLngBounds();

	function geocodeAddress(address, next) {
	geocoder.geocode({address:address}, function (results,status)
	  { 
	     if (status == google.maps.GeocoderStatus.OK) {
	      var p = results[0].geometry.location;
	      var lat=p.lat();
	      var lng=p.lng();
	      createMarker(address,lat,lng);
	    }
	    else {
	       if (status == google.maps.GeocoderStatus.OVER_QUERY_LIMIT) {
	        nextAddress--;
	        delay++;
	      } else {
	                    }   
	    }
	    next();
	  }
	);
	}
	function createMarker(add,lat,lng) {
	var contentString = add;
	marker = new google.maps.Marker({
	 position: new google.maps.LatLng(lat,lng),
	 map: map,
	       });

	google.maps.event.addListener(marker, 'click', function() {
	 infowindow.setContent(contentString); 
	 infowindow.open(map,marker);
	});

	bounds.extend(marker.position);

	}
	var locations = [<?php echo $loc_ary; ?>];
	var nextAddress = 0;
	function theNext() {
	if (nextAddress < locations.length) {
	  setTimeout('geocodeAddress("'+locations[nextAddress]+'",theNext)', delay);
	  nextAddress++;
	} else {
	  map.fitBounds(bounds);
	}
	}
	theNext();
	/*google.maps.event.addListener(map,'center_changed',function() {
	  window.setTimeout(function() {
	    map.panTo(marker.getPosition());
	  },3000);
	});*/
	google.maps.event.addListener(map,'click',function() {
		this.setOptions({scrollwheel:false});
		this.setOptions({draggable:true});
		this.setOptions({scaleControl:true});
	});
	</script>

	<?php
}

exit();
}


/* ----------- MK Detail with get --------- */

function iflair_detail_search_filter_response(){
	global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
	$mainsiteprefix='cm_';
	$agentsiteurl=get_option('siteurl');
	$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
	$agentsiteid=$agentsitedetail->id;
	$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
	$agent_assign_operator;

	/*echo "<pre>";
	print_r($_POST);
	echo "</pre>";*/
	if($_POST['region']=="all" ){ $region = ""; }else{ $region = $_POST['region']; }
	if($_POST['operator']=="all" ){ $operator = ""; }else{ $operator = $_POST['operator']; }
	if($_POST['cruise_ship']=="all" ){ $cruise_ship = ""; }else{ $cruise_ship = $_POST['cruise_ship']; }
	if($_POST['ship_fly_in']=="all" ){ $ship_fly_in = ""; }else{ $ship_fly_in = $_POST['ship_fly_in']; }	
	if($_POST['leaving_from']=="all" ){ $leaving_from = ""; }else{ $leaving_from = $_POST['leaving_from']; }
	if($_POST['ship_starts_on']=="all" ){ $ship_starts_on = ""; }else{ $ship_starts_on = $_POST['ship_starts_on']; }
	if($_POST['ship_vacation_days']=="all" ){ $ship_vacation_days = ""; }else{ $ship_vacation_days = $_POST['ship_vacation_days']; }	


	if($leaving_from!=""){
		$leaving_from_cruise_id= "SELECT cruise_id FROM cruise_port WHERE port_code='$leaving_from'";
		//echo $leaving_from_cruise_id."<---";
		$select_leaving_from_cruise_id = $mydb->get_results($leaving_from_cruise_id);
			$leaving_from_cruise_id_arr = array();
		foreach ($select_leaving_from_cruise_id as $leaving_from_cruise_id_obj) {
			$leaving_from_cruise_id_arr[] = $leaving_from_cruise_id_obj->cruise_id;
		}
		//print_r($leaving_from_cruise_id_arr);
		$leaving_from_cruise_id = $leaving_from_cruise_id_arr[0];
		//print_r($id_res);
		for($i=1;$i<count($leaving_from_cruise_id_arr);$i++){
			$leaving_from_cruise_id = $leaving_from_cruise_id.",".$leaving_from_cruise_id_arr[$i];
		}
		//echo $leaving_from_cruise_id;
	}


	?>
	<script type="text/javascript">jQuery("img.lazy").lazyload({skip_invisible : true});</script>
	<div class="form-field form-field-cruise">
				
		<div class="btn-group i-1 h-1" role="group">
		    <select name="cruise_region" id="cruise_region" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_detail_search_filter('region');" >
				<option value="" >Where</option>
				<?php
				
					$tab_condition = $_POST['tab_id'];
					$cruise_region == "";
					$cruise_region .= "SELECT csc.ship_region , csc.ship_cruise_type , csc.cruise_id FROM `cruise_ship_cruise` as csc WHERE 1=1 ";
					if($tab_condition == 1){
						$cruise_region .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
					}
					elseif($tab_condition == 2){
						$cruise_region .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
					}
					else{
						$cruise_region .= "";
					}
					$cruise_region .= " GROUP BY csc.ship_region ORDER BY FIND_IN_SET('River', csc.ship_cruise_type),csc.ship_region";
					echo $cruise_region;
					$select_cruise_region_res = $mydb->get_results($cruise_region);


				foreach ($select_cruise_region_res as $cruise_region_prepared_obj) :
					$HiddenRiver = explode(',',$cruise_region_prepared_obj->ship_cruise_type);
				?>
					<option value="<?php echo $cruise_region_prepared_obj->ship_region; ?>" <?php if($region == $cruise_region_prepared_obj->ship_region ){ echo "selected"; } ?> ><?php echo $cruise_region_prepared_obj->ship_region; ?><?php if(in_array('River', $HiddenRiver)){ echo " ( River )"; } ?></option>
				<?php
				endforeach;
				?>
		</select>
	  	</div>

		<div class="btn-group i-2 h-2" role="group">
			<?php
				$cruise_operator_title= "SELECT csc.ship_operator_id,csc.ship_operator_app_id FROM cruise_ship_cruise AS csc WHERE 1=1";
			
				if($region != ""){
					$cruise_operator_title .= " AND csc.ship_region = '$region'";
				}
				if($cruise_ship != ""){
					$cruise_operator_title .= " AND csc.ship_id = $cruise_ship";
				}
				if($ship_fly_in != ""){
					$cruise_operator_title .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_starts_on != ""){
					$cruise_operator_title .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
				}
				if($ship_vacation_days != ""){
					$cruise_operator_title .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
				}
				if($tab_condition == 1){
					$cruise_operator_title .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_operator_title .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_operator_title .= "";
				}
	  				$cruise_operator_title .= " GROUP BY csc.ship_operator_app_id ORDER BY csc.ship_operator_app_id";
	  			
				$select_cruise_operator_title = $mydb->get_results($cruise_operator_title);
				$c2 = count($select_cruise_operator_title);
				$qq="0 value";
			?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c2==0){echo 'disabled="true" ';}?> name="cruise_operator" id="cruise_operator" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_detail_search_filter('operator');" >
				<option value="" >Cruiseline</option>
				<option value="all" <?php if($_POST['operator']=="all"){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_operator_title as $cruise_operator_title_obj) :
					?>
					<option value="<?php echo $cruise_operator_title_obj->ship_operator_id; ?>" <?php if($operator == $cruise_operator_title_obj->ship_operator_id ){ echo "selected"; } ?> ><?php echo ucfirst(str_replace("-"," ",$cruise_operator_title_obj->ship_operator_app_id)); ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>

	  	<div class="btn-group i-3 h-3" role="group">
	  		<?php
	  			$cruise_cruise_ship="";
	  			$cruise_cruise_ship .= "SELECT csc.ship_id,cc.cruise_title FROM cruise_cruise AS cc INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1";
				if($region != ""){
					$cruise_cruise_ship .= " AND csc.ship_region = '$region'";
				}
				if($operator != ""){
					$cruise_cruise_ship .= " AND csc.ship_operator_id = $operator";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_fly_in != ""){
					$cruise_cruise_ship .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($ship_starts_on != ""){
					$cruise_cruise_ship .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
				}
				if($ship_vacation_days != ""){
					$cruise_cruise_ship .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
				}
				if($tab_condition == 1){
					$cruise_cruise_ship .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_cruise_ship .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_cruise_ship .= "";
				}
	  				$cruise_cruise_ship .= " GROUP BY cc.cruise_title ORDER BY csc.ship_id";
	  			
				$select_cruise_ship = $mydb->get_results($cruise_cruise_ship);
				$c3 = count($select_cruise_ship);
				if($c3==0){$cruise_ship="";}
	  		?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c3==0){echo 'disabled="true" ';}?> name="cruise_ship" id="cruise_ship" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_detail_search_filter('cruise_ship');" >
				<option value="" >Ship</option>
				<option value="all" <?php if($_POST['cruise_ship']=="all" ){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_ship as $cruise_ship_obj) :
					?>
					<option value="<?php echo $cruise_ship_obj->ship_id; ?>" <?php if($cruise_ship == $cruise_ship_obj->ship_id ){ echo "selected"; } ?> ><?php echo $cruise_ship_obj->cruise_title; ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>

	  	<div class="btn-group i-4 h-4" role="group">
	  		<?php
	  			$cruise_ship_fly_in= "SELECT csc.ship_fly_in FROM cruise_cruise AS cc INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1";
				if($region != ""){
					$cruise_ship_fly_in .= " AND csc.ship_region = '$region'";
				}
				if($operator != ""){
					$cruise_ship_fly_in .= " AND csc.ship_operator_id = $operator";
				}
				if($cruise_ship != ""){
					$cruise_ship_fly_in .= " AND csc.ship_id = $cruise_ship";
				}
				if($ship_starts_on != ""){
					$cruise_ship_fly_in .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
				}
				if($ship_vacation_days != ""){
					$cruise_ship_fly_in .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
				}
				if($tab_condition == 1){
					$cruise_ship_fly_in .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_ship_fly_in .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_ship_fly_in .= "";
				}
	  				$cruise_ship_fly_in .= " GROUP BY csc.ship_fly_in ORDER BY csc.ship_fly_in";
	  			
				$select_cruise_ship_fly_in = $mydb->get_results($cruise_ship_fly_in);
				$c4 = count($select_cruise_ship_fly_in);
	  		?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c4==0){echo 'disabled="true" ';}?> name="cruise_ship_fly_in" id="cruise_ship_fly_in" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_detail_search_filter('ship_fly_in');" >
				<option value="" >Leave</option>
				<option value="all" <?php if($_POST['leaving_from'] == "all" ){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_ship_fly_in as $cruise_ship_fly_in_obj) :
					?>
					<option value="<?php echo $cruise_ship_fly_in_obj->ship_fly_in; ?>" <?php if($ship_fly_in == $cruise_ship_fly_in_obj->ship_fly_in ){ echo "selected"; } ?> ><?php echo $cruise_ship_fly_in_obj->ship_fly_in; ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>
	  	
	  	<div class="btn-group i-2 h-5" role="group">
	  		<?php
				$cruise_when= "SELECT csc.ship_starts_on FROM cruise_cruise AS cc INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1";
				$todays_date = date('Y-m-d H:i:s');
				$cruise_when .= " AND csc.ship_starts_on >= '$todays_date'";
				if($region != ""){
					$cruise_when .= " AND csc.ship_region = '$region'";
				}
				if($operator != ""){
					$cruise_when .= " AND csc.ship_operator_id = $operator";
				}
				if($cruise_ship != ""){
					$cruise_when .= " AND csc.ship_id = $cruise_ship";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_fly_in != ""){
					$cruise_when .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($ship_vacation_days != ""){
					$cruise_when .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
				}
				if($tab_condition == 1){
					$cruise_when .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_when .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_when .= "";
				}
	  				$cruise_when .= " GROUP BY YEAR(csc.ship_starts_on),MONTH(csc.ship_starts_on) ORDER BY csc.ship_starts_on";
	  			
				$select_cruise_when = $mydb->get_results($cruise_when);
				$c5 = count($select_cruise_when);
	  		?>
		    <?php /*
	  		<input type="text" placeholder="When" value="<?php echo $ship_starts_on; ?>" name="cruise_ship_starts_on" id="cruise_ship_starts_on" >
			*/ ?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c5==0){echo 'disabled="true" ';}?> name="cruise_ship_starts_on" id="cruise_ship_starts_on" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_detail_search_filter('ship_starts_on');" >
				<option value="" >When</option>
				<option value="all" <?php if($_POST['ship_starts_on']=="all" ){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_when as $cruise_when_obj) :
					?>
					<option value="<?php echo date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ; ?>" <?php if($ship_starts_on == date('Y-m',strtotime($cruise_when_obj->ship_starts_on)) ){ echo "selected"; } ?> ><?php $ship_date=$cruise_when_obj->ship_starts_on; echo date('F Y',strtotime($ship_date)); ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>

	  	<div class="btn-group i-3 h-6" role="group">
	  		<?php
				$cruise_days= "SELECT csc.ship_vacation_days FROM cruise_cruise AS cc INNER JOIN cruise_ship_cruise AS csc ON cc.cruise_response_id = csc.ship_id WHERE 1=1";
				if($region != ""){
					$cruise_days .= " AND csc.ship_region = '$region'";
				}
				if($operator != ""){
					$cruise_days .= " AND csc.ship_operator_id = $operator";
				}
				if($cruise_ship != ""){
					$cruise_days .= " AND csc.ship_id = $cruise_ship";
				}
				if($leaving_from != ""){
					$cruise_leaving_from .= " AND csc.cruise_id IN ($leaving_from_cruise_id)";
				}
				if($ship_fly_in != ""){
					$cruise_days .= " AND csc.ship_fly_in = '$ship_fly_in'";
				}
				if($ship_starts_on != ""){
					$cruise_days .= " AND csc.ship_starts_on LIKE '%$ship_starts_on%'";
				}
				/*if($ship_vacation_days != ""){
					$cruise_days .= " AND csc.ship_vacation_days = '$ship_vacation_days'";
				}*/
				if($tab_condition == 1){
					$cruise_days .= " AND FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				elseif($tab_condition == 2){
					$cruise_days .= " AND !FIND_IN_SET('River', csc.ship_cruise_type)";
				}
				else{
					$cruise_days .= "";
				}
	  				$cruise_days .= " GROUP BY csc.ship_vacation_days ORDER BY csc.ship_vacation_days";
	  			
				$select_cruise_days = $mydb->get_results($cruise_days);
				$c6 = count($select_cruise_days);
	  		?>
				<img class="loader_filt new_filter" src="<?php echo esc_url( get_template_directory_uri() )."/images/loader_1.gif"; ?>" style="display: none;">
		    <select <?php //if($c6==0){echo 'disabled="true" ';}?> name="cruise_ship_vacation_days" id="cruise_ship_vacation_days" class="btn btn-default dropdown-toggle text p-2 second_filter_class" onchange="iflair_detail_search_filter('ship_vacation_days');" >
				<option value="" >Days</option>
				<option value="all" <?php if($_POST['ship_vacation_days']=="all" ){ echo "selected"; } ?>>Any</option>
				<?php
				foreach ($select_cruise_days as $cruise_days_obj) :
					?>
					<option value="<?php echo $cruise_days_obj->ship_vacation_days ; ?>" <?php if($ship_vacation_days == $cruise_days_obj->ship_vacation_days ){ echo "selected"; } ?> ><?php echo $cruise_days_obj->ship_vacation_days ; ?></option>
					<?php
				endforeach;
				?>
			</select>
	  	</div>
	  	<input type="hidden" value="<?php if($_GET['tab_id']!=""){ echo $_GET['tab_id']; }elseif($_POST['tab_id']!=""){ echo $_POST['tab_id']; }else{ echo "undefined"; } ?>" name="tab_id">
		<!-- 
		<span onclick="iflair_detail_search_filter('search');" class="search-bt-2" style="text-align: center; line-height: 46px;cursor:pointer;">Search</span>
 -->
			<button class="search-bt-2" style="text-align: center; line-height: 46px;cursor:pointer;" type="submit" value="Submit" >Submit</button>

			</div>

	<?php
	exit();
}

define('MY_WORDPRESS_FOLDER',$_SERVER['DOCUMENT_ROOT']);
define('MY_THEME_FOLDER',str_replace("\\",'/',dirname(__FILE__)));
define('MY_THEME_PATH','/' . substr(MY_THEME_FOLDER,stripos(MY_THEME_FOLDER,'wp-content')));
add_action('admin_init','my_meta_init');
function my_meta_init()
{
// review the function reference for parameter details
// http://codex.wordpress.org/Function_Reference/wp_enqueue_script
// http://codex.wordpress.org/Function_Reference/wp_enqueue_style
//wp_enqueue_script('my_meta_js', MY_THEME_PATH . '/custom/meta.js', array('jquery'));
wp_enqueue_style('my_meta_css', MY_THEME_PATH . '/custom/meta.css');
// review the function reference for parameter details
// http://codex.wordpress.org/Function_Reference/add_meta_box
// add a meta box for each of the wordpress page types: posts and pages
foreach (array('post','page') as $type) 
{
add_meta_box('my_all_meta', 'Select Operator', 'my_meta_setup', $type, 'normal', 'high');
}
// add a callback function to save any data a user enters in
add_action('save_post','my_meta_save');
}
function my_meta_setup()
{
global $post;
// using an underscore, prevents the meta variable
// from showing up in the custom fields section
$meta = get_post_meta($post->ID,'_my_meta',TRUE);
// instead of writing HTML here, lets do an include
include(MY_THEME_FOLDER . '/meta.php');
// create a custom nonce for submit verification later
echo '<input type="hidden" name="my_meta_noncename" value="' . wp_create_nonce(__FILE__) . '" />';
}
function my_meta_save($post_id) 
{
// authentication checks
// make sure data came from our meta box
if (!wp_verify_nonce($_POST['my_meta_noncename'],__FILE__)) return $post_id;
// check user permissions
if ($_POST['post_type'] == 'page') 
{
if (!current_user_can('edit_page', $post_id)) return $post_id;
}
else
{
if (!current_user_can('edit_post', $post_id)) return $post_id;
}
// authentication passed, save data
// var types
// single: _my_meta[var]
// array: _my_meta[var][]
// grouped array: _my_meta[var_group][0][var_1], _my_meta[var_group][0][var_2]
$current_data = get_post_meta($post_id, '_my_meta', TRUE);  
$new_data = $_POST['_my_meta'];
my_meta_clean($new_data);
if ($current_data) 
{
if (is_null($new_data)) delete_post_meta($post_id,'_my_meta');
else update_post_meta($post_id,'_my_meta',$new_data);
}
elseif (!is_null($new_data))
{
add_post_meta($post_id,'_my_meta',$new_data,TRUE);
}
return $post_id;
}
function my_meta_clean(&$arr)
{
if (is_array($arr))
{
foreach ($arr as $i => $v)
{
if (is_array($arr[$i])) 
{
my_meta_clean($arr[$i]);
if (!count($arr[$i])) 
{
unset($arr[$i]);
}
}
else
{
if (trim($arr[$i]) == '') 
{
unset($arr[$i]);
}
}
}
if (!count($arr)) 
{
$arr = NULL;
}
}
}

/* Operator detailpage ajax for accommodation & all tab... */
add_action('wp_ajax_operator_detail_feature_tab', 'operator_detail_feature_tab'); // Logged-in users
add_action('wp_ajax_nopriv_operator_detail_feature_tab', 'operator_detail_feature_tab'); // Guest users

function operator_detail_feature_tab(){
global $wpdb,$mydb;
if($_POST['tab_name']=="enrichment_types"){
	$tab_name = "crusie_".$_POST['tab_name'];
}
else{
	$tab_name = "cruise_".$_POST['tab_name'];
}
if($_POST['tab_name']=="deckplans"){
	$img_prefix = "http://ekups3e.cloudimg.io/s/resize/1200/";
}
else{
	$img_prefix = "http://ekups3e.cloudimg.io/s/resize/750/";
}
$response_id = $_POST['response_id'];
$query_all = "SELECT name,image_name,image_href,description,stats FROM ".$tab_name." WHERE ship_response_id=".$response_id." GROUP BY index_val ";
$query_result = $mydb->get_results($query_all);
$count_val = count($query_result);
	if($count_val!=0){
		for($rc=0;$rc<$count_val;$rc++){
		?>
		<div class="acoodetail" id="<?php echo str_replace(" ","_",$query_result[$rc]->name); ?>">
				<?php
				if($query_result[$rc]->image_name!=""){
					?>
					<div class="accodetail">
						<img title="<?php echo $query_result[$rc]->name; ?>" src="<?php echo $img_prefix.''.str_replace("//www","http://www",$query_result[$rc]->image_href); ?>" alt="<?php echo $query_result[$rc]->image_name; ?>" class="img-responsive">
					</div>
					<div class="accdescrptipon">
					<?php
				}
				else{
					?>
					<div class="accdescrptipon" style="width: 100%;">
					<?php
				}
				?>
				<h2><?php echo $query_result[$rc]->name; ?></h2>
				<?php echo html_entity_decode($query_result[$rc]->description); ?>
				<?php if($query_result[$rc]->stats!=""){ echo "<b>Stats</b>"; } ?>
				<?php echo html_entity_decode($query_result[$rc]->stats); ?> 
			</div>
		</div>
		<?php
		}
	}
	else{
		//echo "No details Found...";
	}
	exit();
}
function price_filter_result(){
global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;


$query_price_all = explode(" AND ( (csc.ship_cruise_only_pri" , $_POST['query']);
//echo "<pre>";
//print_r($query_price_all);
//echo "</pre>";
$query_price = $query_price_all[0];
	$pagenum=$_POST['pagenumb'];
	if($_POST['pagenumb']==""){
		$per_page = 10;
		$page='1';
		$start='0';
	}
	else {
		$per_page = 10;
		$page=$_POST['pagenumb'];	
		$start=($page-1)*$per_page;
	}


$start_price = $_POST['s'];	
$end_price = $_POST['e'];	
//if($start_price != "" && $end_price != "")
if($start_price == 0 && $end_price != ""){
	if($start_price == 0 && $end_price == 10000){
		$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price  >= 0";
		$price_history = "";
	}
	elseif($start_price == 0 && $end_price == 1000){
		//$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price < ".$end_price."";
		$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price  > 0 AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price < ".$end_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price < ".$end_price.") )";
		$price_history = "in price Below £".number_format($end_price)."";
	}
	else{
		//$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price < ".$end_price."";
		$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price  >= 0 AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price < ".$end_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price < ".$end_price.") )";
		$price_history = "in price Below £".number_format($end_price)."";
	}
}
else if($start_price != "" && $end_price == 10000){

	if($start_price == 5000 && $end_price == 10000){
		//$select_ship_query = ." AND csc.ship_cruise_only_price >= ".$start_price."";
		$price_q_query_unlimit .= str_replace("\\",'',$query_price)." AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price > ".$start_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price  > ".$start_price.") OR ( csc.ship_cruise_only_price = 0 AND csc.ship_fly_cruise_price = 0 ) )";
		$price_history = "in price Bigger than £".number_format($start_price)."";
	}
	else{
		//$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price > ".$start_price."";
		$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price > ".$start_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price  > ".$start_price.") )";
		$price_history = "in price Bigger than £".number_format($start_price)."";
	}
}
elseif($start_price == "" && $end_price == ""){
	$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price  >= 0";
	$price_history = "";
}
else{
	//$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND csc.ship_cruise_only_price BETWEEN ".$start_price." AND ".$end_price."";
	$price_q_query_unlimit = str_replace("\\",'',$query_price)." AND ( (csc.ship_cruise_only_price <= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price BETWEEN ".$start_price." AND ".$end_price.")  OR (csc.ship_cruise_only_price >= csc.ship_fly_cruise_price AND csc.ship_cruise_only_price BETWEEN ".$start_price." AND ".$end_price.") )";
	$price_history = "in price range of £".number_format($start_price)." to £".number_format($end_price)."";
}

	if( $start_price == "0" &&  $end_price == "10000" ){
		$price_q_query_limit.= $price_q_query_unlimit." ORDER BY csc.ship_starts_on LIMIT $start,$per_page";
	}
	else{
		if($end_price == 10000){
			$price_q_query_limit = $price_q_query_unlimit." ORDER BY IF( (csc.ship_cruise_only_price AND csc.ship_fly_cruise_price) = 0, 1, 0) LIMIT $start,$per_page";
		}
		else{
			$price_q_query_limit = $price_q_query_unlimit." ORDER BY csc.ship_cruise_only_price ASC LIMIT $start,$per_page";
		}
	}
	$price_q = $mydb->get_results($price_q_query_limit);
	/*echo "<pre>";
	echo $price_q_query_limit;
	//print_r($price_q);
	echo "</pre>";*/


echo "<pre id='history1' style='display:none;'>";
//print_r($_POST);
$history_str = "";
	//if($_POST['operator']!="" || $_POST['region']!="" || $_POST['cruise_ship']!="" || $_POST['ship_fly_in']!="" || $_POST['ship_starts_on']!="" || $_POST['ship_vacation_days']!="" ){
		//$history_str .= "Search ";
		$history_str .= "Results Showing ".count($mydb->get_results($price_q_query_unlimit))." ";
	//}

	if($_POST['region']=="all" || $_POST['region']==""){ 
		$history_str .= "cruises to Anywhere "; 
	}elseif($_POST['region']!=""){ 
		$history_str .= "cruises to ".$_POST['region']." "; 
	}

	if($_POST['operator']=="all" || $_POST['operator']==""){ 
		$history_str .= "with All Cruiselines "; 
	}elseif($_POST['operator']!=""){
		$val_op = $mydb->get_row("SELECT operator_title FROM cruise_operators WHERE operator_id = ".$_POST['operator']."");
		$history_str .= "with ".$val_op->operator_title." "; 
	}

	if($_POST['cruise_ship']=="all" || $_POST['cruise_ship']==""){ 
		$history_str .= "on Any Ship "; 
	}elseif($_POST['cruise_ship']!=""){
		$val_ship = $mydb->get_row("SELECT cruise_title FROM cruise_cruise WHERE cruise_response_id = ".$_POST['cruise_ship']."");
		$history_str .= "on ".$val_ship->cruise_title." "; 
	}

	if($_POST['ship_fly_in']=="all" || $_POST['ship_fly_in']==""){ 
		$history_str .= "leaving from Any Port "; 
	}elseif($_POST['ship_fly_in']!=""){ 
		$history_str .= "leaving from ".$_POST['ship_fly_in']." "; 
	}

	if($_POST['ship_starts_on']=="all" || $_POST['ship_starts_on']==""){ 
		$history_str .= "in All Months "; 
	}elseif($_POST['ship_starts_on']!=""){ 
		$history_str .= "in ".date('F Y',strtotime($_POST['ship_starts_on']))." "; 
	}

	if($_POST['ship_vacation_days']=="all" || $_POST['ship_vacation_days']==""){ 
		$history_str .= "for all Days"; 
	}elseif($_POST['ship_vacation_days']!=""){ 
		$history_str .= "for ".$_POST['ship_vacation_days']." Days"; 
	}

echo $history_str."".$price_history.".";
echo "</pre>";


		/*echo "<pre>";
		echo $price_q_query_limit;
		echo "</pre>";*/
	if(count($price_q) == 0)
	{
		echo "<div class='no_result_area'>No Cruise Found ..<div>";
	}
	else
	{
		//echo $page;
		//echo $per_page;
		cruise_pagging($page,$per_page,$price_q_query_unlimit);

		for($i=0;$i<count($price_q);$i++)
		{
		?>

<div class="mediter-box clearfix">
	<div class="medi-left">
		<div class="newtableimg">
			<div class="netablecellimg">
				<img src="<?php if($price_q[$i]->cruise_cover_image_href!=""){ echo "http://ekups3e.cloudimg.io/s/crop/300x200/".str_replace("//www","http://www",$price_q[$i]->cruise_cover_image_href); }else{ echo esc_url( get_template_directory_uri() )."/images/noImageAvailable.png"; } ?>" class="img-responsive">
			</div>
		</div>
	</div>
	<div class="medi-mid mid-mid-two">
		<h3><?php echo $price_q[$i]->ship_name; ?></h3>
		<p class="date_new_site"><?php $ship_date=$price_q[$i]->ship_starts_on; echo date('d M Y',strtotime($ship_date)); ?></p>
		<p class="day_new_site daytotal"><?php echo $price_q[$i]->ship_vacation_days; ?> vacation nights</p>
		<p class="ship_new_site"><div class="tool"></div> <div class="shiptitle">Ship</div><span class="toolname">: <?php echo $price_q[$i]->cruise_title; ?></span></p>
		<p class="itinerary_new_site">
		<span class="itecolor">itinerary : </span>

		<?php
		$select_itinerary_query ="";
		$select_itinerary_query .= "SELECT port_name FROM cruise_port WHERE cruise_id = '";
		$select_itinerary_query .= $price_q[$i]->a;
		$select_itinerary_query .= "' GROUP BY port_name ORDER BY id";
		//echo $select_cruise_query;
		$select_itinerary = $mydb->get_results($select_itinerary_query);
		$itinerary_count = count($select_itinerary);
		if($itinerary_count!="0"){
			echo $select_itinerary[0]->port_name;
			for($i1=1;$i1<count($select_itinerary);$i1++)
			{
				//echo "<pre>";
				//print_r($select_port);
				//echo "</pre>";
				?> <i class="fa fa-caret-right"></i>
				<?php echo $select_itinerary[$i1]->port_name;
				?>
			<?php
			}
		}
		?>
		</p>
	</div>
		<?php
			$offer_query = "SELECT offer_price FROM ".$wpdb->prefix."quote_extra_offer WHERE offer_start_date < curdate() and offer_end_date > curdate() AND cruise_id = '".$price_q[$i]->cruise_id."'";
			$found_offer = $wpdb->get_row($offer_query);
			/*echo "<pre>";
			print_r($found_offer);
			echo "</pre>";*/
			if(!empty($found_offer)){
				$offer_class = '<div class="offer_class"></div>';
				$offer_class2 = " offer_class2";
				//echo '<div class="'.$offer_class.'"><img src="'.esc_url( get_template_directory_uri() ).'/images/superdeal.png" ></div>';
			}
			else{
				$offer_class = "";
				$offer_class2 = "";
			}
		?>
	<div class="medi-right">
		<?php echo $offer_class; ?>
		<div class="main_added_text">
		<?php 
		$price1 = $price_q[$i]->ship_cruise_only_price;
		$price2 = $price_q[$i]->ship_fly_cruise_price;

		if(!empty($found_offer)){
			?>
			<!-- <h2>Guide Price Range</h2> -->
			<p class="text1">From </p><p class="textbld">£<?php echo number_format($found_offer->offer_price); ?><span class="text2">pp</span></p>
			<?php
		}
		elseif($price1=="0" && $price2=="0")
		{
			?>
			<!-- <h2>Guide Price Range</h2> -->
			<p class="text1">Please enquire for today’s price</p>
			<?php
		}
		elseif( ( $price1!="0" && $price1 < $price2 ) || $price2== "0" )
		{
			?>
			<!-- <h2>Guide Price Range</h2> -->
			<p class="text1">From </p><p class="textbld">£<?php echo number_format($price1); ?><span class="text2">pp</span></p>
			<?php
		}
		elseif( ( $price2!="0" && $price1 > $price2 ) || $price1== "0" )
		{
			?>
			<!-- <h2>Guide Price Range</h2> -->
			<p class="text1">From <p class="textbld">£<?php echo number_format($price2); ?><span class="text2">pp</span></p>
			<?php
		}
		elseif( ( $price1!="0" && $price2!="0" ) && $price1==$price2 )
		{
			?>
			<!-- <h2>Guide Price Range</h2> -->
			<p class="text1">From </p><p class="textbld">£<?php echo number_format($price1); ?><span class="text2">pp</span></p>
			<?php
		}
		else{
			?>
			<!-- <h2>Guide Price Range</h2> -->
			<p class="text1">Please enquire for today’s price</p>
			<?php
		}
		echo '<div class="'.$offer_class2.'"></div>';
		?>
		</div>
		<?php $detail_page_id = get_site_option( 'iflair_cruise_theme_ship_detail_page' );?>
		<div class="added_img">
			<a target="_blank" href="<?php echo get_page_link($detail_page_id);?>?cruise_id=<?php echo $price_q[$i]->a; ?>" class="info-bt new_btn_blue new_detail_btn">DETAILS <i class="fa fa-angle-right"></i></a>
					<!-- <script>jQuery("img.lazy").lazyload();</script> -->
			<a onclick="cruise_detail_of('<?php echo $price_q[$i]->cruise_id; ?>');" class="new_btn_blue itinerary_btn">Itinerary <i class="fa fa-caret-down"></i></a>
		</div>
	</div>
</div>
<div class="cruse-information clearfix">
	<div class="above_map_area"><h2 class="above_map_title">Cruise Itinerary</h2>
	<a target="_blank" href="<?php echo get_page_link($detail_page_id);?>?cruise_id=<?php echo $price_q[$i]->a; ?>" class="info-bt new_btn_blue above_map">MORE DETAILS / ENQUIRE <i class="fa fa-caret-down"></i></a></div>
	<div class="scroll<?php echo $price_q[$i]->cruise_id; ?> scroll_empty">
		<div class="loader_1" style="display:none;text-align: center; padding: 0px 0px 30px;">
			<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/loader_1.gif">
		</div>
	</div>

	<?php
	/*echo "<pre>";
	print_r($select_ship[$i]);
	echo "</pre>";*/
	?>
	<div class="clearfix right">
		<?php /*<a href="<?php echo get_page_link($detail_page_id);?>?ship_id=<?php echo $select_ship[$i]->b; ?>" class="info-bt new_btn_blue">VIEW MORE INFORMATION</a> */?>
	</div>
</div>

		<?php
		}
	}
	?>
<script type="text/javascript">
	
		jQuery(document).ready(function(){
			jQuery("#pagination li").click(function(){
				jQuery('.loader').css('display','block');
				var pageNum = this.id;
				var query = "<?php echo $query_price; ?>";
				var s = "<?php echo $start_price; ?>";
				var e = "<?php echo $end_price; ?>";
				    jQuery.ajax({
			            type: "POST",
			            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
			            data: ({
			                action: 'price_filter_result',
				            <?php if($_COOKIE['str1']!=""){ ?>str1: <?php echo "'".$_COOKIE['str1']."',"; } ?>
				            <?php if($_COOKIE['str2']!=""){ ?>str2: <?php echo "'".$_COOKIE['str2']."',"; } ?>
				            query: query,
				            s:s,
				            e:e,
			                pagenumb:pageNum
			            }),
			            success: function (response) {

			                //alert(response);
			                jQuery('.result-part').html(response);
			                //jQuery('#filter_title').empty();
				            //var filter_title=jQuery('#filter_title_tmp').html();
				            //alert(filter_title);
				            //jQuery('#filter_title-new').html(filter_title);
	                		jQuery(".content").mCustomScrollbar();
			            	jQuery('.loader').css('display','none');
			            }
			        });
				
			});
		});

		jQuery(document).ready(function(){
			jQuery('.itinerary_btn').click(function(){
				//jQuery(this).parent().parent().parent().next('.cruse-information').slideToggle();
				if(jQuery(this).parent().parent().parent().next('.cruse-information').hasClass("a1")){
					jQuery(this).parent().parent().parent().next('.cruse-information').removeClass("a1");
					jQuery(this).parent().parent().parent().next('.cruse-information').slideUp();
				}
				else{
					jQuery('.cruse-information').removeClass("a1");
					jQuery('.cruse-information').slideUp();
					jQuery(this).parent().parent().parent().next('.cruse-information').slideDown();
					jQuery(this).parent().parent().parent().next('.cruse-information').addClass("a1");
				}
			});
			/*jQuery('.itinerary_btn').click(function(){
				if(jQuery(this).parent().parent().parent().hasClass("active_information")){
					jQuery(this).parent().parent().parent().slideUp();
					jQuery(this).parent().parent().parent().removeClass("active_information");
					jQuery('.active_information').slideUp();
				}
				else{
					jQuery(this).parent().addClass('active_itinerary');
					jQuery(this).parent().parent().parent().removeClass("active_information");
					jQuery(this).parent().parent().parent().next('.cruse-information').slideDown();
					jQuery(this).parent().parent().parent().slideDown();
					jQuery(this).parent().parent().parent().addClass("active_information");
					jQuery('.active_information').slideDown();
				}
			});*/
		});

		function cruise_detail_of(cruise_id){
	        jQuery('.loader_1').css('display','block');
			var id = id;
			var ship_name = ship_name;
			var cruise_id = cruise_id;
			var region = jQuery('#cruise_region').val();
			var operator = jQuery('#cruise_operator').val();
			var cruise_ship = jQuery('#cruise_ship').val();
			var ship_fly_in = jQuery('#cruise_ship_fly_in').val();
			var leaving_from = jQuery('#cruise_leaving_from').val();
			var ship_starts_on = jQuery('#cruise_ship_starts_on').val();
			var ship_vacation_days = jQuery('#cruise_ship_vacation_days').val();
			jQuery.ajax({
	            type: "POST",
	            url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
	            data: ({
	                action: 'cruise_detail',
		            region: region,
		            operator: operator,
		            cruise_ship: cruise_ship,
		            ship_fly_in: ship_fly_in,
		            leaving_from: leaving_from,
		            ship_starts_on: ship_starts_on,
		            ship_vacation_days: ship_vacation_days,
		            id: id,
		            ship_name: ship_name,
		            cruise_id: cruise_id
	            }),
	            success: function (response) {
	                //alert(response);
	            	//jQuery('.scroll_empty').empty();
	                jQuery('.scroll'+cruise_id).html(response);
	                jQuery(".content").mCustomScrollbar();
	            	jQuery('.loader_1').css('display','none');
	            }
	        });
		}


</script>
	<?php
	exit();
}


/* Operator detailpage ajax for accommodation & all tab... */
add_action('wp_ajax_port_breif_res', 'port_breif_res'); // Logged-in users
add_action('wp_ajax_nopriv_port_breif_res', 'port_breif_res'); // Guest users
function truncateStringWords($str, $maxlen)
{
    if (strlen($str) <= $maxlen) return $str;

    $newstr = substr($str, 0, $maxlen);
    if (substr($newstr, -1, 1) != ' ') $newstr = substr($newstr, 0, strrpos($newstr, " "));

    return $newstr;
}
function port_breif_res(){
global $mydb;
$port_code = $_POST['port_code'];
$port_b_q = "SELECT port_description,port_name,port_tovisit FROM port_extra_information WHERE port_code = '".$port_code."'";
$port_b_r = $mydb->get_row($port_b_q);
echo "<div class='port_breif_details'>";
if($port_b_r->port_tovisit!=""){echo "<span> <b>Highlights - </b>".$port_b_r->port_tovisit."</span><br>"; }
echo "<p> About ".$port_b_r->port_name."</p>";
echo "<span class='less_c_".$port_code."'>".truncateStringWords(strip_tags($port_b_r->port_description), 300)." <a>more >></a></span>";
echo "<span class='more_c_".$port_code."'>".strip_tags($port_b_r->port_description,'<p>')." <a><< less</a></span>";
echo "</div>";
?>
<script type="text/javascript">
jQuery(".more_c_<?php echo $port_code;?>").hide();
jQuery(".less_c_<?php echo $port_code;?> a").click(function(){
	jQuery(".more_c_<?php echo $port_code;?>").slideDown();
	jQuery(".less_c_<?php echo $port_code;?>").hide();
});
jQuery(".more_c_<?php echo $port_code;?> a").click(function(){
	jQuery(".less_c_<?php echo $port_code;?>").slideDown();
	jQuery(".more_c_<?php echo $port_code;?>").hide();
});
</script>
<?php
exit();
}
function operator_cruises( $operator_title ) {

	global $wpdb,$mydb,$agentsiteid,$mainsiteprefix,$agent_assign_operator;
	$mainsiteprefix='cm_';
	$agentsiteurl=get_option('siteurl');
	$agentsitedetail=iflair_get_subsite_id($agentsiteurl);
	$agentsiteid=$agentsitedetail->id;
	$agent_assign_operator=iflair_get_tour_operator_assign($agentsiteid);
	$agent_assign_operator;

	?>
	
	<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/jquery.mCustomScrollbar.css">
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.mCustomScrollbar.concat.min.js"></script>

	<link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
	<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	<?php 

	$operator_title = shortcode_atts( array(
		'operator_name' => 'No Cruise Found ..'
	), $operator_title, 'cruiseoperator' );

	$GetOperatorTitle = $operator_title['operator_name'];
	if ($GetOperatorTitle) 
	{ 
		$cruise_operator_id= "SELECT operator_id FROM cruise_operators WHERE operator_title = '".$GetOperatorTitle."'";
		$Cr_Op_Id = $mydb->get_row($cruise_operator_id);
		if (count($Cr_Op_Id)> 0)
		{
			$Ope_ID = $Cr_Op_Id->operator_id;
		}
		else{
			$s_out .= "No Cruise Found ..";
		}
		$listing_page_id = get_site_option( 'iflair_cruise_theme_ship_listing_page' );
		$s_out = '';
		$s_out .= '<a target="_blank" style="background: rgb(255, 90, 95) none repeat scroll 0% 0%; color: rgb(255, 255, 255); padding: 10px 20px;" href="'.get_page_link($listing_page_id).'?cruise_region=&cruise_operator='.$Ope_ID.'&cruise_ship=&cruise_ship_fly_in=&cruise_ship_starts_on=&cruise_ship_vacation_days=&tab_id=0&start_price=0&end_price=10000">Search All '.$GetOperatorTitle.'</a>';
		$s_out .= '<div class="replace_query_ajax_parent">';
			$s_out .= '<div id="replace_query_ajax">';
				
			$s_out .= '</div>';
		$s_out .= '</div>';
		if(!empty($Ope_ID)){
		?>
			<script type="text/javascript">

				jQuery('.loader').css('display','block');
				var pageNum = 1;
				var operator = "<?php echo $Ope_ID; ?>";
				var newopt1= "<?php echo $Ope_ID; ?>";
				//jQuery.cookie('short-operator',operator);

				jQuery.ajax({
			        type: "POST",
			        url: ("<?php echo admin_url( 'admin-ajax.php' ); ?>"),
			        data: ({
			            action: 'cruise_filter_response',
			            <?php if($_COOKIE['str1']!=""){ ?>str1: <?php echo "'".$_COOKIE['str1']."',"; } ?>
			            <?php if($_COOKIE['str2']!=""){ ?>str2: <?php echo "'".$_COOKIE['str2']."',"; } ?>
			            operator: operator,
			            newopt1:newopt1,
			            pagenumb:pageNum
			        }),
			        success: function (response) {
			            jQuery('.replace_query_ajax_parent #replace_query_ajax').html(response);
			            jQuery(".content").mCustomScrollbar();
			            jQuery("img.lazy").lazyload({skip_invisible : true});
			            var history=jQuery('#history').html();
			            jQuery("#result_story").html(history);
			        	jQuery('.loader').css('display','none');
				               
				var w = window.innerWidth;
				if(w<"1024"){
					var visible = jQuery('.searched .input-form.wrraper').is(":visible");
					
					if(visible){
						
						jQuery('.searched .input-form.wrraper').slideUp();
					}
					else{
						jQuery('.searched .input-form.wrraper').slideDown();
					}
					jQuery('.search-bt-2').click(function(){
						jQuery('.searched .input-form.wrraper').slideUp();
						
					});
				}
					}
			    });
			</script>
	<?php 
		}
	}
	else{
		$s_out .= "No Cruise Found ..";
	}
	return $s_out;
	
	//return "operator_name = {$operator_title['operator_name']}";
}
add_shortcode( 'cruiseoperator', 'operator_cruises' );

add_menu_page('Shortcode Helper', 'Shortcode Helper', 'manage_options', 'shortcode-helper' , 'shortcodehelper', plugins_url( 'iflair-premium-theme-option/images/icon.png' ));

function shortcodehelper(){
global $wpdb,$mydb
?>
<div class="wrap">
	<h2>Shortcode Helper</h2>
	<form name="operator-form" action="" method="post">
		<table class="wp-list-table widefat fixed striped pages">
			<tbody>
				<tr>
					<td class="title column-title has-row-actions column-primary page-title">
						<strong>Select Cruise Operator</strong>
					</td>
					<td>
						<select name="cr-op-name" required="">
							<option value="">Select Cruise Operator</option>
							<?php
							$get_operators = "SELECT `operator_title` FROM `cruise_operators` ORDER BY `operator_title`";
							$get_operators_name = $mydb->get_results($get_operators);
							if (count($get_operators_name) != 0) 
							{
								foreach ($get_operators_name as $operators) 
								{ ?>
									<option value="<?php echo $operators->operator_title; ?>" <?php if($_POST['cr-op-name'] == $operators->operator_title){ echo "selected"; } ?>>
										<?php echo $operators->operator_title; ?>
									</option>
								<?php }
							}
							?>
						</select>
					</td>
					<td>
						<input type="submit" name="get_op_sho" value="Get Shortcode">
					</td>
				</tr>
				<tr>
					<?php
					if (isset($_POST['get_op_sho'])) 
					{
						if ($_POST['cr-op-name'] != "") 
						{ ?>
							<td>
								<?php 
									echo 'Shortcode for operator <strong>'.$_POST['cr-op-name'].'</strong> is <br>[cruiseoperator operator_name="'.$_POST['cr-op-name'].'"]' ?>
							</td>
						<?php }
					}
					?>
				</tr>
				<?php
				if (isset($_POST['get_op_sho'])) 
				{
					if ($_POST['cr-op-name'] != "") 
					{ ?>
						<tr>
							<td>
								Add above shortcode as a plaintext in your posts or pages.
							</td>
						</tr>
					<?php }
				}
				?>
			</tbody>
		</table>
	</form>
</div>
	<!-- echo "123"; -->
<?php }
add_filter( 'auth_cookie_expiration', 'keep_me_logged_in_for_1_year' );

function keep_me_logged_in_for_1_year( $expirein ) {
    return 31556926; // 1 year in seconds
}