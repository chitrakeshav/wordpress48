<?php
/*
Plugin Name: KK Books
Plugin URI: https://wordpress.org/
Description: Use shortcode: [search_books] , Custom post type with custom meta boxes at back-end & Search functionality of created custom post type using shortcode at front-end.
Version: 1.0
Author: Keshav Kansara
Author URI: https://in.linkedin.com/in/keshav-kansara-8b083343
*/

// I was took 1 hour and 10 minutes to develop Admin part.
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/** ADMIN PART START **/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// run the install scripts upon plugin activation
register_activation_hook(__FILE__,'insert_sample_data');

// Custom post type 'Books'
add_action( 'init', 'create_books' );
function create_books() {
	register_post_type( 'books',
		array(
			'labels' => array(
				'name' => 'Books',
				'singular_name' => 'Books',
				'add_new' => 'Add New Book',
				'add_new_item' => 'Add New Book',
				'edit' => 'Edit',
				'edit_item' => 'Edit Book',
				'new_item' => 'New Book',
				'view' => 'View',
				'view_item' => 'View Books',
				'search_items' => 'Search Books',
				'not_found' => 'No Books found',
				'not_found_in_trash' => 'No Books found in Trash',
				'parent' => 'Parent Books'
				),
			'public' => true,
			'menu_position' => 15,
			'supports' => array( 'title', 'editor', 'thumbnail' ),
			'taxonomies' => array( 'post_tag'),
			'has_archive' => true
			)
		);
}

// Custom taxonomy term 'Book Author'
add_action( 'init', 'create_books_tax', 0 );
function create_books_tax() {
	$labels = array(
		'name'              => _x( 'Book Authors', 'taxonomy general name', 'textdomain' ),
		'singular_name'     => _x( 'Book Author', 'taxonomy singular name', 'textdomain' ),
		'search_items'      => __( 'Search Book Authors', 'textdomain' ),
		'all_items'         => __( 'All Book Authors', 'textdomain' ),
		'parent_item'       => __( 'Parent Book Author', 'textdomain' ),
		'parent_item_colon' => __( 'Parent Book Author:', 'textdomain' ),
		'edit_item'         => __( 'Edit Book Author', 'textdomain' ),
		'update_item'       => __( 'Update Book Author', 'textdomain' ),
		'add_new_item'      => __( 'Add New Book Author', 'textdomain' ),
		'new_item_name'     => __( 'New Book Author', 'textdomain' ),
		'menu_name'         => __( 'Book Author', 'textdomain' ),
		);
	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'book-author' ),
		);
	register_taxonomy( 'book-author', array( 'books' ), $args );
}

// Custom Meta boxes 'Price' & 'Rating'
add_action( 'add_meta_boxes', 'add_books_metaboxes' );
function add_books_metaboxes(){
	add_meta_box('book_book_price', 'Price', 'book_book_price', 'books', 'normal', 'default');
	add_meta_box('book_book_rating', 'Rating', 'book_book_rating', 'books', 'normal', 'default');
}

// The Books price Metabox
function book_book_price() {
	global $post;

    // Noncename needed to verify where the data originated
	echo '<input type="hidden" name="books_price_meta_noncename" id="books_price_meta_noncename" value="' . 
	wp_create_nonce( plugin_basename(__FILE__) ) . '" />';

    // Get the price data if its already been entered
	$price = get_post_meta($post->ID, '_book_price', true);

    // Echo out the field as Text box
	echo '<input type="text" name="_book_price" value="' . $price  . '" />';
}

// The Books rating Metabox
function book_book_rating() {
	global $post;

    // Noncename needed to verify where the data originated
	echo '<input type="hidden" name="books_rating_meta_noncename" id="books_rating_meta_noncename" value="' . 
	wp_create_nonce( plugin_basename(__FILE__) ) . '" />';

    // Get the rating data if its already been entered
	$rating = get_post_meta($post->ID, '_book_rating', true);
	?>

	<!-- Echo out the field as Drop down -->
	<label>Rating :  </label>
	<select name="_book_rating" id="_book_rating">
		<option value="1" <?php selected( $rating, '1' ); ?>>1</option>
		<option value="2" <?php selected( $rating, '2' ); ?>>2</option>
		<option value="3" <?php selected( $rating, '3' ); ?>>3</option>
		<option value="4" <?php selected( $rating, '4' ); ?>>4</option>
		<option value="5" <?php selected( $rating, '5' ); ?>>5</option>
	</select>
	<?php
}

// Save the price Metabox Data / Custom field
add_action('save_post', 'save_book_price_meta', 1, 2);
function save_book_price_meta($post_id, $post) {

    // verify this came from the our screen and with proper authorization,
    // because save_post can be triggered at other times
	if ( !wp_verify_nonce( $_POST['books_price_meta_noncename'], plugin_basename(__FILE__) )) {
		return $post->ID;
	}

    // Is the user allowed to edit the post or page?
	if ( !current_user_can( 'edit_post', $post->ID ))
		return $post->ID;

    // OK, i have authenticated: i need to find and save the data
    // i'll put it into an array to make it easier to loop though.

	$price_meta['_book_price'] = $_POST['_book_price'];

    // Add values of $price_meta as custom fields
	foreach ($price_meta as $key => $value) 
	{
        // Cycle through the $price_meta array!
        if( $post->post_type == 'revision' ) return; // Don't store custom data twice
        $value = implode(',', (array)$value); // If $value is an array, make it a CSV (unlikely)
        if(get_post_meta($post->ID, $key, FALSE)) 
        { 
            // If the custom field already has a value
        	update_post_meta($post->ID, $key, $value);
        } 
        else
        { 
            // If the custom field doesn't have a value
        	add_post_meta($post->ID, $key, $value);
        }
        if(!$value) delete_post_meta($post->ID, $key); // Delete if blank
    }
}

// Save the rating Metabox Data / Custom field
add_action('save_post', 'save_book_rating_meta', 1, 2);
function save_book_rating_meta($post_id, $post) {

    // verify this came from the our screen and with proper authorization,
    // because save_post can be triggered at other times
	if ( !wp_verify_nonce( $_POST['books_rating_meta_noncename'], plugin_basename(__FILE__) )) {
		return $post->ID;
	}

    // Is the user allowed to edit the post or page?
	if ( !current_user_can( 'edit_post', $post->ID ))
		return $post->ID;

    // OK, i have authenticated: i need to find and save the data
    // I'll put it into an array to make it easier to loop though.

	$rating_meta['_book_rating'] = $_POST['_book_rating'];

    // Add values of $price_meta as custom fields
    foreach ($rating_meta as $key => $value) { // Cycle through the $price_meta array!
        if( $post->post_type == 'revision' ) return; // Don't store custom data twice
        $value = implode(',', (array)$value); // If $value is an array, make it a CSV (unlikely)
        if(get_post_meta($post->ID, $key, FALSE))
        { 
            // If the custom field already has a value
        	update_post_meta($post->ID, $key, $value);
        }
        else
        { 
            // If the custom field doesn't have a value
        	add_post_meta($post->ID, $key, $value);
        }
        if(!$value) delete_post_meta($post->ID, $key); // Delete if blank
    }
}

// Filter custom posts by custom taxonomy
add_action('restrict_manage_posts', 'filter_post_type_by_taxonomy');
function filter_post_type_by_taxonomy() {
	global $typenow;
	$post_type = 'books'; // Post type name
	$taxonomy  = 'book-author'; // Taxonomy name
	if ($typenow == $post_type) 
	{
		$selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
		$info_taxonomy = get_taxonomy($taxonomy);
		wp_dropdown_categories(array(
			'show_option_all' => __("Show All {$info_taxonomy->label}"),
			'taxonomy'        => $taxonomy,
			'name'            => $taxonomy,
			'orderby'         => 'name',
			'selected'        => $selected,
			'show_count'      => true,
			'hide_empty'      => true,
			));
	};
}

// Generate query as per selected option from drop down
add_filter('parse_query', 'convert_id_to_term_in_query');
function convert_id_to_term_in_query($query) {
	global $pagenow;
	$post_type = 'books'; // Post type name
	$taxonomy  = 'book-author'; // Taxonomy name
	$q_vars    = &$query->query_vars;
	if ( $pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0 ) {
		$term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
		$q_vars[$taxonomy] = $term->slug;
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/** ADMIN PART END **/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// I was took 3 hour and 35 minutes to develop Front part.
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/** FRONT PART START **/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

global $wpdb;
add_action("wp_ajax_search_request_send", "search_request_send");
add_action("wp_ajax_nopriv_search_request_send", "search_request_send");

// shortcode for search books from front side. 
add_shortcode( 'search_books', 'search_books_fun' );
function search_books_fun() {

	global $wpdb;
	global $wp_query;
	
	//external stylesheet and script
	wp_enqueue_style( 'ranger-stylesheet', plugin_dir_url( __FILE__ ) . 'build/freshslider.min.css' );
	wp_enqueue_script( 'jquery-191', plugin_dir_url( __FILE__ ) . 'build/jquery-1.9.1.js', array(), '1.9.1', true );
	wp_enqueue_script( 'ranger-js', plugin_dir_url( __FILE__ ) . 'build/freshslider.min.js', array(), '1.0', true );
	wp_enqueue_script( 'custom-js', plugin_dir_url( __FILE__ ) . 'build/custom.js', array(), '1.0', true );

	?>
	<form method="post" id="book_search" name="book_search">
		<table>
			<tr>
				<th>Title</th>
				<td><input type="text" name="book_title" id="book_title"></td>
				<th>Author</th>
				<td>
					<?php
					$terms_ar = get_terms( array(
						'taxonomy' => 'book-author',
						'hide_empty' => false,
						) );
					if (!empty($terms_ar))
					{
						echo '<select name="book_author" id="book_author">';
						echo '<option value="">Select Author</option>';
						foreach ($terms_ar as $terms) 
						{
							echo '<option value="'.$terms->term_id.'">'.$terms->name.'</option>';
						}
						echo '</select>';
					}
					?>
				</tr>
				<tr>
					<th>Price</th>
					<td>
						<div id="ranged-value" style="width: 250px; margin: 20px; display: inline-block;"></div>
						<input type="hidden" name="book_price_min" id="book_price_min" value="">
						<input type="hidden" name="book_price_max" id="book_price_max" value="">
					</td>
					<th>Rating</th>
					<td>
						<select name="book_rating" id="book_rating">
							<option value="">Select Rating</option>
							<option value="1">1</option>
							<option value="2">2</option>
							<option value="3">3</option>
							<option value="4">4</option>
							<option value="5">5</option>
						</select>
					</td>
				</tr>
				<tr>
					<td class="search"><input type="submit" name="search" value="Search"></td>
					<td class="loader-img" style="display:none;">
						<img src="<?php echo plugin_dir_url( __FILE__ ); ?>/images/loder-img.gif" />
					</td>
				</tr>
			</table>
		</form>
		<div class="response"></div>
		<?php
	}

	function search_request_send(){

		global $wpdb;
		global $wp_query;

		$book_title = $_POST['book_title'];
		$book_author = $_POST['book_author'];
		$book_price_min = $_POST['book_price_min'];
		$book_price_max = $_POST['book_price_max'];
		$book_rating = $_POST['book_rating'];

		$meta_key_bk_price	= '_book_price';
		$meta_key_bk_rating	= '_book_rating';

    	//Get posts of custom taxonomy 'books-author'
		if ($book_author != "") 
		{
			$cat_id = array(
				array(
					'taxonomy' => 'book-author',
					'field' => 'id',
					'terms' => $book_author,
					)
				);
		}

    	//Get posts of custom meta box '_book_price'
		if ($book_price_min != "" || $book_price_max != "")
		{
			$bk_price = array(
				'key' => $meta_key_bk_price,
				'value' => array( $book_price_min, $book_price_max ),
				'type' => 'numeric',
				'compare' => 'BETWEEN'
				);
		}

    	//Get posts of custom meta box '_book_rating'
		$bk_rating = array('');
		if ($book_rating != "") 
		{
			$bk_rating = array(
				'key' => $meta_key_bk_rating,
				'value' => $book_rating,
				'compare' => '=',
				);
		}

		// Query to retrive data as per filteration
		$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
		$the_query = new WP_Query (array( 
			'posts_per_page' => -1,
			's' => $book_title,
			'post_type' => 'books',
			'post_status' => 'publish',
			'meta_query' =>  array($bk_price,$bk_rating),
			'orderby' => 'id',
			'order' => 'desc',
			'tax_query' => $cat_id,
			'paged' => $paged,
			));

    	// The Loop - Fetch result of above search
		if ( $the_query->have_posts() ) {
			?>
			<table>
				<thead>
					<tr>
						<th>Book Name</th>
						<th>Author</th>
						<th>Price</th>
						<th>Rating</th>
					</tr>
				</thead>
				<tbody>
					<?php
					while ( $the_query->have_posts() ) {
						$the_query->the_post();
						$getBookCat = get_the_terms(get_the_ID(), 'book-author');
						$getBookPrice = get_post_meta(get_the_ID(), $meta_key_bk_price);
						$getBookRating = get_post_meta(get_the_ID(), $meta_key_bk_rating);

						?>
						<tr>
							<td>
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</td>
							<td><?php echo $getBookCat[0]->name; ?></td>
							<td><?php echo $getBookPrice[0]; ?></td>
							<td><?php echo $getBookRating[0]; ?></td>
						</tr>
						<?php
					}
					echo '</tbody></table>';
				} else {
					echo "Not any book found related to your search.";
				}
				if ($the_query->max_num_pages > 1) { // check if the max number of pages is greater than 1  ?>
				<nav class="prev-next-posts">
					<div class="prev-posts-link">
						<?php echo get_next_posts_link( 'Next', $the_query->max_num_pages ); // display older posts link ?>
					</div>
					<div class="next-posts-link">
						<?php echo get_previous_posts_link( 'Previous' ); // display newer posts link ?>
					</div>
				</nav>
				<?php }

				//Restore original Post Data
				wp_reset_postdata();
				exit;
			}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			/** FRONT PART END **/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// I was took 00.35 minutes for Data insertion part during plugin activation.
// function to Insert sample data during plugin activation.
			add_action( 'init', 'insert_sample_data' );
			function insert_sample_data() {
				global $wpdb;

				$taxo = 'book-author';
				$terms = array (
					'0' => array (
						'name'          => 'Chetan Bhagat',
						'slug'          => 'chetan-bhagat',
						'description'   => '',
						),
					'1' => array (
						'name'          => 'Deep Trivedi',
						'slug'          => 'deep-trivedi',
						'description'   => '',
						),
					'2' => array (
						'name'          => 'Ryuta Kawashima',
						'slug'          => 'ryuta-kawashima',
						'description'   => '',
						),
					);  

				foreach ( $terms as $nvterm) {
					wp_insert_term(
						$nvterm['name'],
						$taxo, 
						array(
							'description'   => $nvterm['description'],
							'slug'          => $nvterm['slug'],
							)
						);
					unset( $nvterm ); 
				}
				if ( ! function_exists( 'post_exists' ) ) {
					require_once( ABSPATH . 'wp-admin/includes/post.php' );
				}

				$user_id = get_current_user_id();
	// Add custom post data, meta data and taxonomy
				if(!post_exists('Train Your Brain')){
					$post1 = array(
						'post_title' => 'Train Your Brain',
						'post_content' => 'Did you know that simple arithmetical calculations like "5+8" make us use the brain a lot more than a complex problem like "5-(0.4/2)+3x6" does?',
						'post_status' => 'publish',
						'post_author' => $user_id,
						'post_type' => 'books'
						);
					$post_id1 = wp_insert_post( $post1 );
					wp_set_object_terms( $post_id1, array( 2 ), 'book-author');
					if ( ! add_post_meta( $post_id1, '_book_price', '120', true ) ) {
						update_post_meta( $post_id1, '_book_price', '120' );
					}
					if ( ! add_post_meta( $post_id1, '_book_rating', '3', true ) ) { 
						update_post_meta( $post_id1, '_book_rating', '3' );
					}
				}

				if(!post_exists('I am The Mind')){
					$post1 = array(
						'post_title' => 'I am The Mind',
						'post_content' => 'Do you really know who I am? Do you know that the brain &amp; I are two separate entities? Do you know that 24/7 your life is governed by me, me &amp; me alone? Do you know that once you master me, you will be able to exactly know what is going on in anothers mind why they are doing what they are? If you had known this, then why would you &amp; everyone else have had to toil round the clock to achieve joy &amp; success? Although human intelligence has evolved with every passing epoch, still the struggle to survive &amp; achieve success continues to be the same. According to the author of "I am the Mind", Mr. Deep Trivedi,',
						'post_status' => 'publish',
						'post_author' => $user_id,
						'post_type' => 'books'
						);
					$post_id1 = wp_insert_post( $post1 );
					wp_set_object_terms( $post_id1, array( 3 ), 'book-author');
					if ( ! add_post_meta( $post_id1, '_book_price', '330', true ) ) {
						update_post_meta( $post_id1, '_book_price', '330' );
					}
					if ( ! add_post_meta( $post_id1, '_book_rating', '4', true ) ) { 
						update_post_meta( $post_id1, '_book_rating', '4' );
					}
				}

				if(!post_exists('The 3 Mistakes of My Life')){
					$post1 = array(
						'post_title' => 'The 3 Mistakes of My Life',
						'post_content' => 'The 3 Mistakes of My Life is the third novel written by Chetan Bhagat. The book was published in May 2008 and had an initial print-run of 420,000. The novel follows the story of three friends and is based in the city of Ahmedabad in western India.',
						'post_status' => 'publish',
						'post_author' => $user_id,
						'post_type' => 'books'
						);
					$post_id1 = wp_insert_post( $post1 );
					wp_set_object_terms( $post_id1, array( 4 ), 'book-author');
					if ( ! add_post_meta( $post_id1, '_book_price', '440', true ) ) {
						update_post_meta( $post_id1, '_book_price', '440' );
					}
					if ( ! add_post_meta( $post_id1, '_book_rating', '5', true ) ) { 
						update_post_meta( $post_id1, '_book_rating', '5' );
					}
				}

				if(!post_exists('Five Point Someone')){
					$post1 = array(
						'post_title' => 'Five Point Someone',
						'post_content' => "The book is narrated by Hari, with some small passages by his friends Ryan and Alok, as well as a letter by Hari's girlfriend Neha Cherian. It deals with the lives of the 3 friends, whose elation on making it to one of the best engineering colleges in India is quickly deflated by the rigor and monotony of the academic work. Most of the book deals with the numerous attempts by the trio to cope with and/or beat the system as well as Hari's fling with Neha who just happens to be the daughter of Prof. Cherian, the domineering head of the Mechanical Engineering Department of their college.",
						'post_status' => 'publish',
						'post_author' => $user_id,
						'post_type' => 'books'
						);
					$post_id1 = wp_insert_post( $post1 );
					wp_set_object_terms( $post_id1, array( 2 ), 'book-author');
					if ( ! add_post_meta( $post_id1, '_book_price', '385', true ) ) {
						update_post_meta( $post_id1, '_book_price', '385' );
					}
					if ( ! add_post_meta( $post_id1, '_book_rating', '2', true ) ) { 
						update_post_meta( $post_id1, '_book_rating', '2' );
					}
				}

				if(!post_exists('2 States')){
					$post1 = array(
						'post_title' => '2 States',
						'post_content' => "2 States: The Story of My Marriage is partly autobiographical. The story is about a couple, Krish and Ananya, who hail from two different states of India, Punjab and Tamil Nadu respectively, are deeply in love and want to get married.",
						'post_status' => 'publish',
						'post_author' => $user_id,
						'post_type' => 'books',
						'post_category' => array(termid),
						'taxonomy'      => 'vac'  ,
						);
					$post_id1 = wp_insert_post( $post1 );
					wp_set_object_terms( $post_id1, array( 2 ), 'book-author');
					if ( ! add_post_meta( $post_id1, '_book_price', '195', true ) ) {
						update_post_meta( $post_id1, '_book_price', '195' );
					}
					if ( ! add_post_meta( $post_id1, '_book_rating', '5', true ) ) { 
						update_post_meta( $post_id1, '_book_rating', '5' );
					}
				}
			}
			?>