<?php
/*
  Plugin Name: Ck Contact
  Description: This plugin is a custom contact form.
  Author: Ck
*/

  function create_contact_table(){

  	global $wpdb;
  	$table_name = $wpdb->prefix . "ck_contact";
  	$inq_add = "CREATE TABLE IF NOT EXISTS " . $table_name . " (
  		`id` int(11) NOT NULL AUTO_INCREMENT,
  		`ck_name` varchar(512) NOT NULL,
  		`ck_email` varchar(512) NOT NULL,
  		`ck_telephone` varchar(250) NOT NULL,
  		`ck_subject` varchar(512) NOT NULL,
  		`ck_message` varchar(512) NOT NULL,
  		`created_date` datetime NOT NULL,
  		PRIMARY KEY (`id`)
  	) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";

  	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

  	dbDelta($inq_add);

  }
  register_activation_hook( __FILE__, "create_contact_table" );

  if ( function_exists('register_uninstall_hook') )
  	register_uninstall_hook(__FILE__, 'delete_contact_table');

  function delete_contact_table() {
  	global $wpdb;
  	$table_name1 = $wpdb->prefix . "ck_contact";
  	$results = $wpdb->query("DROP TABLE {$table_name1}");
  }

  add_action("wp_ajax_inquiry_request_send_fun", "inquiry_request_send_fun");
  add_action("wp_ajax_nopriv_inquiry_request_send_fun", "inquiry_request_send_fun");

  add_shortcode('ck_contact','ck_contact_fun');
  function ck_contact_fun(){
  	global $wpdb;

  	wp_enqueue_script( 'custom-js', plugin_dir_url( __FILE__ ) . 'js/custom.js', array(), '1.0', true );
  	?>
  	<form method="post" name="smp_con" id="smp_con">
  		<table>
  			<tr>
  				<td>
  					<input type="text" name="ck_name" id="ck_name" placeholder="Name">
  				</td>
  			</tr>
  			<tr>
  				<td>
  					<input type="text" name="ck_email" id="ck_email" placeholder="Email">
  				</td>
  			</tr>
  			<tr>
  				<td>
  					<input type="text" name="ck_telephone" id="ck_telephone" placeholder="Telephone">
  				</td>
  			</tr>
  			<tr>
  				<td>
  					<input type="text" name="ck_subject" id="ck_subject" placeholder="Subject">
  				</td>
  			</tr>
  			<tr>
  				<td>
  					<textarea name="message" id="ck_message" placeholder="Message"></textarea>
  				</td>
  			</tr>
  			<tr>
  				<td>
  					<input type="submit" name="submit" value="submit">
  				</td>
  				<td class="loader-img" style="display:none;">
  					<img src="<?php echo plugin_dir_url( __FILE__ ); ?>/images/loder-img.gif" />
  				</td>
  			</tr>
  		</table>
  	</form>
  	<div class="response"></div>
  	<?php
  }

  function inquiry_request_send_fun(){
  	global $wpdb;
  	
  	$ck_name = $_POST["ck_name"];
  	$ck_email = $_POST["ck_email"];
  	$ck_telephone = $_POST["ck_telephone"];
  	$ck_subject = $_POST["ck_subject"];
  	$ck_message = $_POST["ck_message"];
  	$cur_date = date('Y-m-d H:i:s');
  	$ck_contact_table = $wpdb->prefix."ck_contact";

  	$INFO = $wpdb->insert($ck_contact_table, array(
  		'ck_name'=>$ck_name,
  		'ck_email'=>$ck_email,
  		'ck_telephone'=>$ck_telephone,
  		'ck_subject'=>$ck_subject,
  		'ck_message'=>$ck_message,
  		'created_date'=>$cur_date,
  	));

  	if($INFO){

  		$to = "keshav.kansara@iflair.com";

  		$headers = "MIME-Version: 1.0\r\n";
  		$headers .= "Content-type:text/html; charset=utf-8\n";
  		$headers .= "From: KK<testing.testuser@gmail.com>\n";
  		$headers .= "X-Priority: 3\n";
  		$headers .= "X-MSMail-Priority: Normal\n";
  		$headers .= "Importance: 3\n";

  		$msg =  '<table>';
  		$msg .= '<tr><td>Name</td><td>'.$ck_name.'</td></tr>';
  		$msg .= '<tr><td>Email</td><td>'.$ck_email.'</td></tr>';
  		$msg .= '<tr><td>Telephone</td><td>'.$ck_telephone.'</td></tr>';
  		$msg .= '<tr><td>Subject</td><td>'.$ck_subject.'</td></tr>';
  		$msg .= '<tr><td>Message</td><td>'.$ck_message.'</td></tr>';
  		$msg .= '</table>';

  		wp_mail($to,$subject,$msg,$headers);
  		$_SESSION['success'] = "Inquiry has been sent successfully...";
  		wp_redirect(get_the_permalink());
  		exit;
  	}
  	else
  	{
  		echo $wpdb->last_query;
  	}
  }

  function list_inquirries()
  {
  	global $wpdb;
  	if($_GET['delete'])
  	{
  		$Pid = $_GET['delete'];
  		$result_pid = $wpdb->get_row( 'SELECT * FROM '.$wpdb->prefix.'ck_contact WHERE id = "'.$Pid.'" ', OBJECT );
  		$delete_msg = "Item has been deleted successfully";
  	}

  	$plugins_url = plugin_dir_url( __FILE__ );
  	$edit_icon = $plugins_url.'/icon/edit-validated-icon.png';
  	$delete_icon = $plugins_url.'/icon/delete-icon.png';

  	?>

  	<script src="<?php echo $plugins_url; ?>/js/jquery.dataTables.min.js"></script>
  	<script src="<?php echo $plugins_url; ?>/js/dataTables.bootstrap.min.js"></script>
  	<link rel="stylesheet" type="text/css" href="<?php echo $plugins_url; ?>/css/bootstrap.min.css" />
  	<link rel="stylesheet" type="text/css" href="<?php echo $plugins_url; ?>/css/dataTables.bootstrap.min.css" />
  	<link rel="stylesheet" type="text/css" href="<?php echo $plugins_url; ?>/css/styles.css" />

  	<script type="text/javascript">
  		jQuery(document).ready(function() {
  			jQuery('#ck_listing_qu').DataTable( {
  				"aoColumnDefs": [
  				{ 'bSortable': false, 'aTargets': [ 1 ,2] }
  				]
  			});
  		} );
  	</script>

  	<div class="wrap">
  		<h1>Inquiry Listing</h1>
  		<br>
  		<?php if($delete_msg != ''){ ?>
  		<div class='updated below-h2' id='message'><p><?php echo $delete_msg; ?></p></div>
  		<?php } ?>
  		<table id="ck_listing_qu" class="table table-striped table-bordered" cellspacing="0" style="width: 100%;">
  			<thead>
  				<tr>
  					<th>Name</th> 
  					<th>Email</th>
  					<th>Telephone</th>
  					<th>Subject</th>
  					<th>Action</th>
  				</tr>
  			</thead>       
  			<tbody>
  				<?php 
  				$get_listing = $wpdb->get_results( 'SELECT * FROM '.$wpdb->prefix.'ck_contact ORDER BY id DESC', OBJECT );
  				foreach($get_listing as $ke => $val){

  					?>
  					<tr>
  						<td><?php echo $val->ck_name; ?></td>
  						<td><?php echo $val->ck_email; ?></td>
  						<td><?php echo $val->ck_telephone; ?></td>
  						<td><?php echo $val->ck_subject; ?></td>
  						<td>
  							<a href= "admin.php?page=view-inquiry&p_id=<?php echo $val->id; ?>" name="View" id="p_id">
  								<img src="<?php echo $edit_icon;?>" title="View">
  							</a>
  							<a href= "admin.php?page=inquiry-list&delete=<?php echo $val->id; ?>&amp;act=delete" name="Delete" id="p_id" onclick="return confirm('Are you sure you want to delete?')" title="Delete">
  								<img src="<?php echo $delete_icon;?>">
  							</a>
  						</td>
  					</tr>
  					<?php } ?>
  				</tbody>
  			</table>
  		</div>

  		<?php
  		if (isset($_REQUEST["act"])){
  			
  		}
  	}

  	function admin_menu_fun()
  	{
  		add_menu_page('All Inquiries', 'Inquiries', 'manage_options', 'inquiry-list' , 'list_inquirries');
  		add_submenu_page( 'list_inquirries', 'Inquiries', 'Inquiries', 'manage_options', 'inquiry-list', 'list_inquirries');
  		add_submenu_page( '', 'View', 'View', 'manage_options', 'view-inquiry', 'view_inquiry');
  	}
  	add_action('admin_menu', 'admin_menu_fun' );

  	function view_inquiry(){
  		global $wpdb;
  		$plugins_url = plugin_dir_url( __FILE__ );

  		?>
  		<link rel="stylesheet" type="text/css" href="<?php echo $plugins_url; ?>/css/styles.css" />
  		<?php
  		if($_GET['p_id'])
  		{
  			$get_single_item = $wpdb->get_row( 'SELECT * FROM '.$wpdb->prefix.'ck_contact WHERE id = "'.$_GET['p_id'].'"', OBJECT );
  			?>
  			<div class="wrap">
  				<h1>View message of <?php echo $get_single_item->ck_name; ?></h1>
  				<br>
  				<a href="admin.php?page=inquiry-list">BACK</a>
  				<br>
  				<table id="ck_listing_qu" class="table table-striped table-bordered" cellspacing="0" style="width: 100%;">
  					<thead>
  						<tr>
  							<th>Message</th> 
  						</tr>
  					</thead>
  					<tbody>
  						<tr>
  							<td><?php echo $get_single_item->ck_message;  ?></td>
  						</tr>
  					</tbody>
  				</div>
  				<?php
  			}

  		}

  		function delete_removed_entry()
  		{
  			global $wpdb;
  			if($_POST['id'] != "")
  			{
  				$wpdb->delete( $wpdb->prefix.'ck_contact', array( 'id' => $_POST['id'] ) );    
  			}
  		}