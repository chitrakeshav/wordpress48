jQuery(document).ready(function () {
	//Get site base url and one more directory after '/' slash
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	
	//Search form submit
	jQuery("#smp_con").submit(function(e) {
		var ck_name = jQuery("#ck_name").val();
		var ck_email = jQuery("#ck_email").val();
		var ck_telephone = jQuery("#ck_telephone").val();
		var ck_subject = jQuery("#ck_subject").val();
		var ck_message = jQuery("#ck_message").val();

		jQuery('.loader-img').show();
		jQuery.ajax({
			type: "POST",
			url: (baseUrl+"/wp-admin/admin-ajax.php"),
			data: ({
				action: 'inquiry_request_send_fun',
				ck_name: ck_name,
				ck_email: ck_email,
				ck_telephone: ck_telephone,
				ck_subject: ck_subject,
				ck_message: ck_message
			}),
			success: function (response) {
				jQuery('.loader-img').hide();
				jQuery('.response').html(response);
			}
		});
		e.preventDefault();
	});
});